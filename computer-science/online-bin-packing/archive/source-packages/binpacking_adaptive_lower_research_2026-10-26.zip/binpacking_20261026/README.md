# Deterministic online bin packing: restricted-branch research certificate

Results: no new universal lower bound. Three new adaptive suffix tests were defeated by explicit causal policies on the audited nine-state `t=3` history at `r=3857/2500`.

* `RESEARCH_NOTE.md`: full mathematical derivations, exact quantifiers, constructive offline packings, and gaps.
* `verify_original_tree.py`: preserved checker of the inherited causal prefix and its original eight stopping points.
* `verify_two_architectures.py`: exact count/size/continuous-cone checks for the E-overdose+F and B~2/7+J architectures.
* `verify_high_C_scarcity.py`: standalone exact two-dual certificate for C_h=4/7+2epsilon, including strict finite-size errors.

Run with Python 3, standard library only:

```
python verify_original_tree.py
python verify_two_architectures.py
python verify_high_C_scarcity.py
```

Primary source: Balogh et al., *A new lower bound for classic online bin packing*, https://arxiv.org/html/1807.05554 ; source Theorem 1 for adaptive binary separators and source Sections 2–4 for the inherited adversarial stages.

No solver statuses, floating-point searches, empirical tests, or computational assumptions are used as mathematical proofs.
