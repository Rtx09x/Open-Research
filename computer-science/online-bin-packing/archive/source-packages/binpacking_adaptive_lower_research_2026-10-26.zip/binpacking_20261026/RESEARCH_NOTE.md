# Adaptive lower-bound branches for classic online bin packing: three exact restricted-family obstructions

**Research date:** 26 October 2026. **Status:** exact rational counterstrategies on the audited causal nine-state `t=3` prefix; **no improved universal lower bound**. All online placements are irrevocable, and all input sizes are rational. The adversary's binary separator is used only through Balogh–Békési–Dósa–Epstein–Levin, Theorem 1, https://arxiv.org/html/1807.05554 .

## 0. Scope and source inheritance

The source's `C_3, C_2, A` batches each contain `N` items:

\[
C_3=\frac1{294}-294\epsilon,\quad C_2=\frac{1+28\epsilon}{49},\quad
\frac{1+\epsilon}{7}<A_i<\frac{1+2\epsilon}{7}.
\]

We reuse the **causally realized** nine-state history given in the user's dossier. Its normalized bin mass is
\[
r=3857/2500,\quad z=r/6=3857/15000,\quad
x=r/7=551/2500,\quad t=(2-r)/6=381/5000.
\]
The only old bins capable of receiving either a small above-half item or one of the new `C_h=4/7+2epsilon` items are the `(0,0,2)` and `(0,6,1)` states, whose masses add to `t`. (Other old states fail the size check.) The inherited eight stops and genuine shared-stage continuations are checked in `verify_original_tree.py`. That file originates in the earlier independently audited restricted-family obstruction; its claims are **not** generalized to arbitrary prefix histories here.

Throughout, a batch count `b` means `bN` items. The adversary may stop at every finite prefix in the indicated batch, not merely at its full rational length. The statements are to within an additive `O(1)` for incomplete bounded-size periodic groups and prefix rounding. In the strict finite-size reduction choose `epsilon_N=1/(10^12 N^2)`, which is within the source restriction. The aggregate *initial* item volume is at least
\[
V_{\rm prefix}\ge(1/6-2053\epsilon_N/7)N.
\]
The main proofs below use exact base sizes, then subtract explicit perturbation losses; the verifiers check the strict finite-size inequalities. The distinction is essential: equality of base sizes is not permission to put an oversized item in a full bin.

## 1. Structural conservation lemma (new reduction for this investigation)

Fix a causal suffix policy which adds, after the above prefix, stages `i` of `n_i N` items of base size `s_i<1/2`. Suppose the policy opens at most `u_i n_i N+O(1)` new bins during that stage and creates `v_i n_i N+O(1)` additional bins that are still able to receive a specified following item `C=1/2+epsilon`. It does **not** use any of the original `tN` C-ready slots during these stages. Let `cN` C-items arrive and let this policy fill its ready slots before opening new C bins.

Its cost obeys
\[
A_C/N\le \max\{z+\sum_i u_i n_i,\quad z-t+\sum_i(u_i-v_i)n_i+c\}+O(1/N).
\]
The **actual offline optimum** is at least both the count `cN` and the total item volume
\[
N\bigl(1/6+\sum_i s_i n_i+c/2-o(1)\bigr).
\]
Put
\[
M_V=\sum_i(rs_i-u_i)n_i,\qquad
M_H=\sum_i\bigl(2(r-1)s_i-u_i+v_i\bigr)n_i.
\]
If both are nonnegative throughout the permitted cone of batch counts, then
\[
A_C\le r\,\mathrm{OPT}_C+O(1)
\]
for **every C length**. All earlier suffix stop inequalities follow if every stage contribution to `M_V` is nonnegative.

**Proof.** The first online affine cost is dominated by `r` times the volume bound iff `M_V>=0`. For the second online affine cost, subtract it from `r max(c, 1/6+sum_i s_i n_i+c/2)`. Before `c_*=1/3+2sum_i s_i n_i` its derivative is `r/2-1<0`; after it, its derivative is `r-1>0`. Hence its minimum is at `c_*` and is exactly `M_H`, since `z=r/6` and `t=(2-r)/6`. The inequalities persist with an input-independent additive term under the perturbation margins certified below. QED.

This is a **sufficient defense criterion against a chosen lower-bound branch**, not a competitive-ratio upper bound for the defender on arbitrary bin-packing inputs.

## 2. Attack I: second E separator, F completion, and an E *overdose* beyond the old count cap

### Causal adversarial specification

After the inherited `A` prefix, send `B_i=3/14-H+\delta_i`, with `H=epsilon` and `0<delta_i<epsilon^2`. Label B **LARGE** exactly when its destination already contains two or more B-items. Apply Theorem 1 with this binary condition, so all unmarked B offsets are at most `gamma_B` and all marked offsets are above `4gamma_B`, where `gamma_B<epsilon^2/4`.

The new E stage has
\[
E_i=e_0+\eta_i,\quad e_0=5/14+3H-4\gamma_B,
\quad 0<\eta_i<\gamma_B/4.
\]
Label an E **LARGE** iff it enters a bin already containing an E. Apply a **new**, independent separator; the first E in each destination is small (offset `<=gamma_E`), later Es are large (offset `>4gamma_E`), with `gamma_E<gamma_B/4`. The E batch can stop at every prefix, up to
\[
0\le e\le (b-h_B)/2,
\]
where `h_B` is the normalized number of marked B items. **This is a genuinely different count constraint:** the previously audited `E+3B_small` scheme allowed only `(b-h_B)/3`.

Branch after the common E history to either `C=1/2+H`, or `F=1-2e_0-2gamma_E` followed optionally by that same near-half C. The F stage can stop at any prefix `0<=q<=e`. The natural F amount capable of offline pairing with two small E is `q<=s_E/2`, where `s_E` is the observed count of small E.

The strict geometric facts, all valid for every separator realization in the stated ranges, are
\[
E+3B_S\le1,\quad E+2B_S+B_L>1,
\]
\[
F+2E_S\le1,\quad F+E_L+E_S>1,
\]
\[
E+2B_S+A+3C_3+3C_2<1.
\]
No condition requires `gamma_E` to be comparable to the earlier A separator's gamma. The choice of the E scale occurs **after** the B stage fixes `gamma_B`. The last offline pattern has base load exactly 1 but is strictly feasible because three copies of each original tiny item introduce ample negative epsilon slack.

An important failure of an apparently attractive alternative is also exact:
\[
E+B_S+3A>1.
\]
The source A offsets are positive, E's forced offset dominates B's negative shift, and this tempting base-equality pattern is **not** a valid offline packing.

### Constructive offline packings (one N-unit of each old item)

At the B stop, if `0<=b<=4`, use

* `b/4` bins `[4B,A]`;
* `(1-b/4)/6` bins `[6A,6C_3,6C_2]`;
* `b/168` bins `[42C_3,42C_2]`.

All item counts balance, and their total is exactly
\[
\mathrm{OPT}_B/N\le 1/6+3b/14+O(1/N).
\]
For an E prefix with `2e<=b-h_B`, form `e` bins `[E,2B_S,A,3C_3,3C_2]` and `(b-2e)/4` bins `[4B,A]`. Define
\[
A_{\rm rem}=1-b/4-e/2,\qquad T_{\rm rem}=1-3e.
\]
If these values are nonnegative, pack `min(A_rem,T_rem)/6` bins `[6A,6C_3,6C_2]`, `(A_rem-T_rem)_+/6` bins `[6A]`, and `(T_rem-A_rem)_+/42` bins `[42C_3,42C_2]`. This produces the explicit bound
\[
\boxed{\mathrm{OPT}_E/N\le e+(b-2e)/4+A_{\rm rem}/6+(T_{\rm rem}-A_{\rm rem})_+/42+O(1/N).}
\]
Here all E items and both old tiny item types are accounted for. This bound is available, in particular, at the natural `b=13643/15000`, `e=5b/16`, where `A_rem,T_rem` are both positive.

After E, a separate offline packing can put `q` F items with `2q` small E items (for `q<=s_E/2`), and put the remaining E into pairs. Together with the preceding B-stage offline packing, its bound is `1/6+3b/14+e/2` for these F prefixes. Outside that range, place additional F in fresh triples. For every prefix and further C, the universally valid, possibly loose bound from separate groups is `1/6+b/4+e/2+q/3+c`.

### Causal counterpolicy and exact cone certificate

The defender packs **every 16 B** as three new quartets and two new pairs (no old B slots), so
\[
h_B=3b/8+O(1/N),\qquad b-h_B=5b/8+O(1/N).
\]
It packs all E in fresh pairs, all F in fresh triples, and any near-half C first into the original `tN` old slots and the `bN/8` B-pair slots. It opens new C bins only after those are exhausted. This is one causal policy for all E, F, and C stopping decisions; it uses no future batch length.

Thus `e<=5b/16+O(1/N)`, and the per-item coefficients in the conservation lemma are

| stage | `s_i` | new bins `u_i` | preserved half slots `v_i` |
|---|---:|---:|---:|
| B | `3/14` | `5/16` | `1/8` |
| E | `5/14` | `1/2` | `0` |
| F | `2/7` | `1/3` | `0` |

The *exact* coefficient vectors of `M_V` and `M_H` are
\[
M_V=\frac{181}{10000}b+\frac{51}{1000}e+\frac{403}{3750}q,
\]
\[
M_H=\frac{3159}{70000}b-\frac{393}{3500}e-\frac{304}{13125}q.
\]
For the entire continuum `0<=q<=e<=5b/16`, not a grid,
\[
\boxed{M_H\ge\frac{2353}{840000}b\ge0.}
\]
Hence **this enlarged E count cap, the second independent E separator, the F completion, and any later near-half C batch all fail against this causal policy**, including every E/F/C-prefix stop. The source's original eight alternative stops remain covered by their original causal continuations.

The bound is robust when the adaptive item offsets vary: `B>=3/14-epsilon`, `E>=5/14`, `F>=2/7-6epsilon`, `C>=1/2`, and the initial aggregate volume deficiency is at most `(2053/7)epsilon N`. With `epsilon_N` as above, the coefficient loss is smaller than the displayed exact margins, and the remaining prefix loss is `O(1)`.

## 3. Attack II: change the leading cardinality to B near 2/7

This is **not** another numerical fraction in the old `B~3/14` quartet/pair geometry.

Send `B_i=2/7-H+delta_i`, with `0<delta_i<epsilon^2`. Label B **LARGE** iff it is placed into a bin already containing at least two B items. Separate marked/unmarked offsets as before. At a shared B prefix, offer either the near-half continuation `C=1/2+H`, or a stage
\[
J=3/7+2H-2\gamma_B
\]
with arbitrarily stoppable length `0<=q<= (b-h_B)/2`, optionally followed by C. The exact intended separation is
\[
J+2B_S\le1,\qquad J+B_L+B_S>1.
\]
The original `C_3,C_2,A` history and the old source branches are unchanged. Choosing the J branch occurs only after the B history is observed.

**Offline feasibility.** At the B stop, for `0<=b<=3` use `b/3` bins `[3B,A]`, `(1-b/3)/6` bins `[6A,6C_3,6C_2]`, and `b/126` bins `[42C_3,42C_2]`. The counts balance and
\[
\mathrm{OPT}_B/N\le 1/6+2b/7.
\]
At the J stop, use `q` bins `[J,2B_S]`, `(b-2q)/3` bins `[3B]`, and `1/6` bins `[6A,6C_3,6C_2]`. Thus
\[
\mathrm{OPT}_J/N\le1/6+b/3+q/3.
\]
Subsequent C can always be placed one per extra offline bin, furnishing the constructive (though loose) bound `1/6+b/3+q/3+c`.

**Causal counterpolicy.** Pack every **seven B** as two fresh triples and one fresh singleton. Only the third B of each triple becomes LARGE. Consequently
\[
h_B=2b/7+O(1/N),\quad b-h_B=5b/7+O(1/N),\quad q\le5b/14+O(1/N).
\]
Pack J in fresh pairs; pack C first into the original `tN` ready bins and the `bN/7` B-singleton bins. The stage coefficients are

| stage | `s_i` | `u_i` | `v_i` |
|---|---:|---:|---:|
| B | `2/7` | `3/7` | `1/7` |
| J | `3/7` | `1/2` | `0` |

The **exact** margins are
\[
M_V=\frac{107}{8750}b+\frac{403}{2500}q,
\]
\[
M_H=\frac{107}{4375}b-\frac{152}{4375}q
\ge\boxed{\frac{369}{30625}b}\ge0.
\]
Therefore every B and J stop, and every length of the optional near-half C continuation, survives at ratio `r+o(1)` on this causal face. Changing the leading cardinality from four B per bin to three did not overcome the old half-slot conservation law.

## 4. Attack III: choose a larger C that *destroys* the preserved B-pair slots

The previous lemma assumes the B-pair slots really accept C. The obvious way to break it is to choose
\[
\boxed{C_h=4/7+2H>1/2,}
\]
so even two **small** B items satisfy `C_h+2B_S>1`. On the architecture-I 16-B policy, *none* of its B pairs can accept `C_h`; only the old `tN` prefix bins can. Its online cost after `bN` B, `eN` fresh-paired E, and `cN` of these high C is
\[
A_h/N\le\max\{z+5b/16+e/2,\quad z-t+5b/16+e/2+c\}+O(1/N).
\]
A naive comparison with volume and C-count becomes negative at natural-looking counts. That apparent opportunity is killed by a **different offline bottleneck**, based on the inventory of tiny items.

### New tiny-scarcity / occupancy dual

Consider any OFFLINE packing, with `mN` total bins. Let `wN` be the number of high-C bins also containing a B or E. The following facts use the *strict size inequalities*, not equality-of-base-size relaxations:

1. Each `C_h` bin contains at most one item from the combined B/E population. It cannot contain `2B`, `B+E`, or `2E` in addition to `C_h`.
2. Each bin without `C_h` contains at most **four** B/E items, because every such item has size above `3/14-H`, and `5(3/14-H)>1`.
3. A C-bin containing B can contain at most one A; a C-bin containing E cannot contain A at all. Its non-tiny load is at most `13/14+6H`. It therefore leaves at least `1/14-6H` capacity for tiny items. The TOTAL available old tiny-item volume is less than `N/42`.

Write
\[
V=1/6+3b/14+5e/14+4c/7.
\]
The two exact base-level lower bounds (omitting the small explicitly bounded `H` errors) are
\[
m\ge c+(b+e-w)/4,
\]
\[
m\ge V+w/14-1/42.
\]
Taking `2/9` times the first and `7/9` times the second **eliminates w**:
\[
\boxed{m\ge L:=1/9+2b/9+e/3+2c/3.}
\]
More precisely, with the chosen finite `H=epsilon_N`, it proves
\[
m\ge L-\frac79H\left(\frac{2053}{7}+7b+6e\right).
\]
Also `m>=V-H(2053/7+b)`. Both hold for **every** offline packing, not just the convenient packing patterns exhibited by the adversary.

The second exact convex mixture is the critical certificate: use `V/9+8L/9` as a lower bound on the optimum. Direct rational expansion yields
\[
\begin{aligned}
&\frac r9 V+\frac{8r}{9}L
 -\left(\frac{r-1}{3}+\frac{5b}{16}+\frac e2+c\right)\\
&=\boxed{\frac1{81000}+\frac{23477}{810000}b+
\frac{2477}{135000}e+\frac{206}{16875}c}>0.
\end{aligned}
\]
The exact finite-size penalties in the preceding lower bounds are smaller than **each** corresponding positive coefficient and the constant, as checked in `verify_high_C_scarcity.py`. The first online affine expression is separately dominated by the volume bound since `3r/14-5/16=181/10000>0` and `5r/14-1/2=51/1000>0`.

**Conclusion:** even after the near-half B-pair reservoir is deliberately destroyed, this exact 16-B/paired-E causal policy satisfies
\[
A_h\le r\,\mathrm{OPT}_h+O(1)
\]
**for all nonnegative B, E and high-C lengths b,e,c, without any E count cap at all**, on the fixed inherited prefix. The loss of B-ready slots is paid for by a provable shortage of tiny items needed to make the offline C bins dense.

Constructive offline patterns such as `[C_h,E,3C_3,3C_2]` and `[C_h,B,A,3C_3,3C_2]` are strictly feasible because of the negative C3 perturbation. They do not contradict the scarcity bound, since both consume three units of each tiny class. A general constructive (loose) offline upper bound is `1/6+b/4+e/2+c`; the final survival proof correctly compares instead with **lower bounds on the actual optimum**.

### A threshold caveat

The certificate covers the specified `C_h=4/7+2H`, and the original half-ready cone covers `C=1/2+H`. The intermediate microinterval where **some** B pairs may accept C but others fail because of differing adaptive small-B offsets is **not certified** by a simple interpolation of these two proofs. Its width can be tiny while its effect on the *number* of available C slots is order N. It should not be discarded by a continuity argument. More generally, a C too large to fit the old P2/Q bins is outside the present cost formula.

## 5. Verification, quantifiers, and unresolved gaps

Run from this directory:

```sh
python verify_original_tree.py
python verify_two_architectures.py
python verify_high_C_scarcity.py
```

All three programs use only the Python standard library. The second checks exact nine-state counts, the universal affine coefficients, the whole continuous batch-length cones by extreme-coefficient inequalities, the new E-overdose and B~2/7 constructive item counts, strict finite-size inequalities, and the explicit perturbation margin. The third independently rebuilds the high-C occupancy and tiny-volume dual and checks each **rational** coefficient, including the finite-size error. No floating solver is used in any proof check.

**Causality.** The B policy uses fixed 16-item or 7-item cycles, never future lengths. The E policy uses fresh pairs; F uses fresh triples, J fresh pairs. The old ready slots are known from the past prefix. The algorithm can distinguish each newly chosen adversarial branch from its first item size. All separator predicates are observable immediately upon placement. E is generated only after the B separator has completed; the two separation scales are not spuriously identified. At stages with partial cycles, at most a bounded number of bins differ from the rational formula. The original prefix's rational periodic history and old shared-source continuations are already certified by `verify_original_tree.py`; choose a common multiple of all their fixed denominators and new cycle lengths, or allow bounded rounding. The asymptotic example uses arbitrarily large N and `epsilon_N=1/(10^12 N^2)`, so OPT grows linearly and the additive perturbation is bounded.

**Important limitations.** These are restricted-tree *defender* theorems. None constructs a classic online algorithm with all-input competitive ratio `r`, none excludes all possible prefix packing histories, none improves the published universal lower bound, and none proves the best lower bound possible under different C lengths/size choices or further branches. The exact nine-state history is only a falsification witness. In particular, demonstrating its survival at `r=1.5428` cannot rule out a strict improvement over the published ~`1.54278090647` that lies below `1.5428`.

**Reduced next question.** Design an online-observable branch whose induced half-ready-slot loss cannot be balanced by the two-dimensional (`M_V,M_H`) volume/count cone *and* whose offline completion avoids a resource-scarcity dual like the one above. A concrete first place to investigate is a separator-dependent C threshold in the microscopic interval between “all small-B pairs fit” and “none fit”; one would have to prove a forced count of B-pair size classes and a constructive offline packing, not assume it. A more radical alternative changes the early C3/C2/A resource balance so the tiny scarcity certificate no longer applies.
