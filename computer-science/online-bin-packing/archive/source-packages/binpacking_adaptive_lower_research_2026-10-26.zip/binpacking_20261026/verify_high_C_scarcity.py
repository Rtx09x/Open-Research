#!/usr/bin/env python3
"""Standalone exact Fraction certificate: high-C (~4/7) scarcity dual.

Restricted to the causal 16-B-block (3 quartets+2 pairs), fresh double-E
policy on the audited t=3 prefix. Applies to ALL nonnegative b,e,c, no cap
on e; C size is 4/7+2epsilon. Offline structural lower bound (NOT upper)
is what certifies survival. No external dependencies or floating comparisons.
"""
from fractions import Fraction as Q
r=Q(3857,2500)
eps=Q(1,10**12)
gB=eps**4
gE=gB**3
bl=Q(3,14)-eps+eps**3
bs=Q(3,14)-eps+gB
Amin=(1+eps)/7
Amax=(1+2*eps)/7
C3=Q(1,294)-294*eps
C2=(1+28*eps)/49
E0=Q(5,14)+3*eps-4*gB
Emax=E0+gB**2
Ch=Q(4,7)+2*eps

# The matching conflict is strict, for all choices of offsets in the
# promised ranges, not just these representative offsets.
assert Ch+2*bs>1
assert Ch+bs+E0>1
assert Ch+E0+Amin>1
assert Ch+bs+2*Amin>1
assert Ch+2*E0>1
assert 5*bs>1
assert 2*Amax+Ch<1
assert 6*C2+Amax+Ch<1
# In a C+B or C+E bin, other non-tiny contents are at most B+A or E.
assert Ch+bl+Amax <Q(13,14)+6*eps
assert Ch+Emax <Q(13,14)+6*eps
# Useful OFFLINE patterns have adequate slack from original C3 negativity:
assert Ch+Emax+3*(C3+C2)<1
assert Ch+bl+Amax+3*(C3+C2)<1

# General exact algebra. Let w be the number of C bins carrying one B/E.
# m >= c+(b+e-w)/4       (B/E occupancy)
# m >= V+w/14-1/42       (waste caused by tiny resource shortage)
# convex coefficient 2/9 and 7/9 eliminate w.
def V(b,e,c):return Q(1,6)+Q(3,14)*b+Q(5,14)*e+Q(4,7)*c
def L(b,e,c):return Q(1,9)+Q(2,9)*b+e/3+Q(2,3)*c

def check_elimination(b,e,c,w):
    k1=c+(b+e-w)/4
    k2=V(b,e,c)+w/14-Q(1,42)
    assert Q(2,9)*k1+Q(7,9)*k2 == L(b,e,c)

for b,e,c,w in [(Q(0),Q(0),Q(0),Q(0)),
                (Q(13643,15000),Q(5,16)*Q(13643,15000),Q(1),Q(1,4)),
                (Q(1),Q(7,10),Q(4),Q(1))]:
    check_elimination(b,e,c,w)

# A0=z+5b/16+e/2 and A1=z-t+5b/16+e/2+c; actual online cost
# is max(A0,A1)+O(1), because only old t bins accept Ch.
z=r/6;t=(2-r)/6
assert z-t==(r-1)/3
margin_const= r*(Q(1,9)/6+Q(8,9)/9)-(r-1)/3
margin_b= r*(Q(1,9)*Q(3,14)+Q(8,9)*Q(2,9))-Q(5,16)
margin_e= r*(Q(1,9)*Q(5,14)+Q(8,9)*Q(1,3))-Q(1,2)
margin_c= r*(Q(1,9)*Q(4,7)+Q(8,9)*Q(2,3))-1
assert margin_const==Q(1,81000)
assert margin_b==Q(23477,810000)
assert margin_e==Q(2477,135000)
assert margin_c==Q(206,16875)

# For finite sizes, prefix volume is at least 1/6-(2053/7)eps,
# B>=3/14-eps, E>=5/14, Ch>=4/7.
# C+B/E non-tiny load <=13/14+6eps (verified above),
# so waste>=w(1/14-6eps)-tiny_total and tiny_total<1/42.
# Use w <= b+e to remove the unknown marked offline C-bin count.
deltaV_const=Q(2053,7)*eps;deltaV_b=eps
deltaL_const=Q(7,9)*Q(2053,7)*eps
deltaL_b=Q(7,9)*7*eps
deltaL_e=Q(7,9)*6*eps
# r*(V/9+8L/9) minus A1 remains strictly positive for ALL b,e,c>=0.
assert margin_const-r*(deltaV_const/9+8*deltaL_const/9)>0
assert margin_b-r*(deltaV_b/9+8*deltaL_b/9)>0
assert margin_e-r*(8*deltaL_e/9)>0
assert margin_c>0
# A0 is dominated by volume too, with only O(1) prefix perturbation.
assert 3*r/14-Q(5,16)-r*eps>0
assert 5*r/14-Q(1,2)>0
assert r*deltaV_const <1

print('PASS: C_h+2B, C_h+E+B, C_h+E+A and C_h+B+2A strictly excluded')
print('PASS: every non-C bin contains at most 4 B/E; tiny scarcity 1/42')
print('PASS: exact 2/9,7/9 offline dual eliminates occupancy w')
print('PASS: fixed 1/9,8/9 competitive dual; all four exact positive margins')
print('PASS: finite epsilon error absorbed coefficientwise for all b,e,c >= 0')
print('STRICT certificate margins:',margin_const,margin_b,margin_e,margin_c)
