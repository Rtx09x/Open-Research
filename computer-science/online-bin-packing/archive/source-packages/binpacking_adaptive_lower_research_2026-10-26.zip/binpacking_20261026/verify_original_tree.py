#!/usr/bin/env python3
"""Independent exact-rational verification of a restricted-family bin-packing obstruction.
All claims are for the t=3 nine-state prefix and the specified B~3/14, C>1/2 branch.
No external solver, packages, network calls, or floating-point proof comparisons.
"""
from fractions import Fraction as F
from collections import OrderedDict

R=F(3857,2500)
Z=R/6
X=R/7
M=OrderedDict([
 ((0,0,2),F(1021879,15000000)),
 ((0,0,4),F(143,3000)),
 ((0,0,6),F(1569121,15000000)),
 ((0,6,1),F(121121,15000000)),
 ((0,6,6),F(16869037,24675000000)),
 ((0,41,1),F(93466153,4112500000)),
 ((2,6,6),F(118071,70000000)),
 ((6,20,4),F(1011847,9870000000)),
 ((288,1,0),F(2438153,705000000)),
])

assert sum(m*M_i[0] for M_i,m in M.items()) ==1
assert sum(m*M_i[1] for M_i,m in M.items()) ==1
assert sum(m*M_i[2] for M_i,m in M.items()) ==1
assert sum(m for m in M.values()) == Z
assert sum(m for (i,j,a),m in M.items() if i==0 and j==0) == X
assert sum(m for (i,j,a),m in M.items() if i>0)==R/294
assert sum(m for (i,j,a),m in M.items() if i==0 and j>0)==R/42-R/294
P2=M[(0,0,2)]; P4=M[(0,0,4)]; Q=M[(0,6,1)]
T=P2+Q
K=P2+P4+Q
assert T==F(2,1)/6-R/6==F(381,5000)
assert K==F(929,7500)

# Cross-check that only P2, P4 and Q can absorb B at base size 3/14.
# Every bin with C3/C2/A other than those three has its base load > 1-3/14.
for pat in M:
    nc3,nc2,na=pat
    load=F(nc3,294)+F(nc2,49)+F(na,7)
    assert load <=1
    if load+F(3,14)<=1:
        assert pat in [(0,0,2),(0,0,4),(0,6,1)],(pat,load)

# The 'six quartets + one pair' rule handles 26 B items in 7 bins.
HARD=F(6,26)     # 4-B bins per B item
READY=F(1,26)    # 2-B bins per B item
TOTAL=F(7,26)
assert 4*HARD+2*READY==1
assert HARD+READY==TOTAL
assert HARD==F(3,13)
assert F(3,14)*R-TOTAL==F(27923,455000)>0
KAPPA=F(3,7)*(R-1)
assert KAPPA-HARD==F(423,227500)>0
assert R/2-1<0 and R-1>0
assert Z-T==(R-1)/3

# For B count b>=0 and C count c>=0 (normalized by N), the online rule has
# B stop count Z+TOTAL*b, and C stop count max(Z+TOTAL*b,Z+HARD*b+c-T).
# Lower bounds on offline cost are volume: V=1/6+3b/14+c/2, and C count c.
# The two lower bounds meet at c_star=1/3+3b/7. The error is minimized there.
# At this crossing, r*max(V,c)-[Z+HARD*b+c-T] = (KAPPA-HARD)*b.
assert R*(F(1,3)+F(3,7))-(Z+HARD+F(1,3)+F(3,7)-T)==KAPPA-HARD

# Natural branch length and exact offline packing at that length.
B=F(7,6)*(1-X)
C=F(1,3)+F(3,7)*B
F1=(1-X)/2      # bins: half + 2 small A + B
F2=(1-X)/3      # bins: half + 2 B + 3 C3 + 3 C2
F3=X/3          # bins: half + 3 large A + 3 C3 + 3 C2
assert F1+F2+F3==C
assert F1+2*F2==B
assert 2*F1+3*F3==1
assert 3*F2+3*F3==1
assert C==F(10847,15000) and B==F(13643,15000)
ALG_B=Z+TOTAL*B
ALG_C=Z+HARD*B+C-T
assert C>T+READY*B
assert ALG_B==F(65261,130000)
assert ALG_C==F(108611,97500)
assert R*C-ALG_C==F(274809,162500000)>0

# Exact finite size witness for ALL nine prefix types and online/offline placements.
# It is a geometric certificate. The asymptotic theorem sends eps->0 with N.
eps=F(1,10**12)
gA=eps**3
asml=(1+eps+gA)/7
alrg=(1+eps+eps/2)/7
assert eps/2>4*gA
amax=(1+2*eps)/7
c3=F(1,294)-294*eps
c2=(1+28*eps)/49
H=eps
b_small=F(3,14)-(2*eps+2*gA)/7-H
half=F(1,2)+H
assert c3>0 and b_small>0 and half>F(1,2)
# The published nine state configurations contain one large A in every A-only bin;
# other A are small. Check even conservative bounds on large A and small A.
for (n3,n2,na),mass in M.items():
    nlarge = 1 if n3==0 and n2==0 and na>0 else 0
    load = n3*c3+n2*c2+nlarge*alrg+(na-nlarge)*asml
    assert load<=1,((n3,n2,na),load)
    maxload = n3*c3+n2*c2+nlarge*amax+(na-nlarge)*asml
    assert maxload<=1,((n3,n2,na),maxload)
# Online slots, and offline integer configurations at b0, c0.
assert 4*b_small <1
assert 2*b_small+half<1
assert 2*alrg+half<1
assert 6*c2+asml+half<1
assert 2*asml+b_small+half<=1
assert 2*b_small+3*(c3+c2)+half<=1
assert 3*alrg+3*(c3+c2)+half<=1
assert 4*b_small+alrg<=1
assert 6*alrg+6*(c3+c2)<=1
assert 42*(c3+c2)<=1

# Preserve the exact eight-stop original tree. The continuation schedules are
# sourced from the independently causally realized nine-state history; they
# share precisely the common prefix and (B21,B22)/(B31,B32) shared stages.
B11=(1+2*eps)/2
B21=(1+eps)/3
B22=(1+eps)/2
B31=(5-2*eps-3*gA)/14
B32=(7+gA)/14
u11=R/6  # new singleton B11 bins
assert T+u11==F(1,3)
assert 2*alrg+B11<1 and 6*c2+asml+B11<1
assert Z+u11==R/3

u21single=F(1143,5000)
u21double=F(857,3000)
assert 2*T+P4+u21single+2*u21double==1
assert 2*alrg+2*B21<1
assert 6*c2+asml+2*B21<1
assert alrg+3*asml+B21<1
assert 2*B21<1
assert Z+u21single+u21double==R/2
u22single=F(3857,5000)
assert u21single+u22single==1
assert B21+B22<1
assert Z+u21single+u21double+u22single==R

u31single=F(587207,3750000)
u31double=F(1033693,3000000)
oldB31=F(7,6)*(1-X)
oldB32=(7-5*X)/6
assert P4+2*Q+u31single+2*u31double==oldB31
assert alrg+3*asml+B31<1
assert 6*c2+asml+2*B31<1
assert 2*B31<1
assert Z+u31single+u31double==R*(7-5*X)/12
u32single=F(3791431,5000000)
assert P2+u31single+u32single==oldB32
assert 2*alrg+B32<1
assert B31+B32<1
assert Z+u31single+u31double+u32single==R*(7-5*X)/6

# Alternative structural mark: B is LARGE iff placed into a bin with >=2 B.
# If at B stop ALG <=R*OPT_B and the constructive offline cost
# OPT_B<=1/6+3b/14+O(1/N), the third-or-later B mark h is forced:
# h >= (1-3R/7)b-2K-o(1).
B0=B
hmin=(1-3*R/7)*B0-2*K
assert 1-3*R/7==F(847,2500)
assert hmin==F(755207,12500000)>0

# An independently valid D~4/7 continuation for that mark uses B perturbations
# small d_s <= gamma_B and large d_l >4 gamma_B, at a scale far below H.
gB=eps**3
large_delta=eps**2
assert large_delta>4*gB
b_s=F(3,14)-H+gB
b_l=F(3,14)-H+large_delta
D=F(4,7)+2*H-2*gB
assert D>F(1,2)
assert 2*b_s+D<=1
assert b_l+b_s+D>1
assert D+b_l+alrg+c3+c2<1
assert 6*alrg+6*(c3+c2)<=1
assert 4*b_l+alrg<=1
# The same periodic packing has two large B in every quartet, none in the pair:
h=F(6,13)*B0
d=(B0+h)/2
# Offline upper: [(b-h)/2] (D+2smallB); [h] (D+largeB+A+C3+C2);
# [(1-h)/6] (6A+6C3+6C2).
optD_upper=(B0-h)/2+h+(1-h)/6
assert optD_upper==F(1,6)+F(17,26)*B0
algD=Z+TOTAL*B0+d-T-READY*B0
assert algD==(R-1)/3+F(25,26)*B0
# To check this *particular policy* against the true OPT, use a LOWER bound,
# not the constructive upper bound above: its total base volume.
volD=F(1,6)+F(3,14)*B0+F(4,7)*d
assert volD==F(57827,78000)
assert R*volD-algD==F(17219239,195000000)>0

print('PASS: exact nine-state counts and all 8 original stop prices and shared continuations')
print('PASS: universal B/C two-line affine dominance (all b,c >=0), no grid search')
print('PASS: 26-item periodic causal policy, zero 2A target marks')
print('PASS: new forced third-or-later B mark inequality, B~3/14, D~4/7 patterns')
for key,val in [('r',R),('initial_bins',Z),('ready_old_bins',T),('B_natural',B),
('C_natural',C),('ALG_B',ALG_B),('ALG_C',ALG_C),
('exact_C_slack',R*C-ALG_C),('forced_new_mark_min',hmin),
('D_counterpolicy_margin_vs_volume',R*volD-algD)]:
    print(key, '=',val, '~',float(val))
