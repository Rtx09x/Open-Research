#!/usr/bin/env python3
"""Exact-rational restricted-tree checks for two new adaptive suffix architectures.

Standard library only. All stage counts are normalized by N, all inequalities
are Fraction comparisons. No claim of an improved universal bin-packing bound.
Source prefix/old-branch certificate: verify_packing_branch_obstruction.py
"""
from fractions import Fraction as Q
from collections import OrderedDict

r=Q(3857,2500)
z=r/6
t=(2-r)/6
M=OrderedDict([
 ((0,0,2),Q(1021879,15000000)),
 ((0,0,4),Q(143,3000)),
 ((0,0,6),Q(1569121,15000000)),
 ((0,6,1),Q(121121,15000000)),
 ((0,6,6),Q(16869037,24675000000)),
 ((0,41,1),Q(93466153,4112500000)),
 ((2,6,6),Q(118071,70000000)),
 ((6,20,4),Q(1011847,9870000000)),
 ((288,1,0),Q(2438153,705000000))
])
assert sum(M.values())==z
for j in range(3):
    assert sum(a[j]*v for a,v in M.items())==1
p2=M[(0,0,2)]; qold=M[(0,6,1)]; p4=M[(0,0,4)]
assert p2+qold==t==Q(381,5000)
assert sum(v for a,v in M.items() if a[0]==0 and a[1]==0)==r/7

# The B schedules are executable one item at a time: every mark is determined
# solely by the destination's previous B occupancy, before placement.
def mark_cycle(group_sizes):
    state=[]
    marks=[]
    for length in group_sizes:
        assert length>=1
        group=[]
        for _ in range(length):
            marked = len(group)>=2
            marks.append(marked)
            group.append(marked)
        state.append(group)
    return state,marks
st,marked=mark_cycle([4,4,4,2,2])
assert len(marked)==16 and sum(marked)==6 and len(st)==5
assert sum(1 for x in st if len(x)==2)==2
st2,marked2=mark_cycle([3,3,1])
assert len(marked2)==7 and sum(marked2)==2 and len(st2)==3
assert sum(1 for x in st2 if len(x)==1)==1
# One fresh E pair gives one first-E (small) and one second-E (large).
assert [j>=1 for j in range(2)]==[False,True]

# Continuous two-line domination criterion. A cost A0=z+sum_i u_i x_i
# has ready slots t+sum_i v_i x_i, and the >1/2 C batch has c items.
# OPT >= max(c, 1/6+sum_i s_i*x_i+c/2 -small_error).
# It suffices to verify both nonnegative margins below.
def margins(stages):
    V=sum((r*s-u)*count for (count,s,u,ready) in stages)
    H=sum((2*(r-1)*s-u+ready)*count for (count,s,u,ready) in stages)
    return V,H

# At arbitrary c, the second online affine expression has its worst
# difference at c_star=1/3+2*sum_i s_i*x_i; the first at c=0.
def verify_no_half_counterexample(stages):
    V,H=margins(stages)
    assert V>=0 and H>=0,(V,H)
    a0=z+sum(u*x for x,s,u,v in stages)
    ready=t+sum(v*x for x,s,u,v in stages)
    cstar=Q(1,3)+2*sum(s*x for x,s,u,v in stages)
    assert r*(Q(1,6)+sum(s*x for x,s,u,v in stages)) - a0==V
    assert r*cstar -(a0+cstar-ready)==H
    assert cstar>0
    return V,H

# --- Architecture I: B=3/14, E=5/14 (second E marked), F=2/7.
# Defending B period = 4+4+2, E pairs, F triples.
uB=Q(3,10); vB=Q(1,10)
uE=Q(1,2); uF=Q(1,3)
sB=Q(3,14); sE=Q(5,14); sF=Q(2,7)
coeffV1=[r*sB-uB, r*sE-uE, r*sF-uF]
coeffH1=[2*(r-1)*sB-uB+vB, 2*(r-1)*sE-uE,2*(r-1)*sF-uF]
assert coeffV1==[Q(153,5000),Q(51,1000),Q(403,3750)]
assert coeffH1==[Q(571,17500),-Q(393,3500),-Q(304,13125)]
assert coeffH1[0]+(coeffH1[1]+coeffH1[2])/5==Q(727,131250)>0
# Coefficients confirm the ENTIRE CONE 0 <= q <= e <= b/5.
for b,e,f in [(Q(1),Q(1,5),Q(1,5)), (Q(13643,15000),Q(13643,75000),Q(13643,75000)), (Q(1),Q(0),Q(0))]:
    assert 0<=f<=e<=b/5
    verify_no_half_counterexample([(b,sB,uB,vB),(e,sE,uE,Q(0)),(f,sF,uF,Q(0))])
assert Q(6,10)==Q(3,5) # Six small B per ten in quartet/quartet/pair period.
assert Q(4,10)==Q(2,5) # Four marked B per ten.
assert Q(3,5)/3==Q(1,5) # Valid 3-small-B E budget.
assert Q(1,2)*Q(1,5)==Q(1,10) # Newly opened E bins per B unit at full cap.
# Offline stage formula E+3B_small plus remaining B quartets and old 6A+6tiny.
b=Q(13643,15000);e=b/5;f=e/4
assert e+ (b-3*e)/4 + Q(1,6)==Q(1,6)+b/4+e/4
# F continuation: F+2 smallE (q bins) + remaining E paired
assert f+ (e-2*f)/2 ==e/2
verify_no_half_counterexample([(b,sB,uB,vB),(e,sE,uE,Q(0)),(f,sF,uF,Q(0))])

# --- New overdose variant of Architecture I, NOT the previously tested e<=smallB/3.
# 16 B period = 3 quartets + 2 pairs. Second-E marking still occurs in
# fresh E pairs. Each E may now use only 2 small B in its offline packing:
# E + 2B_small + A + 3(C3+C2). The E budget is e<=smallB/2=5b/16.
# This genuinely extends the old 3-small-B cap; arbitrary F prefixes q<=e
# and later arbitrary >1/2 C prefixes remain dominated by a new causal policy.
fnew=Q(1,4)
uBnew=Q(5,16)
vBnew=Q(1,8)
assert Q(3,4)*Q(1,4)==Q(3,16)  # quartets per arriving B
assert Q(1,4)/2==Q(1,8)          # pairs per arriving B
assert Q(3,4)/2+Q(1,4)==Q(5,8) # small B per B
assert Q(3,4)/2==Q(3,8)        # large B per B
assert Q(5,8)/2==Q(5,16)       # 2-small-B E cap
vnew=[r*sB-uBnew, r*sE-uE, r*sF-uF]
hnew=[2*(r-1)*sB-uBnew+vBnew,2*(r-1)*sE-uE,2*(r-1)*sF-uF]
assert vnew==[Q(181,10000),Q(51,1000),Q(403,3750)]
assert hnew==[Q(3159,70000),-Q(393,3500),-Q(304,13125)]
assert hnew[0]+Q(5,16)*(hnew[1]+hnew[2])==Q(2353,840000)>0
bn=Q(13643,15000)
en=Q(5,16)*bn
qn=en
assert en<=Q(1,3) and bn<=4 and en<1
assert Q(1)-bn/4-en/2>=0
for xx in [Q(0), en/4, en]:
    vv,hh=verify_no_half_counterexample([(bn,sB,uBnew,vBnew), (en,sE,uE,Q(0)), (xx,sF,uF,Q(0))])
assert bn/8==bn*vBnew
# Constructive OFFLINE E-prefix packing using the new overload pattern.
# e bins E+2Bsmall+A+3 C3+3 C2; (b-2e)/4 bins 4B+A;
# balance remaining A,C in 6A+6Cpair; 6A-only; 42Cpair-only.
Arem=1-en-(bn-2*en)/4
Trem=1-3*en
assert Arem>0 and Trem>0
paired=min(Arem,Trem)
shared=paired/6
Aonly=(Arem-paired)/6
Tonly=(Trem-paired)/42
assert en+(bn-2*en)/4+shared+Aonly+Tonly>0
# Verify exact conservation of A and both tiny types, and B and E.
assert en+(bn-2*en)/4+6*shared+6*Aonly==1
assert 3*en+6*shared+42*Tonly==1
assert 2*en+(bn-2*en)==bn
assert en==en
# E/F offline alternate (up to e/4 F): F+2 small E plus residual E pairs.
q_off=en/4
assert q_off+(en-2*q_off)/2==en/2
# Cone robustness: B>=3/14-eps, E>=5/14, F>=2/7-6eps.
assert vnew[0]>0

# --- Architecture II: new leading B=2/7, two triples and a singleton / 7 B.
# Mark B iff it is third-or-later within the destination.
uB2=Q(3,7);vB2=Q(1,7);sB2=Q(2,7)
uJ=Q(1,2);sJ=Q(3,7)
coeffV2=[r*sB2-uB2,r*sJ-uJ]
coeffH2=[2*(r-1)*sB2-uB2+vB2,2*(r-1)*sJ-uJ]
assert coeffV2==[Q(107,8750),Q(403,2500)]
assert coeffH2==[Q(107,4375),-Q(152,4375)]
assert coeffH2[0]+coeffH2[1]*Q(5,14)==Q(369,30625)>0
assert Q(5,7)/2==Q(5,14)
for b,q in [(Q(1),Q(5,14)),(Q(7,6)*(1-r/7),Q(5,14)*Q(7,6)*(1-r/7)),(Q(3),Q(0))]:
    assert 0<=q<=Q(5,14)*b
    verify_no_half_counterexample([(b,sB2,uB2,vB2),(q,sJ,uJ,Q(0))])
# Exact full-volume B=2/7 offline construction (0<=b<=3):
b=Q(7,6)*(1-r/7)
nb=b/3; remA=1-b/3
vA=remA/6; vTiny=(b/3)/42
assert 3*nb==b and nb+6*vA==1 and 6*vA+42*vTiny==1
assert nb+vA+vTiny==Q(1,6)+Q(2,7)*b
# J+2 small B and remaining B triple: all B and J packed.
q=Q(5,14)*b
assert 2*q+(b-2*q)==b
assert q+(b-2*q)/3+Q(1,6)==Q(1,6)+b/3+q/3

# -- Strict finite-size geometry and nesting.
EPS=Q(1,10**12)
assert EPS <Q(1,2058**3)
C3=Q(1,294)-294*EPS
C2=(1+28*EPS)/49
Amin=(1+EPS)/7
Amax=(1+2*EPS)/7
assert C3+C2+Amin==Q(1,6)-Q(2053,7)*EPS
assert 6*(C3+C2+Amax)<1
assert 42*(C3+C2)<1
# Original tight prefix fits for all A sizes (one large A in A-opened bins).
for pat,m in M.items():
    c3,c2,a=pat
    assert c3*C3+c2*C2+a*Amax <1,(pat, c3*C3+c2*C2+a*Amax)

# Explicit admissible small/large offsets, used solely to check strict signs.
# In the causal theorem their actual offsets vary, but remain in proven ranges.
H=EPS
sigB=EPS**2
gB=EPS**4
bs_delta=gB
bl_delta=EPS**3
assert 4*gB<bl_delta<sigB
# Scenario I: E base depends on gamma_B fixed AFTER B; E separator applied later.
bs=Q(3,14)-H+bs_delta
bl=Q(3,14)-H+bl_delta
E0=Q(5,14)+3*H-4*gB
gE=gB**3
Es=E0+gE
El=E0+gB**2
assert gE<gB/4 and El>E0+4*gE
FF=1-2*E0-2*gE
CC=Q(1,2)+H
assert 4*bl<1 and 4*bl+Amax<1
assert 2*Es<1 and 2*El<1
assert Es+3*bs<1 and El+3*bs<1  # offline E+3 Bsmall
assert Es+2*bs+bl>1 # if any B large, E cannot join 3B
assert FF+2*Es==1
assert FF+Es+El>1
assert 3*FF<1 and FF>Q(1,4)
assert 2*bs+CC<1 and 2*Amax+CC<1 and 6*C2+Amax+CC<1
assert Es+CC+Amin>1 and Es+CC+bl>1  # scarcity observation
# E+2smallB+A+3tiny pairs: useful candidate beyond 3-B budget.
assert Es+2*bs+Amax+3*(C3+C2)<1
assert El+2*bs+Amax+3*(C3+C2)<1
assert Es+bs+3*Amin>1  # tempting E+B+3A base-equality is INVALID

# Scenario II: B~2/7 and J~3/7, independent of first architecture.
bs2=Q(2,7)-H+gB
bl2=Q(2,7)-H+bl_delta
JJ=Q(3,7)+2*H-2*gB
assert 3*bl2<1 and 3*bl2+Amax<1
assert JJ+2*bs2==1
assert JJ+bs2+bl2>1
assert 2*JJ<1
assert bs2+CC<1 and 2*Amax+CC<1 and 6*C2+Amax+CC<1

# Robust size margins, uniform for all batch lengths b,e,f,q>=0.
# Baseline prefix volume loss <=(2053/7)*EPS. In scenario I all E sizes
# >=5/14, F>=2/7-6EPS, B>=3/14-EPS; scenario II J>=3/7.
assert E0>Q(5,14) and FF>=Q(2,7)-6*EPS
assert JJ>Q(3,7)
# Worst possible coefficient deductions (online recipe unchanged):
robust1_v_b=coeffV1[0]-r*EPS
robust1_v_f=coeffV1[2]-r*6*EPS
robust1_h_b=coeffH1[0]-2*(r-1)*EPS
robust1_h_f=coeffH1[2]-2*(r-1)*6*EPS
assert robust1_v_b>0 and robust1_v_f>0
assert robust1_h_b+(coeffH1[1]+robust1_h_f)/5>0
assert vnew[0]-r*EPS>0
assert hnew[0]-2*(r-1)*EPS+Q(5,16)*(hnew[1]+robust1_h_f)>0
assert coeffV2[0]-r*EPS>0
assert coeffH2[0]-2*(r-1)*EPS+coeffH2[1]*Q(5,14)>0
assert r*Q(2053,7)*EPS<1

print('PASS: all nine prefix states and their exact count identities')
print('PASS: generic two-line domination, exact continuous cone certificates')
print('PASS: architecture I original E cap and NEW overdose E cap e<=5b/16, q<=e, all later C')
print('PASS: architecture II B~2/7, J~3/7 + all later C, q<=5b/14')
print('PASS: constructive E/F/J/B offline patterns and exact item balances')
print('PASS: strict perturbation/capacity witnesses and robust size inequalities')
print('All margins are rational, not floating-point tests.')
