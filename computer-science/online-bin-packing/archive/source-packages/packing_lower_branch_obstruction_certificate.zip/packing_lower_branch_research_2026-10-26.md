# Restricted-family obstruction and a different occupancy-separator attack

**Date:** 2026-10-26  
**Problem:** Classic deterministic online unit-bin packing, no repacking or advice.  
**Status:** Proven *restricted-family obstruction*, exact finite verification, a separate forced-mark inequality and feasible adaptive `D ≈ 4/7` continuation. **No improved universal lower bound.**

## 1. The inherited nine-state prefix

Use the exact `t=3`, `r=3857/2500` prefix-history masses in `verify_packing_branch_obstruction.py`. Its algorithm opens

\[
zN=\frac r6 N=\frac{3857}{15000}N
\]

bins by the end of the `A` stage, with `x=r/7=551/2500` of the `A` items opening new bins. The nine masses and the original eight stop ratios are checked exactly by the accompanying verifier. The former independently checked *causal realization* of this prefix is assumed; the verifier independently checks its counts, branch schedules, rational load inequalities and eight stop ratios, rather than treating mere fractional feasibility as causality.

Two subsets of these prefix bins are left untouched in the new branch:

\[
p_2=\frac{1021879}{15000000}
\quad\text{bins of type }(0,0,2),
\qquad
q=\frac{121121}{15000000}
\quad\text{bins of type }(0,6,1).
\]

Both can receive a new item just above `1/2`, and their combined mass is exactly

\[
t=p_2+q=\frac{381}{5000}=\frac{2-r}{6}.
\]

All statements below are normalized by `N`; integral rounding incurs only `O(1)` bins. The adversary's near-base perturbations can be chosen to tend to zero with `N`.

## 2. Universal failure of the proposed two-A marking branch on this face

**Theorem 1 (a causal counterpolicy for every near-base two-stage B/C continuation).** Start with the above causally realized prefix. Next send an arbitrary number `bN` of items in an `o(1)`-neighborhood of `3/14`, then an arbitrary number `cN` of items in `(1/2, 1/2+o(1))`. Assume the perturbations are uniformly small enough for four B-items to fit in a bin and a C-item to fit in a bin containing two B-items, two A-items of the prefix type `(0,0,2)`, or the prefix type `(0,6,1)`. This includes any above-half C continuation satisfying the requested offline relation `2 A_small + B_small + C <= 1`. The B-size selection may depend on the algorithm's observed decisions, as long as sizes stay within the specified window.

There is a **single deterministic causal strategy** on this augmented branch that never puts any B item into a bin containing two A-items, and satisfies

\[
\operatorname{ALG}(I)\le\frac{3857}{2500}\operatorname{OPT}(I)+o(N)
\]

at **every** B-prefix stop and at **every** subsequent C-prefix stop. It continues the independently realized original eight-stop policy unchanged on the other branches. Consequently **this particular branch, on this nine-state face, cannot force a lower bound strictly greater than `1.5428`**, whatever positive marked-B count an adversary hoped to extract. It does *not* rule out an improvement between the published limiting lower bound `~1.542780906` and `1.5428`, and does not prove a competitive ratio for all inputs.

**Causal policy.** Never use any old bin for B. Partition the B stream, online, into successive blocks of 26 arrivals: six new bins containing four B each and one new bin containing two B. The final incomplete block costs `O(1)` more bins. The procedure uses no future knowledge of whether C arrives. Every B thus has zero A-items in its chosen bin, so *the proposed LARGE count is identically zero*. If C arrives, place one C in each of the `tN` reserved prefix bins and in each of the B-pair bins, then open one new bin per remaining C. Each C is above `1/2`.

Let

\[
\beta=\frac7{26},\qquad \alpha=\frac6{26}=\frac3{13},\qquad t=\frac{2-r}{6}.
\]

The B-stage and C-stage bin counts satisfy

\[
A_B\le \left(\frac r6+\beta b\right)N+O(1),
\]

\[
A_C\le\max\left\{
\frac r6+\beta b,
\frac r6+\alpha b+c-t
\right\}N+O(1).
\]

(The max, rather than only the second expression, is necessary when too few C items arrive to use the ready bins.)

**Proof against the actual offline optimum.** Actual total volume and the fact that every C item exceeds `1/2` give

\[
\operatorname{OPT}_B\ge
\left(\frac16+\frac{3b}{14}-o(1)(1+b)\right)N,
\]

\[
\operatorname{OPT}_C\ge
\max\left\{c,\frac16+\frac{3b}{14}+\frac c2-o(1)(1+b)\right\}N.
\]

The exact B coefficient margin is

\[
\frac{3r}{14}-\beta=\frac{27923}{455000}>0.
\]

It remains to check the second expression in the C cost. Put

\[
V=\frac16+\frac{3b}{14}+\frac c2,
\quad c_*=\frac13+\frac{3b}{7}.
\]

The functions `V` and `c` cross exactly at `c=c_*`. For `c<=c_*`, the difference

\[
rV-\left(\frac r6+\alpha b+c-t\right)
\]

is decreasing in `c` because `r/2-1<0`; for `c>=c_*`, the difference using the lower bound `c` is increasing because `r-1>0`. Hence the minimum over **all** `b,c>=0`, for fixed `b`, occurs at `c=c_*`, where it is exactly

\[
\left(\frac{3(r-1)}7-\alpha\right)b
=\frac{423}{227500}\,b\ge0.
\]

This is an algebraic all-`b,c` proof, not a finite grid search. Taking the tiny perturbations to zero rapidly with N and absorbing the last partial block yields an `O(1)` additive loss in the choice `epsilon_N=O(N^{-2})` and small B/C offsets. Every B prefix is covered by the first cost inequality, while every C prefix is covered by the max of the first and second.

**An open interval of defensive policies.** Let `f` be the fraction of B items put into paired B bins, the rest in quartets. Their new-bin and C-incompatible-bin rates are `(1+f)/4` and `(1-f)/4`. Both proof conditions hold provided

\[
\boxed{\frac{304}{4375}< f <\frac{403}{1250}}.
\]

Our exact periodic choice `f=1/13` lies strictly inside that interval. Thus the obstruction is not a knife-edge coincidence.

### A constructive OPT equality at the natural batch lengths

Set `x=551/2500`, `b=7(1-x)/6=13643/15000`, and

\[
c=\frac13+\frac{3b}7=\frac{10847}{15000}.
\]

Take A-small offsets at most `gamma_A`, A-large offsets above `4 gamma_A`, with `0<gamma_A<<epsilon`. Choose

\[
B_{\rm small}=\frac3{14}-\frac{2\epsilon+2\gamma_A}{7}-H,
\qquad
C=\frac12+H,
\quad 0<H=O(\epsilon),
\]

with `H=epsilon` an explicit valid choice for sufficiently small epsilon. All B are SMALL for the specified causal policy. The following **offline packing uses exactly `cN` bins**:

| Number of bins per N | Contents |
|---|---|
| `(1-x)/2` | `C + 2 A_small + 1 B_small` |
| `(1-x)/3` | `C + 2 B_small + 3 C3 + 3 C2` |
| `x/3` | `C + 3 A_large + 3 C3 + 3 C2` |

Each pattern has load at most one for the published tiny types `C3=1/294-294epsilon`, `C2=(1+28epsilon)/49`. Their exact item-count identities and capacity inequalities are checked in the script. Since `C>1/2`, at least `cN` bins are necessary, so `OPT=cN` exactly at integral scales.

For this branch the causal policy uses

\[
A_B/N=\frac{65261}{130000}+O(1/N),
\qquad
A_C/N=\frac{108611}{97500}+O(1/N).
\]

The exact margin against the **actual** optimum at the C stop is

\[
rc-A_C/N
=\frac{274809}{162500000}
>0.
\]

This is a direct constructive counterexample to the claim that this branch necessarily excludes the nine-state face.

### Second-round separator warning

Suppose the first A separator permits `A_small` offsets in an interval of width `Delta_A>0`. A common threshold C intended to fit **every** pair of small As with any B_small but exclude **every** pair of small As with any B_large needs, as a necessary inequality,

\[
B_{\min,\rm large}-B_{\max,\rm small}>2\Delta_A.
\]

The cited adaptive binary-separation theorem gives a *multiplicative ordering of the new B offsets*, not this absolute comparison to the older A-offset interval. Both B offset classes can be arbitrarily tiny relative to `Delta_A`. Thus this global uniform-fit/exclusion step is not licensed by two independent applications of the separator theorem. One could restrict which A-pairs need to be accommodated, or prove a new joint-separator lemma. The no-go policy above does **not** rely on this warning; it succeeds even if the desired new-size geometry is granted.

## 3. A genuinely different occupancy mark that is forced

**Theorem 2 (third-and-later B mark count on the exact tight prefix).** Again use the nine-state prefix. Present `bN` items near `3/14`. Mark a B item LARGE iff it is put into a bin already containing **at least two B items**, not according to the number of A items. Let `hN` be the number of marked items. Suppose the online algorithm has not already lost at the B stop, i.e. `A_B <= r OPT_B+o(N)`, and `0<=b<=4`, with perturbations chosen so that four B items and one A can be packed together. Then

\[
\boxed{
h\ \ge\left(1-\frac{3r}{7}\right)b
-2\left(p_2+p_4+q\right)-o(1)
=\frac{847}{2500}b-\frac{929}{3750}-o(1).
}
\]

At the natural `b=13643/15000`, this gives

\[
\boxed{h\ge\frac{755207}{12500000}-o(1)\approx0.06041656.}
\]

**Proof.** Only old bins of types `(0,0,2)`, `(0,0,4)` and `(0,6,1)` can admit a B item. Their total mass is

\[
K=p_2+p_4+q=\frac{929}{7500}.
\]

An offline B-stop construction attains the asymptotic upper bound

\[
\operatorname{OPT}_B\le\left(\frac16+\frac{3b}{14}\right)N+O(1).
\]

Use `(b/4)N` bins with `4B+A`, `(1-b/4)N/6` bins with `6A+6C3+6C2`, and `(b/4)N/42` bins with `42C3+42C2`; their counts cover all three preceding item types and all B. Their loads are at most one for `B=3/14-H+d_i`, `H` chosen greater than the necessary previous-A perturbation and the `d_i` bounded sufficiently small. This construction applies for `b<=4`.

If the B stop has no violation, the number `nN` of new B-stage bins is at most

\[
n\le r\left(\frac16+\frac{3b}{14}\right)-\frac r6+o(1)
=\frac{3rb}{14}+o(1).
\]

Every B-containing bin has at most two **unmarked** B items. Thus

\[
b-h\le 2(K+n)+o(1),
\]

which proves the result. This is a conditional structural fact *on the exact prefix*, not a universal new competitive-ratio lower bound.

### A feasible D≈4/7 adaptive completion, and why it remains insufficient

Choose B sizes **after** the A round as

\[
B_i=\frac3{14}-H+d_i,
\]

with `H` fixed after A and `0<d_i<<H`. The second adaptive separator makes the mark-positive offsets greater than `4 gamma_B` and all mark-negative offsets at most `gamma_B`. This needs **no** separation of B offsets against the earlier A offsets. Then take

\[
D=\frac47+2H-2\gamma_B>\frac12.
\]

Consequently `D+2 B_small<=1`, but `D+B_large+B_small>1` (because the large offset exceeds `4 gamma_B`). This is a genuine shared-history continuation, with D chosen only after the B stage. Let its number of items be `dN=(b+h)N/2`.

For `0<=h<=min(b,1)`, use the explicit offline packing:

| Number of bins per N | Contents |
|---|---|
| `(b-h)/2` | `D+2 B_small` |
| `h` | `D+B_large+A+C3+C2` |
| `(1-h)/6` | `6A+6C3+6C2` |

The second configuration has base load exactly `20/21<1`, giving a fixed safety margin against any earlier A spread; the last is inherited from the original construction. Thus

\[
\boxed{\operatorname{OPT}_D\le
\left(\frac b2+\frac16+\frac h3\right)N+O(1).}
\]

This bound depends on the *forced* h, and the B separator hierarchy is valid. It does not yet yield an improved lower bound. The same causal 26-item B strategy has `h=(6/13)b` for the new predicate, `d=(19/26)b`, and D can be placed into its B-pair bins and the `tN` reserved prefix slots. Its final cost is

\[
A_D/N=\frac{r-1}{3}+\frac{25b}{26}+O(1/N).
\]

At the natural b, the physical-volume **lower** bound for the actual OPT gives

\[
\operatorname{OPT}_D/N\ge
\frac16+\frac{3b}{14}+\frac47\frac{19b}{26}-o(1)
=\frac{57827}{78000}-o(1).
\]

Hence this policy itself satisfies

\[
r\frac{57827}{78000}-\frac{137213}{130000}
=\frac{17219239}{195000000}>0.
\]

The tested D branch does not exclude this particular policy. It remains possible that a different completion, a shared second stopping condition, or a more efficient offline packing would make the *forced* label statistic useful. No such universal winning branch was proved.

## 4. Scope and proof gaps

1. **Proved:** A causal `6x4B + 1x2B` policy defeats the proposed two-A label on the independently realized finite-depth tight history, for *arbitrary lengths* of the new B/C stages and the above-half C geometry. All ratio comparisons use lower bounds on **actual** offline OPT, not a favorable offline upper bound.
2. **Proved:** A different `B>=2` mark is forced to positive density `755207/12500000` at the natural B count if the exact tight-face history remains under the target ratio at the B stop.
3. **Proved:** A D≈4/7 continuation for the forced mark admits exact, feasible offline configurations, avoiding the multiple-separator hierarchy problem. This single D continuation still fails to eliminate a specific causal response at the natural batch count.
4. **Not proved:** An improved lower bound above the published `(1363-sqrt(1387369))/120`; an exclusion of *every* deterministic algorithm, or an exclusion of all possible continuations after B. None of this is an all-input online-algorithm guarantee.
5. **Not covered by Theorem 1:** Continuations at or below exactly 1/2 allowing two C items in one bin, multiple separately priced future item types, large B items outside the near-3/14 window, or adversaries modifying the earlier prefix. The theorem also does not rule out small improvements below `r=1.5428`.
6. **No external or paid computation:** Only exact-rational standard-library Python and source-paper reading. The numerical checks do not establish originality or human peer review.

### Source basis

- Balogh, Békési, Dósa, Epstein, Levin (2018), *A new lower bound for classic online bin packing*, arXiv:1807.05554, §§2–4, particularly Theorem 1 and Lemmas 2–4. https://arxiv.org/html/1807.05554
- Same authors, *A new and improved algorithm for online bin packing*, arXiv:1707.01728, for the classic model and upper-bound context. https://arxiv.org/html/1707.01728
- User-supplied tight-face dossier (nine masses, original restricted causal realization) as an internal mathematical starting point; not a published lower-bound theorem.

### Run exact verifier

```sh
python verify_packing_branch_obstruction.py
```
