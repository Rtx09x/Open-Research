PACKING RESEARCH: AUDIT, STRUCTURAL EXTENSION, AND EXACT CERTIFICATES
==================================================================

Start with REPORT.txt. It states the model, exact algorithm edit, two main
proofs, all ratios, the lower-history realization, and unresolved gaps.

Main result (asymptotic, arbitrary online input):

  R_new = 87931323061219230147063794829048504459349 /
          55715094120735551199336133222286481162240
        = 1.5782316165646344...

This belongs to AH with the dossier's three container-proportion transfers
AND the explicitly specified delayed tiny-container closure rule. It does
not belong to unchanged AH. The improvement over the dossier is approximately
4.445957368769192e-7. Novelty/priority and human review remain unestablished.

OFFLINE REPRODUCTION (Python3, standard library only)
---------------------------------------------------
Run from the extracted bundle's root:

  python packing_work/verify_algebra.py
  python packing_work/reconstruct_ah.py --snapshot
  python packing_work/verify_final_extension.py --snapshot
  python ah_audit/verify_delayed_tiny.py --snapshot --blend
  python lower_structure/verify_robust_history.py

The second command reconstructs the dossier's bound from numeric parameters.
The third recomputes exact maxima for every final scenario. The fourth is an
independent size-order target verifier and imports no code from the third.
The fifth checks the restricted lower-bound history's exact rational data.
The causal realization proof is in lower_structure/robust_history_theorem.md.
The scripts may update JSON verification logs beside themselves.

PRIMARY-SOURCE RECONSTRUCTION
-----------------------------
The source numeric snapshot contains all original classes and scenario
weights, before the three transfers. Its provenance is recorded in the JSON.
The complete primary paper HTML is not included. To repeat source extraction,
download https://arxiv.org/html/1707.01728 as packing_work/ah.html.

Then run without --snapshot:
  python packing_work/reconstruct_ah.py
  python packing_work/verify_final_extension.py
  python ah_audit/verify_delayed_tiny.py --blend

The first two source-mode scripts require lxml for HTML parsing. The
independent verifier uses the standard-library HTMLParser. Both source-mode
routes were executed in this consultation. Offline snapshot verification
checks the arithmetic but does not repeat source retrieval or provenance.

CONTENTS
--------
REPORT.txt: full result and proofs.
packing_work/source_numeric_snapshot.json: all published numeric parameters.
packing_work/refinement_exact_maxima.json: exact maxima for the dossier.
packing_work/final_extension_certificate.json: all402 final scenarios,
 804 exact case maxima, maximizing patterns and modified parameters.
packing_work/verify_algebra.py: scalar dual and final equality-pattern checks.
packing_work/reconstruct_ah.py: source/snapshot extraction and linear pricing.
packing_work/verify_final_extension.py: nonlinear exact full maximization.
ah_audit/verify_delayed_tiny.py: independent source/snapshot target checker.
ah_audit/*verification.json: independent exact verification logs, with modes.
ah_audit/theorem_audit.md: source hypothesis and endpoint audit, including a
 shorter proof of the delicate threshold-class accounting.
ah_audit/delayed_tiny_audit.md: independent audit of the structural extension.
lower_structure/: exact9-prefix/34-continuation history, checker, and proof.
SHA256SUMS.txt: hashes of the delivered files.

No full paper caches, unrelated material, or exploratory parameter sweeps are
needed to reproduce the delivered result. Exact arithmetic supports the
finite certificates; the supplied mathematical proofs establish why those
certificates imply the all-input claim and the restricted-history statement.
