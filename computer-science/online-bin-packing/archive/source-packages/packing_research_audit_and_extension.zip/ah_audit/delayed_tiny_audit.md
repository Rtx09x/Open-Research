# Independent audit of delayed tiny closure and nonlinear pricing

## Verdict

**PASS:** changing only the tiny-container closure rule to Next Fit within its advertised capacity preserves the structural hypotheses needed in the proof of AH Theorem 24. The overflow-charge lemma, its nonlinear offline-bin envelope, and the convexly blended weight certificate are mathematically valid. The following global bound passed independent exact verification:

\[
R_{\rm new}=
\frac{87931323061219230147063794829048504459349}
{55715094120735551199336133222286481162240}.
\]

The three rational proportion transfers from the dossier remain in place. All other proportions, boundaries, advertised volumes, matching rules, and non-tiny analysis weights remain unchanged.

This is a statement about a modified deterministic online algorithm. The nonlinear overflow charging does **not** apply to the original proactive tiny closure rule.

## 1. Portability to AH's structural proof

The source's proactive closure is specified in Section 3, in the paragraph for small/tiny items: close a tiny type-i container as soon as its load exceeds A_i-d, d=1/43. The proposed rule instead retains its open status until a new tiny item would exceed A_i. That item's failed insertion closes the old container, after which it is inserted into a newly created container using the existing quota and matching rules.

No packing exceeds its advertised volume. Every tiny item fits every new tiny container, since s<=d<=min_i A_i. No movement or advance knowledge is used.

I searched the entire primary proof for uses of open/closed tiny state and checked the relevant proofs individually. After the algorithm definition, the only load property required is Lemma 10's statement that all but at most one tiny container have load >A_i-d. The modified rule preserves it, since an overflow trigger s<=d proves load >A_i-s>=A_i-d. The optional rule of closing immediately at exact full load also preserves it.

Other containers see the tiny container's fixed advertised volume, not its actual load or open status. The proof of Lemma 3 therefore remains valid. Large-class proportion/count changes are governed by the same creation and pairing rules, so Lemmas 5–9 remain valid. The largest-temporary-singleton selection rule is unchanged, retaining Lemmas 11–14. Small/tiny quota discrepancy estimates use only the type chosen at each creation, retaining Lemma 19. Consequently the basic and threshold-class weight arguments carry over, with the new tiny total-weight estimate replacing Lemma 20 where desired.

No assertion that the modified algorithm uses fewer bins than the original on every input is necessary or established.

## 2. Overflow lemma

Let p be the number of tiny types, alpha_i their proportions, A_i their advertised capacities, and r_i their scenario-required weights. Put

\[
B=\sum_i\alpha_iA_i,\qquad b=\sum_i\alpha_i r_i.
\]

For c in [0,d], define

\[
\rho_c=\frac b{B-c},\qquad
f_c(s)=\rho_c\bigl(s+(s-c)_+\bigr).
\]

The tiny-type quota discrepancies satisfy n_i=alpha_i m+delta_i, delta_i<=1, and sum delta_i=0. Thus both the total positive discrepancy and total negative discrepancy magnitude are at most p-1. Every closed non-full container wastes less than its distinct triggering item s; this is at most c+(s-c)_+. The unfinished final container wastes at most one. Therefore, writing T for total tiny size and E_c=sum(s-c)_+,

\[
\sum_i A_i n_i-T\le cm+E_c+1,
\qquad
(B-c)m\le T+E_c+p.
\]

Also sum r_i n_i<=bm+p-1. Combining gives

\[
\sum_i r_i n_i
\le\sum_s f_c(s)+\rho_c p+p-1.
\]

All constants are input-independent. Distinct triggering items are essential, and hold because any failed item fits the new container immediately.

At c=d, f_c is the original linear tiny weight. This recovers the original pricing as an available choice for every scenario of the modified algorithm.

## 3. Exact tiny envelope and convex combination

For r>=0 write q=floor(r/d), e=r-qd. The exact maximum of sum[s+(s-c)_+] over tiny multisets of total size at most r is

\[
G_c(r)=r+q(d-c)+(e-c)_+.
\]

One proof counts the n items exceeding c: their total excess is at most min(r,nd)-nc. The best n is q or q+1. The resulting maximum is achieved by q full-size tiny items d and one remainder e, omitting a zero remainder. All coefficients are nonnegative, so total size r is optimal. G_c is continuous and monotone.

The final certificate uses c=1/60, theta=7/60, and the item weight

\[
f(s)=\theta f_{1/60}(s)+(1-\theta)f_d(s)
\]

only in scenarios (533/1600,1/3] and (3/7,1/2]. It uses f_d elsewhere. Both ingredient tiny-weight lower bounds hold for the same run, so their convex combination is valid with the corresponding convex combination of additive constants. This is not a pointwise minimum of separately valid weight functions, which would need another argument.

The exact blended residual-capacity bound is

\[
\theta\rho_{1/60}G_{1/60}(r)+(1-\theta)\rho_d r.
\]

Its minimum slope is theta*rho_(1/60)+(1-theta)*rho_d. Its maximum average density is at most theta*rho_(1/60)*(2-c/d)+(1-theta)*rho_d. These two inequalities justify the independent verifier's item elimination and search pruning.

## 4. Independent arithmetic verification

`verify_delayed_tiny.py` uses only the Python standard library. It does not import the parent's verifier or numerical optimization logic.

* It parses the primary HTML tables with an independently written HTMLParser.
* It reconstructs all class parameters, applies the three transfers, and checks them against the serialized source mapping.
* It regenerates all 402 scenarios from the actual boundary/volume/complement set.
* It derives required weights directly using an interior midpoint t=(x+y)/2, rather than the parent's endpoint/order formulas.
* It checks all large-threshold inequalities.
* It verifies the target in all 804 strict knapsacks with exact Fraction arithmetic and descending **size** order, rather than the parent's density order.
* Multiplicity limits use exact strict rational comparison, not scaled integer capacities.

Final convex-blend result: PASS, 402 scenarios, 804 cases, 29,867 search nodes, approximately 12.20 seconds in the audit run. Output: `independent_blend_verification.json`.

The original dossier's upper bound R* was also independently checked with the old linear tiny weights in all 804 cases: PASS, 29,827 nodes, approximately 9.77 seconds. Output: `independent_original_refinement_verification.json`.

For a source-free bundle, run `python ah_audit/verify_delayed_tiny.py --snapshot --blend`. The explicit snapshot path reads original parameters from `packing_work/source_numeric_snapshot.json`, reapplies the transfers, regenerates the breakpoint set, and recomputes all weights. It compares mapped parameters with `packing_work/final_extension_certificate.json`. Its output records `source_mode: numeric_snapshot`; this verifies the bundled arithmetic without claiming to repeat the primary-source extraction. Without `--snapshot`, the independent HTML parser remains the default when the primary HTML file is present.

The simpler intermediate c=1/44 certificate also independently passed all 804 cases, at

\[
\frac{1899077696629320230341312379790758794811611}
{1203294576680198570840322318297231041495040},
\]

with 29,849 nodes. Output: `independent_delayed_tiny_verification.json`.

## 5. Independent equality witness for the final bound

The remaining limiting scenario is (49/320,1/6], w=0. Its representative pattern has three items of class 167, one item of class 172, and one item of class 179. Its size is

\[
3\cdot\frac14+\frac3{20}+\frac1{11}=\frac{109}{110},
\]

leaving sand 1/110. Independently reconstructed weights are

\[
\omega_{167}=\frac{795881500000}{2013426688063},
\]

\[
\omega_{172}=\frac{661406035963546729717373}{2789317901045682369724416},
\]

\[
\omega_{179}=\frac{7989617598974199532220852929}{56349800236924875233172652032},
\qquad
\rho_d=\frac{1400445382739}{945631002624}.
\]

The exact identity

\[
3\omega_{167}+\omega_{172}+\omega_{179}+\frac{\rho_d}{110}=R_{\rm new}
\]

was checked independently. Thus R_new is the exact largest representative-envelope value for the final supplied analysis, not merely an arbitrary upper target. It is not an algorithm-cost lower bound.

## Limits

No novelty/priority claim is made. No proof-assistant formalization or human review occurred. The new bound is numerically small but follows from a change in algorithmic closure behavior and a size-sensitive charging argument that escapes the dossier's fixed-weight identity. No lower-bound tight-face exclusion follows from this result.

