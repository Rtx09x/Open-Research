# Independent AH theorem audit

Source: Balogh–Békési–Dósa–Epstein–Levin, arXiv:1707.01728v1, full 46-page paper. The primary HTML is `packing_work/ah.html`; the accessible PDF is <https://arxiv.org/pdf/1707.01728>. This audit read the complete uploaded dossier and the relevant primary proof. It does not certify the missing 402-scenario numerical file.

Follow-up: after this theorem audit, an independent source reconstruction and exact Fraction verifier certified all 804 original-refinement cases at R*. See `independent_original_refinement_verification.json` (29,827 search nodes). Thus the arithmetic gap described below was subsequently closed by reconstruction. The stronger modified-algorithm result is audited in `delayed_tiny_audit.md`.

## Verdict

**PASS for the mathematical reduction, conditional on the complete finite pricing certificate.** The three changed classes are small classes, all changed proportions remain positive with the same support, and no parameter admissibility restriction forbids those changes. The interior-threshold extension is legitimate; the two strict-infimum knapsacks dominate every actual offline bin. Theorem 24 consequently gives the asserted all-input asymptotic implication if the reconstructed arithmetic passes. There is no identified asymptotic counterexample.

**UNRESOLVED in this subtask:** all 804 numerical knapsack certificates, full endpoint coverage, and publication priority. These are not established by the narrative's reports of earlier independent checks. The parent is reconstructing the arithmetic independently.

## 1. Parameter admissibility

Section 2 (PDF printed pp. 6–7) defines each large/small class's parameters as arbitrary nonnegative proportions summing to one, with container cardinality bounded by `floor(1/t_(j-1))`. Appendix A's rows 167, 172 and 179 agree with the interval/type/proportion data in the dossier. The online rules in Section 3 select a positive-proportion type whose current count is at most its prescribed fraction; no further small-class parameter equation is imposed.

The proof also uses positivity of the type-2 fraction for every large class (explicit immediately before Corollary 14, printed p. 22), and the tiny-class density bound rho <= 2 (Section 4.3.2, printed p. 15; Lemma 20, printed p. 25). Both remain unchanged by the three transfers. Tiny volumes and the tiny denominator also remain unchanged. A transfer among already-supported types preserves the finite breakpoint set.

The quantities alpha are **container proportions**, not probabilities in a randomized algorithm or item fractions. The modified algorithm remains deterministic once tie-breaking is fixed.

## 2. Interior thresholds are admissible

Let P,N be the sets of unmatched positive and negative containers at the end of a finite input. Set p=min volume(P), with p=1 if P is empty; set n=min volume(N), with n=1/2 if N is empty. Lemma 3 (printed p. 12) says p+n>1 whenever both sets are nonempty. Positives have volume >1/2 and all negative volumes are positive. Therefore

    max(0,1-p) < min(1/2,n).

Choose t strictly between the two sides and outside the finite set V of breakpoints. Then every unmatched positive has volume >1-t, and every unmatched negative has volume >t. Let a=1-t. This choice is for analysis after the execution; no online decision uses t.

The minimum-positive definition of a is not itself a hypothesis needed by the following proofs:

* Lemma 17 uses exactly the two unmatched-container inequalities above, to give every singleton bin required weight 1.
* The start of Section 5.2.1 (printed p. 20) needs that no temporary singleton of threshold class k of size <=t remains unmatched at termination. This follows directly from the new choice.
* Lemma 11 (printed pp. 20–21) uses the largest-temporary-singleton selection rule and the last time tau without a bigger temporary singleton.
* Lemma 12 (printed p. 21) uses the same rule and definition of tau.
* Lemma 13 and Corollary 14 use only those statements and the class-proportion count estimates. They make no use of an unmatched positive container of volume exactly a.
* Lemmas 15–16 then use only counts, the weights u,v,w, and the three balance inequalities.

Thus the proof of Theorem 24 extends to this choice. Every t is in an open scenario (x,y), and all fixed-volume comparisons agree with the numerical scenario formulas. Choosing t in an interval avoiding V removes the exact endpoint ambiguity identified in the dossier.

## 3. An independent short proof of the threshold-class weight bound

This is a clean way of verifying the delicate part of Theorem 24 without relying on every algebraic line of Lemma 16.

Write alpha=alpha_1k, beta=alpha_2k, alpha+beta=1, and assume alpha,beta>0. Let n be the number of threshold-class containers/bins, n1 and n2 the numbers of type-1 and type-2 containers. By Lemma 5 and Corollary 6,

    n1=alpha*n+e, n2=beta*n-e, 0<=e<=2.

Let T be the number of temporary type-1 containers at termination. Split convenient type-2 containers into C1 (has an item >t) and C2 (all other convenient containers, which have a negative partner). Corollary 14 gives

    T <= (alpha/beta)*(C1+C2) + lambda,
    lambda = 5*alpha/beta + 5 = 5/beta.

Let Phi be the total item weights of threshold class k plus the required weights of all its companion containers. Define

    B = u*(alpha+2*beta)+w*alpha,
    m = min(v-u,1-w),
    D = v-u-w + (beta/alpha)*m.

The range/order assumptions ensure m>=0 and D>=-1. A regular type-1 container contributes at least u+w, a temporary singleton contributes v, a regular type-2 container contributes at least 2u, and convenience adds at least v-u or 1-w. There are at most four declared (incomplete) type-2 containers, each losing at most one unit of this bound. Hence

    Phi >= 2u*n2+(u+w)*n1 + (v-u-w)*T
           +(v-u)*C1+(1-w)*C2 - 4
        >= B*n + (v-u-w)*T + m*(C1+C2) - 6
        >= B*n + D*T - 5*m/alpha - 6.

In the second step, (w-u)e>=-2; in the last, use Corollary 14. If D>=0, B>=1 immediately gives Phi>=n-5m/alpha-6. If D<0, T<=n1<=alpha*n+2 gives

    Phi >= (B+alpha*D)*n - 5m/alpha - 8.

Now

    B+alpha*D
      = alpha*v+2*beta*u+beta*min(v-u,1-w)
      = min(v+beta*u, alpha*v+2*beta*u+beta*(1-w))
      >=1

by the remaining two published balance inequalities. Therefore, uniformly in t and the input,

    Phi >= n - 8 - 5*min(v-u,1-w)/alpha.

This finite additive constant is sufficient for Theorem 24. If alpha=0, at most two type-1 and four incomplete type-2 containers remain, while 2u>=1; the source's separate Lemma 15 handles this case.

This proof also explains the exact role of the three inequalities: the first pays for the case with few unmatched threshold singletons; the other two pay for the two possible kinds of convenient pair containers.

### Small source-proof caveat

The displayed transition (14) to (15) in the original proof of Lemma 16 multiplies the first balance inequality by n-T/alpha. The preceding displayed estimates alone allow this coefficient to be negative by O(1), because T<=n1<=alpha*n+2. Thus this line requires a sign justification or a bounded-error correction. The direct proof above avoids the issue completely and proves an input-independent constant, so this is **not a failure of the asymptotic claim**. Do not advertise it as a counterexample to AH.

## 4. Strict-infimum pricing covers all offline bins

Fix the interior t and a=1-t. For a bin without a huge item of weight 1, replace every non-tiny item by its permitted lower representative, preserving its weight or increasing it in the x=t_k duplicate case. Every replacement strictly lowers size: ordinary classes are lower-open; a threshold item of weight v has size >t>x; a threshold item of weight u has size >t_k; a huge item of weight w has size >1/2. Therefore the representative total S is strictly less than 1. The actual tiny-item size is at most 1-S. Its weight is rho times size, so filling to capacity with sand upper-bounds the true weight. The empty representative multiset covers a tiny-only bin.

If the bin contains a weight-1 huge item h>=a, its residual capacity is at most t<y. Every other item has size <=t. Thus larger classes cannot occur, and a threshold-class large item has weight u; weight-v threshold items cannot coexist with h. Replace the remaining non-tiny items by class lower representatives. Their total S is strictly less than y, including the empty case S=0. Actual tiny mass is at most t-S<y-S, so the bound is

    1 + sum(representative weights) + rho*(y-S).

This is exactly the second knapsack. It is unnecessary to permit non-tiny representative sums equal to capacity; doing so adds infeasible limiting patterns, which may spuriously worsen the certificate. Conversely, using strict sums is not a relaxation that misses actual bins.

## 5. Uniformity and the global implication

For each fixed parameter set, the rounding errors depend on finitely many class-support sizes. Threshold-class constants depend only on alpha,beta,u,v,w and are bounded over finitely many scenarios. The new t may depend on the whole input without introducing an input-dependent constant. Taking the maximum over the finite scenario set gives a single C.

Consequently, if every scenario's two knapsack bounds are at most R, then every offline bin has total weight at most R, W(I)<=R*OPT(I), and

    AH(I) <= W(I)+C <= R*OPT(I)+C

for every finite input I. This is a genuine asymptotic competitive-ratio theorem, not an extrapolation from finite benchmarks. It works for arbitrary real item sizes as well as rational inputs because the proof uses only comparisons and inequalities.

