"""Independent AH delayed-tiny target verification, standard library only.

Reads source HTML with HTMLParser when available, or a bundled numeric
snapshot with --snapshot, validates parameter mapping, recomputes weights by
an interior midpoint, and searches in descending SIZE order with Fractions.
Does not import the parent's verifier. Use --blend for the final stronger
certificate. Snapshot mode verifies arithmetic but does not re-audit source
extraction; this distinction is recorded in its JSON output.
"""
from html.parser import HTMLParser
from fractions import Fraction as Q
from pathlib import Path
import json, re, time, sys

ROOT = Path(__file__).resolve().parents[1]
D = Q(1,43)
R = Q(1899077696629320230341312379790758794811611,
      1203294576680198570840322318297231041495040)
OLD = Q(1848920194883516152323541607,1171513518439186595284254720)
BLEND_TARGET=Q(87931323061219230147063794829048504459349,
               55715094120735551199336133222286481162240)

class Tables(HTMLParser):
    def __init__(self):
        super().__init__(); self.tables={}; self.table=None
        self.row=None; self.cell=None; self.math=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='math':
            self.math+=1
            if self.cell is not None:self.cell.append(a.get('alttext',''))
            return
        if self.math:return
        if tag=='table':
            self.table=a.get('id');self.tables[self.table]=[]
        elif tag=='tr' and self.table is not None:self.row=[]
        elif tag in ('td','th') and self.row is not None:self.cell=[]
    def handle_endtag(self,tag):
        if tag=='math':self.math-=1;return
        if self.math:return
        if tag in ('td','th') and self.cell is not None:
            self.row.append(' '.join(self.cell).strip());self.cell=None
        elif tag=='tr' and self.row is not None:
            self.tables[self.table].append(self.row);self.row=None
        elif tag=='table':self.table=None
    def handle_data(self,data):
        if not self.math and self.cell is not None:self.cell.append(data)

def fraction(s):
    m=re.search(r'\\frac\{([0-9]+)\}\{([0-9]+)\}',s)
    if m:return Q(int(m[1]),int(m[2]))
    return Q(re.split(r'\\approx|=',s)[0].strip())

def get_source(use_snapshot=False):
    use_snapshot=use_snapshot or not (ROOT/'packing_work/ah.html').exists()
    cs={};ext={}
    if use_snapshot:
        snapshot=json.loads((ROOT/'packing_work/source_numeric_snapshot.json').read_text())
        for js,c in snapshot['classes'].items():
            cs[int(js)]={'lo':Q(c['lo']),'hi':Q(c['hi']),
                        'alpha':{int(i):Q(v) for i,v in c['alpha'].items()},
                        'vol':{int(i):Q(v) for i,v in c['vol'].items()}}
        for p in snapshot['scenarios']:
            key=Q(p['x']),Q(p['y'])
            assert key not in ext
            ext[key]={k:Q(p[k]) for k in ('u','v','w') if k in p}
    else:
        parser=Tables();parser.feed((ROOT/'packing_work/ah.html').read_text())
        tables=parser.tables
        for row in tables['A1.T1.1'][2:]:
            j=int(row[0])
            lo=fraction(row[1]) if row[1] else cs[j]['lo']
            hi=fraction(row[2]) if row[2] else cs[j]['hi']
            rec=cs.setdefault(j,{'lo':lo,'hi':hi,'alpha':{},'vol':{}})
            assert rec['lo']==lo and rec['hi']==hi
            if j==1:continue
            if j==212:
                i=int(re.search(r'A_\{([0-9]+),212\}',row[3])[1])
                vol=fraction(row[3].split('=')[1])
            else:i=int(row[3]);vol=i*hi
            rec['alpha'][i]=fraction(row[4]);rec['vol'][i]=vol
        for j in range(6,166):
            lo=Q(7,20)-Q(j-5,9600);hi=lo+Q(1,9600)
            cs[j]={'lo':lo,'hi':hi,
                   'alpha':{1:Q(22145926,78181827),2:Q(56035901,78181827)},
                   'vol':{1:hi,2:2*hi}}
        for table in ('A2.T2.1','A2.T3.1'):
            for row in tables[table][1:]:
                ints=re.findall(r'\\frac\{([0-9]+)\}\{([0-9]+)\}',row[1 if table.endswith('T2.1') else 0])
                assert len(ints)==2
                x,y=(Q(int(a),int(b)) for a,b in ints)
                if table.endswith('T2.1'):weights={'w':fraction(row[2])}
                else:weights={a:fraction(b) for a,b in zip(('u','v','w'),row[1:4])}
                assert (x,y) not in ext
                ext[x,y]=weights
    assert set(cs)==set(range(1,213))
    for j in range(1,212):assert cs[j]['lo']==cs[j+1]['hi']
    for j,a,b,eps in [(167,1,3,Q(101,1000000)),
        (172,2,6,Q(203907985616802938880,661406035963546729717373)),
        (179,10,2,Q(56254421499138925905512741470208,47449963408280619234481631165243337))]:
        cs[j]['alpha'][a]-=eps;cs[j]['alpha'][b]+=eps
    for j in range(2,213):
        assert sum(cs[j]['alpha'].values())==1
        assert all(a>0 for a in cs[j]['alpha'].values())
        assert all(D<=v<=1 for v in cs[j]['vol'].values())
    points={Q(0),Q(1,2)}
    for j,c in cs.items():
        points.update(v for v in (c['lo'],c['hi']) if 0<=v<=Q(1,2))
        for v in c['vol'].values():
            points.update(z for z in (v,1-v) if 0<=z<=Q(1,2))
    points=sorted(points);ps=[]
    for x,y in zip(points,points[1:]):
        mid=(x+y)/2
        k=next(j for j,c in cs.items() if c['lo']<mid<c['hi'])
        if y<=Q(1,6):p={'w':Q(0)}
        elif Q(3,10)<=x<y<=Q(1,3):p={'w':Q(413913,524288)}
        else:p=ext[x,y].copy()
        p.update(x=x,y=y,k=k);ps.append(p)
    assert len(ps)==402
    # Independently check the parent's serialized mapping, not its results.
    comparison=ROOT/'packing_work/final_extension_certificate.json'
    if not comparison.exists():comparison=ROOT/'packing_work/refinement_exact_maxima.json'
    ref=json.loads(comparison.read_text())
    for js,c in ref['classes'].items():
        j=int(js)
        assert cs[j]['lo']==Q(c['lo']) and cs[j]['hi']==Q(c['hi'])
        for name in ('alpha','vol'):
            assert cs[j][name]=={int(i):Q(v) for i,v in c[name].items()}
    for p,s in zip(ps,ref['scenarios']):
        for k,v in p.items():assert v==(int(s[k]) if k=='k' else Q(s[k]))
    return cs,ps

def candidates(cs,p,huge,c):
    t=(p['x']+p['y'])/2;a=1-t;w=p['w'];k=p['k']
    assert 0<=w<=1
    if k<=165:
        u,v=p['u'],p['v'];al=cs[k]['alpha'].get(1,Q(0));be=cs[k]['alpha'][2]
        assert 0<=u<=v<=1 and be>0
        assert u*(al+2*be)+w*al>=1
        assert u*be+v>=1
        assert v*al+2*u*be+(1-w)*be>=1
    vals={1:w}
    for j,cl in cs.items():
        if j==1 or j==k and k<=165:continue
        required=Q(0)
        for i,al in cl['alpha'].items():
            volume=(cl['lo']+cl['hi'])/2 if i==1 and j<=165 else cl['vol'][i]
            charge=(Q(1) if volume>=a else w) if volume>Q(1,2) else (Q(1) if volume>t else 1-w)
            required+=al*charge
        denom=sum(al*(cl['vol'][i]-c if j==212 else i) for i,al in cl['alpha'].items())
        vals[j]=required/denom
    ans=[]
    for j in range(k if huge else 1,212):
        if j==k and k<=165:
            ans.append((cs[j]['lo'],p['u'],str(j)+'u'))
            if not huge:ans.append((p['x'],p['v'],str(j)+'v'))
        else:ans.append((cs[j]['lo'],vals[j],str(j)))
    return ans,vals[212]

def fill(r,c):
    q=r//D;e=r-q*D
    return 2*r-q*c-min(e,c)

def prove(candidates,capacity,rho,c,offset,target=R,theta=Q(1),oldrho=None):
    if oldrho is None:oldrho=rho
    lower_density=theta*rho+(1-theta)*oldrho
    upper_density=theta*rho*(2-c/D)+(1-theta)*oldrho
    def sand(r):return theta*rho*fill(r,c)+(1-theta)*oldrho*r
    # Eliminate dominated representatives by checking each one against ALL
    # other distinct sizes, rather than using the parent's running frontier.
    bysize={}
    for s,w,n in candidates:
        if s not in bysize or w>bysize[s][0]:bysize[s]=(w,n)
    triples=[(s,w,n) for s,(w,n) in bysize.items() if 0<s<capacity]
    kept=[]
    for s,w,n in triples:
        if w<=lower_density*s:continue
        if any(z<s and v>=w for z,v,_ in triples):continue
        kept.append((s,w,n))
    kept.sort(reverse=True) # Descending SIZE, not density.
    density=[upper_density]*(len(kept)+1)
    for i in range(len(kept)-1,-1,-1):density[i]=max(density[i+1],kept[i][1]/kept[i][0])
    nodes=0
    def check(i,space,val,path):
        nonlocal nodes
        nodes+=1
        weight=offset+val+sand(space)
        assert weight<=target,('counterexample',weight,capacity,c,path,space)
        if i==len(kept) or offset+val+space*density[i]<=target:return
        s,w,name=kept[i]
        # Enumerate multiplicity with an exact strict comparison; no integer
        # capacity scaling or floating-point branch test.
        multiplicity=0
        while multiplicity*s<space:
            check(i+1,space-multiplicity*s,val+multiplicity*w,path+[(name,multiplicity)] if multiplicity else path)
            multiplicity+=1
    check(0,capacity,Q(0),[])
    return nodes,len(kept)

def run(blend=False,use_snapshot=False):
    use_snapshot=use_snapshot or not (ROOT/'packing_work/ah.html').exists()
    start=time.time();cs,ps=get_source(use_snapshot);total=0;log=[]
    target=BLEND_TARGET if blend else R
    special={(Q(533,1600),Q(1,3)),(Q(3,7),Q(1,2))}
    for no,p in enumerate(ps):
        selected=(p['x'],p['y']) in special
        c=(Q(1,60) if blend else Q(1,44)) if selected else D
        theta=Q(7,60) if selected and blend else Q(1)
        for huge in (False,True):
            cand,rho=candidates(cs,p,huge,c)
            _,oldrho=candidates(cs,p,huge,D)
            nodes,types=prove(cand,p['y'] if huge else Q(1),rho,c,Q(int(huge)),target,theta,oldrho)
            total+=nodes
            log.append({'x':str(p['x']),'y':str(p['y']),'huge':huge,'c':str(c),'theta':str(theta),'nodes':nodes,'kept':types})
        if no%50==0:print('verified',no+1,'scenarios; nodes',total,flush=True)
    assert target<OLD
    out={'pass':True,'source_mode':'numeric_snapshot' if use_snapshot else 'independent_html_parser',
         'target':str(target),'old_target':str(OLD),'improvement':str(OLD-target),
         'scenarios':len(ps),'cases':len(log),'nodes':total,'seconds':time.time()-start,'details':log}
    path='independent_blend_verification.json' if blend else 'independent_delayed_tiny_verification.json'
    if use_snapshot:path=path.replace('_verification.json','_snapshot_verification.json')
    (ROOT/'ah_audit'/path).write_text(json.dumps(out,indent=2))
    print({k:v for k,v in out.items() if k!='details'},flush=True)

if __name__=='__main__':run('--blend' in sys.argv,'--snapshot' in sys.argv)
