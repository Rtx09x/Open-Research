# A causal robust realization of the supplied t=3 tight-face witness

This establishes a limitation of the **original finite-depth adversary tree**,
not an upper bound for arbitrary online bin-packing inputs. It closes the
possible chronology/offset-spread loophole for the supplied nine-type witness.
The numerical ratio is deliberately the dossier's `r=3857/2500=1.5428`.

## 1. Robust flow lifting lemma

Consider a finite tree of batches. Branches are identifiable from the next
incoming item before any branch-specific placement is required; histories
indistinguishable to the algorithm use the same schedule. Suppose a rational
flow specifies all parent-bin-to-descendant-bin refinements. Each descendant
is a word of future item placements extending its parent, each stage has the
correct item counts, and every placement-induced binary label is determined
by that word's already executed prefix. Suppose every complete word fits for
**all** sizes allowed by its labels, and bins only receive positive-size
items. Then, after multiplying by a common denominator, the flow is realized
by a deterministic online placement policy on this restricted tree.

Proof: create the specified integral copies of each parent bin. At each
revealed branch, partition parent copies among the required descendant words.
When the next item arrives, put it into the next scheduled slot. All earlier
slots in that bin have already been filled, so its action label is as
specified. Its full word fits uniformly, hence every prefix fits. Exact
flow balance makes all slots and batches finish together. No item size or
branch is used before it is observable. This is induction over the tree.

The lemma needs more than an endpoint configuration LP: information-set
compatibility, ordered labels, and uniform capacities are essential. It says
nothing about arbitrary inputs outside the tree. If the first batch has one
known size type, periodic integral macroblocks allow its unknown length to
be handled with a constant-size remainder, rather than requiring advice on N.

## 2. The supplied prefix really is realizable

Let the nine prefix types and masses be exactly those in the attachment, with
types ordered `(C3,C2,A)`. They satisfy, in exact rational arithmetic,

* each of the three item totals is 1 per N;
* C3-stage bins: `551/105000 = r/294`;
* C2-stage bins: `551/15000 = r/42`;
* A-stage bins: `3857/15000 = r/6`;
* A-opened bins: `551/2500 = r/7`.

An explicit schedule fills the C3 slots, then C2 slots, then A slots in bins
already containing tiny items, then creates the A-only bins. The first A in
each A-only bin is large, and all other A items are small. Each A-only bin is
filled before starting the next. This is entirely causal.

Use the exact upper bounds

`C3=1/294-294 eps`, `C2=1/49+4 eps/7`,
`L=1/7+2 eps/7`, `S=1/7+(eps+gamma)/7`.

Every supported bin fits for `0<eps<2058^-3`, `0<gamma<eps/4`, regardless
of individual offsets produced by the online separator. The two prefix
patterns of base volume exactly 1 are `(6,20,4)` and `(288,1,0)`; their
perturbation coefficients are negative, so they are safe as well.

## 3. Explicit completions for all three original branches

Write `P2=(0,0,2)`, `P4=(0,0,4)`, and `Q=(0,6,1)`. All prefix types not
mentioned below receive no suffix items. All masses are per N.

### B11 branch

Put one B11 in every P2 and Q bin. Open `3857/15000` new bins with one B11
each. The total cost is `r/3`.

### B21, optionally followed by B22

Put two B21 in every P2 and Q bin, and one B21 in every P4 bin. Open:

* `1143/5000` bins with one B21 each;
* `857/3000` bins with two B21 each.

If B22 arrives, put one into each newly opened single-B21 bin, and open
`3857/5000` further bins containing one B22 each. Stage costs are `r/2`
and `r`.

### B31, optionally followed by B32

Leave P2 bins untouched during B31. Put one B31 in each P4 and two in each Q.
Open:

* `587207/3750000` bins with one B31 each;
* `1033693/3000000` bins with two B31 each.

If B32 arrives, put one in every P2 bin and every new single-B31 bin, and
open `3791431/5000000` further one-B32 bins. With `x=551/2500`, stage costs
are exactly `r(7-5x)/12` and `r(7-5x)/6`.

These completions use only the original shared prefix; no future branch is
needed when packing that prefix. Each second-stage plan extends the actual
first-stage packing.

## 4. The published offline budgets are exact here

Assign each item its unperturbed base size:

`C3 ->1/294`, `C2 ->1/49`, `A ->1/7`,
`B11,B22,B32 ->1/2`, `B21 ->1/3`, `B31 ->5/14`.

These all lie in `(1/294) Z`. Every actual item is bigger than `1/295`,
so a feasible bin contains at most 294 items. No item is smaller than its
base minus `294 eps`. If a bin's base total exceeded 1, it would be at
least `1+1/294`, and its actual total would exceed

`1+1/294 - 294^2 eps > 1`

because `eps<2058^-3<294^-3`. This is impossible. Thus the base sizes form
a valid offline dual. Their total at each of the eight stops is precisely
the corresponding published offline upper bound:

`N/294, N/42, N/6, N/3, N/2, N, (7-5x)N/12, (7-5x)N/6`.

The source's constructive packings attain these values for integral batch
counts. Hence the eight optimal costs are exactly those values. The
counterstrategy's eight ratios are therefore exactly r, not just ratios to
unproved surrogate denominators.

## 5. Uniform online strategy and scope

A common period for all masses, integral completion counts, and the required
`6*7^3` divisibility is `D=2418150000000`. If imposing the source's stronger
convenient convention `N=M*42^3`, use `lcm(D,42^3)=9D=21763350000000`.
For N divisible by D, repeat complete C3 macroblocks,
then fill their prescribed later slots once a new item type reveals the
phase change. This does not require knowing N in advance. The three suffix
branches have disjoint first-item size ranges, so branch detection is causal.

For general N, complete `floor(N/D)` blocks and treat the remainder with at
most O(D) extra bins. All induced batch-count discrepancies are O(D), since
the original branch counts are affine in N and the number of large A items.
Thus a single deterministic policy handles this entire original t=3 family
with ratio at most `1.5428+O(D/N)`. It can be extended to arbitrary other
inputs by any legal fallback, with no claimed global competitive guarantee.

This does not exclude improvements from a new adversarial branch, greater
depth, or changes to the modelled item geometry. It proves that numerical
spread of the original A separator and unmodelled placement chronology
cannot invalidate this particular robust witness. The enriched negative
certificates in the dossier were not supplied, so the theorem has not been
applied to those larger trees.

## Verification

`python lower_structure/verify_robust_history.py` uses only the standard
library and checks the JSON certificate by exact Fraction arithmetic.
The discovery script uses SciPy only to select a sparse support, followed
by exact rational Gaussian elimination; its floating result is not used
as proof. The causal and base-volume arguments above are mathematical
proofs accompanying the finite arithmetic certificate.
