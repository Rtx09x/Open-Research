"""Exact standard-library verifier for the t=3 robust causal history certificate.

Run: python lower_structure/verify_robust_history.py
This checks arithmetic and uniform upper capacities. The causal lifting argument
is given separately in robust_history_theorem.md.
"""
from fractions import Fraction as F
import json
from pathlib import Path

path=Path(__file__).with_name('robust_history.json')
data=json.loads(path.read_text())
r=F(data['r']); E=F(data['epsilon_upper']); x=r/7; z=r/6
assert r==F(3857,2500) and E==F(1,2058**3)
S={'C3':(F(1,294),F(-294),F(0)),
   'C2':(F(1,49),F(4,7),F(0)),
   'L':(F(1,7),F(2,7),F(0)),
   'S':(F(1,7),F(1,7),F(1,7)),
   'B11':(F(1,2),F(1),F(0)),
   'B21':(F(1,3),F(1,3),F(0)),
   'B22':(F(1,2),F(1,2),F(0)),
   'B31':(F(5,14),F(-1,7),F(-3,14)),
   'B32':(F(1,2),F(0),F(1,14))}
def add(*parts):return tuple(sum(S[t][j]*n for t,n in parts) for j in range(3))
def feasible(v):
    b,e,g=v
    return b<=1 and b+max(F(0),e+max(F(0),g)/4)*E<=1
P=[]
for v in data['prefix']:
    c,d,a=v['type']; mass=F(v['mass']); large=int(c==d==0 and a>0)
    p=add(('C3',c),('C2',d),('L',large),('S',a-large))
    assert mass>0 and feasible(p)
    assert list(map(str,p))==v['upper_volume']
    assert (mass*data['period']).denominator==1
    P.append((c,d,a,large,mass,p))
assert all(sum(p[j]*p[4] for p in P)==1 for j in range(3))
assert sum(p[3]*p[4] for p in P)==x
assert sum(p[4] for p in P)==z
assert sum(p[4] for p in P if p[0])==r/294
assert sum(p[4] for p in P if p[0] or p[1])==r/42
branch_cases=[('B11','B11',None,F(1,3),F(0),F(1,3),None),
              ('B21_B22','B21','B22',F(1),F(1),F(1,2),F(1)),
              ('B31_B32','B31','B32',7*(1-x)/6,(7-5*x)/6,(7-5*x)/12,(7-5*x)/6)]
checked=0
for name,first,second,bcount,hcount,opt1,opt2 in branch_cases:
    tally=[F(0)]*len(P); n1=n2=total_b=total_h=F(0)
    for v in data[name]:
        parent=v['parent']; k=v['first']; h=v['second']; mass=F(v['mass'])
        assert mass>0 and (mass*data['period']).denominator==1
        assert (second is not None) or h==0
        if parent>=0:
            tally[parent]+=mass; base=P[parent][-1]
        else:
            assert parent==-1 and k+h>0
            base=(F(0),F(0),F(0))
            if k:n1+=mass
            else:n2+=mass
        extra=add((first,k),*([(second,h)] if second else []))
        volume=tuple(a+b for a,b in zip(base,extra))
        assert feasible(volume) and list(map(str,volume))==v['upper_volume']
        total_b+=mass*k;total_h+=mass*h;checked+=1
    assert tally==[p[4] for p in P]
    assert total_b==bcount and total_h==hcount
    assert z+n1==r*opt1
    if opt2 is not None:assert z+n1+n2==r*opt2

# Discrete base-volume dual: every actual item >1/295; each can fall
# below its base by at most294 epsilon; 294 items cannot offset one
# lattice unit1/294. Thus any feasible bin has total base at most1.
assert F(1,294)-294*E>F(1,295)
assert F(1,294)>294*294*E
assert all((s[0]*294).denominator==1 for s in S.values())
assert all(e+min(F(0),g)/4 >= -294 for b,e,g in S.values())
print(f'PASS: {len(P)} prefix patterns, {checked} branch patterns; all 8 exact stop costs; robust capacities and base-volume dual.')
print('Exact macroblock period:',data['period'])
