"""Independently parse AH primary HTML and verify exact strict knapsacks.

Uses only lxml for source extraction; certificate checker below is Fraction based.
Research task tree: parse source -> reconstruct all scenarios -> validate weights
-> certify both knapsacks -> inspect maximizers for global structural constraints.
"""
from fractions import Fraction as F
from pathlib import Path
from math import lcm
import json, re, time, sys

HERE=Path(__file__).resolve().parent
RSTAR=F(1848920194883516152323541607,1171513518439186595284254720)
R0=F(10060574276093395247,6374352691333693440)

def rat(s):
    s=s.split(r'\approx')[0].split('=')[0].strip()
    m=re.search(r'\\frac\{(\d+)\}\{(\d+)\}',s)
    if m:return F(int(m[1]),int(m[2]))
    return F(s)

def interval(s):
    fs=re.findall(r'\\frac\{(\d+)\}\{(\d+)\}',s)
    assert len(fs)==2,s
    return tuple(F(int(a),int(b)) for a,b in fs)

def source():
    if '--snapshot' in sys.argv or not (HERE/'ah.html').exists():
        raw=json.loads((HERE/'source_numeric_snapshot.json').read_text())
        cs={int(j):{'lo':F(c['lo']),'hi':F(c['hi']),
            'alpha':{int(i):F(v) for i,v in c['alpha'].items()},
            'vol':{int(i):F(v) for i,v in c['vol'].items()}}
            for j,c in raw['classes'].items()}
        ps=[{k:int(v) if k=='k' else F(v) for k,v in p.items()} for p in raw['scenarios']]
        return cs,ps
    from lxml import html
    tree=html.parse(str(HERE/'ah.html')).getroot()
    def rows(tid):
        out=[]
        for row in tree.xpath('//*[@id="'+tid+'"]//tr'):
            cells=[]
            for c in row.xpath('./td|./th'):
                ms=c.xpath('.//math')
                cells.append(ms[0].get('alttext') if ms else ''.join(c.itertext()).strip())
            out.append(cells)
        return out
    classes={}
    for row in rows('A1.T1.1')[2:]:
        j=int(row[0])
        if j not in classes:
            classes[j]={'lo':rat(row[1]),'hi':rat(row[2]),'alpha':{},'vol':{}}
        c=classes[j]
        if j==1:continue
        if j==212:
            i=int(re.search(r'A_\{(\d+),212\}',row[3])[1]);vol=rat(row[3].split('=')[1])
        else:
            i=int(row[3]);vol=i*c['hi']
        c['alpha'][i]=rat(row[4]);c['vol'][i]=vol
    for j in range(6,166):
        hi=F(7,20)-F(j-6,9600);lo=hi-F(1,9600)
        classes[j]={'lo':lo,'hi':hi,'alpha':{1:F(22145926,78181827),2:F(56035901,78181827)},'vol':{1:hi,2:2*hi}}
    classes=dict(sorted(classes.items()))
    scen={}
    for row in rows('A2.T2.1')[1:]:
        x,y=interval(row[1]);scen[x,y]={'w':rat(row[2])}
    for row in rows('A2.T3.1')[1:]:
        x,y=interval(row[0]);scen[x,y]={'u':rat(row[1]),'v':rat(row[2]),'w':rat(row[3])}
    pts={F(0),F(1,2)}
    for j,c in classes.items():
        pts.add(c['lo'])
        for a in c['vol'].values():
            for v in (a,1-a):
                if 0<=v<=F(1,2):pts.add(v)
    pts=sorted(pts);assert len(pts)==403,len(pts)
    allsc=[]
    for x,y in zip(pts,pts[1:]):
        if y<=F(1,6):p={'w':F(0)}
        elif x>=F(3,10) and y<=F(1,3):p={'w':F(413913,524288)}
        else:p=scen[x,y].copy()
        ks=[j for j,c in classes.items() if c['lo']<=x and y<=c['hi']]
        assert len(ks)==1,(x,y,ks)
        p.update(x=x,y=y,k=ks[0]);allsc.append(p)
    assert len(allsc)==402
    return classes,allsc

def modify(classes):
    transfers=[(167,1,3,F(101,1000000)),(172,2,6,F(203907985616802938880,661406035963546729717373)),(179,10,2,F(56254421499138925905512741470208,47449963408280619234481631165243337))]
    for j,i,k,d in transfers:
        classes[j]['alpha'][i]-=d;classes[j]['alpha'][k]+=d
    for j,c in classes.items():
        if j==1:continue
        assert sum(c['alpha'].values())==1
        assert all(a>0 for a in c['alpha'].values())
        if j!=212:assert max(c['alpha'])*c['hi']<=1

def basic_required(j,i,vol,p):
    x,y,w=p['x'],p['y'],p['w']
    if vol>F(1,2):
        assert vol<=1-y or vol>=1-x,(p,j,i,vol)
        return w if vol<=1-y else F(1)
    # Basic large singleton exact size is on one side for all items in its class.
    if 2<=j<=165 and i==1:
        assert j!=p['k']
        return 1-w if j>p['k'] else F(1)
    assert vol<=x or vol>=y,(p,j,i,vol)
    return 1-w if vol<=x else F(1)

def weights(classes,p):
    vals={1:p['w']};k=p['k']
    assert 0<=p['w']<=1
    if k<=165:
        a=classes[k]['alpha'];a1=a.get(1,F(0));a2=a[2];u,v,w=p['u'],p['v'],p['w']
        assert 0<=u<=v<=1
        assert u*(a1+2*a2)+w*a1>=1
        assert u*a2+v>=1
        assert v*a1+2*u*a2+(1-w)*a2>=1
    for j,c in classes.items():
        if j==1:continue
        if j==k and k<=165:continue
        req=sum(a*basic_required(j,i,c['vol'][i],p) for i,a in c['alpha'].items())
        denom=sum(a*(c['vol'][i]-F(1,43) if j==212 else i) for i,a in c['alpha'].items())
        vals[j]=req/denom
    assert 0<vals[212]<=2
    return vals

def candidates(classes,p,huge=False):
    vals=weights(classes,p);rho=vals[212];k=p['k'];out=[]
    for j in range(k if huge else 1,212):
        s=classes[j]['lo']
        if j==k and k<=165:
            out.append((s,p['u'],f'{j}u'))
            if not huge:out.append((p['x'],p['v'],f'{j}v'))
        else:out.append((s,vals[j],str(j)))
    return out,rho

def maximize(cand,cap,rho,offset=F(0),target=None):
    # Exact bounded-depth branch and bound. The sand is continuous; items strict.
    # Negative reduced profit can always be replaced by sand, so remove it.
    # A no-larger representative of at least equal weight dominates another.
    best_weight=F(-1);undominated=[]
    for s,w,name in sorted(cand,key=lambda x:(x[0],-x[1])):
        if w>best_weight:undominated.append((s,w,name));best_weight=w
    bysize={}
    for s,w,name in undominated:
        g=w-rho*s
        if g<=0 or s>=cap:continue
        if s not in bysize or g>bysize[s][0]:bysize[s]=(g,name,w)
    items=sorted([(s,g,n,w) for s,(g,n,w) in bysize.items()],key=lambda t:t[1]/t[0],reverse=True)
    scale=lcm(cap.denominator,*[s.denominator for s,g,n,w in items])
    capacity=int(cap*scale)-1
    sizes=[int(s*scale) for s,g,n,w in items]
    gains=[g for s,g,n,w in items]
    density=[g/s for s,g,n,w in items]
    base=offset+rho*cap
    best=F(0);bestpat=[];nodes=0
    if target is not None: best=target-base
    def dfs(start,remaining,gain,pat):
        nonlocal best,bestpat,nodes
        nodes+=1
        if gain>best:
            best=gain;bestpat=pat.copy()
        while start<len(items) and sizes[start]>remaining:start+=1
        if start==len(items):return
        if gain+F(remaining,scale)*density[start]<=best:return
        nmax=remaining//sizes[start]
        for n in range(nmax,-1,-1):
            g=gain+n*gains[start];r=remaining-n*sizes[start]
            if n:pat.append((items[start][2],n))
            dfs(start+1,r,g,pat)
            if n:pat.pop()
    dfs(0,capacity,F(0),[])
    return base+best,bestpat,nodes

def stringify(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):stringify(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [stringify(a) for a in x]
    return x

def run(original=False):
    cs,ps=source()
    if not original:modify(cs)
    results=[];start=time.time();totalnodes=0
    for no,p in enumerate(ps):
        cases=[]
        for huge in (False,True):
            cand,rho=candidates(cs,p,huge)
            val,pat,nodes=maximize(cand,p['y'] if huge else F(1),rho,F(int(huge)))
            cases.append({'huge':huge,'max':val,'pattern':pat,'nodes':nodes})
            totalnodes+=nodes
        results.append(dict(p, cases=cases))
        if no%50==0:print('progress',no,'nodes',totalnodes,flush=True)
    mx=max(q['max'] for r in results for q in r['cases'])
    print('maximum',str(mx),float(mx),'scenarios',len(ps),'nodes',totalnodes,'sec',time.time()-start)
    print('target passed',mx<=(R0 if original else RSTAR))
    for r in sorted(results,key=lambda r:max(q['max'] for q in r['cases']),reverse=True)[:12]:print(stringify(r))
    out={'classes':cs,'scenarios':results,'max':mx,'nodes':totalnodes}
    (HERE/('original_reconstruction.json' if original else 'refinement_reconstruction.json')).write_text(json.dumps(stringify(out),indent=2))
    return cs,ps,results

if __name__=='__main__':run('--original' in sys.argv)
