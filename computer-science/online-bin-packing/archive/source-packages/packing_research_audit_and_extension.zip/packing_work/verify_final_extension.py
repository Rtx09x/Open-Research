"""Exact full certificate for AH with deferred tiny-container closure.

Only two scenario analyses use the convex combination of original tiny weights
and the overflow charge at c=1/60; mixture coefficient is 7/60. All other
scenario weights and all non-tiny weights remain the published values.
"""
from fractions import Fraction as F
from pathlib import Path
import json,time,hashlib
from reconstruct_ah import source,modify,candidates,basic_required,RSTAR,stringify,maximize

HERE=Path(__file__).resolve().parent
d=F(1,43)
c=F(1,60)
theta=F(7,60)
RNEW=F(87931323061219230147063794829048504459349,55715094120735551199336133222286481162240)

def excess(r):
    q=r//d
    return q*(d-c)+max(F(0),r-q*d-c)

def charge_coefficients(classes,p):
    tiny=classes[212]
    avg=sum(a*tiny['vol'][i] for i,a in tiny['alpha'].items())
    req=sum(a*basic_required(212,i,tiny['vol'][i],p) for i,a in tiny['alpha'].items())
    rd=req/(avg-d);rc=req/(avg-c)
    return (1-theta)*rd+theta*rc,theta*rc

def price_blend(cand,cap,a,b,offset=F(0)):
    """Exact maximum, with strict non-tiny infimum capacity and no float use."""
    bestw=F(-1);items=[]
    for s,w,name in sorted(cand,key=lambda t:(t[0],-t[1])):
        if w<=bestw:continue
        bestw=w
        if s<cap and w>a*s:items.append((s,w,name))
    beta=a+b*(1-c/d)
    items.sort(key=lambda t:t[1]/t[0],reverse=True)
    density=[w/s for s,w,n in items]
    best=offset+a*cap+b*excess(cap);bestpat=[];nodes=0
    def dfs(start,room,value,pat):
        nonlocal best,bestpat,nodes
        nodes+=1
        score=offset+value+a*room+b*excess(room)
        if score>best:best=score;bestpat=pat.copy()
        while start<len(items) and items[start][0]>=room:start+=1
        if start==len(items):return
        if offset+value+room*max(beta,density[start])<=best:return
        s,w,name=items[start]
        nmax=(room/s).__ceil__()-1
        for n in range(nmax,-1,-1):
            if n:pat.append((name,n))
            dfs(start+1,room-n*s,value+n*w,pat)
            if n:pat.pop()
    dfs(0,cap,F(0),[])
    return best,bestpat,nodes

def run():
    cs,ps=source()
    source_hash=hashlib.sha256((HERE/'source_numeric_snapshot.json').read_bytes()).hexdigest()
    modify(cs);start=time.time();out=[];nodes=0;maxval=F(0)
    for p in ps:
        selected=(p['x'],p['y']) in [(F(533,1600),F(1,3)),(F(3,7),F(1,2))]
        cases=[]
        for huge in (False,True):
            cand,rho=candidates(cs,p,huge);cap=p['y'] if huge else F(1)
            if selected:
                a,b=charge_coefficients(cs,p)
                value,pat,count=price_blend(cand,cap,a,b,F(int(huge)))
            else:
                a,b=rho,F(0)
                value,pat,count=maximize(cand,cap,rho,F(int(huge)))
            assert value<=RNEW,(p,huge,value,pat)
            nodes+=count;maxval=max(maxval,value)
            cases.append(dict(huge=huge,maximum=value,pattern=pat,nodes=count))
        out.append(dict(p,tiny_linear=a,tiny_hinge=b,tiny_hinge_at=c if selected else None,cases=cases))
    assert len(out)==402 and sum(1 for p in out if p['k']<=165)==164
    assert maxval==RNEW
    result=dict(status='PASS',R=RNEW,R_decimal=float(RNEW),RSTAR=RSTAR,improvement=RSTAR-RNEW,
        original_source_sha256=source_hash,classes=cs,scenarios=out,
        scenario_count=len(out),knapsack_count=2*len(out),large_balance_count=3*164,
        nodes=nodes,seconds=time.time()-start,c=c,theta=theta)
    (HERE/'final_extension_certificate.json').write_text(json.dumps(stringify(result),indent=2))
    print('PASS: 402 scenarios, 804 exact strict knapsacks, 492 large-class balance inequalities.')
    print('Exact R:',RNEW,'~',float(RNEW))
    print('Exact improvement:',RSTAR-RNEW,'~',float(RSTAR-RNEW))
    print('Nodes:',nodes,'seconds:',time.time()-start)
    for p in out:
        for q in p['cases']:
            if q['maximum']==RNEW:print('Active case:',stringify(dict(x=p['x'],y=p['y'],**q)))

if __name__=='__main__':run()
