# Minimum resistance readings for nominated trees

This standalone extension contains a ten-page research supplement, exact Python reference algorithms and tests, checkable finite optimization certificates, and 15 partially formalized Lean statements. Start with the PDF or editable Word document in `documents/`.

## What is proved

For a nominated positive weighted tree on n accessible labeled vertices, alternatives may be any same-label simple network with finite nonnegative conductances, including cycles, additions, deletions, and disconnected components. Measurements are exact scalar pair effective resistances; disconnected pairs return physical infinity. Zero conductance and an absent edge mean the same electrical network.

- A nominated path needs exactly n certificate readings for n >= 3.
- A nominated star needs exactly binom(n-1,2) + 2 certificate readings for n >= 3.
- A singleton needs 0 readings and a two-vertex tree needs 1.
- For any nominated tree, among designs REQUIRED TO INCLUDE EVERY TREE-EDGE PAIR, the exact minimum is n-1 + tau(T). Here tau(T) is the minimum number of tree paths covering every two-edge turn. Leaf-pair paths suffice for this finite optimization.
- An eight-vertex double-star with three leaves at each center has restricted optimum 16. This is also an unrestricted upper bound, disproving a proposed unrestricted formula that would give 18. It does not prove an unrestricted optimum of 16.

A certificate's size equals the deterministic minimax cost of verifying a fixed nominated weighted tree. It also bounds the realized accepting transcript of any exact reconstruction algorithm. It is not the global cost of discovering an unknown topology. Nominated-center/order reconstruction branches infer unknown weights and use an all-pairs fallback if the candidate fails. The unrestricted certificate optimum for a general tree remains a genuine open gap in this extension.

No fault-count, monotonicity, noisy-measurement, hidden-vertex, or parallel-component identification guarantee is implicit. Changing those promises changes the problem. In particular, the necessity witness uses two decreases and one addition. The original baseline matters when a separate fault-budget restriction is imposed.

## Contents

- `documents/`: final PDF and editable DOCX with full proofs and primary-source references.
- `research/universal_fault_framework/`: exact resistance oracle helpers, universal reconstruction, finite-hypothesis optimal planning, and its regression tests. The finite planner requires an explicit finite family; it does not discretize or solve arbitrary continuous severity models. Duplicate list entries receive distinct default labels unless equal labels are supplied.
- `research/tree_certificate_optimality/`: optimal nominated-star/path binary verifiers, safe unknown-magnitude reconstruction branches, lower-bound constructions, and tests.
- `research/tree_turn_cover/`: exact turn-cover optimizer, a separate optimality-certificate checker, weighted verifier, triangle witnesses, tests, and example DP certificates.
- `plan_tree.py`: command-line wrapper for structural turn-cover optimization.
- `examples/double_star_3_3.json`: a portable example with total restricted count 16.
- `lean/`: clean Lean sources, pinned dependency manifest, build/audit scripts, coverage statement, and successful proof-check logs.
- `run_tests.py`: runs all three Python suites from this package root.
- `SHA256SUMS.txt` and `verify_checksums.py`: verify all distributed files, excluding the checksum list itself.

## Reproduce the Python results

Tested with Python 3.12.14 and SymPy 1.14.0. Use exact integers, fractions, or SymPy rationals rather than binary floating-point weights. The executable helpers target exact rational inputs; the proofs allow arbitrary positive real weights.

From the extracted package directory:

    python3 -m venv .venv
    . .venv/bin/activate
    python -m pip install -r requirements.txt
    python verify_checksums.py
    python run_tests.py

On Windows, activate `.venv\Scripts\activate` instead. No private data, external service, or network request is used by the tests once SymPy is installed. Dependency installation requires normal package access. Do not run the tests with Python assertion optimization enabled.

To compute an exact optimal turn-cover family and a checkable DP table:

    python plan_tree.py examples/double_star_3_3.json --output double_star_plan.json

The input contains `n` and zero-based unordered `edges`; they must form a tree. The returned total is restricted to designs including all tree-edge pairs. The algorithm can take exponential time on larger inputs; no polynomial runtime or unrestricted optimality is claimed.

For separate execution:

    python research/universal_fault_framework/test_reference.py
    python research/tree_certificate_optimality/test_exact.py
    python research/tree_turn_cover/test_exact.py

Run these from the package root because each writes its deterministic results there. `run_tests.py` sets the working directory automatically. It also refreshes `verification/python_suites.log` and `verification/python_summary.json`. Regenerating files or running Lean can change distributed logs; verify the original checksum manifest before reproduction.

## Exact tests and their meaning

The staged bundle was rerun through all three suites before packaging. They include 729 exhaustive four-vertex targets in universal recovery; 729 in the star/path branches and binary verifiers; 1,458 turn-cover verifications; weighted path/star cases; 168 star hiding constructions; 81 pendant-center alternatives; 51 general hidden-turn constructions; and native-integer normalization regressions. Some test families overlap and should not be summed as independent mathematical theorems.

The finite DP output includes both a chosen cover and all recurrence states required to check its lower bound. The verifier rebuilds coverage from the tree and checks every required successor and minimum. These checks certify the finite combinatorial optimum; the electrical proof explains when it equals a measurement optimum. Numerical/exhaustive tests corroborate rather than replace the continuous-weight proofs.

## Lean coverage is partial

The 15 checked declarations comprise nine local real-algebra statements for the hidden triangle and six abstract finite-cover/budget statements. They cover positivity, old-edge decreases, exact inverse-product entries, terminal quadratic forms, attachment-sum arithmetic, and the bounded pivot recurrence and coverage replacement facts.

They DO NOT formalize physical resistance semantics, attachment series decomposition, the separator criterion, local-to-global topology recovery, the full n-1+tau(T) theorem, or the unrestricted path/star optimality proofs. They also do not verify the Python implementation. `lean/COVERAGE.md` states each checked result and exclusion. There are no custom axioms or proof placeholders; recorded dependencies are standard Lean foundations. See `lean/README.md` for pinned reproduction. A full machine-checked proof of the global theorems is not supplied.

## Provenance and classical ingredients

The leaf-path covering condition is the classical **t-cover** of Dress, Huber and Steel, *Lassoing a phylogenetic tree I*, Journal of Mathematical Biology 65 (2012), 77–105, Section 7, p. 99. Their leaf-distance/tree-alternative setting differs from the all-labeled-edge-resistance and arbitrary-network setting proved in this supplement. The latter needs the additional electrical argument; a t-cover alone need not identify a tree.

Primary source: https://www.math.canterbury.ac.nz/~m.steel/Non_UC/files/research/lasso.pdf

The resistance equality/cut-vertex criterion is folklore, explicitly credited in Warton et al., *Graph Inference with Effective Resistance Queries*, ALT 2026, Lemma 7.

Primary source: https://proceedings.mlr.press/v313/warton26a.html

Kron reduction, Laplacian inversion, the implicit-function theorem, and finite set-cover dynamic programming are classical. This package does not establish novelty or publication priority for the exact counts or their combination. It is a standalone extension, not a replacement for a broader research release.
