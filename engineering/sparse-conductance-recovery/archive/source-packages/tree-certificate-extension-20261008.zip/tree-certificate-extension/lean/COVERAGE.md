# Exact coverage of the turn-cover extension

## Nine local algebra statements

Use original edge resistances r,s>0, 0<delta<2r, delta<2s, and

    D = r*s - delta^2/4
    cUV = (s-delta/2)/D
    cVW = (r-delta/2)/D
    cUW = delta/(2D).

The checked propositions are:

1. `determinant_positive`: D>0 under those hypotheses.
2. `all_conductances_positive`: all three displayed conductances are strictly positive.
3. `original_conductances_decrease`: cUV<1/r and cVW<1/s.
4. `original_conductance_changes`: the exact differences are respectively
   delta*(delta-2r)/(4*r*D) and delta*(delta-2s)/(4*s*D), assuming r,s,D nonzero.
5. `grounded_inverse_entries`: all four scalar entries of
   [[cUV+cUW,-cUW],[-cUW,cVW+cUW]] * [[r,delta/2],[delta/2,s]] equal those of I.
   D nonzero is explicit; result 1 supplies it in the physical parameter range.
6. `terminal_quadratic_forms`: the three quadratic forms at (1,0), (0,1), (1,-1)
   evaluate to r, s, r+s-delta.
7. `changed_pair_positive_and_shorter`: 0<r+s-delta<r+s.
8. `unchanged_attachment_sum`: equal local contributions remain equal after adding
   identical left/right contributions. This is just the arithmetic implication.
9. `changed_attachment_sum`: replacing r+s by r+s-delta between identical left/right
   contributions changes their total by exactly delta. Again the series law itself
   is not assumed as an axiom or claimed as checked.

The product identity is expressed entry by entry rather than through a Matrix API.
It is the four actual matrix-multiplication equations; it is not a finite numeric
sample or an unrelated toy matrix. Positivity, change signs, and identities are
quantified over all real parameters satisfying the displayed conditions.

## Six cover/recurrence statements

The abstract model has a query type Q, turn type T, coverage predicate covers(q,t),
and remaining-turn predicate U. A finite query list covers U if each member of U
is covered by some listed query. Feasible(U,k) means such a list of length at most
k exists. No optimum, recurrence, or coverage correctness is postulated.

1. `covers_cons_iff`: q followed by qs covers U iff qs covers U minus covers(q).
2. `remove_selected_query`: removing one occurrence of a selected q from a cover
   leaves a cover of that residual set.
3. `pivot_recurrence`: for any t in U, Feasible(U,k+1) iff some q covering t has
   Feasible(U minus covers(q),k). The forward direction extracts a real occurrence
   from the covering list and proves the smaller length; the reverse constructs it.
4. `zero_budget_iff`: zero-query feasibility iff U is empty.
5. `residual_strict_at_pivot`: the residual is contained in U and excludes the
   chosen covered pivot. This is the set-theoretic strict-decrease fact.
6. `refinement_preserves_budget`: replacing every query by one with a superset of
   its coverage preserves feasibility at the same budget. The output list is
   explicitly mapped and its unchanged length is proved.

These establish the bounded-feasibility form of the recurrence used by the exact
cover solver. They do not verify its Python implementation, bitsets, returned state
table, finite-universe encoding, optimal-family cardinality, or complexity. Lists
may contain duplicates; no claim is made here about a formal Finset minimization
API. The graph-dependent theorem that every tree path extends to a leaf path with
superset coverage is still required to instantiate result 6 for leaf-only designs.

## Explicitly unformalized global obligations

- Construction of the three attached components U,V,W from an actual tree turn.
- Identification of the displayed scalar Laplacian inverse with physical resistance.
- Electrical series decomposition through attached subtrees and the statement that
  exactly U-by-W pairs change.
- Resistance triangle inequality and equality iff a specified vertex separates.
- Local-to-global separator propagation, exact topology and weight recovery.
- The full necessity/sufficiency theorem that the edge-first certificate minimum is
  n-1+tau(T), or its relationship to unrestricted certificate optima.
- Closed forms for stars, paths, double-stars; priority/novelty; noise or statistics.

Consequently the 15 new declarations strengthen the local algebra and optimizer
foundation. They must not be summarized as “the general tree theorem is Lean proved.”
The package contains these 15 checked declarations, not 15 independently formalized paper theorems.
