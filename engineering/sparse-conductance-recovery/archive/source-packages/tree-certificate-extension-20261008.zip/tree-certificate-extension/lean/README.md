# Local triangle algebra and finite cover recurrence

This directory contains 15 checked theorem declarations: nine in TriangleWitness.lean and six in TurnCover.lean. They were checked with Lean 4.34.1 and mathlib commit d13f23b723b8a846827a245b89c10fc7d3f11612. The toolchain and all transitive dependency revisions are pinned in the supplied files.

Partial coverage is essential: this does not formalize graph resistance semantics, separator theorems, the complete general-tree certificate theorem, or the Python solver. COVERAGE.md lists the exact statements and exclusions. Comments referring to a mathematical source note are descriptive provenance; the self-contained sources need only the dependencies declared here.

## Reproduce

Install the official Lean/elan toolchain manager, enter this directory, and run:

    MATHLIB_NO_CACHE_ON_UPDATE=1 lake update
    lake exe cache get Mathlib.Tactic.FieldSimp Mathlib.Tactic.Ring Mathlib.Tactic.Linarith Mathlib.Basic.Real.Basic
    bash verify.sh

These commands need network access or a compatible local dependency cache. The repository excludes .lake and compiled dependency caches. Set XDG_CACHE_HOME to a writable location if needed. The supplied manifest pins the package revisions; do not replace it with a floating dependency update.

The verification script builds the sources, prints axioms for all declarations, and runs check_audit.py. The successful logs are included. The accepted foundational dependencies are propext, Classical.choice, and Quot.sound, or no axioms. No custom axioms, sorry/admit placeholders, or native-decision proofs are used. Noncomputable real definitions are ordinary exact real mathematics, not extracted numerical algorithms.

The sources are unchanged from the checked extension. This README and COVERAGE.md are curated for standalone use; the encompassing package checksum file records their distributed versions.
