import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Basic.Real.Basic

/-! Local algebra for the hidden triangle in TURN_COVER_THEOREM.md.
No graph resistance definition or separator theorem is assumed here. -/
noncomputable section
namespace TreeCertificate

def determinant (r s delta : ℝ) := r * s - delta ^ 2 / 4
def cUV (r s delta : ℝ) := (s - delta / 2) / determinant r s delta
def cVW (r s delta : ℝ) := (r - delta / 2) / determinant r s delta
def cUW (r s delta : ℝ) := delta / (2 * determinant r s delta)

theorem determinant_positive (r s delta : ℝ) (_hr : 0 < r) (_hs : 0 < s)
    (hd : 0 < delta) (hdr : delta < 2 * r) (hds : delta < 2 * s) :
    0 < determinant r s delta := by
  unfold determinant
  have h1 : 0 < r - delta / 2 := by linarith
  have h2 : 0 < s - delta / 2 := by linarith
  nlinarith [mul_pos h1 h2, mul_pos hd h1, mul_pos hd h2]

theorem all_conductances_positive (r s delta : ℝ) (hr : 0 < r) (hs : 0 < s)
    (hd : 0 < delta) (hdr : delta < 2 * r) (hds : delta < 2 * s) :
    0 < cUV r s delta ∧ 0 < cVW r s delta ∧ 0 < cUW r s delta := by
  have hD := determinant_positive r s delta hr hs hd hdr hds
  unfold cUV cVW cUW
  exact ⟨div_pos (by linarith) hD, div_pos (by linarith) hD,
    div_pos hd (by linarith)⟩

/-- Both old edge conductances strictly decrease, while cUW is a positive addition. -/
theorem original_conductances_decrease (r s delta : ℝ) (hr : 0 < r) (hs : 0 < s)
    (hd : 0 < delta) (hdr : delta < 2 * r) (hds : delta < 2 * s) :
    cUV r s delta < 1 / r ∧ cVW r s delta < 1 / s := by
  have hD := determinant_positive r s delta hr hs hd hdr hds
  unfold cUV cVW
  constructor
  · apply (div_lt_div_iff₀ hD hr).mpr
    unfold determinant
    nlinarith [mul_pos hd (show 0 < 2 * r - delta by linarith)]
  · apply (div_lt_div_iff₀ hD hs).mpr
    unfold determinant
    nlinarith [mul_pos hd (show 0 < 2 * s - delta by linarith)]

/-- Exact changes relative to the original reciprocal edge weights. -/
theorem original_conductance_changes (r s delta : ℝ) (hr : r ≠ 0) (hs : s ≠ 0)
    (hD : determinant r s delta ≠ 0) :
    cUV r s delta - 1 / r = delta * (delta - 2 * r) / (4 * r * determinant r s delta) ∧
    cVW r s delta - 1 / s = delta * (delta - 2 * s) / (4 * s * determinant r s delta) := by
  unfold cUV cVW
  constructor
  · field_simp [hD]
    unfold determinant
    ring
  · field_simp [hD]
    unfold determinant
    ring

/-- All four entries of L_grounded * B = I, where
L_grounded = [[cUV+cUW,-cUW],[-cUW,cVW+cUW]] and
B = [[r,delta/2],[delta/2,s]]. This states actual multiplication entries. -/
theorem grounded_inverse_entries (r s delta : ℝ) (hD : determinant r s delta ≠ 0) :
    (cUV r s delta + cUW r s delta) * r - cUW r s delta * (delta / 2) = 1 ∧
    (cUV r s delta + cUW r s delta) * (delta / 2) - cUW r s delta * s = 0 ∧
    -cUW r s delta * r + (cVW r s delta + cUW r s delta) * (delta / 2) = 0 ∧
    -cUW r s delta * (delta / 2) + (cVW r s delta + cUW r s delta) * s = 1 := by
  unfold cUV cVW cUW
  constructor
  · field_simp [hD]
    unfold determinant
    ring
  constructor
  · field_simp [hD]
    unfold determinant
    ring
  constructor
  · field_simp [hD]
    unfold determinant
    ring
  · field_simp [hD]
    unfold determinant
    ring

/-- The grounded quadratic form on the three terminal differences gives r, s,
and r+s-delta. This is algebra, not yet the electrical inverse formula. -/
theorem terminal_quadratic_forms (r s delta : ℝ) :
    r * (1 : ℝ)^2 + 2 * (delta / 2) * 1 * 0 + s * 0^2 = r ∧
    r * (0 : ℝ)^2 + 2 * (delta / 2) * 0 * 1 + s * 1^2 = s ∧
    r * (1 : ℝ)^2 + 2 * (delta / 2) * 1 * (-1) + s * (-1)^2 = r + s - delta := by
  constructor
  · ring
  constructor <;> ring

theorem changed_pair_positive_and_shorter (r s delta : ℝ)
    (hd : 0 < delta) (hdr : delta < 2 * r) (hds : delta < 2 * s) :
    0 < r + s - delta ∧ r + s - delta < r + s := by
  constructor <;> linarith

/-- An attached-tree pair with an unchanged local contribution remains unchanged. -/
theorem unchanged_attachment_sum (left right localBefore localAfter : ℝ)
    (h : localBefore = localAfter) :
    left + localBefore + right = left + localAfter + right := by rw [h]

/-- If the local contribution decreases by delta, fixed attachment contributions
preserve exactly that decrease. The electrical series premise is not encoded. -/
theorem changed_attachment_sum (left right r s delta : ℝ) :
    (left + (r + s) + right) - (left + (r + s - delta) + right) = delta := by ring

end TreeCertificate
