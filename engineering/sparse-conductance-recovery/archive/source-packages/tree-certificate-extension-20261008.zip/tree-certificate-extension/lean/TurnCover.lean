import Std
namespace TurnCover
variable {Q T : Type}

def Covers (covers : Q → T → Prop) (U : T → Prop) (queries : List Q) : Prop :=
  ∀ t, U t → ∃ q, q ∈ queries ∧ covers q t

def Residual (covers : Q → T → Prop) (U : T → Prop) (q : Q) : T → Prop :=
  fun t => U t ∧ ¬ covers q t

def Feasible (covers : Q → T → Prop) (U : T → Prop) (k : Nat) : Prop :=
  ∃ queries : List Q, queries.length ≤ k ∧ Covers covers U queries

theorem covers_cons_iff (covers : Q → T → Prop) (U : T → Prop) (q : Q) (qs : List Q) :
    Covers covers U (q :: qs) ↔ Covers covers (Residual covers U q) qs := by
  classical
  constructor
  · intro h t ht
    obtain ⟨p, hp, hc⟩ := h t ht.1
    simp only [List.mem_cons] at hp
    rcases hp with rfl | hp
    · exact False.elim (ht.2 hc)
    · exact ⟨p, hp, hc⟩
  · intro h t ht
    by_cases hc : covers q t
    · exact ⟨q, List.mem_cons_self, hc⟩
    · obtain ⟨p, hp, hc⟩ := h t ⟨ht, hc⟩
      exact ⟨p, List.mem_cons_of_mem q hp, hc⟩

/-- A selected witness covering any fixed remaining turn can be removed from
its list, leaving a cover of precisely the residual turns. -/
theorem remove_selected_query (covers : Q → T → Prop) (U : T → Prop)
    (before after : List Q) (q : Q) (h : Covers covers U (before ++ q :: after)) :
    Covers covers (Residual covers U q) (before ++ after) := by
  intro t ht
  obtain ⟨p, hp, hc⟩ := h t ht.1
  simp only [List.mem_append, List.mem_cons] at hp
  rcases hp with hp | hp | hp
  · exact ⟨p, List.mem_append.mpr (Or.inl hp), hc⟩
  · subst p
    exact False.elim (ht.2 hc)
  · exact ⟨p, List.mem_append.mpr (Or.inr hp), hc⟩

/-- Exact bounded form of the DP recurrence: choose any remaining turn t;
feasibility in k+1 queries iff one query covering t leaves a k-coverable residual. -/
theorem pivot_recurrence (covers : Q → T → Prop) (U : T → Prop)
    (t : T) (ht : U t) (k : Nat) :
    Feasible covers U (k + 1) ↔
      ∃ q, covers q t ∧ Feasible covers (Residual covers U q) k := by
  constructor
  · rintro ⟨qs, hlen, hc⟩
    obtain ⟨q, hq, hqt⟩ := hc t ht
    obtain ⟨before, after, heq⟩ := List.mem_iff_append.mp hq
    subst qs
    refine ⟨q, hqt, before ++ after, ?_, remove_selected_query covers U before after q hc⟩
    simp only [List.length_append, List.length_cons] at hlen ⊢
    omega
  · rintro ⟨q, hqt, qs, hlen, hc⟩
    refine ⟨q :: qs, ?_, (covers_cons_iff covers U q qs).mpr hc⟩
    simp only [List.length_cons]
    omega

theorem zero_budget_iff (covers : Q → T → Prop) (U : T → Prop) :
    Feasible covers U 0 ↔ ∀ t, ¬ U t := by
  constructor
  · rintro ⟨qs, hlen, hc⟩ t ht
    have he : qs = [] := List.eq_nil_of_length_eq_zero (by omega)
    obtain ⟨q, hq, _⟩ := hc t ht
    simp [he] at hq
  · intro h
    exact ⟨[], Nat.le_refl 0, fun t ht => False.elim (h t ht)⟩

/-- The chosen pivot is removed and every residual turn was originally present. -/
theorem residual_strict_at_pivot (covers : Q → T → Prop) (U : T → Prop)
    (q : Q) (t : T) (ht : U t) (hq : covers q t) :
    (∀ u, Residual covers U q u → U u) ∧ U t ∧ ¬ Residual covers U q t := by
  exact ⟨fun _ h => h.1, ht, fun h => h.2 hq⟩

/-- Replacing each query by one with superset coverage cannot raise the budget.
For leaf-path restriction the tree path-extension claim supplies href. -/
theorem refinement_preserves_budget {P : Type} (covers : Q → T → Prop)
    (coversP : P → T → Prop) (replace : Q → P)
    (href : ∀ q t, covers q t → coversP (replace q) t)
    (U : T → Prop) (k : Nat) (h : Feasible covers U k) :
    Feasible coversP U k := by
  obtain ⟨qs, hlen, hc⟩ := h
  refine ⟨qs.map replace, ?_, ?_⟩
  · simpa only [List.length_map] using hlen
  · intro t ht
    obtain ⟨q, hq, hqt⟩ := hc t ht
    exact ⟨replace q, List.mem_map.mpr ⟨q, hq, rfl⟩, href q t hqt⟩

end TurnCover
