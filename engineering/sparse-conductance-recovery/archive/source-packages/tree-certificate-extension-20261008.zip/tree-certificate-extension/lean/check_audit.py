from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
names=[]
for file,ns in [('TriangleWitness.lean','TreeCertificate'),('TurnCover.lean','TurnCover')]:
    source=(root/file).read_text()
    assert not re.search(r'\b(sorry|admit|native_decide)\b',source)
    assert not re.search(r'^\s*(axiom|unsafe)\b',source,re.M)
    names += [ns+'.'+line.split()[1] for line in source.splitlines() if line.startswith('theorem ')]
log=(root/'logs/axioms.log').read_text()
assert 'sorryAx' not in log
axioms={}
for name in names:
    m=re.search("'"+re.escape(name)+r"' (does not depend on any axioms|depends on axioms: \[([^]]*)\])",log)
    assert m,name
    deps=[] if m.group(2) is None else [s.strip() for s in m.group(2).split(',')]
    assert set(deps)<={'propext','Classical.choice','Quot.sound'},(name,deps)
    axioms[name]=deps
result={'compiler':'Lean 4.34.1','mathlib_commit':'d13f23b723b8a846827a245b89c10fc7d3f11612','theorem_count':len(names),'placeholder_scan':'passed','custom_axiom_scan':'passed','axioms':axioms}
(root/'logs/audit_summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='axioms'},indent=2))
