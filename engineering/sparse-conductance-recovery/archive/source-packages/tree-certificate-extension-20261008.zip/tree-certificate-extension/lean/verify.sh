#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
lean --version | tee logs/compiler-version.log
lake build 2>&1 | tee logs/build.log
lake env lean AuditAxioms.lean 2>&1 | tee logs/axioms.log
python3 check_audit.py | tee logs/audit-check.log
