"""Exact edge-required certificate optimization from a JSON tree."""
from pathlib import Path
import argparse,importlib.util,json
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('turn_cover_reference',root/'research/tree_turn_cover/reference.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('tree_json');parser.add_argument('--output')
a=parser.parse_args();tree=json.loads(Path(a.tree_json).read_text())
cert=mod.optimize_turn_cover(tree['n'],tree['edges']);mod.verify_optimality_certificate(cert)
cert['total_tree_edge_required_readings']=tree['n']-1+cert['tau']
text=json.dumps(cert,indent=2)+'\n'
if a.output:Path(a.output).write_text(text)
else:print(text,end='')
