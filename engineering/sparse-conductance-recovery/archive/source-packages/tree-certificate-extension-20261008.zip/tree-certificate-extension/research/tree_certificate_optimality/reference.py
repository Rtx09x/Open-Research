"""Exact rational optimally stopping star/path branches with universal fallback."""
import sys
from pathlib import Path
from itertools import combinations
import sympy as S
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'universal_fault_framework'))
import importlib.util
_spec=importlib.util.spec_from_file_location('universal_reference',Path(__file__).resolve().parents[1]/'universal_fault_framework'/'reference.py')
_mod=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_mod)
laplacian,resistance_table,CachedOracle,recover_arbitrary=(_mod.laplacian,_mod.resistance_table,_mod.CachedOracle,_mod.recover_arbitrary)


def fallback(n,q):
    L,_,_=recover_arbitrary(n,q,try_paths=False)
    return L,q.answers,False


def recover_with_star_candidate(n,center,oracle):
    q=CachedOracle(oracle)
    if n==1: return S.zeros(1),q.answers,True
    leaves=[v for v in range(n) if v!=center]
    if len(leaves)<=2:
        r={i:q(center,i) for i in leaves}
        if any(x==S.oo for x in r.values()): return fallback(n,q)
        if len(leaves)==2 and q(*leaves)!=sum(r.values()): return fallback(n,q)
    else:
        for i,j in combinations(leaves,2):
            if q(i,j)==S.oo: return fallback(n,q)
        r={}
        for i in leaves:
            j,k=[v for v in leaves if v!=i][:2]
            r[i]=(q(i,j)+q(i,k)-q(j,k))/2
        if any(x<=0 for x in r.values()): return fallback(n,q)
        if any(q(i,j)!=r[i]+r[j] for i,j in combinations(leaves,2)): return fallback(n,q)
        if any(q(center,i)!=r[i] for i in leaves[:2]): return fallback(n,q)
    return laplacian(n,{tuple(sorted((center,i))):1/r[i] for i in leaves}),q.answers,True


def recover_with_path_candidate(order,oracle):
    n=len(order)
    if set(order)!=set(range(n)): raise ValueError('order must list all labels')
    q=CachedOracle(oracle)
    if n<=1: return S.zeros(n),q.answers,True
    edges=list(zip(order,order[1:])); r=[q(u,v) for u,v in edges]
    if S.oo in r or q(order[0],order[-1])!=sum(r): return fallback(n,q)
    return laplacian(n,{tuple(sorted(e)):1/x for e,x in zip(edges,r)}),q.answers,True


def leaf_pair_hiding_star(n,center,r,u,v):
    r={i:S.Rational(x) for i,x in r.items()}
    delta=min(r[u],r[v])/2
    D=r[u]*r[v]-delta**2/4
    w={tuple(sorted((center,i))):1/x for i,x in r.items()}
    w[tuple(sorted((center,u)))]=(r[v]-delta/2)/D
    w[tuple(sorted((center,v)))]=(r[u]-delta/2)/D
    w[tuple(sorted((u,v)))]=delta/(2*D)
    return w


def pendant_center_alternative(n,center,r,a):
    r={i:S.Rational(x) for i,x in r.items()}
    c={i:1/x for i,x in r.items()}; C=sum(c.values())
    w={(i,j):c[i]*c[j]/C for i,j in combinations(sorted(r),2)}
    w[tuple(sorted((center,a)))]=1/r[a]
    return w


def verify_weighted_star(n,center,spoke_resistances,oracle):
    """Optimal minimax binary verifier of the specified positive weighted star."""
    leaves=[v for v in range(n) if v!=center]
    if set(spoke_resistances)!=set(leaves) or any(r<=0 for r in spoke_resistances.values()): raise ValueError("invalid positive star")
    pairs=list(combinations(leaves,2))+[(center,v) for v in leaves[:2]]
    q=CachedOracle(oracle)
    for u,v in pairs:
        expected=(spoke_resistances[v] if u==center else
                  spoke_resistances[u] if v==center else
                  spoke_resistances[u]+spoke_resistances[v])
        if q(u,v)!=expected: return False,q.answers
    return True,q.answers


def verify_weighted_path(order,edge_resistances,oracle):
    """Optimal minimax binary verifier of the specified positive weighted path."""
    if set(order)!=set(range(len(order))) or len(edge_resistances)!=max(0,len(order)-1) or any(r<=0 for r in edge_resistances): raise ValueError("invalid positive path")
    q=CachedOracle(oracle)
    for (u,v),r in zip(zip(order,order[1:]),edge_resistances):
        if q(u,v)!=r: return False,q.answers
    if len(order)>=2 and q(order[0],order[-1])!=sum(edge_resistances): return False,q.answers
    return True,q.answers
