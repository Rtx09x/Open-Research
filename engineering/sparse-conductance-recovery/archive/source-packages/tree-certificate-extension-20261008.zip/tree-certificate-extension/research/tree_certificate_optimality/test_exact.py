from reference import *
from itertools import product
import json,random
rng=random.Random(20261008); results={}; count=0
for weights in product((0,S.Rational(1,2),1),repeat=6):
    w=dict(zip(combinations(range(4),2),weights)); table=resistance_table(4,w)
    for mode in ['star','path']:
        oracle=lambda u,v:table[tuple(sorted((u,v)))]
        L,answers,accepted=(recover_with_star_candidate(4,0,oracle) if mode=='star' else recover_with_path_candidate([0,1,2,3],oracle))
        assert L==laplacian(4,w) and len(answers)<=6
        if accepted:
            if mode=='star': assert len(answers)==5
            else: assert len(answers)==4
    oracle=lambda u,v:table[tuple(sorted((u,v)))]
    ok,answers=verify_weighted_star(4,0,{1:S.Integer(1),2:S.Integer(1),3:S.Integer(1)},oracle)
    assert ok==(laplacian(4,w)==laplacian(4,{(0,1):1,(0,2):1,(0,3):1})) and len(answers)<=5
    ok,answers=verify_weighted_path([0,1,2,3],[S.Integer(1)]*3,oracle)
    assert ok==(laplacian(4,w)==laplacian(4,{(0,1):1,(1,2):1,(2,3):1})) and len(answers)<=4
    count+=1
results['exhaustive_K4_unrestricted_targets_both_branches']=count
stars=paths=gadgets=pendants=0
for n in range(1,11):
    for trial in range(3):
        center=rng.randrange(n); r={i:S.Rational(rng.randrange(1,8),rng.randrange(1,8)) for i in range(n) if i!=center}
        w={tuple(sorted((center,i))):1/x for i,x in r.items()}; table=resistance_table(n,w)
        L,answers,accepted=recover_with_star_candidate(n,center,lambda u,v:table[tuple(sorted((u,v)))])
        expected=0 if n==1 else 1 if n==2 else (n-1)*(n-2)//2+2
        assert accepted and L==laplacian(n,w) and len(answers)==expected
        stars+=1
        if 3<=n<=8:
            for u,v in combinations(sorted(r),2):
                hidden=leaf_pair_hiding_star(n,center,r,u,v); alt=resistance_table(n,hidden)
                assert [e for e in table if table[e]!=alt[e]]==[(u,v)]
                assert sum(hidden.get(e,0)!=w.get(e,0) for e in combinations(range(n),2))==3
                gadgets+=1
            for a in r:
                alt=resistance_table(n,pendant_center_alternative(n,center,r,a))
                assert all(alt[e]==table[e] for e in combinations(sorted(r),2))
                assert alt[tuple(sorted((center,a)))]==r[a]
                assert any(alt[e]!=table[e] for e in table)
                pendants+=1
        order=list(range(n)); rng.shuffle(order)
        w={tuple(sorted((u,v))):S.Rational(rng.randrange(1,8),rng.randrange(1,8)) for u,v in zip(order,order[1:])}
        table=resistance_table(n,w)
        L,answers,accepted=recover_with_path_candidate(order,lambda u,v:table[tuple(sorted((u,v)))])
        assert accepted and L==laplacian(n,w) and len(answers)==(0 if n==1 else 1 if n==2 else n)
        paths+=1
results.update(weighted_star_optimal_stops=stars,weighted_path_optimal_stops=paths,weighted_leaf_pair_hiding_gadgets=gadgets,pendant_center_alternatives=pendants)
with open('research/tree_certificate_optimality/test_results.json','w') as f: json.dump(results,f,indent=2)
print(json.dumps(results,indent=2))
