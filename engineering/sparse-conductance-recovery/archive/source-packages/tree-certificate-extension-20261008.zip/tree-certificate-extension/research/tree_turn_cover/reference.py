"""Exact finite turn-cover optimization with independently checkable DP certificate."""
from itertools import combinations
from functools import lru_cache
from pathlib import Path
import importlib.util
import sympy as S
_spec=importlib.util.spec_from_file_location('universal_reference',Path(__file__).resolve().parents[1]/'universal_fault_framework'/'reference.py')
_mod=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_mod)
laplacian,resistance_table,CachedOracle=_mod.laplacian,_mod.resistance_table,_mod.CachedOracle


def tree_data(n,edges):
    edges=tuple(sorted(tuple(sorted(e)) for e in edges)); adj=[[] for _ in range(n)]
    if n<1 or len(set(edges))!=n-1 or len(edges)!=n-1: raise ValueError('not a tree')
    for u,v in edges:
        if not 0<=u<v<n: raise ValueError('invalid edge')
        adj[u].append(v); adj[v].append(u)
    def path(a,b):
        parent={a:None}; stack=[a]
        while stack:
            u=stack.pop()
            for v in adj[u]:
                if v not in parent: parent[v]=u; stack.append(v)
        if b not in parent: raise ValueError('not connected')
        out=[b]
        while out[-1]!=a: out.append(parent[out[-1]])
        return out[::-1]
    for b in range(n): path(0,b)
    turns=tuple((u,v,w) for v in range(n) for u,w in combinations(sorted(adj[v]),2))
    indices={t:i for i,t in enumerate(turns)}
    def cover(a,b):
        p=path(a,b); mask=0
        for x,v,z in zip(p,p[1:],p[2:]): mask|=1<<indices[(min(x,z),v,max(x,z))]
        return mask
    leaves=[u for u in range(n) if len(adj[u])==1]
    pairs=tuple(combinations(leaves,2)); masks=tuple(cover(*e) for e in pairs)
    return edges,turns,pairs,masks,path,cover


def optimize_turn_cover(n,edges):
    edges,turns,pairs,masks,_,_=tree_data(n,edges)
    table={0:0}
    @lru_cache(None)
    def solve(rem):
        if rem==0: return 0
        bit=rem&-rem
        value=1+min(solve(rem&~m) for m in masks if m&bit)
        table[rem]=value; return value
    full=(1<<len(turns))-1; optimum=solve(full); rem=full; chosen=[]
    while rem:
        bit=rem&-rem
        j=next(j for j,m in enumerate(masks) if m&bit and solve(rem&~m)==solve(rem)-1)
        chosen.append(pairs[j]); rem&=~masks[j]
    certificate={'n':n,'edges':[list(e) for e in edges], 'tau':optimum,
                 'leaf_pairs':[list(e) for e in chosen],
                 'dp':{str(k):v for k,v in sorted(table.items())}}
    return certificate


def verify_optimality_certificate(cert):
    n=cert['n']; edges,turns,pairs,masks,_,cover=tree_data(n,cert['edges'])
    table={int(k):v for k,v in cert['dp'].items()}; full=(1<<len(turns))-1
    assert table.get(0)==0 and table.get(full)==cert['tau']
    for rem,value in table.items():
        assert 0<=rem<=full and isinstance(value,int) and value>=0
        if not rem: continue
        bit=rem&-rem; successors=[rem&~m for m in masks if m&bit]
        assert all(t in table for t in successors)
        assert value==1+min(table[t] for t in successors)
    union=0
    for pair in cert['leaf_pairs']:
        assert tuple(pair) in pairs
        union|=cover(*pair)
    assert union==full and len(cert['leaf_pairs'])==cert['tau']
    return True


def verify_weighted_tree(n,weights,cert,oracle):
    weights={e:S.Rational(w) for e,w in weights.items()}
    assert verify_optimality_certificate(cert)
    assert n==cert['n'] and set(weights)==set(map(tuple,cert['edges']))
    assert all(w>0 for w in weights.values())
    _,_,_,_,path,_=tree_data(n,weights); q=CachedOracle(oracle)
    for u,v in list(weights)+[tuple(e) for e in cert['leaf_pairs']]:
        p=path(u,v); expected=sum(1/weights[tuple(sorted(e))] for e in zip(p,p[1:]))
        if q(u,v)!=expected: return False,q.answers
    return True,q.answers


def hidden_turn_alternative(n,weights,turn):
    weights={e:S.Rational(w) for e,w in weights.items()}
    u,v,w=turn; r=1/weights[tuple(sorted((u,v)))]; s=1/weights[tuple(sorted((v,w)))]
    delta=min(r,s)/2; D=r*s-delta**2/4; out=dict(weights)
    out[tuple(sorted((u,v)))]=(s-delta/2)/D
    out[tuple(sorted((v,w)))]=(r-delta/2)/D
    out[tuple(sorted((u,w)))]=delta/(2*D)
    return out
