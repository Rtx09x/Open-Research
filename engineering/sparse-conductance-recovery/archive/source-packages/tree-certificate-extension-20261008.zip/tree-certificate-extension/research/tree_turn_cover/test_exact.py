from reference import *
import json,random
from itertools import product
rng=random.Random(410108); results={}; certificates={}
examples={
 'singleton':(1,[]), 'edge':(2,[(0,1)]),
 'path8':(8,[(i,i+1) for i in range(7)]),
 'star8':(8,[(0,i) for i in range(1,8)]),
 'double_star_3_3':(8,[(0,1)]+[(0,i) for i in (2,3,4)]+[(1,i) for i in (5,6,7)]),
 'branched_internal_skeleton':(10,[(0,i) for i in (1,2,3)]+[(1,4),(1,5),(2,6),(2,7),(3,8),(3,9)])}
gadgets=0
for name,(n,edges) in examples.items():
    cert=optimize_turn_cover(n,edges); assert verify_optimality_certificate(cert)
    certificates[name]=cert
    weights={tuple(sorted(e)):S.Rational(rng.randrange(1,9),rng.randrange(1,9)) for e in edges}
    base=resistance_table(n,weights)
    ok,answers=verify_weighted_tree(n,weights,cert,lambda u,v:base[tuple(sorted((u,v)))])
    assert ok and len(answers)==n-1+cert['tau']
    _,turns,_,_,_,cover=tree_data(n,edges)
    for j,turn in enumerate(turns):
        altweights=hidden_turn_alternative(n,weights,turn); alt=resistance_table(n,altweights)
        assert all(w>0 for w in altweights.values())
        assert sum(altweights.get(e,0)!=weights.get(e,0) for e in combinations(range(n),2))==3
        for e in combinations(range(n),2): assert (alt[e]!=base[e])==bool(cover(*e)&(1<<j))
        assert all(alt[e]==base[e] for e in weights)
        ok,_=verify_weighted_tree(n,weights,cert,lambda u,v:alt[tuple(sorted((u,v)))])
        assert not ok; gadgets+=1
    results[name]={'n':n,'tau':cert['tau'],'total':n-1+cert['tau'],'dp_states':len(cert['dp'])}
assert results['path8']['total']==8
assert results['star8']['tau']==21
assert results['double_star_3_3']['total']==16
assert results['branched_internal_skeleton']['total']==15
# Check all 729 K4 nonnegative targets against a nominated path and star.
verified=0
for edges in ([(0,1),(1,2),(2,3)],[(0,1),(0,2),(0,3)]):
    weights={e:S.Integer(1) for e in edges}; cert=optimize_turn_cover(4,edges)
    for ws in product((0,S.Rational(1,2),1),repeat=6):
        target=dict(zip(combinations(range(4),2),ws)); table=resistance_table(4,target)
        ok,answers=verify_weighted_tree(4,weights,cert,lambda u,v:table[tuple(sorted((u,v)))])
        assert ok==(laplacian(4,target)==laplacian(4,weights))
        assert len(answers)<=3+cert['tau']; verified+=1
# Native Python integer inputs must stay exact rather than produce floats.
integer_cert=optimize_turn_cover(2,[(0,1)])
ok,_=verify_weighted_tree(2,{(0,1):3},integer_cert,lambda u,v:S.Rational(1,3))
assert ok
integer_hidden=hidden_turn_alternative(3,{(0,1):3,(1,2):7},(0,1,2))
assert all(isinstance(w,S.Rational) for w in integer_hidden.values())
results['native_integer_input_regressions']=2
results['weighted_turn_hiding_witnesses']=gadgets
results['exhaustive_K4_verifications']=verified
# Tampered lower certificate must be rejected.
bad=dict(certificates['double_star_3_3']); bad['tau']-=1
try: verify_optimality_certificate(bad)
except AssertionError: pass
else: raise AssertionError('accepted false lower certificate')
with open('research/tree_turn_cover/optimality_certificates.json','w') as f:json.dump(certificates,f,indent=2)
with open('research/tree_turn_cover/test_results.json','w') as f:json.dump(results,f,indent=2)
print(json.dumps(results,indent=2))
