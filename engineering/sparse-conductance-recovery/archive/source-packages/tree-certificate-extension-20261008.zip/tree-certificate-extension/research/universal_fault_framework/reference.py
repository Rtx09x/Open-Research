"""Exact scalar-pair resistance reconstruction and finite-model optimal planning.
Python 3 + SymPy. Infinity is physical disconnection, never pseudoinverse distance.
"""
from itertools import combinations
from functools import lru_cache
import sympy as S


def laplacian(n, weights):
    L = S.zeros(n)
    for (u,v), w in weights.items():
        w=S.Rational(w)
        if w < 0 or not (0 <= u < v < n): raise ValueError('invalid edge')
        L[u,u]+=w; L[v,v]+=w; L[u,v]-=w; L[v,u]-=w
    return L


def resistance_table(n, weights):
    L=laplacian(n,weights); unseen=set(range(n)); table={}
    while unseen:
        root=min(unseen); C={root}; stack=[root]
        while stack:
            u=stack.pop()
            for v in unseen-C:
                if L[u,v]<0: C.add(v); stack.append(v)
        unseen-=C; C=sorted(C); m=len(C); J=S.ones(m)/m
        P=(L.extract(C,C)+J).inv()-J
        for i,j in combinations(range(m),2):
            table[(C[i],C[j])]=P[i,i]+P[j,j]-2*P[i,j]
    return {e:table.get(e,S.oo) for e in combinations(range(n),2)}


class CachedOracle:
    def __init__(self, oracle): self.oracle=oracle; self.answers={}
    def __call__(self,u,v):
        if u==v: return S.Integer(0)
        e=tuple(sorted((u,v)))
        if e not in self.answers: self.answers[e]=S.sympify(self.oracle(*e))
        return self.answers[e]


def recover_arbitrary(n, oracle, try_paths=True):
    """Always exact; optional rigorously certified path-component shortcuts."""
    q=CachedOracle(oracle); unseen=set(range(n)); out=S.zeros(n); branches=[]
    while unseen:
        o=min(unseen); C=[o]+[v for v in sorted(unseen-{o}) if q(o,v)!=S.oo]
        unseen-=set(C); m=len(C)
        if m==1: branches.append('singleton'); continue
        if try_paths:
            a=max(C,key=lambda v:q(o,v))
            order=sorted(C,key=lambda v:q(a,v))
            lengths=[q(order[i],order[i+1]) for i in range(m-1)]
            if sum(lengths)==q(order[0],order[-1]):
                for i,r in enumerate(lengths):
                    u,v=order[i:i+2]; w=1/r
                    out[u,u]+=w; out[v,v]+=w; out[u,v]-=w; out[v,u]-=w
                branches.append('certified path'); continue
        R=S.Matrix(m,m,lambda i,j:q(C[i],C[j])); J=S.eye(m)-S.ones(m)/m
        P=-J*R*J/2; U=S.ones(m)/m; L=(P+U).inv()-U
        for i,u in enumerate(C):
            for j,v in enumerate(C): out[u,v]=L[i,j]
        branches.append('all pairs')
    return out,q.answers,branches


def optimal_finite_plan(tables, labels=None, allowed_pairs=None):
    """Minimax exact diagnosis for finite hypotheses; labels define desired output.
    Full reconstruction defaults to a separate label for each hypothesis.
    Returns optimum, first query, and callable policy for any surviving state.
    No request to execute a physical query is made by this planner.
    """
    tables=tuple(tables); labels=tuple(range(len(tables))) if labels is None else tuple(labels)
    if not tables or len(labels)!=len(tables): raise ValueError('nonempty aligned family required')
    pairs=tuple(sorted(tables[0] if allowed_pairs is None else allowed_pairs))
    def parts(A,e):
        groups={}
        for h in A: groups.setdefault(tables[h][e],[]).append(h)
        return tuple(tuple(B) for B in groups.values())
    @lru_cache(None)
    def solve(A):
        if len({labels[h] for h in A})<=1: return 0,None
        best=S.oo; first=None
        for e in pairs:
            groups=parts(A,e)
            if len(groups)==1: continue
            val=1+max(solve(B)[0] for B in groups)
            if val<best: best,first=val,e
        return best,first
    A=tuple(range(len(tables))); optimum,first=solve(A)
    return optimum,first,solve


def certificate_size(tables, target, labels=None, allowed_pairs=None):
    """Minimum nonadaptive certificate for this realized hypothesis, by enumeration."""
    labels=tuple(range(len(tables))) if labels is None else tuple(labels)
    pairs=tuple(sorted(tables[0] if allowed_pairs is None else allowed_pairs))
    bad=[h for h in range(len(tables)) if labels[h]!=labels[target]]
    for k in range(len(pairs)+1):
        for Q in combinations(pairs,k):
            if all(any(tables[h][e]!=tables[target][e] for e in Q) for h in bad): return k,Q
    return S.oo,None


def nonadaptive_size(tables, labels=None, allowed_pairs=None):
    labels=tuple(range(len(tables))) if labels is None else tuple(labels)
    pairs=tuple(sorted(tables[0] if allowed_pairs is None else allowed_pairs))
    bad=[(a,b) for a,b in combinations(range(len(tables)),2) if labels[a]!=labels[b]]
    for k in range(len(pairs)+1):
        for Q in combinations(pairs,k):
            if all(any(tables[a][e]!=tables[b][e] for e in Q) for a,b in bad): return k,Q
    return S.oo,None


def certify_tree(n, tree_edges, oracle):
    """Return (certified Laplacian or None, queried answers) for a proposed topology.
    No promise that the unknown target is a tree is used. Invalid topology raises.
    """
    edges=tuple(tuple(sorted(e)) for e in tree_edges)
    if n<1 or len(edges)!=n-1 or len(set(edges))!=n-1: raise ValueError('not a tree')
    adjacency={u:[] for u in range(n)}
    for u,v in edges:
        if not (0<=u<v<n): raise ValueError('invalid edge')
        adjacency[u].append(v); adjacency[v].append(u)
    seen={0}; stack=[0]
    while stack:
        u=stack.pop()
        for v in adjacency[u]:
            if v not in seen: seen.add(v); stack.append(v)
    if len(seen)!=n: raise ValueError('not a tree')
    q=CachedOracle(oracle); lengths={}
    for u,v in edges:
        r=q(u,v)
        if r==S.oo: return None,q.answers
        lengths[u,v]=r
    leaves=[u for u in range(n) if len(adjacency[u])==1]
    for a in leaves:
        distances={a:S.Integer(0)}; stack=[a]
        while stack:
            u=stack.pop()
            for v in adjacency[u]:
                if v not in distances:
                    distances[v]=distances[u]+lengths[tuple(sorted((u,v)))]; stack.append(v)
        for b in leaves:
            if a<b and q(a,b)!=distances[b]: return None,q.answers
    return laplacian(n,{e:1/r for e,r in lengths.items()}),q.answers
