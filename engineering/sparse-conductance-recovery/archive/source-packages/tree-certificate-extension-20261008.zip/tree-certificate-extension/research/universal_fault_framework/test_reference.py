import json, random
from itertools import combinations,product
import sympy as S
from reference import *

results={}; count=0
for ws in product((0,S.Rational(1,2),1),repeat=6):
    edges=dict(zip(combinations(range(4),2),ws)); T=resistance_table(4,edges)
    for shortcut in (False,True):
        L,answers,_=recover_arbitrary(4,lambda u,v:T[(u,v)],shortcut)
        assert L==laplacian(4,edges)
        assert len(answers)<=6
    count+=1
results['exhaustive_K4_nonnegative_targets']=count
# Native integer exact oracle values must be normalized before reciprocals.
L,_,_=recover_arbitrary(2,lambda u,v:3)
assert L==laplacian(2,{(0,1):S.Rational(1,3)})
L,_=certify_tree(2,[(0,1)],lambda u,v:3)
assert L==laplacian(2,{(0,1):S.Rational(1,3)})
results['native_integer_oracle_regressions']=2
rng=random.Random(104729); count=0
for n in range(2,14):
    for trial in range(4):
        order=list(range(n)); rng.shuffle(order)
        edges={tuple(sorted((order[i],order[i+1]))):S.Rational(rng.randrange(1,8),rng.randrange(1,8)) for i in range(n-1)}
        T=resistance_table(n,edges)
        L,answers,branches=recover_arbitrary(n,lambda u,v:T[(u,v)])
        assert L==laplacian(n,edges) and branches==['certified path']
        assert len(answers)<=min(n*(n-1)//2,3*n-5)
        count+=1
results['random_weighted_path_certificates']=count
for n in (4,5,6):
    family=[]
    for u,v in combinations(range(1,n),2):
        w={(0,i):S.Integer(1) for i in range(1,n)}
        w[0,u]=w[0,v]=w[u,v]=S.Rational(2,3)
        family.append(resistance_table(n,w))
    M=len(family); D,first,policy=optimal_finite_plan(family)
    assert D==M-1
    assert nonadaptive_size(family)[0]==M-1
    assert all(certificate_size(family,h)[0]==1 for h in range(M))
    for truth in range(M):
        A=tuple(range(M)); used=0
        while policy(A)[1] is not None:
            e=policy(A)[1]; answer=family[truth][e]
            A=tuple(h for h in A if family[h][e]==answer); used+=1
        assert A==(truth,) and used<=D
    restricted=tuple((0,i) for i in range(1,n))
    assert optimal_finite_plan(family,allowed_pairs=restricted)[0]==S.oo
    results[f'star_hidden_pair_n{n}']={'hypotheses':M,'adaptive_optimum':int(D),'certificate_each':1,'restricted_star_optimum':'infinite'}
# Output-label grouping permits diagnosis even if full physical hypotheses coincide.
table=resistance_table(2,{(0,1):1})
assert optimal_finite_plan([table,table])[0]==S.oo
assert optimal_finite_plan([table,table],labels=['same','same'])[0]==0
# Full real-valued family: any missing coordinate can be changed near a positive clique.
n=4; P=(S.eye(n)-S.ones(n)/n)/n; base=resistance_table(n,{e:1 for e in combinations(range(n),2)})
for u,v in combinations(range(n),2):
    R=S.Matrix(n,n,lambda i,j:0 if i==j else base[tuple(sorted((i,j)))])
    R[u,v]+=S.Rational(1,1000); R[v,u]=R[u,v]
    J=S.eye(n)-S.ones(n)/n; PP=-J*R*J/2; U=S.ones(n)/n; L=(PP+U).inv()-U
    assert all(L[i,j]<0 for i,j in combinations(range(n),2))
    got=resistance_table(n,{(i,j):-L[i,j] for i,j in combinations(range(n),2)})
    assert all(got[e]==base[e] for e in base if e!=(u,v)) and got[u,v]!=base[u,v]
results['positive_clique_missing_coordinate_counterexamples']=6
count=0
for n in range(2,16):
    for trial in range(4):
        edges={(rng.randrange(v),v):S.Rational(rng.randrange(1,8),rng.randrange(1,8)) for v in range(1,n)}
        T=resistance_table(n,edges)
        L,answers=certify_tree(n,edges,lambda u,v:T[(u,v)])
        assert L==laplacian(n,edges)
        degree=[sum(v in e for e in edges) for v in range(n)]; leaves=degree.count(1)
        assert len(answers)<=min(n*(n-1)//2,n-1+leaves*(leaves-1)//2)
        missing=[e for e in combinations(range(n),2) if e not in edges]
        if missing:
            altered=dict(edges); altered[missing[0]]=S.Rational(1,7)
            U=resistance_table(n,altered)
            bad,_=certify_tree(n,edges,lambda u,v:U[(u,v)])
            assert bad is None
        count+=1
results['random_tree_certificates_and_non_tree_rejections']=count
with open('research/universal_fault_framework/test_results.json','w') as f: json.dump(results,f,indent=2)
print(json.dumps(results,indent=2))
