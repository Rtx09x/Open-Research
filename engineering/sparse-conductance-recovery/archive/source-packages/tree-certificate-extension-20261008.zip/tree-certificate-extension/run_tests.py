"""Portable runner; execute from any current directory with exact dependencies installed."""
from pathlib import Path
import os,subprocess,sys,json
root=Path(__file__).resolve().parent
if not __debug__: raise RuntimeError('Run without Python -O optimization')
suites=['research/universal_fault_framework/test_reference.py','research/tree_certificate_optimality/test_exact.py','research/tree_turn_cover/test_exact.py']
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONOPTIMIZE',None)
logs=[];results=[]
for suite in suites:
    result=subprocess.run([sys.executable,'-B',suite],cwd=root,env=env,text=True,capture_output=True)
    logs.append('=== '+suite+' ===\n'+result.stdout+result.stderr)
    results.append({'suite':suite,'exit_code':result.returncode})
    print(suite+': '+('PASS' if result.returncode==0 else 'FAIL'))
    if result.returncode:print(result.stdout+result.stderr)
out=root/'verification';out.mkdir(exist_ok=True)
(out/'python_suites.log').write_text('\n'.join(logs))
(out/'python_summary.json').write_text(json.dumps({'all_passed':all(x['exit_code']==0 for x in results),'suites':results},indent=2)+'\n')
raise SystemExit(0 if all(x['exit_code']==0 for x in results) else 1)
