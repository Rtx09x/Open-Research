# Compositional electrical diagnosis

A bounded, exact-reading research addendum dated 8 October 2026. The proof is in `composition_addendum.md`; PDF and editable Word versions are supplied separately. No priority certification or external peer review is claimed.

## Run

Requires Python 3.10 or newer. From this directory:

```
python -m venv .venv
# Linux or macOS
. .venv/bin/activate
# Windows PowerShell alternative: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python test_exact.py
```

The tests print two JSON records. Expected results: 71 graphs, 161 articulation witnesses, 2,224 pair-response comparisons, 125 smaller-cover checks; and 192 recovery trials, comprising 6 certified-decomposition branches and 186 all-pairs fallbacks. `test_results.jsonl` stores the verified output. Dependencies used for the supplied run: NetworkX 3.7, SymPy 1.14.0.

## What the code does

- `design(n, edges)` computes biconnected blocks, all articulation turns, a minimum turn-cover family, and the exact block-first certificate count. It uses finite subset dynamic programming, with exponential worst-case complexity.
- `witness(n, weights, a, U, W)` constructs the exact three-conductance hiding witness for one articulation turn. Its arguments U,W must be distinct connected components after removing a; weights must describe the nominated connected graph.
- `recover_with_bags(n, bags, oracle)` asks scalar pair queries through `oracle(u,v)`, caches answers, infers local Kron networks, and validates their composition. On validation failure or disconnection it reconstructs by all pairs. Bags must form a spanning tree of one-vertex gluings; validation rejects other bag arrangements. Exact rational arithmetic is supported. A real instrument or noisy numerical values are not modeled.
- `oracle.py` is a separate exact componentwise electrical solver used by the tests. Infinity means physical disconnection.

## Scope

All vertices are known, labeled 0 through n−1 and accessible. Conductances are nonnegative and finite. Networks are simple and undirected; zero means absent. Local certificates must identify each local weighted network against arbitrary connected nonnegative alternatives, not merely locate one presumed fault. The exact additional optimum is conditional on already committing local certificates. No unrestricted global minimum is claimed. The universal wrapper may need every pair and makes no subquadratic worst-case promise.

The bundle contains only scientific prose, code, tests and results. Frozen prior manuscripts are not changed.
