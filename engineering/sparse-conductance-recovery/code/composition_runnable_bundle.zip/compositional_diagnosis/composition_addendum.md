---
title: Composing electrical network certificates
date: 8 October 2026
---

A local electrical diagnosis can be combined with others, but cross-block faults must also be ruled out. This addendum gives an exact answer to that additional verification problem. Once valid certificates for all biconnected blocks are fixed, the minimum additional scalar resistance readings equal a combinatorial articulation-turn covering number. A three-conductance perturbation proves necessity; resistance equalities and Kron reduction prove sufficiency. The result also supplies a correct recovery algorithm with an all-pairs fallback.

The exact optimum is conditional on the local certificates. It is not the unrestricted global minimum, and no claim of priority is made. Decomposition, Kron reduction, turn covering and optimal decision-tree search have substantial prior literature.

# Model and the additional query problem

The nominated network $H$ is connected, simple and undirected, with positive conductances on its support. All vertices are known, labeled and accessible. Alternatives are all networks on those same labels with finite nonnegative conductances; zero means absent. Measurements are exact scalar effective resistances. Disconnection returns physical infinity. Hidden vertices, individual parallel physical branches and noisy exact-weight recovery are outside this model.

A block is a vertex-biconnected block; a bridge is treated as a two-vertex block. At an articulation vertex $a$, the incident blocks correspond to the connected components of $H-a$. An articulation turn is an unordered pair of these components, $U,W$. A query $x,y$ covers the turn if its endpoints lie on opposite sides, one in $U$ and one in $W$. Equivalently, its block-cut route enters and leaves $a$ through those two incident blocks.

Write $\tau_{\mathrm{art}}(H)$ for the minimum number of pairs covering every articulation turn. A single block has no turns and covering number zero. This is a finite set-cover problem, solved exactly by the supplied subset dynamic program. A query route can be extended to private vertices of leaf blocks without losing covered turns, so one representative per leaf block suffices when choosing an optimal cover. No polynomial-time claim is made.

# Certificate gluing theorem

For every block $B$, fix a query family $C_B$ that uniquely certifies the weighted network $H[B]$ among all connected nonnegative networks on the labels of $B$. Let $C$ be their union.

**Theorem.** For any additional query family $P$, the readings on $C\cup P$ uniquely certify $H$ among all same-label nonnegative networks if and only if $P$ covers every articulation turn. Therefore the minimum number of additional distinct readings is exactly $\tau_{\mathrm{art}}(H)$, and the achieved total is

$$\sum_B |C_B|+\tau_{\mathrm{art}}(H).$$

Local queries cover no articulation turn and distinct blocks share no vertex pair. Complete within-block pair measurements are always valid local certificates. Hence, among designs required to contain all those pairs, the exact total optimum is

$$\sum_B { |B|\choose 2}+\tau_{\mathrm{art}}(H).$$

Any genuine local certificate may replace the complete local measurements. A solver that identifies only a single presumed fault does not automatically satisfy this hypothesis. Even substituting optimal local certificates establishes an unrestricted upper bound, not an unrestricted global optimum: cross-block queries can sometimes replace local readings.

## Why matching local certificates gives complete local information

Every valid local certificate has a connected query graph. Otherwise, split its labels into query-connected sets $S_i$. Realize each resistance restriction on $S_i$ by its Kron reduction, keep these realizations disjoint, and connect representatives by arbitrary positive tree bridges. The bridges do not affect within-set resistances. Varying their weights produces distinct connected alternatives with all queried values unchanged, contradicting certification.

Consequently, finite readings matching all the local certificates force a candidate alternative $G$ to be connected on all labels. Kron-reducing $G$ onto $B$ produces a connected nonnegative network on $B$ with exactly the same within-$B$ resistances. The local certificate forces that reduction to be $H[B]$. Thus all within-block resistances agree, including unmeasured pairs.

## Sufficiency and separator propagation

Ground a connected network at $a$, and let $Q$ be its inverse grounded Laplacian. The basic identity is

$$R(x,a)+R(a,y)-R(x,y)=2Q_{xy}.$$

The inverse is nonnegative, and $Q_{xy}=0$ exactly when $x,y$ belong to different positive-support components after deleting $a$. This gives both the triangle inequality and its equality characterization by vertex separation.

If a block $B$ contains an articulation $a$, its vertices other than $a$ lie in one component of $G-a$. For a nontrivial block, $H[B]-a$ is connected, so its resistance triangle inequality through $a$ is strict for every distinct pair in $B-a$. Matching the complete local matrix gives the same strictness in $G$. For a bridge block there is only one such vertex. The claim concerns paths in the whole graph $G-a$, not necessarily the induced graph $G[B-a]$.

For any queried pair in $P$, list its successive block-cut gates, including the endpoints. In $H$, its resistance is the sum of consecutive local gate resistances. Those summands are already fixed by the local certificates. Matching the endpoint reading forces equality on every subchain: a strict triangle shortcut would contradict equality of the full sum. Each traversed articulation therefore separates its adjacent gates in $G$. Connectivity within each incident block away from that articulation promotes this to separation of all vertices on its two incident block sides.

Turn coverage establishes every such local separation. They propagate using the elementary lemma: if $b$ separates $x,c$ and $c$ separates $b,y$, then both $b$ and $c$ separate $x,y$. A simple $b$-to-$y$ path contains $c$, whose suffix avoids $b$; this places $c,y$ on the same side of $b$, opposite $x$. The symmetric argument proves the other conclusion.

Induct along any block-cut route. Resistance in $G$ adds along its articulation gates, and all local summands equal those of $H$. Therefore every pair resistance agrees. The complete resistance matrix uniquely determines the weighted Laplacian, proving $G=H$.

## Necessity through an invisible three-conductance fault

Let the turn $a,U,W$ be uncovered. Ground $H$ at $a$. Let $A,D$ be the grounded Laplacian blocks on the components $U,W$. Choose positive edges $au$ and $av$ with $u\in U$ and $v\in W$, and set

$$x=A^{-1}e_u,\quad y=D^{-1}e_v,\quad \alpha=x_u,\quad\beta=y_v.$$

Both vectors are strictly positive, by the inverse irreducible M-matrix property. Replace the zero $U\times W$ block of the grounded inverse by $\delta xy^T$ and its transpose, leaving all other blocks unchanged. For sufficiently small $\delta>0$, put $d=1-\delta^2\alpha\beta>0$. Direct block inversion shows that this is exactly the following physical change:

- Add edge $uv$ with conductance $\delta/d$.
- Decrease the conductance of $au$ by $\delta(1-\delta\beta)/d$.
- Decrease the conductance of $av$ by $\delta(1-\delta\alpha)/d$.

For sufficiently small positive $\delta$, both original edges retain positive conductance. No other conductance changes. Every pair resistance is unchanged except for pairs $i\in U,j\in W$, for which

$$R_{\mathrm{new}}(i,j)=R_H(i,j)-2\delta x_i y_j<R_H(i,j).$$

Thus precisely the queries covering this turn detect the fault. If the turn is uncovered, every measured value remains identical. This proves necessity for any certificate, including certificates that are not local-first. The witness uses two decreases and one addition, so it applies to mixed-fault budgets of at least three but not to a monotone-only or no-addition promise.

# Examples and limits of composition

**Triangle chain.** For $k\geq2$ triangles joined in a chain at articulations, complete local information costs $3k$ readings. One end-to-end query covers all articulation turns. The block-first optimum is $3k+1$, linear in $n=2k+1$, while certifying against arbitrary same-label changes and additions. A single triangle needs its three local pair readings.

**Triangle bouquet.** For $k$ triangles sharing one articulation, every pair of branches forms a turn and a query covers only one. The covering number is ${k\choose2}$. Small blocks alone do not guarantee a linear certificate. A biconnected graph remains one core; decomposition does not remove its difficulty.

**Local optimum sums can overestimate.** On a two-edge path, let the independent edge resistances range over $\{1,2\}$ and $\{1,3\}$. Each local diagnosis needs one reading. One end-to-end reading has values $2,3,4,5$ and identifies both edges, so the global optimum is one rather than two. In a product family of connected block-preserving faults, valid general bounds are $\max_i A_i\leq A\leq\sum_i A_i$. The sum becomes exact when queries are restricted to one block at a time. Without that restriction, a scalar sum may encode multiple local states or leave them ambiguous.

**Larger interfaces.** A piece with boundary $B$ and interior $I$ exposes the classical Kron matrix $L_{BB}-L_{BI}L_{II}^{-1}L_{IB}$. These matrices compose when all cross-piece interactions are represented in shared boundaries. One scalar is generally insufficient for a boundary of size at least three. Even the complete interface matrix cannot distinguish electrically equivalent interiors: two hidden series resistances expose only their sum. Identification requires an injective fault dictionary or additional interior measurements.

# Recovery when the target is unknown

The supplied implementation turns certification into a universally correct recovery strategy. It does not need a fault-count bound.

1. Choose known vertex bags forming a spanning tree of one-vertex gluings, such as the baseline blocks. Query every within-bag pair. If any answer is infinite, use componentwise all-pairs recovery.
2. Invert each finite resistance restriction to obtain its local Kron network. Glue these into a candidate network $H$.
3. Decompose the candidate into its actual blocks. Existing measurements contain every within-actual-block pair and may already cover some articulation turns. Compute a minimum cover of the remaining turns.
4. Query that cover. If every answer equals the candidate prediction, the theorem certifies the target. Otherwise, query the remaining pairs and reconstruct the actual target, reusing cached answers.

For targets respecting the nominated decomposition the structural branch succeeds. Cross-block changes cannot be silently ignored: validation either certifies the exact composition or sends recovery to the fallback. With caching, no more than all vertex pairs are queried. This is a structural upper bound, not a universally optimal or universally subquadratic diagnosis algorithm.

# Verification and relationship to earlier work

Exact rational tests cover all 71 connected unlabeled graphs through six vertices having an articulation: 161 three-change witnesses, 2,224 pair-response comparisons and exhaustive exclusion of smaller turn covers. Chain and star formulas are also checked. The recovery wrapper reconstructs all 64 four-vertex binary-support targets under three nominated decompositions, including disconnected targets, for 192 successful trials. Six use the certified-decomposition branch and 186 the fallback. These finite tests corroborate the proofs; they do not establish their generality or priority.

The distinction from prior work is narrow. Huang and Cheng already used graph decomposition and combination of minimal accessible-node sets for single-branch analog diagnosis from voltage-response directions [1]. This addendum concerns scalar pair-resistance certificates against arbitrary same-label mixed changes and additions. Broad decomposition or topology-driven-access novelty is not claimed. Kron reduction and terminal equivalence are classical [2]. Warton et al. study effective-resistance query inference, attribute the separator equality criterion to folklore, and provide known-location completion results [3]. Their results must not be relabeled as new foundations here. For trees, the turn condition coincides with the t-cover notion of Dress, Huber and Steel in the phylogenetic setting [4]; the present alternatives and access assumptions differ. Exact set-cover and decision-tree dynamic programming are standard methods.

The completed claim is the stated certificate gluing equivalence, its three-change witness and its recovery wrapper. Whether this precise combination is previously published remains unestablished. Nothing here certifies publishability or resolves unrestricted minimum-query diagnosis.

# References

[1] J.-L. Huang and K.-T. Cheng. Test Point Selection for Analog Fault Diagnosis of Unpowered Circuit Boards. IEEE Transactions on Circuits and Systems II Analog and Digital Signal Processing 47(10), 977–987, October 2000. DOI 10.1109/82.877140. https://doi.org/10.1109/82.877140

[2] F. Dörfler and F. Bullo. Kron Reduction of Graphs with Applications to Electrical Networks. IEEE Transactions on Circuits and Systems I 60(1), 150–163, 2013. DOI 10.1109/TCSI.2012.2215780. https://motion.me.ucsb.edu/pdf/2011d-db.pdf

[3] Warton et al. Graph Inference with Effective Resistance Queries. ALT 2026. https://proceedings.mlr.press/v313/warton26a.html

[4] A. Dress, K. T. Huber and M. Steel. Lassoing a phylogenetic tree I basic properties shellings and covers. Journal of Mathematical Biology 65, 77–105, 2012. DOI 10.1007/s00285-011-0450-4. https://www.math.canterbury.ac.nz/~m.steel/Non_UC/files/research/lasso.pdf
