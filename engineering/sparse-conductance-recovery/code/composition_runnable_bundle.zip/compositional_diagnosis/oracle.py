"""Exact disconnected-target test oracle using componentwise Laplacian inversion."""
from itertools import combinations
import sympy as S

def laplacian(n, weights):
    L = S.zeros(n)
    for (u,v), w in weights.items():
        w=S.Rational(w)
        if w < 0 or not (0 <= u < v < n): raise ValueError('invalid edge')
        L[u,u]+=w; L[v,v]+=w; L[u,v]-=w; L[v,u]-=w
    return L


def resistance_table(n, weights):
    L=laplacian(n,weights); unseen=set(range(n)); table={}
    while unseen:
        root=min(unseen); C={root}; stack=[root]
        while stack:
            u=stack.pop()
            for v in unseen-C:
                if L[u,v]<0: C.add(v); stack.append(v)
        unseen-=C; C=sorted(C); m=len(C); J=S.ones(m)/m
        P=(L.extract(C,C)+J).inv()-J
        for i,j in combinations(range(m),2):
            table[(C[i],C[j])]=P[i,i]+P[j,j]-2*P[i,j]
    return {e:table.get(e,S.oo) for e in combinations(range(n),2)}

