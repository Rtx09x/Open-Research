"""Exact block-first certificate design and three-change articulation witness.
Install requirements.txt before use. No physical measurements are performed.
"""
from itertools import combinations
from functools import lru_cache
import networkx as nx
import sympy as S

def resistance(n, weights):
    L=S.zeros(n)
    for (u,v),w in weights.items():
        w=S.Rational(w); L[u,u]+=w; L[v,v]+=w; L[u,v]-=w; L[v,u]-=w
    # callers here use connected graphs
    K=L[:n-1,:n-1].inv(); K=K.row_join(S.zeros(n-1,1)).col_join(S.zeros(1,n))
    return {(u,v):S.factor(K[u,u]+K[v,v]-2*K[u,v]) for u,v in combinations(range(n),2)}

def design(n, edges):
    G=nx.Graph(); G.add_nodes_from(range(n)); G.add_edges_from(edges)
    if n<1 or not nx.is_connected(G): raise ValueError('connected graph required')
    blocks=sorted([sorted(b) for b in nx.biconnected_components(G)])
    local=sorted({p for b in blocks for p in combinations(b,2)})
    turns=[]
    for a in sorted(nx.articulation_points(G)):
        H=G.copy(); H.remove_node(a)
        C=sorted([frozenset(c) for c in nx.connected_components(H)],key=lambda c:min(c))
        for U,W in combinations(C,2): turns.append((a,U,W))
    pairs=list(combinations(range(n),2))
    masks={p:sum(1<<i for i,(_,U,W) in enumerate(turns) if (p[0] in U and p[1] in W) or (p[1] in U and p[0] in W)) for p in pairs}
    candidates=[p for p in pairs if masks[p]]
    @lru_cache(None)
    def dp(m):
        if not m:return 0,()
        bit=m&-m; best=(len(turns)+1,())
        for p in candidates:
            if masks[p]&bit:
                k,tail=dp(m&~masks[p]); candidate=(1+k,(p,)+tail)
                if candidate[0]<best[0]:best=candidate
        return best
    tau,P=dp((1<<len(turns))-1)
    return {'blocks':blocks,'local':local,'turns':turns,'extra':list(P),'tau':tau,'count':len(local)+tau,'masks':masks}

def witness(n, weights, a, U, W):
    """Find exact positive rational 3-change target invisible outside U x W."""
    V=[v for v in range(n) if v!=a]; pos={v:i for i,v in enumerate(V)}
    L=S.zeros(n)
    for (i,j),w in weights.items():
        w=S.Rational(w); L[i,i]+=w;L[j,j]+=w;L[i,j]-=w;L[j,i]-=w
    K=L.extract(V,V).inv()
    u=next(u for u in sorted(U) if weights.get(tuple(sorted((a,u))),0)>0)
    v=next(v for v in sorted(W) if weights.get(tuple(sorted((a,v))),0)>0)
    alpha=K[pos[u],pos[u]];beta=K[pos[v],pos[v]]
    delta=S.Rational(1,2)
    au=tuple(sorted((a,u))); av=tuple(sorted((a,v))); uv=tuple(sorted((u,v)))
    while True:
        den=1-delta**2*alpha*beta
        if den>0:
            add=delta/den; du=delta*(1-delta*beta)/den;dv=delta*(1-delta*alpha)/den
            if 0<du<weights[au] and 0<dv<weights[av]:break
        delta/=2
    out=dict(weights);out[au]-=du;out[av]-=dv;out[uv]=add
    return out,{'a':a,'u':u,'v':v,'delta':str(delta),'alpha':str(alpha),'beta':str(beta)}

def reconstruct(vertices, readings):
    """Invert a finite connected resistance restriction into conductances."""
    vertices=list(vertices)
    if len(vertices)<2:return {}
    r=vertices[-1]; others=vertices[:-1]
    def R(i,j):return S.Integer(0) if i==j else readings[tuple(sorted((i,j)))]
    K=S.Matrix(len(others),len(others),lambda i,j:(R(others[i],r)+R(others[j],r)-R(others[i],others[j]))/2)
    A=K.inv();weights={}
    for i,u in enumerate(others):
        for j in range(i+1,len(others)):
            if A[i,j]:weights[tuple(sorted((u,others[j])))]=-A[i,j]
        w=sum(A[i,j] for j in range(len(others)))
        if w:weights[tuple(sorted((u,r)))]=w
    assert all(w>0 for w in weights.values())
    return weights

def recover_with_bags(n, bags, oracle):
    """Certified structural branch with all-pairs fallback, exact arithmetic.
    Bags must be blocks of a nominated connected graph, possibly single bridges.
    """
    incidence=nx.Graph();incidence.add_nodes_from(('v',v) for v in range(n))
    for i,bag in enumerate(bags):
        if len(set(bag))!=len(bag) or len(bag)<2 or any(v not in range(n) for v in bag):
            raise ValueError('invalid bag')
        incidence.add_edges_from((('b',i),('v',v)) for v in bag)
    if n<1 or not nx.is_tree(incidence):
        raise ValueError('bags must form a spanning one-vertex gluing tree')
    answers={}
    def ask(p):
        p=tuple(sorted(p))
        if p not in answers:answers[p]=S.sympify(oracle(*p))
        return answers[p]
    def fallback():
        for p in combinations(range(n),2):ask(p)
        unseen=set(range(n));weights={}
        while unseen:
            r=min(unseen);V=[v for v in sorted(unseen) if v==r or answers[tuple(sorted((r,v)))]!=S.oo]
            unseen-=set(V);weights.update(reconstruct(V,answers))
        return weights,answers,'fallback'
    candidate={}
    for bag in bags:
        for p in combinations(sorted(bag),2):
            if ask(p)==S.oo:return fallback()
        candidate.update(reconstruct(sorted(bag),answers))
    D=design(n,candidate);predicted=resistance(n,candidate) if n>1 else {}
    remaining=(1<<len(D['turns']))-1
    for p in answers:remaining &= ~D['masks'][p]
    @lru_cache(None)
    def cover(m):
        if not m:return ()
        bit=m&-m;best=None
        for p,mask in D['masks'].items():
            if mask&bit:
                out=(p,)+cover(m&~mask)
                if best is None or len(out)<len(best):best=out
        return best
    for p in cover(remaining):
        if ask(p)!=predicted[p]:return fallback()
    return candidate,answers,'certified decomposition'
