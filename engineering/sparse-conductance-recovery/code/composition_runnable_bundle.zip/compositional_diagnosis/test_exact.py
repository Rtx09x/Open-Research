import json
from itertools import combinations
import networkx as nx
from reference import design,resistance,witness

counts={'graphs':0,'articulation_witnesses':0,'resistance_comparisons':0,'cover_checks':0}
for G in nx.graph_atlas_g():
    n=len(G)
    if n<2 or n>6 or not nx.is_connected(G):continue
    if not list(nx.articulation_points(G)):continue
    weights={tuple(sorted(e)):1+(i%3) for i,e in enumerate(G.edges())}
    D=design(n,weights);R=resistance(n,weights)
    mask=0
    for p in D['extra']:mask|=D['masks'][p]
    assert mask==(1<<len(D['turns']))-1
    # independent brute force minimum over all pairs for manageable cases
    pairs=[p for p,m in D['masks'].items() if m]
    for k in range(D['tau']):
        for Q in combinations(pairs,k):
            union=0
            for p in Q:union|=D['masks'][p]
            assert union!=(1<<len(D['turns']))-1
        counts['cover_checks']+=1
    for a,U,W in D['turns']:
        target,meta=witness(n,weights,a,U,W); Rp=resistance(n,target)
        changed={e for e in set(weights)|set(target) if weights.get(e,0)!=target.get(e,0)}
        assert len(changed)==3
        assert all(w>0 for w in target.values())
        for p in R:
            crossing=(p[0] in U and p[1] in W) or (p[1] in U and p[0] in W)
            assert (Rp[p]!=R[p])==crossing
            if crossing:assert Rp[p]<R[p]
            counts['resistance_comparisons']+=1
        assert all(Rp[p]==R[p] for p in D['local'])
        counts['articulation_witnesses']+=1
    counts['graphs']+=1
examples={}
for k in range(1,7):
    edges=[]
    for i in range(k):edges += [(2*i,2*i+1),(2*i+1,2*i+2),(2*i,2*i+2)]
    d=design(2*k+1,edges);assert d['count']==3*k+(k>1)
    examples[f'triangle_chain_{k}']={key:d[key] for key in ['tau','count','extra']}
for leaves in range(2,7):
    d=design(leaves+1,[(0,i) for i in range(1,leaves+1)])
    assert d['tau']==leaves*(leaves-1)//2
print(json.dumps({'status':'passed','counts':counts,'examples':examples}))

# Universal recovery wrapper: exhaustive simple targets on four labels.
# Use the separate physical-disconnection oracle included in this bundle.
import oracle as universal
from reference import recover_with_bags
recovery={'targets':0,'certified':0,'fallback':0}
pairs=list(combinations(range(4),2))
for mask in range(1<<len(pairs)):
    target={p:1+(i%2) for i,p in enumerate(pairs) if mask>>i&1}
    R=universal.resistance_table(4,target)
    for bags in [[[0,1],[1,2],[2,3]],[[0,1],[0,2],[0,3]],[[0,1,2],[2,3]]]:
        out,answers,branch=recover_with_bags(4,bags,lambda u,v:R[u,v])
        assert out==target,(target,out)
        assert len(answers)<=6
        recovery['targets']+=1
        recovery['certified' if branch=='certified decomposition' else 'fallback']+=1
print(json.dumps({'recovery_wrapper':'passed','counts':recovery}))
