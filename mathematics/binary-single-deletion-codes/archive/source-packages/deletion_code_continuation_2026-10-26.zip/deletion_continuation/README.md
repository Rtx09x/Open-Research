# Length-12 binary single-deletion continuation, 2026-10-26

**Target:** find a 317-word binary single-deletion code of block length 12, or
prove a **universal** upper bound at most 319 (ideally 316).

**Result:** target still open. Exact new structural inequalities make the
full all-clique fractional relaxation considerably stronger. An independently
checked rational dual proves

    A(12,1) <= 320678373028/1000000000 = 320.678373028, hence <=320.

This reproduces the **previously published** integer upper 320 in a new way;
it does not improve that integer bound. The best known construction remains
316, with no 317-word witness here.

## Independent exact verification (no third-party dependencies)

From this directory:

    python tools/verify_exact_bound.py
    python tools/verify_rank5.py
    python tools/verify_comb_family.py
    python tools/verify_exact_primal.py       # requires networkx for full clique enumeration

The dual checker verifies **all 1056 integer dual constraints** from binary-string
deletion geometry. It verifies every supporting clique, all odd receiver
sets, all orbit bounds and the exact rational sum. A second, slightly weaker
certified dual is retained as an independent regression control:

    python tools/verify_exact_bound.py --certificate certificates/exact_upper320_stronger.json

The 33-word rank-five certificate `proofs/odd_clique_dependency_11.json` is
checked by `verify_rank5.py`. The separate exact-primal checker independently
regenerates all 155,496 maximal cliques (no stored matrix trusted) and proves
that the displayed **20-cut continuous relaxation** has a feasible fractional
point with objective `320678371719391/10^12 = 320.678371719391`. Together
with the exact dual, this brackets its true LP optimum in the mathematically
proved interval `[320.678371719391, 320.678373028]`. In particular, the
current cuts cannot prove a bound below 320. This fractional witness is
**NOT a code**.

## Numeric reproduction (numpy + scipy; networkx for generator)

The full orbit-clique matrix and both original and strengthened points are
provided in `numeric/`. No MIP warm start or five-syndrome-class dual study
was repeated.

    python tools/numeric_lp_reproduce.py --cuts one
    python tools/numeric_lp_reproduce.py --cuts full
    python tools/numeric_lp_reproduce.py --cuts full \
      --add-receiver 65,66,68,72,80,160,288,544,1056 \
      --add-receiver 1025,1027,1033,1153,1537 \
      --add-receiver 1,2,3,5,9,17,33,65,129,258,260,264,272,288,320,513,640,1025,1152

Objectives (numerical only): 320.792052690, 320.682534901, 320.678371720.
The total matrix has 38,978 distinct averaged maximal clique rows. Each
reoptimization verifies **all** 38,978 for omission violations. Only the
independent exact dual certificate constitutes a mathematical proof.

## Separator and dual certificate generation

    python tools/receiver_parity_separator.py numeric/root_all_clique_point.json
    python tools/receiver_parity_separator.py numeric/plus_three_receivers_point.json

This incomplete GF(2) heuristic outputs exact-valid cuts. It can fail to
find an existing cut; it is not a proof of full separation. The stronger
(optional) restricted-band decoding search uses scipy MILP:

    python tools/parity_band_mip.py numeric/strengthened_point.json --weights 1,2 --seconds 20

A candidate with parity cost <1 is strictly violated. MILP status is not a
proof of global optimality. The rationalizer, which maps positive averaged
rows to explicit cliques and rounds coefficients **up**, is:

    python tools/rationalize_dual.py numeric/plus_three_receivers_point.json \
      numeric/plus_three_receivers_dual.json \
      --out certificates/rebuilt_test.json
    python tools/verify_exact_bound.py --certificate certificates/rebuilt_test.json

The generator uses scipy and networkx. The verifier does not. Every stored
certificate is checkable without relying on the original solver or external
services.

## Mathematical explanation

**Read [THEORY.md](THEORY.md)** for full statements and proofs, including:

- `S_12={4,5,6,10,18,34,66,130,258,514,1026}` is an odd receiver set;
  its rank cut is violated by **0.5** at the actual all-clique optimum.
- The comb receiver family `S_n` yields `|W_n|=binom(n,2)-3` relevant
  length-n words at every n>=5, with an elementary exact characterization.
- A rigorous parity-based separation identity and an executable heuristic.
- Correct handling of orbit averaging **without assuming code symmetry**.
- An exact integer dual verifying 320.678373028.
- Separation of numerical evidence from proved statements.

## File map

- `THEORY.md`: results, proofs, parity reduction, and limitations.
- `proofs/`: explicit 11-receiver clique coverage, 5-clique cut, later
  13-clique candidate discovery records.
- `certificates/exact_upper320_improved.json`: **preferred exact proof**.
- `certificates/exact_upper320_stronger.json`: prior exact checkpoint.
- `certificates/exact_primal_20cuts.json`: exact feasible fractional
  solution proving a limitation of the 20-cut LP, *not* a code construction.
- `numeric/`: root, strengthened and reoptimized orbit points, LP rows,
  numeric duals (NOT certificates), and separator records.
- `tools/verify_exact_bound.py`, `tools/verify_rank5.py`,
  `tools/verify_comb_family.py`: third-party-free exact replay.
- `tools/numeric_lp_reproduce.py`: full all-clique numeric reoptimization.
- `tools/rationalize_dual.py`: reproducible rational dual construction.
- `tools/receiver_parity_separator.py`: filtered GF(2) candidate discovery.
- `tools/parity_band_mip.py`: optional bounded decoding MILP.
- `logs/`: positive and negative exploratory experiment data.

No paid services, external communications, Pro calls, or GitHub edits were used.
