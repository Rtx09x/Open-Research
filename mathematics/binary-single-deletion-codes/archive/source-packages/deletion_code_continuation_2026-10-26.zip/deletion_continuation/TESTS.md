# Test log and reproducibility contract

Run from the archive's root directory:

```bash
python tools/verify_rank5.py
python tools/verify_comb_family.py
python tools/verify_exact_bound.py
python tools/verify_exact_bound.py --certificate certificates/exact_upper320_stronger.json
python tools/verify_exact_primal.py  # only this exact checker requires networkx
```

The checks independently recreate binary deletion sets from string slicing;
all critical certificate comparisons use Python integers or sets. The
`verify_exact_bound.py` checker neither loads scipy nor reads stored LP rows.
The `verify_exact_primal.py` checker constructs the full conflict graph,
enumerates all maximal cliques independently of the stored matrix, and checks
its complete 20-cut fractional solution with Python integers.

Expected key statements:

```
... 595 clique certificates, 9 odd receiver certificates,
    1 odd clique-family certificate ...
Exact rational universal bound: 320678373028/1000000000 = 320.678373028
Therefore any length-12 single-deletion code has size <=320.
... 155496 maximal cliques and 19 odd-receiver cuts ...
EXACT LP lower witness: 320678371719391/1000000000000
```

Optional numeric replication (SciPy/NumPy):

```bash
python tools/numeric_lp_reproduce.py --cuts one
python tools/numeric_lp_reproduce.py --cuts full
python tools/numeric_lp_reproduce.py --cuts full \
  --add-receiver 65,66,68,72,80,160,288,544,1056 \
  --add-receiver 1025,1027,1033,1153,1537 \
  --add-receiver 1,2,3,5,9,17,33,65,129,258,260,264,272,288,320,513,640,1025,1152
```

Numerical results and their row-separation timestamps are not proof of
optimality. The exact primal and dual certificate files are the proofs.
