# Exact mathematics and limitations

## 1. Problem and scope

A binary *length-12 single-deletion code* is a subset `C` of the integers
`0,...,4095` (interpreted as 12-bit words with leading zeros) for which the
sets of **distinct** received words

`D(x) = { delete one position from the 12-bit representation of x }`

are pairwise disjoint. The classical `VT_0(12)` construction has 316 words.
This continuation **does not** construct 317 words and **does not** lower the
published integer upper bound 320. Its strongest certified continuous upper
bound is 320.678373028, which rounds down to 320.

The new content relative to the provided dossier is an explicit n=12 deletion
geometry yielding strongly violated rank-one inequalities, an effective
fractional separator, a family of analogous inequalities for general lengths,
and independently replayable rational LP certificates.

## 2. Odd received-word inequalities: valid for every code

For each received word `y` of length 11, the usual packing inequality is

`sum_{x : y in D(x)} X_x <= 1`.

Take any odd-sized subset `S` of the 2048 possible received words. For each
candidate original word `x`, let

`k_S(x) = |D(x) ∩ S|`.

Summing the receiver inequalities gives `sum_x k_S(x) X_x <= |S|`.
Since every *actual* code has `X_x in {0,1}`,

    sum_x floor(k_S(x)/2) X_x <= floor(|S|/2).           (R_S)

Indeed, `sum_x floor(k_S(x)/2)X_x` is an integer no greater than
`(sum_x k_S(x)X_x)/2 <= |S|/2`. This is a Chvatal-Gomory rank-one / subset-row
packing inequality. **The generic class is known in combinatorial
optimization. We do not claim to have invented it.**

For a fractional point `p`, define receiver slacks

    δ_y = 1 - sum_{x : y in D(x)} p_x >= 0,

and parity indicators `t_S(x) = k_S(x) mod 2`. Since `|S|` is odd,

    lhs(R_S) - rhs(R_S)
      = (1 - sum_{y in S} δ_y - sum_{x : t_S(x)=1} p_x)/2.

Thus **exactly when**

    sum_{y in S} δ_y + sum_{x : t_S(x)=1} p_x < 1,      (PARITY)

`R_S` separates the fractional point. The second sum is an XOR-syndrome cost:
construct one binary column for each receiver, indicating which positive-
weight codeword columns it meets, XOR the columns of S, and add the weights
of positions where the XOR is one. This is the implemented heuristic in
`tools/receiver_parity_separator.py`. Gaussian elimination with *filtered*
codeword columns generates candidate small odd dependencies. Every returned
candidate is checked against the full point; filtering impacts discovery,
**not cut validity**. The heuristic is incomplete.

The optional `tools/parity_band_mip.py` models (PARITY) directly as a bounded
parity-decoding MILP on selected receiver weight layers. Its constraints are
exact as a finite decoding formulation, but its reported solver optima/bounds
are **not** presented as mathematical certificates. Any incumbent S yields a
globally valid inequality independently of MILP status.

## 3. An explicit `comb` deletion geometry (all lengths)

For every `n >= 5`, define the following set of `(n-1)`-bit receivers, written
as nonnegative integers with leading zeros:

    S_n = {4,5} ∪ {2+2^k : k=2,3,...,n-2}.

It contains **n-1** distinct received strings, with Hamming weight 1 or 2.
Let `W_n = {x in {0,1}^n : |D_n(x) ∩ S_n| >= 2}`.

**Exact characterization:** number the 1-bit positions from the least
significant bit, zero-based. The words in `W_n` are precisely the following:

- Hamming weight 2: `(0,3)`; `(1,b)` for `3<=b<=n-2`;
  `(2,b)` for `3<=b<=n-1`.
- Hamming weight 3: `(0,2,c)` for `3<=c<=n-1`;
  `(1,b,c)` for `2<=b<=c-2` and `c<=n-1`.
- No words of other weights.

Therefore

    |W_n| = [1+(n-4)+(n-3)] + [(n-3)+(n-4)(n-3)/2]
          = 2(n-3) + binom(n-2,2)
          = binom(n,2)-3.

**Proof of classification:** The only permitted weight-two received bit-pairs
are `(0,2)` (received word 5) and `(1,k)` for `2<=k<=n-2`
(the other members of `S_n`). A weight-two parent with ones at `a<b` can
produce weight-two received bit-pairs only among
`(a-1,b-1)` (if deleting a zero below a), `(a,b-1)` (zero between a and b),
and `(a,b)` (zero above b), omitting nonexistent cases. Deleting a 1 produces
the sole permitted weight-one output `(2)` (word 4) precisely when `a=2` or
`b=3`. Checking `a=0,1,2` gives exactly the three displayed weight-two
families; `a>=3` gives none.

A weight-three parent at positions `a<b<c` can produce weight-two receivers
only by deleting a 1, giving `(b-1,c-1)`, `(a,c-1)`, and `(a,b)`. Two **distinct**
permitted pairs arise exactly if `(a,b,c)=(0,2,c)` with `c>=3` or
`a=1`, `b>=2`, and `c>=b+2`. The exceptional triple `(1,2,3)` produces
the same weight-two receiver from every deletion of a 1, so it is not in W.
Higher or lower parent weights cannot produce two distinct members of S.

For **any** length-n single-deletion code C, the D-sets of selected words
cannot reuse any receiver, hence

    |C ∩ W_n| <= floor((n-1)/2).                      (COMB_n)

For even n, `|S_n|=n-1` is odd and `(COMB_n)` is an odd-receiver rank cut.
For odd n the displayed rank bound remains valid, but S_n is even and the
corresponding half-sum rounding need not strengthen the receiver LP.

The general classification and cardinality are regression-checked by independent
direct binary string deletion for all `5<=n<=16` in
`tools/verify_comb_family.py`. The mathematical proof above is not dependent
on those finite checks.

## 4. Length 12: exact rank-five cut and a fractional violation of 1/2

At n=12,

    S={4,5,6,10,18,34,66,130,258,514,1026}

has size 11 and `W_12` has exactly 63 words. Every code satisfies

    |C∩W_12| <= 5.

The inequality is **tight**: words `[21,82,258,1028,2114]` are mutually
single-deletion-compatible members of W. All ten pairwise disjointness checks
are independently reproduced from strings in `tools/verify_rank5.py`.

The stored all-clique optimum has `sum_{x in W_12} p_x = 5.5`, so it violates
both the rank cut and the receiver CG cut `R_S` by 0.5. One word, `x=10`, has
`k_S(10)=4`, and 62 other words have `k_S(x)=2`; all others have `k_S(x)<2`.
In the fractional point the weight of the `x=10` coefficient and of all 30
other nonselected W-words is zero, which explains equality of these two tested
left sides at 5.5.

A shorter **33-word witness** W' and eleven explicit insertion cliques (one
for each y∈S, restricted to 33 words) are given in
`proofs/odd_clique_dependency_11.json`. Each of the 33 words belongs to
exactly two of the eleven cliques. Summing their eleven clique inequalities
and using integrality gives `|C∩W'|<=5`. Independent direct-string checks also
find a five-word compatible subset of W'. At the old all-clique LP point
`sum_{x in W'} p_x=5.5`. This 33-word configuration is a compact structural
certificate of strict fractional separation.

An earlier 5-clique cut `proofs/five_clique_cut.json` also violates the original
fractional point by ~0.03047584. Rank cuts obtained by odd combinations of
arbitrary clique rows obey the same formula as `R_S`, with the multiplicity of
x across the chosen clique rows taking the role of `k_S(x)`. A 13-clique
example is present in `certificates/exact_upper320_improved.json`.

## 5. The unrestricted LP and the exact upper certificate

Let `G={identity, complement, reversal, complement∘reversal}` act on 12-bit
words. Its 1056 orbits have size 2 or 4. **No symmetry is assumed about C.**
For an arbitrary code C, the orbit occupancy `z_O=|C∩O|` is integral and
satisfies all inequalities obtained by averaging each globally valid packing
inequality over G. For any clique Q the orbit-averaged inequality is

    sum_O [4*|Q∩O|/|O|] z_O <= 4.               (CLIQUE)

For a globally valid cut with word coefficients a_x and RHS b,

    sum_O [(4/|O|)*sum_{x∈O} a_x] z_O <= 4b. (AVG-CUT)

An additional orbit bound `z_O<=α(G[O])` is universally valid; α(G[O]) is
computed *exactly* by brute force over at most four words. These orbit
occupancy constraints are **necessary only** and do not imply that each
integer orbit vector lifts to a code. Accordingly, an upper bound proved
from them is a valid unrestricted upper bound, whereas a feasible orbit
count vector is not an unrestricted construction.

A dual certificate contains nonnegative rational multipliers for rows of
(CLIQUE), (AVG-CUT), and `z_O<=α(G[O])`, covering every primal objective
coefficient (=1). Summing these universally valid constraints proves the
rational upper bound. The certificate uses a common integer scale M=10^9.
Its exact checker `tools/verify_exact_bound.py` independently:

1. Recreates all 4096 binary strings and **all distinct deletion outputs**.
2. Verifies every pair in every cited clique, including cliques in an odd
   family cut, from first principles.
3. Verifies each receiver-cut S has distinct elements and odd cardinality.
4. Constructs complement/reversal orbits from the word strings.
5. Computes exact induced orbit independence bounds, using subset enumeration.
6. Checks 1056 full integer-valued dual coverage inequalities and their total.

The strongest stored certificate uses **595 ordinary clique rows, nine
odd-receiver rows, one odd-13-clique-family row**, plus one positive orbit-upper-
bound correction, and gives

    A(12,1) <= 320678373028 / 1000000000 = 320.678373028 < 321.

Since cardinality is integral, **A(12,1)<=320**. This matches, but does not
beat, the published No (2019) integer upper bound. The prior checked
certificate at 320.682536196 is included as a regression control.

## 6. Numeric reoptimization (NOT a theorem without Section 5)

The source-agnostic orbit row matrix contains **38,978 distinct orbit-averaged
maximal clique inequalities** of the original graph. Row generation, with a
full oracle scan of all stored clique rows after each iteration, reproduces:

| LP relaxation | Numeric upper objective |
|---|---:|
| Original maximal cliques | 321.1248423665932 |
| Add only S_12 receiver cut | 320.792052690410 |
| Add 16 receiver cuts and one 13-clique family cut | 320.682534901034 |
| Add three additional receiver cuts | **320.678371719682** |

These are **numeric LP objectives**. The strict inequality below 321 in
Section 5 is independently certified using exact integer arithmetic, not
floating solver status. No integer upper bound below 320 was obtained.

The final three cuts were found by (i) a bounded parity-decoding MILP on
received weight layers 1 and 2, (ii) filtered GF(2) elimination, and (iii)
another bounded parity-decoding search. The new receiver sets are stored in
`numeric/plus_three_receivers_point.json` and can be replayed numerically.

**Matching exact lower certificate for this fractional relaxation.** The file
`certificates/exact_primal_20cuts.json` contains 1056 nonnegative rational
orbit-occupancy coordinates, scaled by exactly `10^12`. The separate script
`tools/verify_exact_primal.py` *independently* rebuilds the conflict graph from
12-bit strings, enumerates its **155,496** maximal cliques, and checks with
integers every orbit upper bound, every clique row, all **19** selected
odd-receiver inequalities and the one odd-13-clique-family inequality. It
verifies a feasible fractional point with objective

    320678371719391 / 1000000000000 = 320.678371719391.

Together with the exact rational dual in Section 5, this proves the exact
*relaxation optimum* lies in the interval

    [320.678371719391, 320.678373028].

The interval has width only `0.000001308609`. Thus, even with **all** maximal
clique rows and these 20 extra valid rank cuts, this fractional relaxation
provably cannot certify `A(12,1)<=319`, nor even a continuous upper <320.
The *primal* fractional point is not a liftable code and is not an
unrestricted construction. The *dual* upper certificate still proves the
unrestricted integer bound 320.

The all-clique orbit LP originally also admitted exact pair-count and 3-orbit
phase constraints, but direct evaluation showed they did not separate its
initial fractional root. This motivated investigating parity of received
outputs rather than adding further threshold binaries `1[z_O>=2]`.

## 7. Limitations and most concrete next finite problem

The strict improvement from **321.124842 to 320.678372** in the continuous
all-clique relaxation is substantial relative to previous tested rank cuts,
but it is insufficient to prove 319 or 316. It also does not exhibit 317.
The exact primal/dual interval in Section 6 proves that the **present finite
cut list**, not the unrestricted optimization problem, has a substantial
remaining integrality gap.

A sharper finite task now has a precise mathematical statement:

> At an all-clique-plus-current-cuts fractional root p, minimize the parity
> cost `(PARITY)` over **all odd receiver sets S**, without restricting to a
> prescribed Hamming-weight band. The current filtered-GF2 heuristic is
> incomplete; `parity_band_mip.py` proves feasibility of each incumbent S but
> does not certify global optimality of the separator.

This is a parity decoding problem with an additional nonnegative cost per
selected receiver and a nonnegative cost per odd-parity word. A certificate
of separator optimality would require exact branch/dual verification; no
claim of such optimality is made. Other fruitful extensions would combine
odd receiver rows and odd clique rows in the same mod-two dependency, or
exploit signed orbit phases directly instead of relying on threshold-count
variables. These are candidate directions, **not achieved results**.

## 8. Related prior research / novelty boundary

- S. No, *Nonasymptotic Upper Bounds on Binary Single Deletion Codes via
  Mixed Integer Linear Programming*, IEEE Access / PMC, 2019:
  https://pmc.ncbi.nlm.nih.gov/articles/PMC7514547/ . Published bound 320
  obtained by partial integrality, **not newly beaten here**.
- F. Weindel and R. Heckel, *LLM-Guided Search for Deletion-Correcting Codes*,
  TMLR 2026: https://arxiv.org/html/2504.00613v2 . Existing n=12 interval
  316..320.
- Generic Chvátal-Gomory subset-row inequalities and their use in packing
  predate this work, e.g. research on subset-row inequalities (Jepsen et al.,
  2008) and generalized odd-set inequalities. **Novelty here is not the
  inequality template**, but the explicit deletion-specific receiver set,
  its strong fractional witness, efficient finite separation formulation,
  full reoptimization and independent rational dual witness.
