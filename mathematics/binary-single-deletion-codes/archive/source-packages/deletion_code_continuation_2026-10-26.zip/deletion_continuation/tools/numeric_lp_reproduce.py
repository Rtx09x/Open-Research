"""Reoptimize orbit-averaged all-clique continuous LP with certified-valid cuts.

DEPENDENCIES: numpy/scipy. The LP result itself is NUMERICAL, never a proof.
Proof requires tools/verify_exact_bound.py instead.

Usage:
  python tools/numeric_lp_reproduce.py --cuts one
  python tools/numeric_lp_reproduce.py --cuts full
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz,vstack,csr_matrix
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parents[1]

def solve(mode,seconds,extra_receiver=None,save=None):
 info=json.loads((ROOT/'numeric/clique_orbit_info.json').read_text())
 roots=json.loads((ROOT/'numeric/root_all_clique_point.json').read_text())
 A=load_npz(ROOT/'numeric/clique_orbit_matrix.npz').tocsr()
 orbits=info['orbits'];alpha=np.array(info['alpha'],float)
 oid=[None]*4096
 for i,o in enumerate(orbits):
  for w in o:oid[w]=i
 DD=[{((w>>(k+1))<<k)|(w&((1<<k)-1)) for k in range(12)} for w in range(4096)]
 point=json.loads((ROOT/'numeric/strengthened_point.json').read_text())
 if mode=='one':
  receivers=[point['received_output_sets'][0]];clique_families=[]
 elif mode=='full':
  receivers=point['received_output_sets'];clique_families=point['added_clique_cuts']
 else:receivers=[];clique_families=[]
 if extra_receiver:
  for S in extra_receiver:
   if len(S)%2!=1 or len(S)!=len(set(S)) or any(y<0 or y>=2048 for y in S):
    raise ValueError('Each added receiver set must have distinct 11-bit words and odd size')
  receivers+=extra_receiver
 rows=[];bounds=[]
 for S in receivers:
  sv=set(S);c=np.zeros(len(orbits))
  for w in range(4096):
   k=len(DD[w]&sv)//2
   if k:c[oid[w]]+=(4//len(orbits[oid[w]]))*k
  rows.append(c);bounds.append(4*(len(S)//2))
 for fam in clique_families:
  from collections import Counter
  mult=Counter(w for q in fam['cliques'] for w in q)
  c=np.zeros(len(orbits))
  for w,k in mult.items():
   if k//2:c[oid[w]]+=(4//len(orbits[oid[w]]))*(k//2)
  rows.append(c);bounds.append(4*(len(fam['cliques'])//2))
 C=csr_matrix(np.array(rows).reshape(len(rows),len(orbits))) if rows else csr_matrix((0,len(orbits)))
 z0=np.array(roots['orbit_counts'])
 indices=set(np.flatnonzero(A@z0>4-1e-7).tolist())
 start=time.time();numiters=0
 while True:
  numiters+=1
  ids=np.array(sorted(indices))
  mat=vstack([A[ids],C]).tocsc()
  rhs=np.r_[np.full(len(ids),4.),bounds]
  res=linprog(-np.ones(len(orbits)),A_ub=mat,b_ub=rhs,bounds=[(0,float(a)) for a in alpha],
              method='highs',options={'presolve':True,'time_limit':min(30,max(1,seconds-(time.time()-start)))})
  if not res.success:raise RuntimeError('Solver failed: '+res.message)
  residual=A@res.x-4.
  misses=np.flatnonzero(residual>5e-7)
  print('iter',numiters,'objective',round(-res.fun,12),'active',len(indices),'omitted clique violations',len(misses),flush=True)
  if len(misses)==0:
   assert (np.asarray(C@res.x).ravel()<=np.asarray(bounds)+1e-6).all()
   print('NUMERICAL ONLY: feasible for all stored clique rows; bound',-res.fun,'cuts',len(rows),flush=True)
   if save:
    P={'numerical_only':True,'bound':float(-res.fun),'orbit_counts':res.x.tolist(),'received_output_sets':receivers,'added_clique_cuts':clique_families}
    Path(str(save)+'_point.json').write_text(json.dumps(P)+'\n')
    d=-res.ineqlin.marginals
    dual={'numerical_only':True,'bound':float(-res.fun),'rows':[(int(i),float(y)) for i,y in zip(ids,d[:len(ids)]) if y>1e-9], 'receiver_duals':[float(y) for y in d[len(ids):len(ids)+len(receivers)]],'family_duals':[float(y) for y in d[len(ids)+len(receivers):]],'z':res.x.tolist()}
    Path(str(save)+'_dual.json').write_text(json.dumps(dual)+'\n')
   return res
  indices.update(misses.tolist())
  if time.time()-start>seconds or numiters>=40:raise TimeoutError('No all-clique convergence in allotted time')

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--cuts',choices=['none','one','full'],default='one')
 ap.add_argument('--seconds',type=float,default=65.)
 ap.add_argument('--add-receiver',action='append',default=[],help='comma-separated 11-bit receiver IDs; repeatable')
 ap.add_argument('--save',type=Path,help='prefix for numeric primal + dual files')
 args=ap.parse_args()
 extra=[[int(y) for y in entry.split(',')] for entry in args.add_receiver]
 solve(args.cuts,args.seconds,extra_receiver=extra,save=args.save)
