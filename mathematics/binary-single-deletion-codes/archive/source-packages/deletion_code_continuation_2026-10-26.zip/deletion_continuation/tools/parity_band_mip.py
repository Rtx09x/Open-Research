"""Optional exact-PARITY modelling / NUMERICAL search, not a proof of optimum.

Requires numpy + scipy>=1.11. Searches receiver sets S of ODD cardinality
confined to user-supplied received-word Hamming-weight bands. Linear constraints
encode the parity of intersections |D(x) ∩ S| exactly, using integer variables.
Any returned candidate can be verified directly and yields an EXACT-VALID CG cut.
A timeout, no incumbent, or an incumbent of cost>=1 DOES NOT rule out violations.

Example:
  python tools/parity_band_mip.py numeric/strengthened_point.json --weights 1,2 --seconds 20
"""
import argparse,json,sys,time
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import milp, Bounds, LinearConstraint
sys.path.insert(0,str(Path(__file__).resolve().parent))
from receiver_parity_separator import load_x

D=[{((w>>(k+1))<<k)|(w&((1<<k)-1)) for k in range(12)} for w in range(4096)]
P=[[] for _ in range(2048)]
for w,ds in enumerate(D):
 for y in ds:P[y].append(w)

def solve(point,weights,seconds):
 x=np.array(load_x(point))
 # A checked all-clique fractional point should satisfy all receiver constraints.
 rawdelta=np.array([1-sum(x[w] for w in ps) for ps in P])
 if min(rawdelta)<-1e-6:raise ValueError('Input violates original deletion packing constraints')
 delta=np.maximum(0,rawdelta)
 Y=[y for y in range(2048) if y.bit_count() in weights]
 if not Y:raise ValueError('No permitted receivers')
 idx={y:i for i,y in enumerate(Y)}
 W=[w for w in range(4096) if x[w]>1e-9 and D[w]&idx.keys()]
 ny=len(Y);nw=len(W);N=ny+2*nw+1
 lo=np.zeros(N);hi=np.ones(N)
 hi[ny+nw:ny+2*nw]=6
 hi[-1]=(ny-1)//2
 cost=np.zeros(N);cost[:ny]=delta[Y];cost[ny:ny+nw]=x[W]
 ii=[];jj=[];dd=[]
 for k,w in enumerate(W):
  for y in D[w]&idx.keys():ii.append(k);jj.append(idx[y]);dd.append(1.)
  ii.extend((k,k));jj.extend((ny+k,ny+nw+k));dd.extend((-1.,-2.))
 for y in Y:ii.append(nw);jj.append(idx[y]);dd.append(1.)
 ii.append(nw);jj.append(N-1);dd.append(-2.)
 A=coo_matrix((dd,(ii,jj)),shape=(nw+1,N)).tocsc()
 rhs=np.zeros(nw+1);rhs[-1]=1
 print(f'Search: {len(Y)} receivers, {nw} positive words, {N} integer variables; cap {seconds}s',flush=True)
 res=milp(cost,integrality=np.ones(N),bounds=Bounds(lo,hi),
          constraints=LinearConstraint(A,rhs,rhs),
          options={'time_limit':seconds,'presolve':True,'mip_rel_gap':0.})
 report={'numerical_discovery_only':True,'receiver_weights':sorted(weights),
         'status':int(res.status),'message':res.message,
         'objective':None if res.fun is None else float(res.fun),
         'best_bound':getattr(res,'mip_dual_bound',None),
         'nodes':getattr(res,'mip_node_count',None)}
 if res.x is not None:
  S=sorted(y for y in Y if res.x[idx[y]]>0.5)
  ss=set(S)
  exact_recomputed_cost=float(sum(delta[y] for y in S)+sum(x[w] for w in range(4096) if len(D[w]&ss)%2))
  lhs=float(sum((len(D[w]&ss)//2)*x[w] for w in range(4096)))
  rhs=(len(S)-1)//2
  report.update({'S':S,'parity_cost':exact_recomputed_cost,'violation':lhs-rhs,
                 'globally_valid_CG_cut':bool(S and len(S)%2==1),
                 'is_separating_this_point':bool(lhs>rhs+1e-7)})
 print(json.dumps(report,indent=2,default=float))
 return report

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('point',type=Path)
 ap.add_argument('--weights',default='1,2')
 ap.add_argument('--seconds',type=float,default=20.)
 ap.add_argument('--out',type=Path)
 args=ap.parse_args()
 result=solve(args.point,{int(a) for a in args.weights.split(',')},args.seconds)
 if args.out:args.out.write_text(json.dumps(result,indent=2,default=float)+'\n')
