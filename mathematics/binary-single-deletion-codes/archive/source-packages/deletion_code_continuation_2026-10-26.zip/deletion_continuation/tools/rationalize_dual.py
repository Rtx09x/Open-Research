"""Convert numerical orbit-LP dual into an EXACT independent-checkable certificate.

Requirements for certificate *generation*: numpy, scipy, networkx.
For validation: tools/verify_exact_bound.py uses only the Python standard library.

Discovery point + dual JSON are UNTRUSTED. This program rounds positive
floating multipliers upward to 1/scale and compensates any missing coverage
with explicit orbit upper-bound multipliers. The separate verifier reconstructs
all deletion sets from binary strings and checks all 1056 rows exactly.

Example:
  python tools/rationalize_dual.py numeric/plus_three_receivers_point.json \\
      numeric/plus_three_receivers_dual.json --out certificates/exact_upper320_rational.json
"""
import json,math,argparse,collections,time
from pathlib import Path
from itertools import combinations
import networkx as nx
import numpy as np
from scipy.sparse import load_npz
ROOT=Path(__file__).resolve().parents[1]

def main(point_path,dual_path,out,scale):
 point=json.loads(Path(point_path).read_text());dual=json.loads(Path(dual_path).read_text())
 info=json.loads((ROOT/'numeric/clique_orbit_info.json').read_text());orbits=info['orbits'];alpha=info['alpha']
 oid=[None]*4096
 for i,o in enumerate(orbits):
  for w in o:oid[w]=i
 A=load_npz(ROOT/'numeric/clique_orbit_matrix.npz').tocsr()
 needed={int(i) for i,y in dual['rows'] if y>1e-10}
 patterns={tuple(zip(A.getrow(k).indices.tolist(),A.getrow(k).data.astype(int).tolist())):k for k in needed}
 # Independent construction of maximal conflict cliques from deletion outputs.
 dd=[{((w>>(j+1))<<j)|(w&((1<<j)-1)) for j in range(12)} for w in range(4096)]
 rx=[[] for _ in range(2048)]
 for w,Ds in enumerate(dd):
  for y in Ds:rx[y].append(w)
 G=nx.Graph();G.add_nodes_from(range(4096))
 for Q in rx:
  G.add_edges_from(combinations(Q,2))
 print('conflict graph:',G.number_of_nodes(),'vertices',G.number_of_edges(),'edges',flush=True)
 representatives={};nseen=0
 t0=time.time()
 for Q in nx.find_cliques(G):
  nseen+=1
  cnt=collections.Counter(oid[w] for w in Q)
  key=tuple(sorted((i,(4//len(orbits[i]))*m) for i,m in cnt.items()))
  if key in patterns and patterns[key] not in representatives:
   representatives[patterns[key]]=sorted(Q)
  if len(representatives)==len(needed):break
 print('found',len(representatives),'of',len(needed),'needed reps from',nseen,'cliques in',time.time()-t0,'seconds',flush=True)
 assert len(representatives)==len(needed)
 ceil=lambda v:max(0,int(math.ceil(float(v)*scale-1e-8)))
 std=[{'words':representatives[int(i)],'y':ceil(y)} for i,y in dual['rows'] if ceil(y)>0]
 output=[{'S':S,'y':ceil(y)} for S,y in zip(point['received_output_sets'],dual['receiver_duals']) if ceil(y)>0]
 family=[{'cliques':f['cliques'],'y':ceil(y)} for f,y in zip(point['added_clique_cuts'],dual['family_duals']) if ceil(y)>0]
 assert len(point['received_output_sets'])==len(dual['receiver_duals'])
 assert len(point['added_clique_cuts'])==len(dual['family_duals'])
 cover=[0]*len(orbits)
 for r in std:
  for w in r['words']:cover[oid[w]]+=(4//len(orbits[oid[w]]))*r['y']
 for r in output:
  S=set(r['S'])
  for w,ds in enumerate(dd):
   m=len(ds&S)//2
   if m:cover[oid[w]]+=(4//len(orbits[oid[w]]))*m*r['y']
 for r in family:
  cnt=collections.Counter(w for q in r['cliques'] for w in q)
  for w,m in cnt.items():
   if m//2:cover[oid[w]]+=(4//len(orbits[oid[w]]))*(m//2)*r['y']
 u=[max(0,scale-x) for x in cover]
 upper=(4*sum(r['y'] for r in std)
        +sum(4*(len(r['S'])//2)*r['y'] for r in output)
        +sum(4*(len(r['cliques'])//2)*r['y'] for r in family)
        +sum(a*v for a,v in zip(alpha,u)))
 cert={'n':12,'scale':scale,'upper_bound_numerator':upper,'target_strict_bound':321,
       'cliques':std,'output_cuts':output,'clique_family_cuts':family,'orbit_upper_slacks':u}
 Path(out).write_text(json.dumps(cert,separators=(',',':'))+'\n')
 print('EXACT TESTABLE upper',upper,'/',scale,'=',upper/scale,'stdcliques',len(std),'outputcuts',len(output),'familycuts',len(family),'nonzero orbit bounds',sum(v>0 for v in u),flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('point',type=Path);ap.add_argument('dual',type=Path)
 ap.add_argument('--out',type=Path,default=ROOT/'certificates/exact_upper320_improved.json')
 ap.add_argument('--scale',type=int,default=10**9)
 a=ap.parse_args();main(a.point,a.dual,a.out,a.scale)
