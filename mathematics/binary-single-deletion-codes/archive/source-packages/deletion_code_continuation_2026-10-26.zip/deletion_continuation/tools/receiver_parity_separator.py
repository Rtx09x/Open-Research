"""Polynomial-time GF(2) filtration HEURISTIC for exact-valid odd receiver-set CG cuts.

Usage: python tools/receiver_parity_separator.py numeric/root_all_clique_point.json --out candidates.json
Every output cut is globally valid. A failure to find a cut does NOT certify
that no rank-one odd receiver cut exists. Solver-independent standard library.
"""
import argparse,json,random
from pathlib import Path


def orbits12():
 o=[];own={}
 for w in range(4096):
  if w in own:continue
  rev=int(f'{w:012b}'[::-1],2)
  oo=sorted({w,w^4095,rev,rev^4095})
  for v in oo:own[v]=len(o)
  o.append(oo)
 return o

def load_x(path):
 data=json.loads(Path(path).read_text())
 if 'word_values' in data:
  xs=data['word_values']
 elif 'orbit_counts' in data:
  o=orbits12();zz=data['orbit_counts']
  assert len(zz)==len(o)==1056
  xs=[0.]*4096
  for z,oo in zip(zz,o):
   for w in oo:xs[w]=z/len(oo)
 else:raise ValueError('Requires word_values or orbit_counts in the point JSON')
 assert len(xs)==4096 and all(v>=-1e-7 for v in xs)
 return [max(0.,v) for v in xs]

def bits(mask):
 while mask:
  b=mask&-mask;yield b.bit_length()-1;mask-=b

def group_key(S):
 n=11;mask=(1<<n)-1
 rev=lambda y:int(f'{y:011b}'[::-1],2)
 return min(tuple(sorted(f(y) for y in S)) for f in (
  lambda y:y,lambda y:y^mask,rev,lambda y:rev(y)^mask))

def separate(xs, thresholds, seeds=6, size_cap=100, limit=30, min_gap=1e-6):
 p=[[] for _ in range(2048)]
 for w in range(4096):
  if xs[w]<=1e-9:continue
  D={((w>>(k+1))<<k)|(w&((1<<k)-1)) for k in range(12)}
  for y in D:p[y].append(w)
 positive=[w for w in range(4096) if xs[w]>1e-9]
 wm={w:i for i,w in enumerate(positive)}
 weights=[xs[w] for w in positive]
 full=[sum(1<<wm[w] for w in pp) for pp in p]
 slack=[max(0.,1-sum(xs[w] for w in pp)) for pp in p]
 found={};checked=0
 for threshold in thresholds:
  heavy=[w for w in positive if xs[w]>threshold]
  hm={w:i for i,w in enumerate(heavy)}
  comp=[sum(1<<hm[w] for w in pp if w in hm) for pp in p]
  for seed in range(seeds):
   order=list(range(2048))
   if seed==1:order.reverse()
   elif seed==2:order.sort(key=lambda y:(comp[y].bit_count(),y))
   elif seed==3:order.sort(key=lambda y:(-comp[y].bit_count(),y))
   elif seed>=4:random.Random(seed*379+int(threshold*10000)).shuffle(order)
   base={}
   for y in order:
    row=comp[y];dep=1<<y
    while row:
     col=row.bit_length()-1
     if col not in base:
      base[col]=(row,dep);break
     row^=base[col][0];dep^=base[col][1]
    else:
     if dep.bit_count()%2==0 or dep.bit_count()>size_cap:continue
     checked+=1
     S=list(bits(dep));residual=0
     for yy in S:residual^=full[yy]
     cost=sum(slack[y] for y in S)+sum(weights[k] for k in bits(residual))
     gap=(1-cost)/2
     if gap>min_gap:
      key=group_key(S)
      if key not in found or gap>found[key]['violation']:
       found[key]={'S':S,'parity_cost':cost,'violation':gap,'size':len(S),'threshold':threshold,'seed':seed}
 results=sorted(found.values(),key=lambda c:-c['violation'])[:limit]
 return {'method':'filtered GF2; incomplete heuristic; every proposed cut exact-valid',
         'fractional_sum':sum(xs),'tested_odd_dependencies':checked,'cuts':results}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('point',type=Path)
 ap.add_argument('--out',type=Path,default=None)
 ap.add_argument('--thresholds',default='0,0.005,0.01,0.02,0.04,0.075,0.1,0.125,0.15,0.2,0.25,0.3')
 ap.add_argument('--seeds',type=int,default=6)
 ap.add_argument('--limit',type=int,default=30)
 a=ap.parse_args()
 vals=[float(s) for s in a.thresholds.split(',')]
 report=separate(load_x(a.point),vals,a.seeds,limit=a.limit)
 if a.out:a.out.write_text(json.dumps(report,indent=2)+'\n')
 print('tested dependencies:',report['tested_odd_dependencies'],'separated cuts:',len(report['cuts']))
 for c in report['cuts'][:5]:print('margin %.9f, |S| %s, S=%s'%(c['violation'],c['size'],c['S']))

if __name__=='__main__':main()
