"""Direct-string regression test for the explicit comb receiver family.

For n>=5 let S_n={4,5} ∪ {2+2^k : k=2,..,n-2}, subsets
of length-(n-1) receiver words. The set W_n of length-n words having
>=2 DISTINCT descendants in S_n has exactly C(n,2)-3 words.

Analytic classification, with bit positions numbered from the least
significant bit (zero-based):
 weight2: (0,3), (1,b) for 3<=b<=n-2, (2,b) for 3<=b<=n-1.
 weight3: (0,2,c) for 3<=c<=n-1, and
          (1,b,c) for 2<=b<=c-2 and c<=n-1.
No other weights appear. Every member of W_n uses >=2 distinct
receivers, hence every single-deletion code selects at most floor((n-1)/2)
of them. This gives a structured family of globally valid rank cuts.
"""
import math

def direct_D(w,n):
 s=f'{w:0{n}b}'
 return {int(s[:k]+s[k+1:],2) for k in range(n)}

def classified_W(n):
 def number(positions):return sum(1<<k for k in positions)
 E={number((0,3))}
 E|={number((1,b)) for b in range(3,n-1)}
 E|={number((2,b)) for b in range(3,n)}
 E|={number((0,2,c)) for c in range(3,n)}
 E|={number((1,b,c)) for c in range(4,n) for b in range(2,c-1)}
 return E

if __name__=='__main__':
 for n in range(5,17):
  S={4,5}|{2+2**k for k in range(2,n-1)}
  W={w for w in range(1<<n) if len(direct_D(w,n)&S)>=2}
  E=classified_W(n)
  assert W==E,(n,sorted(W-E)[:10],sorted(E-W)[:10])
  assert len(W)==math.comb(n,2)-3,(n,len(W))
  print('PASS n=%s, |S|=%s, |W|=%s, rank upper=%s'%(n,len(S),len(W),(n-1)//2))
