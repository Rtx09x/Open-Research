"""Standard-library-only independent checker of the length-12 universal upper 320 certificate.
Does NOT trust the LP optimizer, row generator, orbit graph library, or numerical floats.
"""
import json,itertools,sys,collections,argparse
from pathlib import Path

N=12;TOTAL=1<<N
B=[format(x,'012b') for x in range(TOTAL)]
D=[{B[x][:k]+B[x][k+1:] for k in range(N)} for x in range(TOTAL)]
by_id=[{int(y,2) for y in D[x]} for x in range(TOTAL)]
orbits=[];owner={}
for x,s in enumerate(B):
 if x in owner:continue
 o=sorted({x,x^4095,int(s[::-1],2),int(s[::-1],2)^4095})
 i=len(orbits);orbits.append(o)
 for w in o:
  assert w not in owner
  owner[w]=i
assert len(owner)==4096 and len(orbits)==1056
alpha=[]
for o in orbits:
 mx=0
 for r in range(len(o)+1):
  for t in itertools.combinations(o,r):
   if all(not(D[a]&D[b]) for a,b in itertools.combinations(t,2)):mx=max(mx,len(t))
 alpha.append(mx)

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--certificate',type=Path,default=Path(__file__).resolve().parents[1] / 'certificates' / 'exact_upper320_improved.json')
arguments=parser.parse_args()
cert=json.load(open(arguments.certificate))
M=cert['scale'];assert cert['n']==N and M>0
cover=[0]*len(orbits)
for j, row in enumerate(cert['cliques']):
 Q=row['words'];n=row['y']
 assert isinstance(n,int) and n>=0
 assert isinstance(Q,list) and len(set(Q))==len(Q) and all(0<=w<TOTAL for w in Q)
 for a,b in itertools.combinations(Q,2):
  assert D[a]&D[b],('nonclique',j,a,b)
 for w in Q:
  i=owner[w];assert 4%len(orbits[i])==0
  cover[i]+=(4//len(orbits[i]))*n
for j, row in enumerate(cert['output_cuts']):
 S=row['S'];n=row['y']
 assert isinstance(n,int) and n>=0
 assert len(S)%2==1 and len(S)==len(set(S)) and all(type(y)==int and 0<=y<2048 for y in S)
 S=set(S)
 for w,Dw in enumerate(by_id):
  coefficient=len(Dw&S)//2
  if coefficient:
   i=owner[w];cover[i]+=(4//len(orbits[i]))*coefficient*n
for j, row in enumerate(cert.get('clique_family_cuts', [])):
 QS=row['cliques'];n=row['y']
 assert len(QS)%2==1 and n>=0 and type(n)==int
 counter=collections.Counter()
 for Q in QS:
  assert len(Q)==len(set(Q)) and all(0<=w<TOTAL for w in Q)
  for a,b in itertools.combinations(Q,2):assert D[a]&D[b],('nonclique_in_family',j,a,b)
  counter.update(Q)
 for w,k in counter.items():
  v=k//2
  if v:
   i=owner[w];cover[i]+=(4//len(orbits[i]))*v*n
u=cert['orbit_upper_slacks']
assert len(u)==len(orbits) and all(type(v)==int and v>=0 for v in u)
assert all(cover[i]+u[i]>=M for i in range(len(orbits)))
total=(4*sum(row['y'] for row in cert['cliques'])
       +sum(4*(len(row['S'])//2)*row['y'] for row in cert['output_cuts'])
       +sum(4*(len(row['cliques'])//2)*row['y'] for row in cert.get('clique_family_cuts', []))
       +sum(a*v for a,v in zip(alpha,u)))
assert total==cert['upper_bound_numerator']
assert total<cert['target_strict_bound']*M
assert cert['target_strict_bound']==321
print('PASS: binary string deletion check,',len(orbits),'orbits,',len(cert['cliques']),'clique certificates,',len(cert['output_cuts']),'odd receiver certificates,',len(cert.get('clique_family_cuts', [])),'odd clique-family certificates,',len(u),'exact dual cover rows.')
print('Exact rational universal bound:',f'{total}/{M} = {total/M:.9f}')
print('Therefore any length-12 single-deletion code has size <=320.')
