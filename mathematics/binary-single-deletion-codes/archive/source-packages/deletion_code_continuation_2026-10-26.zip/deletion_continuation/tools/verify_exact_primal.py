"""Independent EXACT primal feasibility witness for the 20-cut all-clique LP.

Requires networkx only to independently enumerate the 155,496 maximal
conflict cliques from DIRECT BINARY STRING DELETION. All inequalities are
checked with Python integers; no floating LP library or provided LP matrix.

The purpose is to give an EXACT lower bound on a *relaxation* optimum,
NOT a 317-word code or a lower bound on A(12,1).
"""
import json,collections,itertools,argparse
from pathlib import Path
import networkx as nx

R=Path(__file__).resolve().parents[1]
P=argparse.ArgumentParser(description=__doc__)
P.add_argument('--certificate',type=Path,default=R/'certificates/exact_primal_20cuts.json')
a=P.parse_args()
c=json.loads(a.certificate.read_text())
n=c['n'];m=c['scale'];assert n==12 and m>0
z=c['z_numerators'];assert len(z)==1056 and all(type(v)==int and v>=0 for v in z)
words=[f'{w:012b}' for w in range(4096)]
D=[{int(words[w][:k]+words[w][k+1:],2) for k in range(12)} for w in range(4096)]
O=[];owner={}
for w,s in enumerate(words):
 if w in owner:continue
 rr=int(s[::-1],2)
 orbit=sorted({w,w^4095,rr,rr^4095})
 j=len(O);O.append(orbit)
 for v in orbit:
  assert v not in owner
  owner[v]=j
assert len(O)==1056
alpha=[]
for oo in O:
 a=0
 for k in range(len(oo)+1):
  for cc in itertools.combinations(oo,k):
   if all(not(D[x]&D[y]) for x,y in itertools.combinations(cc,2)):a=max(a,k)
 alpha.append(a)
assert all(v<=a*m for v,a in zip(z,alpha))
value=sum(z)
assert value>320*m,('does not demonstrate LP limitation',value/m)
# Sum over all 155,496 maximal cliques. This is independent of the saved
# orbit matrix and of the earlier clique enumerator.
receiver_to_parents=[[] for _ in range(2048)]
for w,ds in enumerate(D):
 for y in ds:receiver_to_parents[y].append(w)
G=nx.Graph();G.add_nodes_from(range(4096))
for Q in receiver_to_parents:G.add_edges_from(itertools.combinations(Q,2))
assert G.number_of_edges()==139263
maxlhs=0;count=0
for Q in nx.find_cliques(G):
 count+=1
 lhs=sum((4//len(O[owner[w]]))*z[owner[w]] for w in Q)
 maxlhs=max(maxlhs,lhs)
 assert lhs<=4*m,('maximal clique violation',Q,lhs-4*m)
assert count==155496,('graph clique count did not match independent earlier enumeration',count)
for S in c['receiver_sets']:
 assert len(S)%2 and len(S)==len(set(S)) and all(type(y)==int and 0<=y<2048 for y in S)
 ss=set(S)
 lhs=sum((4//len(O[owner[w]]))*(len(D[w]&ss)//2)*z[owner[w]] for w in range(4096))
 assert lhs<=4*(len(S)//2)*m,('receiver cut',S,lhs-4*(len(S)//2)*m)
for fam in c['clique_family_cuts']:
 family=fam['cliques'];assert len(family)%2
 cnt=collections.Counter()
 for Q in family:
  assert len(Q)==len(set(Q))
  for x,y in itertools.combinations(Q,2):assert D[x]&D[y],('invalid family clique',x,y)
  cnt.update(Q)
 lhs=sum((4//len(O[owner[w]]))*(k//2)*z[owner[w]] for w,k in cnt.items())
 assert lhs<=4*(len(family)//2)*m
print('PASS direct-string-derived conflict graph,',count,'maximal cliques and',len(c['receiver_sets']),'odd-receiver cuts; all inequalities verified EXACTLY.')
print('EXACT LP lower witness:',str(value)+'/'+str(m),'=',format(value/m,'.12f'))
print('This is a feasible fractional orbit-count vector, NOT a deletion code.')
