"""Pure Python exact independent verifier for the 11-receiver/33-word rank-five cut."""
import json,itertools
from pathlib import Path

S=[4,5,6,10,18,34,66,130,258,514,1026]
B=[f'{w:012b}' for w in range(4096)]
D=[{s[:i]+s[i+1:] for i in range(12)} for s in B]
DI=[{int(y,2) for y in dd} for dd in D]
Q=json.load(open(Path(__file__).resolve().parents[1]/'proofs'/'odd_clique_dependency_11.json'))['cliques']
assert len(Q)==11
from collections import Counter
N=Counter(w for q in Q for w in q)
assert len(N)==33 and set(N.values())=={2}
for j,q in enumerate(Q):
 for a,b in itertools.combinations(q,2):assert D[a]&D[b],('not clique',j,a,b)
 assert any(all(y in DI[w] for w in q) for y in S),('not insertion clique',j)
W=[w for w in range(4096) if len(DI[w]&set(S))>=2]
assert len(W)==63 and set(N).issubset(W)
I=[21,82,258,1028,2114]
assert len(set(I))==5 and all(w in W for w in I)
for a,b in itertools.combinations(I,2):assert not (D[a]&D[b]),('not independent',a,b)
# Any valid code can choose at most five W-words: each consumes at least two
# of the eleven outputs and those outputs cannot be reused.
root=json.load(open(Path(__file__).resolve().parents[1]/'numeric'/'root_all_clique_point.json'))
x=root['word_values']
value=sum(x[w] for w in W)
assert abs(value-5.5)<1e-7, value
# Check the rounded row, which counts word 10 twice, and equals 5.5 here.
valueCG=sum((len(DI[w]&set(S))//2)*x[w] for w in range(4096))
assert abs(valueCG-5.5)<1e-7
print('PASS: 11 direct-string insertion cliques cover 33 words twice; 63 eligible words have rank exactly five.')
print('Exact independent witness:',I)
print('Stored fractional root: rank and CG left sides',value,valueCG,'> 5.')
