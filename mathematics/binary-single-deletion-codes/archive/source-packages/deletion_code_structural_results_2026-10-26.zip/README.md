# Deletion-code structural results

Read `REPORT.md` first. This bundle contains exact structural results for unrestricted binary length-12 single-deletion codes, independently checkable certificates, and clearly marked numerical experiments.

**No 317-word construction or universal bound below 320 is claimed.**

## Main proved results

- Any code different from VT_0(12) with at least 316 words uses at least five VT syndromes.
- VT_0 is the unique 316-word code among arbitrary unions of complete (weight, unreduced-checksum) cells.
- An explicit 16-word rank-seven inequality is not implied by all clique and odd-walk inequalities.
- A polynomial phase test detects inconsistent two-per-orbit choices, including an explicit integer-count obstruction surviving every pairwise test.
- Exact strict-Hall certificates exclude all single-syndrome trades, at every radius.

## Verify the mathematics

From the unpacked directory:

```bash
python deletion_research/verify_all.py
```

Python 3.10 or newer is recommended for the scripts; only its standard library is needed for verification. Do not use Python's `-O` option, which disables assertions. No solver, network connection, NumPy, or SciPy is needed to replay the proofs.

The supplied dossier's earlier local-radius enumeration is not included or reverified.

## Use the new orbit separator

```bash
python orbit_agent/orbit_phase_separator.py candidate.json --output consistency.json
```

Input:

```json
{"n":12,"counts":["1056 integer counts in canonical orbit order"],"orbits":["optional canonical orbit arrays"]}
```

Replace the illustrative strings with actual arrays. Orbits are ordered by their smallest integer word; the implementation constructs this order. A successful check is necessary, not sufficient, for an actual code. Violations include exact graph/parity witnesses.

## Files

- `checksum_structure/`: all 715 four-syndrome supports, compressed by complement symmetry into 365 exact rational certificates, plus strict-Hall certificates.
- `deletion_structured/`: analytic cell quotient, rational cover, exact 68-node equality search, and an independent audit of the orbit proofs.
- `orbit_agent/`: explicit subdivision graphs, orbit pair tables, phase theorem and separator, exact cut-lifting generator/verifier.
- `deletion_research/`: independent combined checker, structural witness checker, numerical LP control, its point and results, and a certified lifted rank-seven cut.
- `MANIFEST_SHA256.json`: hashes of every bundled file except the manifest itself.

Discovery scripts may require NumPy and SciPy. Their numerical statuses are not proof dependencies. The recorded all-clique control and the tested rank cuts did not improve the global numerical upper bound.

The complete derivations, limitations, primary-source links, and verification scope are in `REPORT.md`.
