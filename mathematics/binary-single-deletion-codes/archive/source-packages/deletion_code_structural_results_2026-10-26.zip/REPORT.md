# Length-12 binary single-deletion codes: structural results

Date: 26 October 2026.

## Outcome and exact scope

The unrestricted target remains open in this investigation. No 317-word code and no universal upper bound below the published 320 were obtained. The results below are proved structural exclusions and stronger valid constraints, not a claim that 316 is globally optimal.

The substantive results are:

1. **At least five VT syndromes are necessary for any alternative code of size at least 316.** Every code of that size supported on at most four checksum classes is exactly VT_0(12). All 715 four-class supports are covered by exact certificates.
2. **VT_0 is the unique optimal code among arbitrary unions of complete weight/unreduced-checksum cells.** Every other code in this family has at most 315 words. This uses a general structural quotient formula and an exact length-12 certificate.
3. **An explicit 16-word rank-seven inequality is stronger than the entire clique-plus-odd-walk fractional relaxation.** A rational point in the full 4,096-word graph proves strict nonredundancy. The underlying odd-K4 inequality is classical; the specific deletion-graph realization and its role here are the work of this investigation.
4. **A polynomial-time consistency theorem detects impossible integer orbit counts.** It is complete for selecting two words from each free complement/reversal orbit. An explicit three-orbit example passes all pairwise tests and even lies in the projection of the true stable-set polytope, while its exact integer counts cannot be realized.

There is also an exact strict-Hall certificate excluding all single-syndrome trades at every radius. These results are new relative to the supplied dossier. Literature priority for the deletion-specific statements has not been established.

## Notation

Let D(x) be the distinct length-11 words obtainable by deleting one bit of a binary length-12 word x. A code C is valid when D(x) and D(x') are disjoint for distinct members. The conflict graph has the 4,096 length-12 words as vertices and an edge precisely when their deletion sets meet.

Write

    s(x) = sum_(i=1)^12 i*x_i,
    sigma(x) = s(x) mod 13,
    V_a = {x : sigma(x)=a},
    B = V_0.

All integer word identifiers below mean 12-bit binary representations, including leading zeros. Independent direct-string checks verify |B|=316, |V_a|=315 for a nonzero, and that every VT class partitions all 2,048 received words by its deletion balls.

## 1. A five-syndrome necessity theorem

**Theorem.** If a valid C uses at most four distinct values of sigma and |C|>=316, then C=B.

Equivalently, every different 316-word code and every possible 317-word code uses at least five VT classes. This is an unrestricted necessary condition: C is not assumed symmetric, close to B, or a union of entire classes.

The exact restricted maxima are:

| Four-class support | Number of supports | Maximum and equality |
|---|---:|---|
| Contains 0 | 220 | 316, uniquely B |
| Excludes 0 | 495 | 315 |

### Certificate proof

Let M=1,000,000,000 and e=100,000. For each four-class support S, assign nonnegative integer weights q_S(y) to received words.

For 0 not in S, the certificate satisfies

    sum_(y in D(x)) q_S(y) >= M    for all sigma(x) in S,
    sum_y q_S(y) < 316*M.

Summing the first inequality over a deletion code uses every received word at most once. Thus M|C|<316M, proving |C|<=315.

For 0 in S, the certificate instead satisfies

    sum_(y in D(x)) q_S(y) >= M                  if x in B,
    sum_(y in D(x)) q_S(y) >= M+e                otherwise,
    sum_y q_S(y) < 316*M+e.

Consequently

    M|C| + e|C\B| < 316*M+e.

Since 0<e<M, this excludes |C|>=317. When |C|=316, it forces |C\B|=0, hence C=B. Supports of smaller size extend to four-element supports, so they are covered too.

Complement maps sigma to -sigma modulo 13 and commutes with deletion, allowing 365 certificates to cover all 715 supports. The checker verifies this action on every word and checks closure to the entire support family. This transports proofs; it does not constrain C to be invariant.

The worst certified cover costs are 316.000000658 for zero-containing supports, strictly below 316.0001, and 315.133333948 for nonzero supports, strictly below 316. These decimal presentations are exact rational numbers, not floating-point assumptions. The verifier checks all inequalities with integers.

Numerical LPs discovered the certificates. Upward rounding, exact coverage repair, and independent checking provide the proof. There are 460,010 checked coverage inequalities. The two generation jobs took about 118 and 126 seconds, each enforcing one CPU, 1 GiB address space, and a 150-second cap.

Files: `checksum_structure/four_syndrome_proof.md`, the two `four_syndrome_duals_part*.json` files, and `verify_four_syndromes.py`.

## 2. Exact weight/checksum cells: a structural quotient and uniqueness

For general length n, define

    F(w,s) = {x : wt(x)=w and sum_i i*x_i=s}.

Each nonempty cell is itself a deletion code. Put an edge between two cells if at least one cross-cell pair of words conflicts. A code formed from complete cells is precisely an independent set in this quotient graph, with cell weight |F(w,s)|.

**General quotient theorem.** For existing, distinct cells:

- At the same weight w, checksums s<t conflict exactly when t-s<=max(w,n-w).
- At adjacent weights w,w+1, checksums s,t respectively conflict exactly when 1<=t-s<=n.
- Cells whose weights differ by at least two do not conflict.

### Why the formula is exact

Take a received word y of length n-1, weight w, and checksum u. Its distinct zero-insertion parents have the consecutive checksums

    u, u+1, ..., u+w,

and its distinct one-insertion parents have the consecutive checksums

    u+w+1, ..., u+n.

Inserting zero increases the checksum by the number of ones after the insertion position. Inserting one increases it by w+1 plus the number of zeros before that position. Repeated insertion positions in a run give the same parent, so these increments index the distinct parents exactly.

Checksums of all length-m, weight-w words fill every integer in

    [w(w+1)/2, w(2m-w+1)/2].

Indeed, writing the one positions as p_i=i+d_i reduces the claim to representing every integer from 0 to w(m-w) by a nondecreasing list of w integers between 0 and m-w; the quotient and remainder on division by w supply such a list.

The conflict conditions now follow by intersecting the possible received-checksum interval with the relevant parent-checksum intervals. For adjacent weights the intervals are

    [L_(n-1)(w), U_(n-1)(w)], [s-w,s], [t-n,t-w-1].

Their intersection is nonempty exactly when 1<=t-s<=n, after using the assumed existence of the two cells. The same-weight cases give t-s<=w or t-s<=n-w. The complete boundary argument is in `deletion_structured/cell_theorem.md`.

### Exact length-12 upper bound and equality

There are 299 cells and 4,965 quotient edges. A certificate of 207 quotient cliques with nonnegative rational weights lambda_Q satisfies

    sum_Q lambda_Q = 316,
    sum_(Q containing F) lambda_Q >= |F|    for every cell F.

All denominators divide 32. Summing weighted clique inequalities proves that a whole-cell code has at most 316 words.

Equality is also completely checked. Twenty-one cells have positive dual coverage slack, so they cannot be selected in an equality case. The remaining 278 cells must meet each of the 207 positive-weight cliques exactly once. A deterministic exhaustive exact-cover search, preserving all quotient conflicts, visits 68 nodes and finds exactly the VT_0 selection. The independent verifier includes this equality search.

**Therefore any valid code of size at least 316 whose membership depends only on (weight, unreduced checksum) equals B.** Every alternative code of size at least 316 must split at least one such cell.

The restriction matters. A quotient edge means some cross-cell pair conflicts, not all pairs. In F(1,1), take the word whose one is at position 1. In F(2,8), the words with one positions (2,6) and (3,5) are both compatible with it and with each other. They yield normalized occupancy 1+2/3>1 across an adjacent cell pair. Thus normalizing arbitrary partial-cell counts does not turn this certificate into an unrestricted upper bound.

Files: `deletion_structured/cell_theorem.md`, `cell_clique_certificate.json`, `verify_cells.py`.

## 3. Explicit rank-seven inequality beyond all clique and odd-walk cuts

Let

    W = {173,605,1109,1237,1321,1349,1357,1373,
         1390,1493,2705,2722,2774,2896,2980,2986}.

Then every deletion code satisfies

    |C intersect W| <= 7.

The induced conflict graph is exactly K4 with each edge replaced by a path of length three. The hubs are 1109,1373,2722,2986, and the six paths are:

| Endpoints | Internal words in order |
|---|---|
| 1109,1373 | 173,605 |
| 1109,2722 | 1321,2705 |
| 1109,2986 | 1237,1493 |
| 1373,2722 | 1357,1349 |
| 1373,2986 | 1390,2774 |
| 2722,2986 | 2896,2980 |

**Proof.** Suppose s hubs are selected. Each of the six internal pairs contributes at most one selected word, and contributes zero if both endpoint hubs are selected. Therefore

    |C intersect W| <= 6+s-binomial(s,2) <= 7,   0<=s<=4.

The bound is attained by {173,1237,1321,1349,1373,2774,2896}. A separate exhaustive recurrence over all 65,536 subsets verifies the local independence number.

### Strict separation from the full old cut families

Give the four hubs fractional value 1/3, the twelve internal words value 1/2, and every other word in the full graph value zero. The induced support is triangle-free, so all clique inequalities hold. Every simple odd cycle within it is a length-nine cycle with three hubs and six internal words, of total value 4, exactly its odd-cycle bound.

An odd closed walk entirely inside the support decomposes into cycles and doubled edges; edge bounds and odd-cycle bounds imply its inequality. If a closed walk has an outside position, that position has value zero and every other position has value at most 1/2, immediately giving the required bound. Thus **every** ordinary odd-closed-walk inequality in the full graph holds.

Nevertheless the rank-seven left side is 4/3+12/2=22/3>7. This is a rigorous nonredundancy witness against the entire clique-plus-odd-walk fractional relaxation.

The full seven-orbit construction has two paths per K4 edge and 28 words, with independence number 13. Each of 64 choices of one path per edge gives a rank-seven cut. Averaging a rank-seven cut over complement/reversal yields

    2*z_hub + sum_(six outer orbits) z_O <= 14.

This is stronger than the rank-thirteen consequence. The latter follows by averaging the displayed inequality with the existing bound sum_outer z_O<=12 supplied by twelve disjoint internal conflict pairs.

General odd-K4 rank inequalities are classical. The explicit deletion-graph embedding, its rational separation witness, and the checksum-independent orbit construction are the contributions here relative to the dossier.

### Measured practical limitation

The all-clique control LP was reconstructed and reproduced 321.1248423665932. The displayed averaged rank-seven row has left side only 2.394983155020096 at that optimum, against right side 14. Adding the rank-seven and rank-thirteen rows left the objective unchanged to numerical precision (321.1248423665923).

An exact sequential lifting procedure enlarged the 16-word rank-seven set to 38 words. For every added vertex v it certified alpha(W minus N(v))<=6, ensuring alpha(W union {v})<=7. The final certificate has 391 proof states and independently replays by direct string deletion. Its mass at the control LP point is only 3.0275347559010477, below 7. Therefore this tested seed and its lifted cut do not improve the global LP bound. Other seeds were not exhaustively tested.

These negative numerical checks are explicitly separated from the valid structural theorem. No gain toward 319 is claimed from them.

## 4. What integral orbit counts still forget

Let G=F2^2 act by complement c and reversal r, with labels 0=id,1=c,2=r,3=cr. A free orbit has four words. For two free orbits O,P, define

    T_OP = {t : O_0 conflicts with P_t}.

Invariance gives O_g adjacent to P_h exactly when g+h belongs to T_OP. Every single offset defines a perfect matching, so any actual counts satisfy z_O+z_P<=4 whenever the two orbits are adjacent.

### Exact two-per-orbit theorem

Every two-element subset of G is a coset a+{0,d}, with a unique nonzero direction d. If two adjacent orbits each select two words, a conflict matching makes the second pair the complement of a translate of the first. Their directions must agree. Thus every connected component has a common direction.

For a proposed direction d, let ell_d be the nonzero linear functional with kernel {0,d}. A two-per-orbit selection exists exactly when:

1. d is absent from every orbit's internal conflict offsets.
2. All offsets on each orbit-pair edge have the same value under ell_d.
3. The binary equations p_O+p_P=1+ell_d(t) for each edge offset t are consistent.

Necessity follows from the complementary-coset observation. For sufficiency, select precisely the labels g satisfying ell_d(g)=p_O. Those are two internally compatible words, and the equations forbid every cross-orbit conflict.

There are only three possible directions. Each test is a parity breadth-first search, so the complete decision procedure is linear in the component's vertices and edges. Separate connected components may choose different directions. This is an exact test for this specific induced two-per-orbit problem, not an exact test for arbitrary full-code feasibility.

If a connected nontrivial set S fails, then the following necessary constraint is valid for unrestricted codes:

    sum_(O in S) 1[z_O>=2] <= |S|-1.

If every count were at least two, the matching bounds on the connected edges would force every count to equal two, contradicting the exact test.

### A three-orbit counterexample to liftability

Take

    O = {410,1432,2663,3685},
    P = {716,820,3275,3379},
    Q = {1230,1842,2253,2865}.

All three orbits are internally independent; there are no P-Q edges. The offsets are T_OP={0,2} and T_OQ={0,3}. Each pair of orbits can separately realize counts (2,2). Joint counts (2,2,2) are impossible because they force O's direction to be both 2 and 3.

In fact the half-valued vector on the twelve words belongs to the true stable-set polytope: it is the average of the two actual valid codes O and P union Q. Its orbit counts are the integers (2,2,2), but no valid code has those exact counts on these three orbits.

Therefore even all linear stable-set inequalities plus orbit-count integrality do not ensure realization of a particular count vector. The dossier's averaging remains a valid upper-bound relaxation; this example defeats the stronger inference of exact liftability, not the relaxation's validity. It also does not show that linear methods cannot prove a global cardinality bound.

The explicit valid disjunction is

    1[z_O>=2] + 1[z_P>=2] + 1[z_Q>=2] <= 2.

For free orbits, introduce binary q_O with 2*q_O<=z_O<=1+3*q_O, making q_O exactly the threshold indicator.

### Pair tables and finite implementation

For arbitrary orbits O,P of size two or four, define f_OP(s) as the largest feasible count in P when exactly s words are selected in O. All tables are obtained by at most 2^8 subset choices. The function is nonincreasing.

With exact threshold indicators t_(O,k)=1[z_O>=k], each table is encoded by

    z_P + sum_k (f_OP(k-1)-f_OP(k))*t_(O,k) <= alpha(P).

The direct-string enumeration covered 33,512 adjacent orbit pairs. Of these, 489 exclude integer count pairs permitted by all averaged local clique rows; 965 ordered count pairs are newly excluded. The three-orbit example survives every pair table and is eliminated by the phase test.

`orbit_agent/orbit_phase_separator.py` implements the checks. It accepts an exact integer count vector and returns replayable inconsistency witnesses: an internal conflict, incompatible offsets, or a parity cycle for each excluded direction. Passing is necessary only. Known VT_0 counts pass; the three-orbit obstruction passes all pair checks and fails the phase check.

## 5. A separate all-radius expansion certificate

For every a=1,...,12 and every nonempty T subset V_a,

    |N_B(T)| >= |T|+1.

Each of twelve certificates gives a 315-edge matching saturating V_a, leaving one baseline word unmatched. Alternating reachability from that unmatched baseline word reaches all 631 vertices. If a nonempty T were Hall-tight, every member of N(T) would be matched back into T, so such a path could never first enter T. Contradiction.

This excludes neutral or improving single-syndrome trades at every removal radius. The proof is a matching-and-reachability argument, with no LP, floating point, or bounded-radius search. This strict expansion is not asserted for all lengths; length-6 and length-10 checks provide negative controls.

## 6. Verification and research implications

Run from the unpacked bundle:

    python deletion_research/verify_all.py

Only the Python standard library is needed. The combined verification passed in about 1.75 seconds here, checking the four-syndrome certificates, whole-cell bound and uniqueness, twelve strict-Hall certificates, explicit rank/phase witnesses, all 1,024 Cayley pair templates, separator controls, and the lifted rank-seven proof DAG. Scripts needing NumPy/SciPy are discovery helpers, not proof dependencies.

The provided dossier's old radius-nine enumeration is not rechecked because its artifacts were not part of the attachment. Combining its reported theorem with our results, any candidate alternative of size at least 316 must remove at least ten baseline words, use at least five VT syndromes, and split a weight/unreduced-checksum cell. The first condition remains attributed to the supplied dossier; the latter two are independently certified here.

No result in this bundle changes the unrestricted interval 316<=A(12,1)<=320. The supplied finite improvement for the active orbit route is precise: retain unrestricted counts, impose exact pair tables, and separate incompatible two-per-orbit components by the polynomial phase test. A new universal upper bound still requires a globally verified certificate for the resulting optimization problem.

## Primary literature and novelty boundaries

- Weindel and Heckel, *LLM-Guided Search for Deletion-Correcting Codes*, arXiv:2504.00613v2: https://arxiv.org/html/2504.00613v2 . Table 1 reports the length-12 baseline and upper bound used here.
- Nakasho, Hagiwara, Anderson and Nation, *The Tight Upper Bound for the Size of Single Deletion Error Correcting Codes in Dimension 11*, arXiv:2309.14736v1: https://arxiv.org/html/2309.14736v1 . Their conclusion explicitly reports failure to improve the length-12 upper bound below 320.
- Sloane, *On Single-Deletion-Correcting Codes*: https://neilsloane.com/doc/dijen.pdf . Perfect VT classes, the optimality conjecture, and neutral trades are prior work.
- Gerards and Shepherd, *The Graphs with All Subgraphs T-Perfect*, SIAM Journal on Discrete Mathematics 11(4), 1998, DOI 10.1137/S0895480196306361: https://epubs.siam.org/doi/10.1137/S0895480196306361 . Odd-K4 subdivision obstructions are established polyhedral theory.
- Sewell and Trotter, *Stability critical graphs and ranks facets of the stable set polytope*, Discrete Mathematics 147, 1995, DOI 10.1016/0012-365X(94)00168-I: https://www.sciencedirect.com/science/article/pii/0012365X9400168I . Rank inequalities from critical subgraphs are prior work.

No claim of first publication is made for the length-12 structural statements. Their proofs and precise differences from the supplied dossier are available for independent review.
