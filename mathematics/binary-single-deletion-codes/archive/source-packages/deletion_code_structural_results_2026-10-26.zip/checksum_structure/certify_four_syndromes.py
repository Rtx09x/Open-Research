#!/usr/bin/env python3
"""Certify one of two bounded batches of four-syndrome representatives.

Usage: python certify_four_syndromes.py 0|1
The two batches partition the 365 representatives under checksum negation.
Each run is single-threaded, address-space limited to 1 GiB, and has a
145-second wall-clock work budget. A failed mathematical threshold stops
the batch immediately and is recorded as a failure, not a code witness.
"""

import json
import math
import os
from pathlib import Path
import resource
import sys
import time
import warnings
from itertools import combinations

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
resource.setrlimit(resource.RLIMIT_CPU, (148, 149))

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

batch = int(sys.argv[1])
assert batch in (0,1)
n = 12
denominator = 10**9
outside_bonus = denominator // 10000
all_sets = list(combinations(range(13),4))
negate = lambda s: tuple(sorted((-a)%13 for a in s))
representatives = [s for s in all_sets if s <= negate(s)]
assert len(all_sets)==715 and len(representatives)==365
split = 183
work = representatives[:split] if batch==0 else representatives[split:]
syndrome = [sum(i*((x>>(n-i))&1) for i in range(1,n+1))%13 for x in range(4096)]
descendants = [sorted({((x>>(k+1))<<k)|(x&((1<<k)-1)) for k in range(n)})
               for x in range(4096)]
rows,cols = [],[]
for x,ys in enumerate(descendants):
    rows.extend(ys)
    cols.extend([x]*len(ys))
incidence = coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(2048,4096)).tocsc()
records = []
failed = []
started = time.monotonic()
output = Path(__file__).with_name(f"four_syndrome_duals_part{batch}.json")

def save():
    result = {"n":12,"denominator":denominator,"outside_bonus":outside_bonus,
              "batch":batch,"required_representatives":work,"records":records,
              "failed":failed,"elapsed_seconds":time.monotonic()-started}
    output.write_text(json.dumps(result,separators=(",", ":"))+"\n")

with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    for index,support in enumerate(work):
        if time.monotonic()-started > 139:
            failed.append({"support":support,"reason":"whole_job_time_cap"})
            break
        keep = [x for x in range(4096) if syndrome[x] in support]
        has_zero = 0 in support
        targets = [denominator+(outside_bonus if has_zero and syndrome[x] else 0) for x in keep]
        objective = -np.array(targets,dtype=float)/denominator
        result = linprog(objective,A_ub=incidence[:,keep],b_ub=np.ones(2048),
                         bounds=(0,None),method="highs",
                         options={"threads":1,"time_limit":5})
        if not result.success:
            failed.append({"support":support,"reason":result.message})
            break
        numerators = [max(0,math.ceil(-v*denominator)) for v in result.ineqlin.marginals]
        for x,target in zip(keep,targets):
            deficit = target-sum(numerators[y] for y in descendants[x])
            if deficit>0:
                numerators[descendants[x][0]] += deficit
        assert all(sum(numerators[y] for y in descendants[x])>=target for x,target in zip(keep,targets))
        total = sum(numerators)
        threshold = 316*denominator+(outside_bonus if has_zero else 0)
        if total>=threshold:
            failed.append({"support":support,"reason":"cover_not_strong_enough",
                           "total_numerator":total,"threshold":threshold,
                           "numerical_objective":-result.fun,
                           "fractional_primal":[[x,float(result.x[i])] for i,x in enumerate(keep) if result.x[i]>1e-8]})
            break
        records.append({"support":support,"total_numerator":total,
                        "weights":[[y,q] for y,q in enumerate(numerators) if q]})
        if (index+1)%20==0:
            save()
            print(f"batch{batch}: {index+1}/{len(work)}, elapsed={time.monotonic()-started:.1f}s",flush=True)

save()
print(json.dumps({"batch":batch,"stored_records":len(records),"required_records":len(work),
                  "elapsed_seconds":time.monotonic()-started,
                  "failed":[{k:v for k,v in f.items() if k!="fractional_primal"} for f in failed]},indent=2))
