# Every alternative code of size at least 316 needs at least five VT syndromes

For a binary word `x` of length 12, write

    sigma(x) = sum_{i=1}^{12} i x_i (mod 13),
    V_a = {x : sigma(x)=a},
    B = V_0.

## Theorem

**If a length-12 binary single-deletion code `C` uses at most four VT
syndromes and `|C| >= 316`, then `C = B`.**

Consequently every different code with at least 316 words, including any
317-word construction, must use **at least five distinct VT syndromes**.
There is no restriction on its distance from `B`, and no assumption of
complement or reversal invariance of the code.

The more precise classification is:

| Four-element syndrome support | Number of supports | Exact optimum |
| --- | ---: | --- |
| Contains zero | 220 | 316, attained uniquely by `B` |
| Does not contain zero | 495 | 315 |

For the second row, any one of its VT classes supplies 315 words. For the
first row, `B` supplies 316 words. Thus the stated upper bounds are sharp
for every support.

This theorem supersedes the three-syndrome exclusion established in the
companion note. It does **not** prove an unrestricted upper bound below
320, and it does not supply a 317-word construction. Literature priority
has not been established; this is a new result relative to the supplied
research dossier.

## Weighted packing certificate

Set

    D = 1,000,000,000,
    e = 100,000,

so that `e/D = 1/10,000`.

For each required syndrome support `S`, the certificate gives nonnegative
integer weights `q_S(y)` on the 2,048 possible received words `y` of length
11. Omitted weights are zero. There are two cases.

### Supports not containing zero

The weights satisfy

    sum_{y in D(x)} q_S(y) >= D       for every x with sigma(x) in S,
    sum_y q_S(y) < 316 D.

For any deletion code `C` contained in this support, its distinct deletion
balls are pairwise disjoint. Therefore

    D |C| <= sum_{x in C} sum_{y in D(x)} q_S(y)
           <= sum_y q_S(y) < 316 D.

Hence `|C| <= 315`.

### Supports containing zero

The weights satisfy the stronger coverage conditions

    sum_{y in D(x)} q_S(y) >= D         if x belongs to B,
    sum_{y in D(x)} q_S(y) >= D + e     if sigma(x) in S and x not in B,
    sum_y q_S(y) < 316 D + e.

Writing `t = |C minus B|`, disjointness gives

    D |C| + e t < 316 D + e.

Because `0 < e < D`, this excludes `|C| >= 317`. If `|C|=316`, it forces
`t=0`. Since `B` has exactly 316 words, `C=B` follows. Every code supported
on fewer than four syndromes is contained in one of these four-element
supports, completing the theorem.

## Why 365 representatives cover all 715 supports

For bitwise complement `bar(x)`,

    sigma(bar(x)) = (1+2+...+12) - sigma(x)
                 = 78 - sigma(x)
                 = -sigma(x) (mod 13).

Complement commutes with deletion. Thus it maps the conflict graph to
itself and maps syndrome support `S` to

    -S = {(-a mod 13) : a in S}.

The received-word weights transport by

    q_{-S}(y) = q_S(bar(y)).

Their total is unchanged. Zero stays zero, so the extra outsider weight
`e` is also preserved. This is a proof about a graph automorphism; the
code itself is never assumed to be invariant under that automorphism.

Taking the lexicographically smaller of `S,-S` leaves 365 representatives:
110 containing zero and 255 not containing zero. The 15 fixed supports
have the form `{a,-a,b,-b}`. Their complement closure is exactly the 715
four-element subsets of the 13 syndromes.

Reversal independently has the same checksum action,

    sigma(reverse(x)) = 13 wt(x) - sigma(x) = -sigma(x) (mod 13),

and also commutes with deletion. Only one of these two automorphisms is
needed to transport the certificates.

## Exact verification and computational scope

The independent verifier `verify_four_syndromes.py` uses only Python's
standard library. It imports neither the generator nor a numerical
optimizer. It does the following:

1. Reconstructs all 4,096 binary words and their checksums directly.
2. Rebuilds every distinct deletion ball by string slicing.
3. Checks the class sizes `[316,315,...,315]` and independently verifies
   that every `V_a` has disjoint deletion balls covering all 2,048 outputs.
4. Checks complement and reversal checksum identities and their
   commutation with deletion for all 4,096 words.
5. Checks that all 365 representatives occur exactly once and that their
   complement closure is exactly all 715 supports.
6. Checks all nonnegative integer weights, **460,010 exact coverage
   inequalities**, and all strict cost thresholds.

The largest total weight among zero-containing supports was

    316 D + 658,

which is strictly smaller than `316 D + 100,000`. In ordinary units this
is `316.000000658 < 316.0001`.

The largest total weight among nonzero supports was

    315,133,333,948,

or `315.133333948 < 316` in ordinary units. The fractional upper bound
rounds to the integer bound 315. No assertion is made that the fractional
packing optimum equals 315 for all these supports.

The generator used a numerical LP to discover dual weights, rounded every
coordinate upward at denominator `10^9`, and repaired any remaining
coverage deficit using exact integers. **The proof rests on the stored
integer certificates and the independent checker, not on solver status
or floating-point assumptions.**

The 365 representatives were split into sequential batches of 183 and
182. They took approximately 117.9 and 125.5 seconds, respectively. Each
job was restricted to one CPU, a 1 GiB address-space limit, and a hard
150-second timeout. Independent verification took approximately one
second. All supports passed; there is no unresolved case in this theorem.

## Globally valid count inequalities

Let `z_x` be the 0/1 incidence vector of an otherwise unrestricted deletion
code. Each zero-containing four-element support `S` yields

    315 sum_{x in B} z_x
      + 316 sum_{x : sigma(x) in S minus {0}} z_x <= 99,540.

If the code's restriction to these classes contains an outsider, it has
at most 315 words, and its weighted count is at most `316*315`. If it
contains no outsider, it has at most 316 baseline words, giving the same
bound. Each nonzero support yields the rank inequality

    sum_{x : sigma(x) in S} z_x <= 315.

These are valid for the unrestricted problem but primarily exclude
constructions concentrated in a few checksum classes. Their existence
does not by itself show they tighten the balanced global fractional
optimum or improve the unrestricted upper bound 320.

## Certificate files and replay

Required files:

- `four_syndrome_duals_part0.json`
- `four_syndrome_duals_part1.json`
- `verify_four_syndromes.py`

Replay:

    python checksum_structure/verify_four_syndromes.py

Generator, if regeneration is desired:

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout 150s python checksum_structure/certify_four_syndromes.py 0
    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout 150s python checksum_structure/certify_four_syndromes.py 1

SHA-256 values:

    four_syndrome_duals_part0.json
    1e7f0c8478321aa30af08b05a485bc08281b0962f633a3548618b5c214da8cd9

    four_syndrome_duals_part1.json
    1191b5677ed18484eb6252b7e7d657fef9943904432a7ee87e8428b8fe50ad07
