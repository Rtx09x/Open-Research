#!/usr/bin/env python3
"""Deterministically create the small n=12 matching certificate.

This generator uses bit operations. Its independent verifier uses strings.
"""

import json
from pathlib import Path

n = 12
syndrome = [sum(i * ((x >> (n-i)) & 1) for i in range(1, n+1)) % 13
            for x in range(1 << n)]
classes = [[x for x in range(1 << n) if syndrome[x] == a] for a in range(13)]
owner = {}
for b in classes[0]:
    for k in range(n):
        owner[((b >> (k+1)) << k) | (b & ((1 << k)-1))] = b

images = {}
for a in range(1, 13):
    left = classes[a]
    neighbors = {x: sorted({owner[((x >> (k+1)) << k) | (x & ((1 << k)-1))]
                            for k in range(n)}) for x in left}
    inverse_match = {}

    def augment(x, seen):
        for b in neighbors[x]:
            if b in seen:
                continue
            seen.add(b)
            if b not in inverse_match or augment(inverse_match[b], seen):
                inverse_match[b] = x
                return True
        return False

    for x in left:
        assert augment(x, set())
    match = {x: b for b, x in inverse_match.items()}
    images[str(a)] = [match[x] for x in left]

output = Path(__file__).with_name("strict_hall_n12.json")
output.write_text(json.dumps({"n": 12, "matching_images": images}, separators=(",", ":")) + "\n")
print(output)
