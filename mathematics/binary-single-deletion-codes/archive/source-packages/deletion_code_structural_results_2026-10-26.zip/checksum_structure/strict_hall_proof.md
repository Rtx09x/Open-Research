# A global obstruction to a single-checksum trade at length 12

Let `B = VT_0(12)` and let `A_a = VT_a(12)`, for `1 <= a <= 12`.
Join `x in A_a` to `b in B` precisely when their distinct one-deletion
descendant sets intersect. For `T subset A_a`, write `N(T)` for its
neighbors in `B`.

## Verified theorem

For every `a = 1,...,12` and every **nonempty** `T subset A_a`,

    |N(T)| >= |T| + 1.

The statement concerns all subsets of each 315-word class. There is no
restriction on the size of `T`, no restriction to small removal supports,
and no assumption of complement or reversal invariance.

## Certificate lemma and proof

Consider any bipartite graph with left side `A`, right side `B`, and
`|B| = |A| + 1`. Suppose a matching saturates `A`, leaving exactly one
right vertex `b_*` unmatched. Start at `b_*`, allow steps from a right
vertex to any neighboring left vertex, and then from a left vertex to its
matched right vertex. Suppose all left vertices can be reached this way.
Then every nonempty `T subset A` satisfies `|N(T)| >= |T| + 1`.

Indeed, the matching gives `|N(T)| >= |T|`. If equality held for nonempty
`T`, then `N(T)` would equal the set of matched partners of `T`; in
particular, `b_*` would not belong to `N(T)`. No allowed alternating path
from `b_*` could first enter `T`: the right vertex immediately preceding
that first entry would lie in `N(T)`, so, being matched, it could only have
been reached through its matched partner, which already belongs to `T`.
This contradicts first entry. Thus no vertex in `T` would be reachable,
contrary to the hypothesis.

The certificate supplies twelve matchings, each with 315 edges. The
independent verifier reconstructs every word's checksum and descendants
by direct string slicing, checks every matching edge, checks the unique
unmatched baseline vertex, and checks reachability of all 315 left and
316 right vertices. It uses only the Python standard library and exact
integer/set operations. The generator uses a separate packed-bit
implementation of descendants.

## Consequences

1. `B` is the **unique** size-316 deletion code contained in `B union A_a`.
   To see this, write a code there as `(B minus S) union T`.
   If `T` is nonempty, disjoint deletion balls require `N(T) subset S`, so
   its size is at most `316 - |N(T)| + |T| <= 315`.

2. No neutral or improving replacement of `B` can use outsiders from only
   one nonzero VT syndrome, regardless of the replacement radius. In
   particular, every different code with at least 316 words contains
   outsiders from at least two nonzero VT syndromes.

3. For an arbitrary 0/1 incidence vector of a deletion code and any
   `u in A_a`, the following valid lifted inequality holds:

       sum_{b in B} x_b + sum_{v in A_a} x_v + x_u <= 316.

   If `x_u=0`, the restriction to `B union A_a` has at most 316 words;
   if `x_u=1`, it has at most 315. These inequalities are globally valid
   even when the code also uses other syndrome classes. Their practical
   strength near a balanced fractional solution has not been established.

## Scope

This does not prove the unrestricted maximum is 316 or improve the known
unrestricted upper bound 320. It rules out a precisely defined class of
arbitrarily large trades. It is new relative to the supplied dossier;
priority in the literature has not been established.

The strict expansion claim should **not** be extrapolated to all block
lengths. Direct checks at lengths 6 and 10 exhibit Hall-tight nonempty
subsets for syndromes 1 and n. The length-12 certificates are essential.

## Replay

    python checksum_structure/generate_strict_hall.py
    python checksum_structure/verify_strict_hall.py

Generation and verification each take well under one second here. The
certificate is a list of integer matching partners, not solver output or
a floating-point bound.
