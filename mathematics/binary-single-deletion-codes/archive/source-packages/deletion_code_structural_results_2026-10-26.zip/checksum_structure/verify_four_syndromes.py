#!/usr/bin/env python3
"""Exact independent verifier for all 715 four-syndrome supports.

Checks the 365 representative duals, validates complement's action on all
words and deletion balls, and checks that negation closes the family to
exactly all 715 supports. No numerical packages or optimizer are imported.
"""

import hashlib
import json
from itertools import combinations
from pathlib import Path
import sys

base = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
paths = [base/f"four_syndrome_duals_part{b}.json" for b in (0,1)]
parts = [json.loads(path.read_text()) for path in paths]
assert all(part["n"]==12 and not part["failed"] for part in parts)
assert [part["batch"] for part in parts]==[0,1]
denominator = parts[0]["denominator"]
bonus = parts[0]["outside_bonus"]
assert denominator>bonus>0 and all(isinstance(t,int) for t in (denominator,bonus))
assert all(part["denominator"]==denominator and part["outside_bonus"]==bonus for part in parts)

words = [format(x,"012b") for x in range(4096)]
syndromes = [sum(i for i,bit in enumerate(s,1) if bit=="1")%13 for s in words]
descendants = [{int(s[:i]+s[i+1:],2) for i in range(12)} for s in words]
assert [sum(a==b for a in syndromes) for b in range(13)] == [316]+[315]*12
for a in range(13):
    class_outputs = set()
    for x in range(4096):
        if syndromes[x]==a:
            assert not (class_outputs & descendants[x])
            class_outputs.update(descendants[x])
    assert len(class_outputs)==2048
for x in range(4096):
    assert syndromes[4095-x] == (-syndromes[x])%13
    assert descendants[4095-x] == {2047-y for y in descendants[x]}
    reversed_x = int(words[x][::-1],2)
    assert syndromes[reversed_x] == (-syndromes[x])%13
    assert descendants[reversed_x] == {int(format(y,"011b")[::-1],2) for y in descendants[x]}

expected_all = set(combinations(range(13),4))
negate = lambda s: tuple(sorted((-a)%13 for a in s))
expected_reps = {s for s in expected_all if s<=negate(s)}
assert len(expected_all)==715 and len(expected_reps)==365
seen = set()
closure = set()
checks = 0
max_zero_excess = 0
max_nonzero_total = 0

for part in parts:
    required = {tuple(s) for s in part["required_representatives"]}
    assert len(required)==len(part["required_representatives"])
    local_seen = set()
    for record in part["records"]:
        support = tuple(record["support"])
        assert support in expected_reps and support not in seen and support in required
        seen.add(support)
        local_seen.add(support)
        closure.update((support,negate(support)))
        assert (0 in support)==(0 in negate(support))
        q = [0]*2048
        for y,numerator in record["weights"]:
            assert isinstance(y,int) and 0<=y<2048
            assert isinstance(numerator,int) and numerator>0 and q[y]==0
            q[y]=numerator
        has_zero = 0 in support
        total = sum(q)
        assert total == record["total_numerator"]
        assert total < 316*denominator+(bonus if has_zero else 0)
        for x in range(4096):
            if syndromes[x] not in support:
                continue
            target = denominator+(bonus if has_zero and syndromes[x] else 0)
            assert sum(q[y] for y in descendants[x])>=target
            checks += 1
        if has_zero:
            max_zero_excess=max(max_zero_excess,total-316*denominator)
        else:
            max_nonzero_total=max(max_nonzero_total,total)
    assert local_seen==required

assert seen==expected_reps and closure==expected_all
print(json.dumps({"verified":True,"representatives":len(seen),"supports_after_complement":len(closure),
                  "integer_coverage_checks":checks,"denominator":denominator,"outside_bonus":bonus,
                  "max_zero_cover_excess_numerator":max_zero_excess,
                  "max_nonzero_cover_total_numerator":max_nonzero_total,
                  "certificate_sha256":{path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}},indent=2))
