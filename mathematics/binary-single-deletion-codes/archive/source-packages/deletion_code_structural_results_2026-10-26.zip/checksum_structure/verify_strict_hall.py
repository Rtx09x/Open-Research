#!/usr/bin/env python3
"""Verify n=12 strict Hall certificates, using only standard-library integers.

Usage: python verify_strict_hall.py [strict_hall_n12.json]
The certificate lists a matching into VT_0 for each of the twelve nonzero
syndromes. Vertices on the left are implicitly in increasing binary order.
All deletion edges and all alternating reachability are reconstructed here.
"""

import hashlib
import json
from collections import deque
from pathlib import Path
import sys


def verify(path):
    certificate = json.loads(path.read_text())
    assert certificate["n"] == 12
    n = 12
    words = [format(x, "012b") for x in range(1 << n)]
    syndromes = [sum(i for i, bit in enumerate(s, 1) if bit == "1") % 13
                 for s in words]
    classes = [[x for x in range(1 << n) if syndromes[x] == a]
               for a in range(13)]
    assert list(map(len, classes)) == [316] + [315] * 12
    descendants = [{s[:i] + s[i+1:] for i in range(n)} for s in words]
    baseline = set(classes[0])
    owner = {}
    for b in sorted(baseline):
        for y in descendants[b]:
            assert y not in owner
            owner[y] = b
    assert len(owner) == 2048

    reports = []
    for a in range(1, 13):
        left = classes[a]
        image = certificate["matching_images"][str(a)]
        assert len(image) == len(left) == 315
        assert len(set(image)) == 315
        assert set(image) <= baseline
        match = dict(zip(left, image))
        neighbors = {x: {owner[y] for y in descendants[x]} for x in left}
        reverse = {b: set() for b in baseline}
        for x in left:
            assert match[x] in neighbors[x]
            assert descendants[x] & descendants[match[x]]
            for b in neighbors[x]:
                reverse[b].add(x)

        free = baseline - set(image)
        assert len(free) == 1
        reached_right = set(free)
        reached_left = set()
        queue = deque(free)
        while queue:
            b = queue.popleft()
            for x in reverse[b]:
                if x in reached_left:
                    continue
                reached_left.add(x)
                matched_b = match[x]
                if matched_b not in reached_right:
                    reached_right.add(matched_b)
                    queue.append(matched_b)
        assert reached_left == set(left)
        assert reached_right == baseline
        reports.append({"syndrome": a, "matching_size": len(match),
                        "free_baseline_word": next(iter(free)),
                        "reached_left": len(reached_left),
                        "reached_right": len(reached_right)})

    print(json.dumps({"verified": True, "n": n,
                      "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "strict_hall_syndromes": reports}, indent=2))


if __name__ == "__main__":
    supplied = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("strict_hall_n12.json")
    verify(supplied)
