"""One bounded control test for the new orbit constraints.

Rebuilds the dossier's all-clique relaxation only as a control, then measures
the concrete new rank inequalities and pair/star count consistency. Numerical
outputs from this file are experiments, never proof certificates.
"""
import argparse,json,math,time,warnings
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
from scipy.optimize import linprog,milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix,vstack,hstack,csc_matrix

ROOT=Path(__file__).resolve().parents[1]
def build():
    strings=[format(x,'012b') for x in range(4096)]
    outputs=[[] for _ in range(2048)]
    for x,s in enumerate(strings):
        for y in {s[:k]+s[k+1:] for k in range(12)}:outputs[int(y,2)].append(x)
    adj=[0]*4096
    for parents in outputs:
        mask=sum(1<<x for x in parents)
        for x in parents:adj[x] |= mask^(1<<x)
    orbits=[];oid={}
    for x,s in enumerate(strings):
        if x in oid:continue
        r=int(s[::-1],2);o=sorted({x,x^4095,r,r^4095})
        oid.update((v,len(orbits)) for v in o);orbits.append(o)
    rows=set();clique_count=0
    def visit(R,P,X):
        nonlocal clique_count
        if not P:
            if not X:
                clique_count+=1
                counts=Counter(oid[x] for x in R)
                rows.add(tuple(sorted((i,int(4//len(orbits[i]))*v) for i,v in counts.items())))
            return
        Q=P|X;pivot=-1;best=-1
        while Q:
            b=Q&-Q;Q^=b;u=b.bit_length()-1;score=(P&adj[u]).bit_count()
            if score>best:best=score;pivot=u
        candidates=P&~adj[pivot]
        while candidates:
            bit=candidates&-candidates;candidates^=bit;v=bit.bit_length()-1
            visit(R+[v],P&adj[v],X&adj[v]);P^=bit;X|=bit
    visit([], (1<<4096)-1,0)
    assert clique_count==155496,clique_count
    rr=[];cc=[];dd=[]
    for k,row in enumerate(sorted(rows)):
        for i,v in row:rr.append(k);cc.append(i);dd.append(v)
    A=coo_matrix((np.asarray(dd,float),(rr,cc)),shape=(len(rows),len(orbits))).tocsc()
    alpha=[]
    for o in orbits:
        aa=0
        for m in range(1<<len(o)):
            vs=[o[k] for k in range(len(o)) if (m>>k)&1]
            if all(not ((adj[v]>>w)&1) for k,v in enumerate(vs) for w in vs[k+1:]):aa=max(aa,len(vs))
        alpha.append(aa)
    return A,np.array(alpha),orbits,oid

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--milp-seconds',type=float,default=0);args=parser.parse_args()
    start=time.monotonic();A,alpha,orbits,oid=build();n=len(orbits)
    print(json.dumps({'stage':'built','all_cliques':155496,'averaged_rows':A.shape[0],'orbit_variables':n,'seconds':time.monotonic()-start}),flush=True)
    res=linprog(-np.ones(n),A_ub=A,b_ub=np.full(A.shape[0],4.),bounds=list(zip(np.zeros(n),alpha)),method='highs',options={'threads':1})
    assert res.success,res.message
    (ROOT/'deletion_research/clique_lp_point.json').write_text(json.dumps({'numerical_only':True,'bound':-res.fun,'orbit_counts':res.x.tolist(),'word_values':[float(res.x[oid[x]]/len(orbits[oid[x]])) for x in range(4096)],'orbits':orbits},indent=2)+'\n')
    # A 16-vertex two-subdivision of K4; the averaged rank7 inequality is
    # 2 z_center + sum_(six outer orbits) z <=14.
    hubs=[1109,1373,2722,2986]
    outer=[173,605,1321,2705,1237,1493,1357,1349,1390,2774,2896,2980]
    hub_id=oid[hubs[0]];outer_ids=sorted(set(oid[x] for x in outer))
    assert len(outer_ids)==6 and all(oid[x]==hub_id for x in hubs)
    cut=np.zeros(n);cut[hub_id]=2;cut[outer_ids]=1
    report={'numerical_only':True,'all_clique_bound':-res.fun,'rank7_lhs_at_control_optimum':float(cut@res.x),'rank7_rhs':14,'rank13_lhs_at_control_optimum':float(sum(res.x[i] for i in [hub_id]+outer_ids)),'rank13_rhs':13}
    rank=np.zeros(n);rank[hub_id]=1;rank[outer_ids]=1
    A=vstack([A,csc_matrix(cut.reshape(1,-1)),csc_matrix(rank.reshape(1,-1))],format='csc');rhs=np.r_[np.full(A.shape[0]-2,4.),14.,13.]
    strengthened=linprog(-np.ones(n),A_ub=A,b_ub=rhs,bounds=list(zip(np.zeros(n),alpha)),method='highs',options={'threads':1})
    report['with_two_rank_rows']=-strengthened.fun
    if args.milp_seconds>0:
        pair=json.loads((ROOT/'orbit_agent/pair_tables.json').read_text())['strict_pairs']
        phase=json.loads((ROOT/'orbit_agent/phase_witnesses.json').read_text())['simple_stars']
        thresholds=set()
        for row in pair:
            f=row['f'];thresholds.update((row['i'],k) for k in range(1,len(f)) if f[k-1]!=f[k])
        for star in phase:thresholds.update((i,2) for i in star['ids'])
        thresholds=sorted(thresholds);tid={p:n+k for k,p in enumerate(thresholds)};N=n+len(thresholds)
        rr=[];cc=[];dd=[];ub=[]
        def add(entries,bound):
            k=len(ub);ub.append(bound)
            for j,v in entries:rr.append(k);cc.append(j);dd.append(v)
        for (i,k),j in tid.items():
            add([(i,-1),(j,k)],0)
            add([(i,1),(j,-int(alpha[i]-k+1))],k-1)
        for row in pair:
            f=row['f'];entries=[(row['j'],1)]
            entries += [(tid[row['i'],k],f[k-1]-f[k]) for k in range(1,len(f)) if f[k-1]!=f[k]]
            add(entries,f[0])
        for star in phase:add([(tid[i,2],1) for i in star['ids']],2)
        add([(i,-1) for i in range(n)],-320)
        extra=coo_matrix((np.asarray(dd,float),(rr,cc)),shape=(len(ub),N)).tocsc()
        model=vstack([hstack([A,csc_matrix((A.shape[0],N-n))],format='csc'),extra],format='csc')
        upper=np.r_[rhs,ub];lb=np.zeros(N);hi=np.r_[alpha,np.ones(N-n)]
        # WLOG for a maximum: replace any weight-one word by the all-zero
        # word, and any weight-eleven word by the all-one word.
        lb[oid[0]]=2;hi[oid[0]]=2
        opt=milp(np.zeros(N),integrality=np.ones(N),bounds=Bounds(lb,hi),constraints=LinearConstraint(model,np.full(model.shape[0],-np.inf),upper),options={'time_limit':args.milp_seconds,'mip_rel_gap':0.,'threads':1})
        report['strengthened_320_feasibility']={'variables':N,'thresholds':N-n,'strict_pairs':len(pair),'phase_stars':len(phase),'status':int(opt.status),'message':opt.message,'nodes':int(getattr(opt,'mip_node_count',0) or 0),'has_candidate':opt.x is not None}
        if opt.x is not None:
            counts=np.rint(opt.x[:n]).astype(int)
            report['strengthened_320_feasibility']['candidate_total']=int(sum(counts))
            (ROOT/'deletion_research/orbit_count_candidate.json').write_text(json.dumps({'counts':counts.tolist(),'orbits':orbits},indent=2)+'\n')
    report['seconds']=time.monotonic()-start
    (ROOT/'deletion_research/orbit_relaxation_probe.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':
    warnings.filterwarnings('ignore',category=RuntimeWarning)
    warnings.filterwarnings('ignore',category=UserWarning)
    main()
