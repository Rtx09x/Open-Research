#!/usr/bin/env python3
"""Replay the substantive mathematical certificates with the standard library.

Run from any working directory. No optimizer or numerical package is required.
The supplied dossier's old removal-radius result is not rechecked by this file.
"""
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
jobs=[
    ('four_syndrome_theorem',root/'checksum_structure/verify_four_syndromes.py',[]),
    ('whole_cell_uniqueness',root/'deletion_structured/verify_cells.py',[]),
    ('strict_hall',root/'checksum_structure/verify_strict_hall.py',[]),
    ('orbit_rank_and_phase',root/'deletion_research/verify_orbit_structure.py',[]),
    ('lifted_rank7',root/'orbit_agent/lift_subdivision_cut.py',
      ['--verify',str(root/'deletion_research/lifted_rank7.json')]),
]
start=time.monotonic();reports={}
for name,script,args in jobs:
    result=subprocess.run([sys.executable,'-B',str(script),*args],cwd=root,
                          check=True,capture_output=True,text=True,timeout=60)
    try: reports[name]=json.loads(result.stdout)
    except json.JSONDecodeError:reports[name]={'output':result.stdout.strip()}
summary={'all_verifiers_passed':True,'seconds':time.monotonic()-start,'reports':reports}
print(json.dumps(summary,indent=2))
