"""Independent integer/string checks of the structural orbit witnesses.

No solver, NumPy or graph package is used. The general proofs are in REPORT.md.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations,product
from pathlib import Path
import json,sys

N=12
def descendants(x):
    s=format(x,'012b')
    return {s[:i]+s[i+1:] for i in range(N)}

def orbit(x):
    r=int(format(x,'012b')[::-1],2)
    return {x,x^4095,r,r^4095}

def stable(vertices,ds):
    return all(not ds[x]&ds[y] for x,y in combinations(vertices,2))

def check_subdivision():
    hubs=[1109,1373,2722,2986]
    paths=[
        [1109,173,605,1373],[1109,1115,1199,1373],
        [1109,1321,2705,2722],[1109,2197,2378,2722],
        [1109,1237,1493,2986],[1109,2602,2858,2986],
        [1373,1357,1349,2722],[1373,2746,2738,2722],
        [1373,1390,2774,2986],[1373,1717,1898,2986],
        [2722,2896,2980,2986],[2722,3490,3922,2986]]
    words=sorted(set(sum(paths,[])));ds={x:descendants(x) for x in words}
    assert len(words)==28 and set(hubs)==orbit(hubs[0])
    expected={tuple(sorted((a,b))) for p in paths for a,b in zip(p,p[1:])}
    actual={(a,b) for a,b in combinations(words,2) if ds[a]&ds[b]}
    assert actual==expected and len(actual)==36
    assert Counter(tuple(sorted((p[0],p[-1]))) for p in paths)==Counter({p:2 for p in combinations(hubs,2)})
    chosen=paths[::2];sixteen=sorted(set(sum(chosen,[])))
    assert len(sixteen)==16
    expected16={tuple(sorted((a,b))) for p in chosen for a,b in zip(p,p[1:])}
    assert {(a,b) for a,b in combinations(sixteen,2) if ds[a]&ds[b]}==expected16
    assert len(expected16)==18
    # Independent bitmask dynamic program, exhaustive over all 65,536 subsets.
    adj=[]
    for x in sixteen:adj.append(sum(1<<j for j,y in enumerate(sixteen) if x!=y and ds[x]&ds[y]))
    dp=[0]*(1<<16)
    for m in range(1,1<<16):
        bit=m&-m;i=bit.bit_length()-1;rest=m^bit
        dp[m]=max(dp[rest],1+dp[rest&~adj[i]])
    assert dp[-1]==7
    witness=[173,1237,1321,1349,1373,2774,2896]
    assert len(witness)==7 and set(witness)<=set(sixteen) and stable(witness,ds)
    # All 64 path selections induce the same odd K4 subdivision.
    for pick in product(range(2),repeat=6):
        pp=[paths[2*i+b] for i,b in enumerate(pick)]
        vv=set(sum(pp,[]))
        ee={tuple(sorted((a,b))) for p in pp for a,b in zip(p,p[1:])}
        assert len(vv)==16 and {(a,b) for a,b in combinations(sorted(vv),2) if ds[a]&ds[b]}==ee
    weights={v:Fraction(1,3) if v in hubs else Fraction(1,2) for v in sixteen}
    assert sum(weights.values())==Fraction(22,3)>7
    assert all(weights[a]+weights[b]<=1 for a,b in expected16)
    assert 3*Fraction(1,3)+6*Fraction(1,2)==4
    assert max(6+s-s*(s-1)//2 for s in range(5))==7
    assert max(12+s-s*(s-1) for s in range(5))==13
    return {'rank7_words':sixteen,'rank7_witness':witness,'rank7':7,
            'all64_subdivisions_verified':True,'fractional_oddwalk_feasible_mass':'22/3'}

def check_pair_and_star():
    O=[818,1228,2867,3277];P=[1433,1637,2458,2662]
    ds={x:descendants(x) for x in O+P}
    assert set(O)==orbit(O[0]) and set(P)==orbit(P[0])
    assert stable(O,ds) and stable(P,ds)
    assert all(sum(bool(ds[x]&ds[y]) for y in P)==3 for x in O)
    assert all(sum(bool(ds[x]&ds[y]) for x in O)==3 for y in P)
    assert not any(stable(a+b,ds) for a in combinations(O,2) for b in combinations(P,2))
    O=[410,1432,2663,3685];P=[716,820,3275,3379];Q=[1230,1842,2253,2865]
    all_words=O+P+Q;ds={x:descendants(x) for x in all_words}
    for part in (O,P,Q):assert set(part)==orbit(part[0]) and stable(part,ds)
    assert stable(P+Q,ds)
    assert all(sum(bool(ds[x]&ds[y]) for y in P)==2 for x in O)
    assert all(sum(bool(ds[x]&ds[y]) for y in Q)==2 for x in O)
    for a,b in combinations((O,P,Q),2):
        assert any(stable(s+t,ds) for s in combinations(a,2) for t in combinations(b,2))
    assert not any(stable(a+b+c,ds) for a in combinations(O,2) for b in combinations(P,2) for c in combinations(Q,2))
    # The uniform 1/2 point is the average of two actual valid codes O and P+Q.
    assert stable(O,ds) and stable(P+Q,ds) and not set(O)&set(P+Q)
    return {'pair_count_obstruction':True,'star_pairwise_feasible':True,
            'star_jointly_infeasible':True,'star_point_in_true_stable_set_polytope':True}

def check_general_pair_algebra():
    # Exhaust every Cayley pair template, including all possible internal
    # conflict offsets: 8*8*16 templates, compared with all 36 pair choices.
    pairs=list(combinations(range(4),2));checks=0
    for ai,aj,tmask in product(range(8),range(8),range(16)):
        internal_i={d for d in (1,2,3) if ai>>(d-1)&1}
        internal_j={d for d in (1,2,3) if aj>>(d-1)&1}
        offsets={d for d in range(4) if tmask>>d&1}
        brute=any((s[0]^s[1]) not in internal_i and (t[0]^t[1]) not in internal_j
                  and all((a^b) not in offsets for a in s for b in t)
                  for s in pairs for t in pairs)
        if not offsets:
            criterion=bool(set((1,2,3))-internal_i) and bool(set((1,2,3))-internal_j)
        else:
            criterion=False
            for delta in (1,2,3):
                if delta in internal_i or delta in internal_j:continue
                requirements={int(t not in (0,delta))^1 for t in offsets}
                if len(requirements)==1:criterion=True
        assert brute==criterion,(ai,aj,tmask)
        checks+=1
    return checks

def check_separator():
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'orbit_agent'))
    from orbit_phase_separator import OrbitGraph
    graph=OrbitGraph(12)
    baseline=[x for x in range(4096) if sum(i for i,b in enumerate(format(x,'012b'),1) if b=='1')%13==0]
    counts=[0]*len(graph.orbits)
    for x in baseline:counts[graph.oid[x]]+=1
    control=graph.check_counts(counts)
    assert control['passes_necessary_checks'] and sum(counts)==316
    star=[0]*len(counts)
    for x in [410,716,1230]:star[graph.oid[x]]=2
    rejected=graph.check_counts(star)
    assert not rejected['internal_violations'] and not rejected['pair_violations']
    assert len(rejected['phase_cuts'])==1 and rejected['phase_cuts'][0]['cut']['rhs']==2
    return {'baseline316_passes':True,'pairwise_consistent_star_rejected':True}

if __name__=='__main__':
    result={'verified':True,'subdivision':check_subdivision(),
            'orbit_obstructions':check_pair_and_star(),
            'exhausted_cayley_pair_templates':check_general_pair_algebra(),
            'separator_controls':check_separator()}
    print(json.dumps(result,indent=2))
