import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from collections import defaultdict
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
import numpy as np,json,warnings,time
cells=defaultdict(list)
for x in range(4096):
 s=f'{x:012b}';cells[(s.count('1'),sum(i for i,c in enumerate(s,1) if c=='1'))].append(x)
keys=sorted(cells);n=len(keys);adj=[0]*n
for i,(w,s) in enumerate(keys):
 for j in range(i+1,n):
  v,t=keys[j]
  if(v==w and t-s<=max(w,12-w))or(v==w+1 and 1<=t-s<=12):adj[i]|=1<<j;adj[j]|=1<<i
qs=[]
def bk(r,p,x):
 if not p|x:qs.append(r);return
 ux=p|x;u=max((i for i in range(n)if ux>>i&1),key=lambda i:(p&adj[i]).bit_count())
 cand=p&~adj[u]
 while cand:
  b=cand&-cand;v=b.bit_length()-1;bk(r+[v],p&adj[v],x&adj[v]);p^=b;x|=b;cand^=b
start=time.monotonic();bk([],(1<<n)-1,0);print('cliques',len(qs),'seconds',time.monotonic()-start)
rows=[];cols=[]
for i,q in enumerate(qs):rows.extend([i]*len(q));cols.extend(q)
M=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(qs),n)).tocsc()
with warnings.catch_warnings():
 warnings.simplefilter('ignore');r=linprog(c=-np.array([len(cells[k])for k in keys]),A_ub=M,b_ub=np.ones(len(qs)),bounds=(0,None),method='highs',options={'threads':1})
print('cliqueLP',-r.fun);print('dualvalues',sorted(set(round(-y,9)for y in r.ineqlin.marginals)))
from fractions import Fraction
weights=[Fraction(float(-y)).limit_denominator(1000000)for y in r.ineqlin.marginals]
cover=[sum((weights[j] for j,q in enumerate(qs)if i in q),Fraction()) for i in range(n)]
print('dualexactvalid',all(cover[i]>=len(cells[k]) for i,k in enumerate(keys)),'exactsum',sum(weights))
if all(cover[i]>=len(cells[k]) for i,k in enumerate(keys)):
 cert=[{'cells':[keys[i]for i in q],'weight':[y.numerator,y.denominator]}for q,y in zip(qs,weights)if y]
 open('deletion_structured/cell_clique_certificate.json','w').write(json.dumps(cert,indent=2)+'\n')
