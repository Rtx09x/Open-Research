# Exact checksum-cell theorem (length 12)

## Proved statement and its scope

Let `wt(x)` be binary Hamming weight and `s(x)=sum(i*x_i, i=1..12)` the **unreduced** checksum. If membership of a length-12 single-deletion code is a function only of `(wt(x),s(x))`, its size is at most **316**, with equality **only for VT0**. Every other code in this family has at most315 words.

Equivalently, every code of size at least317 must distinguish at least two words having the same Hamming weight and the same unreduced checksum. This excludes every union of complete checksum/weight cells, including arbitrary weight-dependent checksum rules, unions of residues or intervals, and rules using any modulus that depend on no extra word information. It assumes no complement or reversal symmetry, but it is a restricted-family theorem, **not an unrestricted upper bound**.

At length12 there are299 cells. Their quotient conflict graph has4965 edges. A207-clique weighted cover with exact rational weights, all denominators dividing32, proves weighted independence number316. The certificate has total weight316 and covers each cell by at least the cardinality of the cell. Equality conditions leave a small exact-cover problem whose complete68-node enumeration has the unique solution VT0. The certificate and uniqueness are verified using Python integers/Fractions and direct string deletions; no floating-point solver status enters the theorem.

## Structural quotient, valid for general n

For each nonempty cell

    F(w,s) = {x in {0,1}^n : wt(x)=w, checksum(x)=s},

make one vertex of weight `|F(w,s)|`. Every cell is itself a single-deletion code. Join two cell vertices whenever some word in one conflicts with some word in the other. For distinct cells, the exact edges are:

1. Same weight w, with s<t: an edge iff `t-s <= max(w,n-w)`.
2. Adjacent weights w,w+1, with checksums s,t respectively: an edge iff `1 <= t-s <= n`.
3. Weight difference at least2: no edge.

Therefore every whole-cell code is exactly an independent set in this explicitly described weighted strip graph.

### Proof of the edge formula

Take a received word y of length n-1, weight w, and checksum u. Its distinct zero-insertion parents have checksums

    u, u+1, ..., u+w,

and its distinct one-insertion parents have checksums

    u+w+1, ..., u+n.

For zero insertion, the increment is the number of ones after the insertion position, attaining each integer0..w. Positions giving the same increment give the same resulting word. For one insertion, the increment is w+1 plus the number of zeros before the insertion position, attaining each integer w+1..n. Consequently all parents of a fixed received word have distinct checksums; this also proves independence of each cell.

The checksums attained by all length m, weight w words are every integer in

    L_m(w) = w(w+1)/2,
    U_m(w) = w(2m-w+1)/2.

To see no gaps, write one positions as `p_i=i+d_i` with `0<=d_1<=...<=d_w<=m-w`. Every total between0 and w(m-w) can be represented by such a nondecreasing list: use entries q and q+1 for the quotient/remainder upon division by w. The cases w=0 are immediate.

For adjacent weights w,w+1, a conflicting pair with checksums s,t exists exactly when an integer u belongs to all three intervals

    [L_(n-1)(w), U_(n-1)(w)],
    [s-w,s],
    [t-n,t-w-1].

The first interval is nonempty for w=0..n-1. The individual existence of the two cells supplies all boundary inequalities against the first interval. The remaining cross inequalities are precisely `t-s>=1` and `t-s<=n`. Since integer intervals have a common point iff all lower endpoints are at most all upper endpoints, this proves condition2.

For two weight-w cells, zero deletion is possible exactly when an integer u lies in `[L_(n-1)(w),U_(n-1)(w)]` and `[t-w,s]`, which is equivalent to `t-s<=w` (for w<n). One deletion similarly asks that u lie in `[L_(n-1)(w-1),U_(n-1)(w-1)]` and `[t-n,s-w]`, equivalent to `t-s<=n-w` (for w>0). The union gives condition1. Boundary weights0,n have only one cell each, so need no pair case. Condition3 follows because a deletion changes weight by at most1.

## Exact upper certificate

For a quotient clique Q, any independent cell selection I satisfies

    sum_(a in Q) 1_I(a) <= 1.

Assign nonnegative rational weights lambda_Q to207 such cliques. The supplied certificate satisfies

    sum_Q lambda_Q =316,
    sum_(Q containing a) lambda_Q >= |F_a|  for every cell a.

Multiply the clique inequalities by their weights and add. The number of original words in a whole-cell code is at most316. The VT0 selection attains316 and its deletion balls cover all2048 received words.

Run:

    python deletion_structured/verify_cells.py

The checker builds all4096 words by strings, recomputes cells and conflicts from2048 received words, verifies the analytic quotient formula on all cell pairs, checks every certificate clique, checks every rational covering inequality and its exact total316, verifies the316-word lower bound by direct deletion, and exhausts the68-node equality problem to prove uniqueness.

### Exact uniqueness check

For a whole-cell code with indicators z_a, write the gap to the certificate bound as

    316 - sum_a |F_a| z_a
      = sum_Q lambda_Q (1 - sum_(a in Q) z_a)
        + sum_a (sum_(Q containing a) lambda_Q - |F_a|) z_a.

Every term is nonnegative. Equality therefore forces every selected cell to have zero covering slack and every positive-weight certificate clique to contain exactly one selected cell. There are21 positive-slack cells, leaving278 eligible cells and207 exact-cover equations, together with the quotient conflict constraints.

The checker exhausts this system by choosing an uncovered clique with the fewest currently available cells, branching on each possible cell, removing that cell's conflicts and every other cell in every newly covered clique, and recursing. A branch with an uncovered clique having no available cell is impossible. A branch with all cliques covered gives a solution; every eligible cell belongs to a positive clique, so none can be added afterward. This search is exhaustive by induction on the number of uncovered rows. It visits68 nodes and yields exactly the cells with checksum divisible by13. Thus VT0 is the unique equality case.

Certificate SHA256:

    d4dd0e7abf44fcb4a4396a7253c5c5cbd071cc8940ae5d5c935d86048f9f3f53

## Why the restriction matters

An edge in the cell quotient says **some** two words conflict, not every cross-cell pair. For example, cell F(1,1) contains only the word with its one at position1. Cell F(2,8) contains the three words with one positions `(1,7)`, `(2,6)`, `(3,5)`. Only `(1,7)` conflicts with the first cell's word; the other two do not. Thus the normalized cell inequality `|C intersect F(1,1)|/1 + |C intersect F(2,8)|/3 <=1` is false for arbitrary codes: these three compatible words give5/3. The exact certificate cannot be silently promoted to unrestricted codes.

## Computational provenance

The299-cell graph's whole-cell MILP returned316 at its root in0.061s. This was used only as a guide. Enumeration found1162 maximal quotient cliques in0.114s; their weighted LP optimum was316. Its rationalized207 positive dual weights passed the independent exact checker in0.024s. The equality-case enumeration required68 nodes and0.003s; the extended checker, including all reconstruction and uniqueness, ran in0.048s. No search repeated the dossier's4096-word clique enumeration or bounded-radius trades.

Files:

- `cell_clique_certificate.json`: exact upper-bound certificate.
- `verify_cells.py`: solver-free independent checker; this and the JSON suffice.
- `cell_theorem.md`: this proof and scope.
- `cell_cliques.py`: generator used to find the certificate.
- `cell_milp.py`, `cell_milp.json`, `cell_code.txt`: exploratory whole-cell MILP and its316-word witness, not needed for verification.

Novelty beyond the supplied dossier is claimed only as a new result for this investigation; no literature-priority claim is made.
