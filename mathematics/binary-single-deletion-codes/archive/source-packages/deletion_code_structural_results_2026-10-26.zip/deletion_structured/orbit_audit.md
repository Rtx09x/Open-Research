# Independent audit: orbit phase obstruction and subdivision cuts

## Scope and result

I independently reconstructed all deletion neighborhoods of the28 words in `orbit_agent/subdivision_certificate.json` using **direct string slicing**, and checked every pair. The28-word induced conflict graph is exactly the graph obtained by replacing each edge of a K4 on the four hubs by **two internally vertex-disjoint length-three paths**. There are36 edges, and no extra edges. The indicated16-word subset is exactly the ordinary two-subdivision of K4: one length-three path for each of its six edges,18 edges, and no extra edges.

The rank13 and rank7 inequalities are valid for unrestricted codes. Their indicated fractional witnesses satisfy every original conflict clique inequality and every ordinary odd-closed-walk inequality on the **entire4096-vertex graph**. Thus nonredundancy against that combined continuous relaxation is proved. No universal numerical upper bound improvement follows from this alone.

The general graph-theoretic rank inequality for an odd K4 subdivision is not claimed novel. The contribution here is the explicit deletion-graph embedding, the orbit-phase route leading to it, and the resulting independently checkable new cuts relative to this dossier.

## Rank bounds

Let h be the number of selected hubs. Each length-three path `u-a-b-v` contributes at most one internal vertex, and contributes none if both endpoints u,v are selected. Its internal vertices do not appear on any other path.

For16 vertices (one path per pair of hubs), every independent set has size at most

    6 + h - binom(h,2),  h=0,1,2,3,4.

The five values are6,7,7,6,4, so the rank is at most7. It is attained by the following decimal words, independently verified pairwise nonconflicting:

    173, 1237, 1321, 1349, 1373, 2774, 2896.

Therefore every unrestricted code C obeys `|C intersect T16|<=7`.

For28 vertices (two paths per pair), the corresponding bound is

    12 + h - 2*binom(h,2),  h=0,1,2,3,4.

The values are12,13,12,9,4. The13-word witness supplied in the JSON was independently checked, proving exact rank13. Thus `|C intersect S28|<=13` universally.

This upper-bound argument would remain valid if the induced subgraphs had additional edges; the exact isomorphism check is additionally needed for the stated fractional witness and equality claims.

## Fractional witness: every clique and every odd closed walk

For either chosen subgraph, assign value1/3 to its four hubs,1/2 to each selected internal vertex, and0 to **every other word** in the4096-word conflict graph.

The sums are22/3 on T16 and40/3 on S28, violating their rank bounds by1/3.

### Clique inequalities

Both induced support graphs are triangle-free. An arbitrary clique of the full4096-vertex graph consequently intersects the positive support in at most two adjacent vertices. Those values sum to at most1. All other values are0. This covers all maximal cliques without requiring their enumeration.

### Odd closed walks, including walks leaving the support

For an odd closed walk of length L, the ordinary inequality is

    sum_(i=0..L-1) x_(v_i) <= (L-1)/2,

where repeated occurrences are counted. There are two exhaustive cases.

1. **At least one occurrence is outside the support.** Its value is0, and every other occurrence has value at most1/2. The sum is immediately at most `(L-1)/2`. Thus external graph shortcuts cause no problem.
2. **The entire walk lies inside the support.** Decompose the walk into simple cycles and length-two backtracks. Simple cycles use2,3, or4 distinct hubs, hence have lengths6,9,12 in S28, and9,12 in T16. The only odd simple cycles have length9. They contain three hubs and six internal vertices, giving weight `3*(1/3)+6*(1/2)=4=(9-1)/2`. Every even component has weight at most half its length, since all coordinates are at most1/2. An odd closed walk's decomposition contains at least one odd component; adding the component inequalities gives the desired deficit of at least1/2.

This proves feasibility for **all** ordinary odd closed walks, including repeated vertices, not merely the finitely many simple odd cycles found by a separator. This statement does not assert feasibility for arbitrary strengthened/lifted odd-cycle inequalities, which were not the dossier's claimed family.

## Averaging the16-word cut: a stronger and simpler orbit inequality

The28-word support consists of these seven free complement/reversal orbits:

    (173,1199,2896,3922)
    (605,1115,2980,3490)
    H=(1109,1373,2722,2986)
    (1237,1357,2738,2858)
    (1321,1717,2378,2774)
    (1349,1493,2602,2746)
    (1390,1898,2197,2705)

The16-word set contains all four hubs and exactly two words from each of the other six orbits. Let z_H be the number of selected hub words and z_i the counts in the other orbits. Averaging the rank7 inequality over the Klein-four group gives

    2 z_H + sum_(six nonhub orbits i) z_i <= 14.

This is valid for **arbitrary** codes: averaging inequalities does not require the code to be invariant, and the coefficient of each word is the fraction of the16-word set's orbit represented by that word's orbit.

The twelve internal pairs a-b are disjoint conflict edges, so original clique rows already give

    sum_(six nonhub orbits i) z_i <=12.

Taking half the sum of these two inequalities gives

    z_H + sum_i z_i <=13.

Consequently the28-word rank13 cut is **dominated by the averaged16-word rank7 cut together with existing edge rows**. Both cuts are valid, but the16-word rank7 cut (and its orbit average) is the more useful primary deliverable. Reporting the28-word cut as a separate stronger family would be misleading.

## General half-orbit phase-lifting theorem

This theorem applies to a selected collection of **free four-element** Klein-four orbits when exactly two words are required from each orbit. It does not impose this count condition on arbitrary codes; it tests a specified orbit-count pattern.

Identify the group with F2^2, choose representatives c_i, and label orbit i as `{g*c_i:g in F2^2}`. Every two-element subset of a free orbit is an affine line

    a_i + {0,delta_i},  delta_i !=0.

For distinct orbit representatives define the conflict shifts

    T_ij = {t in F2^2 : c_i conflicts with t*c_j}.

Group invariance gives the exact pair-conflict rule: `g*c_i` conflicts with `h*c_j` iff `g+h in T_ij`. Let I_i be the analogous nonzero internal conflict shifts.

If T_ij is nonempty and two selected affine lines have different directions, their pairwise sum is all F2^2. It therefore contains a forbidden shift. Compatibility forces `delta_i=delta_j`. Thus directions agree throughout each connected component of the interaction graph with edges `T_ij != empty`.

Fix one component and a candidate common direction delta. Let ell_delta be the unique nonzero linear functional F2^2→F2 whose kernel is `{0,delta}`. Write p_i=ell_delta(a_i). Compatibility is equivalent to all of:

- `delta notin I_i` for each orbit i;
- ell_delta is constant on every nonempty T_ij;
- for that constant value t_ij,

      p_i + p_j = 1 + t_ij  (mod2).

Necessity follows because the selected pairwise sum is the affine line with quotient bit `p_i+p_j`, and it must be disjoint from T_ij. Sufficiency follows by choosing the affine line with quotient bit p_i in every orbit: the first condition prevents internal conflicts, and the last two prevent every cross-orbit conflict.

The bit equations are feasible exactly when their parity sum is zero around every cycle. Testing each of the three possible nonzero directions is sufficient, so the exact feasibility test is linear in the component's interaction edges after the small shift sets are known.

### Scope guard

An infeasible all-counts-two pattern proves a valid disjunction saying that at least one orbit has count different from2. It does **not**, by itself, prove a linear rank inequality on the union: patterns with counts1,3,4 could have a larger total. The explicit16/28-word graph arguments above independently establish the rank inequalities and avoid this gap.
