"""Exact independent certificate: whole (weight, checksum)-cell codes have size <=316.
No numerical libraries or solver required. Execute from any directory.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
import json, hashlib
root=Path(__file__).resolve().parent
cells=defaultdict(set);received=defaultdict(set)
for number in range(4096):
 word=format(number,'012b')
 key=(word.count('1'),sum(i for i,bit in enumerate(word,1) if bit=='1'))
 cells[key].add(word)
 for i in range(12):received[word[:i]+word[i+1:]].add(key)
edges=set()
for keys in received.values():
 for a,b in combinations(sorted(keys),2):edges.add((a,b))
# Audit formula independently against every pair of cell indices.
for a,b in combinations(sorted(cells),2):
 w,s=a;v,t=b
 formula=(v==w and t-s<=max(w,12-w))or(v==w+1 and 1<=t-s<=12)
 assert formula==((a,b)in edges),(a,b)
raw=(root/'cell_clique_certificate.json').read_bytes();cert=json.loads(raw)
coverage={key:Fraction() for key in cells};total=Fraction()
for row in cert:
 keys=[tuple(key)for key in row['cells']];weight=Fraction(*row['weight'])
 assert weight>=0 and len(keys)==len(set(keys))
 assert all(key in cells for key in keys)
 assert all(tuple(sorted((a,b)))in edges for a,b in combinations(keys,2))
 for key in keys:coverage[key]+=weight
 total+=weight
assert all(coverage[key]>=len(words)for key,words in cells.items())
assert total==316
# Check matching lower bound by direct deletion, independently of VT theorem.
words=[word for (w,s),bucket in cells.items()if s%13==0 for word in bucket]
assert len(words)==316
seen=set()
for word in words:
 descendants={word[:i]+word[i+1:]for i in range(12)}
 assert not descendants.intersection(seen)
 seen.update(descendants)
assert len(seen)==2048
# Equality requires zero covering slack on selected cells and exactly one cell
# in each positive-weight clique. Exhaust this small exact-cover system while
# preserving every quotient conflict; this independently checks uniqueness.
eligible=sorted(key for key in cells if coverage[key]==len(cells[key]))
index={key:i for i,key in enumerate(eligible)}
rows=[sum(1<<index[tuple(key)] for key in row['cells'] if tuple(key)in index)
      for row in cert]
covered_rows=[sum(1<<r for r,q in enumerate(rows) if q>>i&1)
              for i in range(len(eligible))]
conflicts=[sum(1<<j for j,b in enumerate(eligible)
               if a==b or tuple(sorted((a,b)))in edges)
           for a in eligible]
nodes=0;solutions=[]
def exact_cover(uncovered,available,selected):
    global nodes
    nodes+=1
    if not uncovered:
        assert available==0
        solutions.append(frozenset(eligible[i]for i in selected))
        return
    r=min((r for r in range(len(rows))if uncovered>>r&1),
          key=lambda r:(rows[r]&available).bit_count())
    choices=rows[r]&available
    while choices:
        bit=choices&-choices;choices^=bit;i=bit.bit_length()-1
        forbidden=conflicts[i]
        for r in range(len(rows)):
            if covered_rows[i]>>r&1:forbidden|=rows[r]
        exact_cover(uncovered&~covered_rows[i],available&~forbidden,selected+[i])
exact_cover((1<<len(rows))-1,(1<<len(eligible))-1,[])
assert solutions==[frozenset(key for key in cells if key[1]%13==0)]
print(json.dumps({'verified':True,'whole_cell_optimum':316,
                 'unique_optimum_is_VT0':True,'uniqueness_search_nodes':nodes,
                 'cells':len(cells),'quotient_edges':len(edges),
                 'positive_dual_cliques':len(cert),'dual_sum':str(total),
                 'certificate_sha256':hashlib.sha256(raw).hexdigest()},indent=2))
