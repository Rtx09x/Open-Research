"""Bounded exact sequential lifting of the explicit rank-seven subdivision cut.

Generate: python lift_subdivision_cut.py point.json --output lift.json --seconds 60
Verify:   python lift_subdivision_cut.py --verify lift.json

The generating oracle uses packed-bit deletion adjacency. Verification reconstructs
only needed edges by direct string deletion and checks an exact branch/cover DAG.
No floating-point quantity participates in validity; weights only order candidates.
"""
import argparse
import json
import time
from pathlib import Path
from itertools import combinations

from orbit_phase_separator import OrbitGraph, bit_members

SEED = [173,605,1109,1237,1321,1349,1357,1373,
        1390,1493,2705,2722,2774,2896,2980,2986]
HUBS = [1109,1373,2722,2986]
PATH_PAIRS = [((173,605),(1115,1199)),
              ((1321,2705),(2197,2378)),
              ((1237,1493),(2602,2858)),
              ((1357,1349),(2746,2738)),
              ((1390,2774),(1717,1898)),
              ((2896,2980),(3490,3922))]


class BudgetExceeded(Exception):
    pass


class ProofOracle:
    def __init__(self, adjacency, deadline, max_nodes=20000):
        self.adj = adjacency
        self.deadline = deadline
        self.max_nodes = max_nodes
        self.nodes = []
        self.cache = {}
        self.calls = 0

    def leaf(self, cliques):
        node = len(self.nodes)
        self.nodes.append({'kind':'cover','cliques':cliques})
        return ('bound',node)

    def decide(self, mask, k):
        """Return ('witness', k independent words), or ('bound', proof alpha<k)."""
        self.calls += 1
        if time.monotonic() >= self.deadline or len(self.nodes) >= self.max_nodes:
            raise BudgetExceeded
        if k == 0:
            return ('witness',())
        key = (mask,k)
        if key in self.cache:
            return self.cache[key]
        vertices = list(bit_members(mask))
        if len(vertices) < k:
            answer = self.leaf([[v] for v in vertices])
        else:
            # A quick lower-bound witness usually rejects a lifting candidate.
            remaining, witness = mask, []
            while remaining and len(witness) < k:
                v = min(bit_members(remaining),
                        key=lambda x:(self.adj[x]&remaining).bit_count())
                witness.append(v)
                remaining &= ~(self.adj[v] | (1 << v))
            if len(witness) == k:
                answer = ('witness',tuple(witness))
            else:
                # A conflict-clique partition is an independently replayable bound.
                remaining, cliques = mask, []
                while remaining and len(cliques) < k:
                    candidates, clique = remaining, []
                    while candidates:
                        v = max(bit_members(candidates),
                                key=lambda x:(self.adj[x]&candidates).bit_count())
                        clique.append(v)
                        remaining ^= 1 << v
                        candidates &= self.adj[v] & remaining
                    cliques.append(clique)
                if not remaining and len(cliques) < k:
                    answer = self.leaf(cliques)
                else:
                    v = max(vertices,key=lambda x:(self.adj[x]&mask).bit_count())
                    child = mask & ~(self.adj[v] | (1 << v))
                    inside = self.decide(child,k-1)
                    if inside[0] == 'witness':
                        answer = ('witness',(v,)+inside[1])
                    else:
                        outside = self.decide(mask ^ (1 << v),k)
                        if outside[0] == 'witness':
                            answer = outside
                        else:
                            node = len(self.nodes)
                            self.nodes.append({'kind':'branch','word':v,
                                               'exclude':outside[1],'include':inside[1]})
                            answer = ('bound',node)
        if len(self.cache) < 20000:
            self.cache[key] = answer
        return answer


def load_weights(path, graph):
    data = json.loads(path.read_text())
    if isinstance(data,list):
        weights = data
    else:
        weights = data.get('word_values',data.get('weights'))
        if weights is None:
            counts = data.get('orbit_values',data.get('orbit_counts'))
            if counts is None or len(counts) != len(graph.orbits):
                raise ValueError('Expected 4096 word_values or 1056 orbit_counts')
            weights = [0.0] * len(graph.adj)
            for orbit,z in zip(graph.orbits,counts):
                for word in orbit:
                    weights[word] = z / len(orbit)
    if len(weights) != len(graph.adj):
        raise ValueError('Wrong number of weights')
    return list(map(float,weights))


def compact_dag(nodes, roots):
    reachable = set()
    def visit(node):
        if node in reachable:
            return
        reachable.add(node)
        record = nodes[node]
        if record['kind'] == 'branch':
            visit(record['exclude'])
            visit(record['include'])
    for root in roots:
        visit(root)
    old_ids = sorted(reachable)
    remap = {old:new for new,old in enumerate(old_ids)}
    result = []
    for old in old_ids:
        record = dict(nodes[old])
        if record['kind'] == 'branch':
            record['exclude'] = remap[record['exclude']]
            record['include'] = remap[record['include']]
        result.append(record)
    return result,remap


def generate(args):
    started = time.monotonic()
    graph = OrbitGraph(12)
    weights = load_weights(args.point,graph)
    oracle = ProofOracle(graph.adj,started+args.seconds,args.max_nodes)
    if not 0 <= args.seed_mask < 64:
        raise ValueError('--seed-mask must be in 0..63')
    seed = sorted(HUBS + [v for k,pair in enumerate(PATH_PAIRS)
                         for v in pair[(args.seed_mask >> k) & 1]])
    mask = sum(1 << x for x in seed)
    seed_bound = oracle.decide(mask,8)
    assert seed_bound[0] == 'bound'
    additions, rejected = [], 0
    candidates = sorted((v for v,w in enumerate(weights)
                         if w > args.minimum_weight and v not in seed),
                        key=lambda v:(-weights[v],v))
    reason = 'all_candidates_checked'
    for v in candidates:
        if mask.bit_count() >= args.max_support:
            reason = 'support_budget'
            break
        try:
            proof = oracle.decide(mask & ~graph.adj[v],7)
        except BudgetExceeded:
            reason = 'time_or_node_budget'
            break
        if proof[0] == 'bound':
            additions.append({'word':v,'proof':proof[1]})
            mask |= 1 << v
        else:
            rejected += 1
    roots = [seed_bound[1]] + [step['proof'] for step in additions]
    nodes,remap = compact_dag(oracle.nodes,roots)
    for step in additions:
        step['proof'] = remap[step['proof']]
    support = list(bit_members(mask))
    result = {'n':12,'rank':7,'seed':seed,'seed_mask':args.seed_mask,
              'seed_proof':remap[seed_bound[1]],
              'additions':additions,'proof_nodes':nodes,'support':support,
              'numerical_mass':sum(weights[v] for v in support),
              'seed_numerical_mass':sum(weights[v] for v in seed),
              'candidate_count':len(candidates),'rejected_candidates':rejected,
              'stop_reason':reason,'oracle_calls':oracle.calls,
              'elapsed_seconds':time.monotonic()-started,
              'scope':'Exact rank-seven cut only; no global code bound is asserted.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in
                      ('numerical_mass','seed_numerical_mass','candidate_count',
                       'rejected_candidates','stop_reason','oracle_calls','elapsed_seconds')}
                     | {'support_size':len(support),'additions':len(additions),
                        'proof_nodes':len(nodes)},indent=2))


def verify(path):
    data = json.loads(path.read_text())
    assert data['n'] == 12 and data['rank'] == 7
    support = data['support']
    assert len(support) == len(set(support))
    strings = {v:format(v,'012b') for v in support}
    deletes = {v:{s[:k]+s[k+1:] for k in range(12)} for v,s in strings.items()}
    adjacency = {v:sum(1 << w for w in support
                      if v != w and deletes[v]&deletes[w]) for v in support}
    nodes = data['proof_nodes']
    verified = set()
    def check(node_id,mask,k):
        state = (node_id,mask,k)
        if state in verified:
            return
        node = nodes[node_id]
        if node['kind'] == 'cover':
            cliques = node['cliques']
            assert len(cliques) < k
            union = 0
            for clique in cliques:
                assert len(clique) == len(set(clique))
                for v in clique:
                    assert (mask >> v) & 1
                    union |= 1 << v
                assert all(deletes[u]&deletes[v] for u,v in combinations(clique,2))
            assert union == mask
        else:
            assert node['kind'] == 'branch' and k > 0
            v = node['word']
            assert (mask >> v) & 1
            check(node['exclude'],mask ^ (1 << v),k)
            check(node['include'],mask & ~(adjacency[v] | (1 << v)),k-1)
        verified.add(state)
    mask = sum(1 << v for v in data['seed'])
    check(data['seed_proof'],mask,8)
    for step in data['additions']:
        v = step['word']
        assert not (mask >> v) & 1
        check(step['proof'],mask & ~adjacency[v],7)
        mask |= 1 << v
    assert set(bit_members(mask)) == set(support)
    print(json.dumps({'exact_valid':True,'support_size':len(support),'rank':7,
                      'proof_states_checked':len(verified),
                      'deletion_method':'independent direct string slicing'},indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('point',type=Path,nargs='?')
    parser.add_argument('--output',type=Path,default=Path('lift_certificate.json'))
    parser.add_argument('--seconds',type=float,default=60)
    parser.add_argument('--max-nodes',type=int,default=20000)
    parser.add_argument('--max-support',type=int,default=256)
    parser.add_argument('--minimum-weight',type=float,default=1e-12)
    parser.add_argument('--seed-mask',type=int,default=0,
                        help='One of the 64 path choices in the doubled subdivision')
    parser.add_argument('--verify',type=Path)
    args = parser.parse_args()
    if args.verify:
        verify(args.verify)
    elif args.point:
        generate(args)
    else:
        parser.error('Supply a fractional point or --verify certificate')


if __name__ == '__main__':
    main()
