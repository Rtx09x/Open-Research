"""Exact necessary orbit-count consistency checks for a binary deletion code.

Usage: python orbit_phase_separator.py candidate.json --output report.json
Input: {"n":12,"counts":[...],"orbits":[[...],...]}. Orbits are optional;
when present they must equal canonical complement/reversal orbits ordered by
least integer word. Passing this test does NOT prove that counts lift to a code.
Only Python's standard library is required.
"""
import argparse
import json
from collections import deque
from itertools import combinations
from pathlib import Path


def bit_members(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length()-1
        mask ^= bit


class OrbitGraph:
    def __init__(self, n=12):
        self.n = n
        size = 1 << n
        allbits = size-1
        self.orbits, self.oid, self.labels = [], {}, []
        def reverse(x):
            return int(format(x, f'0{n}b')[::-1], 2)
        for x in range(size):
            if x in self.oid:
                continue
            labels = [x, x ^ allbits, reverse(x), reverse(x) ^ allbits]
            orbit = sorted(set(labels))
            i = len(self.orbits)
            self.orbits.append(orbit)
            self.labels.append(labels)
            for y in orbit:
                self.oid[y] = i
        receivers = [[] for _ in range(1 << (n-1))]
        for x in range(size):
            outputs = {((x >> (k+1)) << k) | (x & ((1 << k)-1))
                       for k in range(n)}
            for y in outputs:
                receivers[y].append(x)
        self.adj = [0] * size
        for parents in receivers:
            mask = sum(1 << x for x in parents)
            for x in parents:
                self.adj[x] |= mask ^ (1 << x)
        self.stable = []
        self.alpha = []
        for orbit in self.orbits:
            by_size = [[] for _ in range(len(orbit)+1)]
            for k in range(len(orbit)+1):
                for subset in combinations(orbit, k):
                    mask = sum(1 << x for x in subset)
                    if any(self.adj[x] & mask for x in subset):
                        continue
                    forbidden = 0
                    for x in subset:
                        forbidden |= self.adj[x]
                    by_size[k].append((mask, forbidden))
            self.stable.append(by_size)
            self.alpha.append(max(k for k, options in enumerate(by_size) if options))
        self.pairs = []
        self.free = {i for i,o in enumerate(self.orbits) if len(o) == 4}
        self.internal = {}
        self.offsets = {i:{} for i in self.free}
        for i, orbit in enumerate(self.orbits):
            neighbors = {self.oid[y] for x in orbit for y in bit_members(self.adj[x])}
            self.pairs.extend((i,j) for j in sorted(neighbors) if j > i)
            if i not in self.free:
                continue
            labels = self.labels[i]
            self.internal[i] = tuple(g for g in range(1,4)
                                     if (self.adj[labels[0]] >> labels[g]) & 1)
            for j in neighbors & self.free:
                if j <= i:
                    continue
                ts = tuple(g for g in range(4)
                           if (self.adj[labels[0]] >> self.labels[j][g]) & 1)
                assert ts
                self.offsets[i][j] = ts
                self.offsets[j][i] = ts

    def pair_feasible(self, i, s, j, t):
        return any(not (forbidden & mask_t)
                   for _, forbidden in self.stable[i][s]
                   for mask_t, _ in self.stable[j][t])

    @staticmethod
    def ell(direction, offset):
        return int(offset not in (0, direction))

    def _direction_test(self, component, direction):
        component = set(component)
        for i in sorted(component):
            if direction in self.internal[i]:
                return False, {"kind":"internal_conflict", "orbit":i,
                               "direction":direction,
                               "words":[self.labels[i][0], self.labels[i][direction]]}
        edge_parity = {}
        for i in sorted(component):
            for j, ts in self.offsets[i].items():
                if j not in component or j <= i:
                    continue
                values = {1 ^ self.ell(direction,t) for t in ts}
                if len(values) != 1:
                    return False, {"kind":"incompatible_offsets", "edge":[i,j],
                                   "offsets":list(ts), "direction":direction}
                edge_parity[i,j] = next(iter(values))
        phase = {}
        parent = {}
        for start in sorted(component):
            if start in phase:
                continue
            phase[start] = 0
            parent[start] = None
            q = deque([start])
            while q:
                i = q.popleft()
                for j in self.offsets[i]:
                    if j not in component:
                        continue
                    b = edge_parity[min(i,j), max(i,j)]
                    expected = phase[i] ^ b
                    if j not in phase:
                        phase[j] = expected
                        parent[j] = i
                        q.append(j)
                    elif phase[j] != expected:
                        left = []
                        p = i
                        while p is not None:
                            left.append(p)
                            p = parent[p]
                        right = []
                        p = j
                        while p not in left:
                            right.append(p)
                            p = parent[p]
                        cycle = left[:left.index(p)+1] + list(reversed(right)) + [i]
                        parities = [edge_parity[min(a,b), max(a,b)]
                                    for a,b in zip(cycle,cycle[1:])]
                        assert sum(parities) % 2 == 1
                        return False, {"kind":"odd_parity_cycle", "direction":direction,
                                       "cycle_orbits":cycle,"edge_parities":parities}
        return True, {"direction":direction, "phases":phase}

    def half_orbit_test(self, vertices):
        """Complete two-selected-words-per-orbit test on the supplied free orbits."""
        vertices = set(vertices)
        if not vertices <= self.free:
            raise ValueError("Half-orbit test requires only free four-word orbits")
        unseen = set(vertices)
        reports = []
        while unseen:
            start = min(unseen)
            component = {start}
            q = deque([start])
            unseen.remove(start)
            while q:
                i = q.popleft()
                for j in self.offsets[i]:
                    if j in unseen:
                        unseen.remove(j)
                        component.add(j)
                        q.append(j)
            failures, witness = {}, None
            for direction in (1,2,3):
                ok, certificate = self._direction_test(component,direction)
                if ok:
                    witness = certificate
                    break
                failures[str(direction)] = certificate
            reports.append({"orbits":sorted(component),"feasible":witness is not None,
                            "witness":witness,"direction_failures":failures})
        return reports

    def check_counts(self, counts):
        if len(counts) != len(self.orbits):
            raise ValueError("Wrong number of orbit counts")
        if any(type(z) is not int or z < 0 or z > len(o)
               for z,o in zip(counts,self.orbits)):
            raise ValueError("Counts must be exact integers in their orbit-size range")
        local = [{"orbit":i,"count":z,"maximum":self.alpha[i]}
                 for i,z in enumerate(counts) if z > self.alpha[i]]
        pair_violations = []
        if not local:
            for i,j in self.pairs:
                s,t = counts[i],counts[j]
                if s and t and not self.pair_feasible(i,s,j,t):
                    pair_violations.append({"orbits":[i,j],"counts":[s,t]})
        active = [i for i in self.free if counts[i] >= 2]
        phase_cuts = []
        for result in self.half_orbit_test(active):
            if result['feasible']:
                continue
            result['cut'] = {"variables":"indicator(count[orbit] >= 2)",
                             "orbits":result['orbits'],"rhs":len(result['orbits'])-1}
            phase_cuts.append(result)
        return {"n":self.n,"orbit_count":len(self.orbits),"total_count":sum(counts),
                "passes_necessary_checks":not(local or pair_violations or phase_cuts),
                "meaning":"Passing is necessary only; no full-code realization is asserted.",
                "internal_violations":local,"pair_violations":pair_violations,
                "phase_cuts":phase_cuts}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    data = json.loads(args.candidate.read_text())
    graph = OrbitGraph(data.get('n',12))
    if 'orbits' in data and data['orbits'] != graph.orbits:
        raise ValueError("Input orbit order differs from canonical least-word order")
    result = graph.check_counts(data['counts'])
    text = json.dumps(result,indent=2)+'\n'
    if args.output:
        args.output.write_text(text)
    else:
        print(text,end='')


if __name__ == '__main__':
    main()
