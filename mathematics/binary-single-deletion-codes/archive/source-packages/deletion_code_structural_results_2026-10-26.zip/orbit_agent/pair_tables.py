"""Exact Klein-four orbit pair occupancy tables, with direct string deletions."""
from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path

n = 12
words = [format(x, '012b') for x in range(4096)]
ds = [{s[:k] + s[k+1:] for k in range(12)} for s in words]
receivers = defaultdict(list)
for x, dd in enumerate(ds):
    for y in dd:
        receivers[y].append(x)
adj = [set() for _ in words]
for parents in receivers.values():
    for x in parents:
        adj[x].update(parents)
        adj[x].discard(x)

orbits, oid = [], {}
for x in range(4096):
    if x in oid:
        continue
    r = int(words[x][::-1], 2)
    o = sorted({x, x ^ 4095, r, r ^ 4095})
    i = len(orbits)
    orbits.append(o)
    for v in o:
        oid[v] = i

stable, cliques = [], []
for o in orbits:
    stable.append([s for r in range(len(o)+1) for s in combinations(o, r)
                   if all(v not in adj[u] for u, v in combinations(s, 2))])
    cliques.append([s for r in range(1, len(o)+1) for s in combinations(o, r)
                    if all(v in adj[u] for u, v in combinations(s, 2))])
alphas = [max(map(len, ss)) for ss in stable]
families = Counter()
example = {}
allpairs = []
bad_count = 0
required_thresholds = set()
for i, o in enumerate(orbits):
    neighbors = {oid[y] for x in o for y in adj[x] if oid[y] > i}
    for j in sorted(neighbors):
        p = orbits[j]
        feasible = {(len(s), len(t)) for s in stable[i] for t in stable[j]
                    if all(y not in adj[x] for x in s for y in t)}
        f = tuple(max(t for ss, t in feasible if ss == s)
                  for s in range(alphas[i]+1))
        clique_counts = sorted({(len(s), len(t)) for s in cliques[i] for t in cliques[j]
                               if all(y in adj[x] for x in s for y in t)})
        # Common denominator |O|*|P|, all arithmetic exact integers.
        old = {(s, t) for s in range(alphas[i]+1) for t in range(alphas[j]+1)
               if all(a*s*len(p) + b*t*len(o) <= len(o)*len(p)
                      for a, b in clique_counts)}
        bad = sorted(old - feasible)
        if bad:
            bad_count += len(bad)
            # Only an upper bound on threshold variables needed; both directions optional.
            required_thresholds.update((i,k) for k in range(1,alphas[i]+1)
                                       if f[k-1] != f[k])
        key = (len(o),len(p),alphas[i],alphas[j],f,tuple(clique_counts),tuple(bad))
        families[key] += 1
        example.setdefault(key, (o,p))
        if bad:
            allpairs.append({'i':i, 'j':j, 'O':o, 'P':p, 'f':f,
                             'clique_counts':clique_counts,'bad':bad})

result = {'orbit_count': len(orbits), 'pair_count': sum(families.values()),
          'strict_pair_count': len(allpairs), 'newly_forbidden_integer_pairs':bad_count,
          'alphas': dict(Counter(alphas)), 'active_ordered_thresholds':len(required_thresholds),
          'families':[{'sizes':k[:2], 'alphas':k[2:4], 'f':k[4],
                       'clique_counts':k[5], 'bad':k[6], 'multiplicity':v,
                       'example':example[k]}
                      for k,v in sorted(families.items())], 'strict_pairs':allpairs}
Path('orbit_agent/pair_tables.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('families','strict_pairs')},indent=2))
for family in result['families']:
    print(family)
