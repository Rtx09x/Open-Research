"""Exact half-orbit feasibility for the complement/reversal Klein-four action."""
from itertools import combinations
from collections import defaultdict, Counter, deque
import json
from pathlib import Path

n = 12
def rev(x):
    return int(format(x, '012b')[::-1], 2)
def act(x,g):
    return (rev(x) if g&2 else x) ^ (4095 if g&1 else 0)
orbits=[];oid={};labels=[]
for x in range(4096):
    if x in oid:continue
    o=sorted({act(x,g) for g in range(4)})
    i=len(orbits);orbits.append(o);labels.append([act(x,g) for g in range(4)])
    for v in o:oid[v]=i
ds=[{((x>>(k+1))<<k)|(x&((1<<k)-1)) for k in range(n)} for x in range(4096)]
outputs=[[] for _ in range(2048)]
for x,dd in enumerate(ds):
    for y in dd:outputs[y].append(x)
adj=[set() for _ in range(4096)]
for parents in outputs:
    for x in parents:adj[x].update(parents);adj[x].discard(x)
free=[i for i,o in enumerate(orbits) if len(o)==4]
internal={i:tuple(g for g in range(1,4) if labels[i][g] in adj[labels[i][0]]) for i in free}
indep={i for i in free if not internal[i]}
edges={};ngh=defaultdict(dict)
for i in free:
    for j in {oid[y] for y in adj[labels[i][0]] if oid[y]>i and len(orbits[oid[y]])==4}:
        ts=tuple(g for g in range(4) if labels[j][g] in adj[labels[i][0]])
        edges[i,j]=ts;ngh[i][j]=ts;ngh[j][i]=ts

def ell(delta,g):
    return int(g not in (0,delta))

def phase_feasible(vertices,delta):
    vertices=set(vertices)
    if any(delta in internal[i] for i in vertices):return False
    phase={}
    for start in sorted(vertices):
        if start in phase:continue
        phase[start]=0;q=deque([start])
        while q:
            i=q.popleft()
            for j,ts in ngh[i].items():
                if j not in vertices:continue
                bs={1^ell(delta,t) for t in ts}
                if len(bs)!=1:return False
                b=next(iter(bs));v=phase[i]^b
                if j in phase:
                    if phase[j]!=v:return False
                else:phase[j]=v;q.append(j)
    return True

def all_directions(vertices):
    return [d for d in range(1,4) if phase_feasible(vertices,d)]

def triangle_free(vertices):
    selected=set(x for i in vertices for x in orbits[i])
    return not any(adj[x]&adj[y]&selected for x in selected for y in adj[x]&selected)

stars=[]
for i in sorted(indep):
    ds2=[j for j,ts in ngh[i].items() if j in indep and len(ts)==2]
    for j,k in combinations(ds2,2):
        ts1,ts2=ngh[i][j],ngh[i][k]
        if ts1[0]^ts1[1] == ts2[0]^ts2[1]:continue
        if k in ngh[j]:continue
        s=tuple(sorted((i,j,k)))
        if s not in stars:stars.append(s)

simple_stars=[{'ids':s,'orbits':[orbits[i] for i in s],
               'edges':[[i,j,edges[i,j]] for i,j in combinations(s,2) if (i,j) in edges],
               'triangle_free':triangle_free(s),'admissible_directions':all_directions(s)}
              for s in stars]

# All free-orbit triples whose positive pair count (2,2) is feasible, then
# exact criterion; seek one passing the original all-clique relaxation.
def pair_valid(i,j):
    if j not in ngh[i]:return True
    return bool(all_directions((i,j)))
triple_witness=[];seen=set();tested=0
for i in free:
    eligible=[j for j in ngh[i] if pair_valid(i,j)]
    for j,k in combinations(eligible,2):
        s=tuple(sorted((i,j,k)))
        if s in seen:continue
        seen.add(s)
        if not pair_valid(j,k):continue
        tested+=1
        if not all_directions(s) and triangle_free(s):
            triple_witness.append({'ids':s,'orbits':[orbits[v] for v in s],
                'internal':{v:internal[v] for v in s},
                'edges':[[a,b,edges[a,b]] for a,b in combinations(s,2) if (a,b) in edges]})
            if len(triple_witness)>=10:break
    if len(triple_witness)>=10:break

result={'free_orbits':len(free),'independent_free_orbits':len(indep),
        'edge_degree_distribution':dict(Counter(map(len,edges.values()))),
        'simple_star_count':len(stars),'simple_stars':simple_stars[:10],
        'triple_tests_until_first_ten':tested,'triple_witnesses':triple_witness}
Path('orbit_agent/phase_witnesses.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
