# Exact Klein-four consistency and subdivision rank cuts

These are mathematical results and explicit finite certificates for the unrestricted binary length-12 deletion graph. They do **not** establish a 317-word code or a universal upper bound below 320. General subdivision rank inequalities and local consistency lifts are not claimed to be new in polyhedral combinatorics; the contribution here is their explicit deletion-graph realization and their relationship to the dossier's relaxation.

## 1. A 16-word rank-seven cut beyond every clique and odd-walk cut

Let conflict mean that the two length-12 binary words have a common length-11 deletion output. Interpret integers below in 12-bit, big-endian binary. Let

```
H = {1109, 1373, 2722, 2986}
W = {173,605,1109,1237,1321,1349,1357,1373,
     1390,1493,2705,2722,2774,2896,2980,2986}.
```

The induced conflict graph on W is exactly K4 with each of its six edges subdivided twice. The branch vertices are H. The six length-three paths are

| Branch endpoints | Internal vertices in path order |
|---|---|
| 1109, 1373 | 173, 605 |
| 1109, 2722 | 1321, 2705 |
| 1109, 2986 | 1237, 1493 |
| 1373, 2722 | 1357, 1349 |
| 1373, 2986 | 1390, 2774 |
| 2722, 2986 | 2896, 2980 |

For any deletion code C,

\[
\boxed{|C\cap W|\le 7.}
\]

**Proof.** If C selects s branch vertices, each length-three path permits at most one of its two internal vertices, and permits none when both branch endpoints are selected. The six internal pairs are disjoint. Hence

\[
|C\cap W|\le s+6-\binom{s}{2}\le7\qquad(0\le s\le4).
\]

The bound is attained, for example by selecting one branch vertex and one eligible internal vertex from every path. Exhaustive independent-set recursion separately gives alpha=7.

**Not implied by any collection of the dossier's clique and odd-walk inequalities.** Put x=1/3 on the four branch vertices, x=1/2 on the twelve internal vertices, and x=0 on all other 4,080 words. The induced graph has no triangles, so every clique inequality holds. Its simple odd cycles have length nine and contain three branch vertices and six internal vertices. Their total weight is 3/3+6/2=4, exactly the odd-cycle bound. Even closed walks satisfy their half-length bound by summing edge inequalities. Decomposing any odd closed walk entirely within W into cycles proves its odd-walk inequality. If an odd closed walk includes an outside vertex, at least one of its positions has weight zero and every other position has weight at most one half, which also proves the inequality directly. Nevertheless

\[
\sum_{x\in W}x_x=4/3+12/2=22/3>7.
\]

Thus this is a strictly stronger local linear inequality, with an exact rational separation witness in the full 4,096-word graph. It does not imply that the currently optimal all-clique LP solution violates this particular cut.

## 2. A 28-word rank-thirteen cut

The seven full complement/reversal orbits in `subdivision_certificate.json` form the 28-word set U. Its induced graph consists of the same four branch vertices, with **two** internally disjoint length-three paths replacing each K4 edge. There are twelve disjoint internal pairs. The second paths, in addition to those above, are

| Branch endpoints | Additional internal pair |
|---|---|
| 1109, 1373 | 1115, 1199 |
| 1109, 2722 | 2197, 2378 |
| 1109, 2986 | 2602, 2858 |
| 1373, 2722 | 2746, 2738 |
| 1373, 2986 | 1717, 1898 |
| 2722, 2986 | 3490, 3922 |

Therefore

\[
\boxed{|C\cap U|\le13,}
\]

because selecting s branch vertices gives at most

\[
s+12-2\binom{s}{2}=12+2s-s^2\le13.
\]

This bound is attained by the 13-word independent set in the certificate. The same fractional assignment (branch values 1/3, all 24 internal values 1/2) satisfies every clique and odd-walk inequality globally and has objective 40/3>13. Simple odd cycles are still exactly length nine; the doubled paths additionally create even six-cycles.

Each of the 2^6 choices of one path per branch pair yields a rank-seven cut on sixteen words. These 64 cuts need not be enumerated to separate against a fractional vector: choose, independently for each branch pair, whichever of its two internal pairs has the larger total weight.

## 3. How the group action produces this graph

Let G=F2^2 act by bit complement c and reversal r, encoded as 0=id, 1=c, 2=r, 3=cr. A free orbit O has four words labeled by g in G, starting from its least word. For two free orbits O,P, let

\[
T_{OP}=\{t\in G: O_0\text{ conflicts with }P_t\}.
\]

By invariance, O_g conflicts with P_h exactly when g+h belongs to T_OP. Thus each selected t in T_OP determines a perfect matching between the orbits.

The seven-orbit graph underlying U consists of three quotient triangles sharing the branch orbit. Their three nonzero offset sums are the three distinct nonzero elements of G. A quotient triangle with offset sum h lifts to two disjoint six-cycles. Viewed from the branch orbit, it supplies two internally disjoint length-three paths between each pair {g,g+h}. Taking one such quotient triangle for each h yields the doubled K4 subdivision.

Additional conflict edges would not invalidate the rank-seven or rank-thirteen upper inequalities: the proof only uses the displayed path edges. Inducedness is needed here only to establish the exact local independence number and the strict separation witness.

This gives a precise finite generator. For each free branch orbit, enumerate quotient triangles and their attainable nonzero offset sums. Choose three triangles, one of each nonzero sum, with their six outer orbits distinct. The resulting seven orbits always give a rank-thirteen inequality, and the chosen matchings give 64 rank-seven inequalities. One can inspect candidates in decreasing fractional weight; no unconstrained code search is involved.

In orbit counts, averaging any one of the rank-seven cuts over G gives

\[
2z_{\rm branch}+\sum_{\rm six\ outer\ orbits}z_O\le14.
\]

The rank-thirteen cut is already invariant:

\[
z_{\rm branch}+\sum_{\rm six\ outer\ orbits}z_O\le13.
\]

The averaged rank-seven inequality is the stronger primary cut: the twelve disjoint internal conflict edges already give sum_outer z_O≤12, and taking half the sum of this inequality and 2z_branch+sum_outer z_O≤14 gives the rank-thirteen inequality.

These inequalities are redundant if one already imposes *all* averaged odd-walk constraints *and* exact orbit-count integrality for this local graph; they are not redundant in the fractional clique/odd-walk LPs. This distinction must not be blurred.

## 4. Exact half-occupancy consistency theorem

Consider a connected set S of free four-word orbits, and ask whether one can choose exactly two mutually nonconflicting words from every orbit in S. Every two-element subset of G is a coset a+{0,d} for a unique nonzero direction d.

**Theorem.** Such a selection exists if and only if at least one direction d in G\{0} satisfies all of the following:

1. No orbit's internal conflict offsets include d.
2. For every adjacent pair O,P, all offsets in T_OP have the same value under the nonzero linear functional ell_d:G→F2 whose kernel is {0,d}.
3. The edge equations

   \[
   p_O+p_P=1+\ell_d(t)\pmod2,\qquad t\in T_{OP},
   \]

   admit a binary phase p_O for every orbit in S.

**Proof of necessity.** A single conflict matching with offset t maps the selected pair in O to a forbidden pair in P. Since P must select two words, it must select exactly the complementary pair. A pair and the complement of a translate of it have the same direction. Hence the direction is constant throughout a connected component. A second offset in the same pair must give the same forbidden coset, establishing condition 2. Internal edges exclude their direction. Expressing a coset by ell_d(g)=p_O gives condition 3.

**Proof of sufficiency.** Choose in orbit O precisely the labels g satisfying ell_d(g)=p_O. These are two words. Condition 1 prevents internal conflicts, and conditions 2–3 prevent every cross-orbit conflict.

**Complexity.** For each of three directions, reject inconsistent internal offsets or edge offsets, then perform a parity breadth-first search. This is O(|S|+|E(S)|) for fixed G. Disconnected sets are handled component by component, each with its own direction. The test is complete for this induced two-per-free-orbit question, not for arbitrary orbit counts or full code feasibility.

**Valid cut.** Any connected S with no two-per-orbit selection gives

\[
\boxed{\sum_{O\in S}{\bf1}[z_O\ge2]\le |S|-1.}
\]

Indeed, every cross-orbit conflict matching gives z_O+z_P≤4. If all z_O≥2 in a connected nontrivial S, every z_O must equal two. This contradicts the exact test.

## 5. Explicit half-occupancy obstruction even beyond the stable-set polytope

The following three independent free orbits provide a particularly strong demonstration of what averaging loses:

```
O = {410,1432,2663,3685}
P = {716,820,3275,3379}
Q = {1230,1842,2253,2865}.
```

The offset sets are T_OP={0,2}, T_OQ={0,3}, and there are no P–Q conflicts. Every two-orbit occupancy pair (2,2) is feasible, but choosing two in all three orbits would force O's direction to be both 2 and 3. Thus

\[
{\bf1}[z_O\ge2]+{\bf1}[z_P\ge2]+{\bf1}[z_Q\ge2]\le2.
\]

The vector assigning one half to all twelve words satisfies even the **true stable-set polytope**: it is the average of the valid set O and the valid set P∪Q. Its orbit counts are the integers (2,2,2), yet those exact counts have no realization. Consequently no linear inequality in the averaged word vector, even from the full stable-set polytope, can exclude this occupancy tuple. The missing information is a nonconvex fiber-consistency condition. The phase test detects it exactly. This is not a counterexample to a valid bound; it is a counterexample to the inference that integral averaged orbit counts are realizable.

## 6. Exact pair tables

For any orbits O,P, define

\[
f_{OP}(s)=\max\{|T|:S\subseteq O, T\subseteq P, S\cup T\text{ independent}, |S|=s\}.
\]

The function is nonincreasing. Introducing exact threshold indicators t_{O,k}=1[z_O≥k] yields the valid disjunctive table constraint

\[
z_P+\sum_{k=1}^{\alpha(O)}(f_{OP}(k-1)-f_{OP}(k))t_{O,k}\le \alpha(P).
\]

These are exact two-orbit feasibility conditions, not sufficient global conditions. Exhaustive direct-string enumeration found 33,512 adjacent orbit pairs. Of them, 489 exclude integer occupancy pairs that satisfy every averaged local clique row; there are 965 newly excluded ordered occupancy tuples in total. The exact instances and all 31 function families are recorded in `pair_tables.json`. The stronger phase obstruction above survives all of these pair tests.

## Verification files

- `pair_tables.py` / `pair_tables.json`: exact direct-string orbit-pair enumeration.
- `phase_test.py` / `phase_witnesses.json`: offset reconstruction, exact phase criterion, and concrete three-orbit obstructions.
- `friendship_witness.json`: seven-orbit voltage witness.
- `subdivision_certificate.json`: hub/path list, full sets, binary words, and attained local bounds.
- `orbit_phase_separator.py`: reusable exact pair and half-occupancy separator accepting an integer count candidate; parity failures include finite certificates and the resulting indicator cut. Its necessary-check status is explicitly distinguished from actual code realizability.
- `lift_subdivision_cut.py`: bounded exact lifting of the rank-seven support, with an independently replayable branch/cover proof DAG. Run `python lift_subdivision_cut.py POINT.json --output LIFT.json --seconds 60`, then `python lift_subdivision_cut.py --verify LIFT.json`. The fractional point may use `word_values` (4,096 values) or `orbit_counts` (1,056 values). Floating weights only order candidates; the verifier uses direct string deletion and exact integer graph operations.

The lifting rule is exact: if a current support A satisfies alpha(A)≤7, then adjoining v preserves that bound whenever alpha(A\\N(v))≤6. A certificate establishes the latter bound using conflict-clique covers and exhaustive binary include/exclude branching. A synthetic all-one-weight smoke test scanned all 4,080 candidates in under one second, grew the 16-word seed to a 42-word support, and produced a 525-node certificate which the independent string verifier accepted. These synthetic weights are not a feasible LP point and imply no bound improvement.

All these conclusions are finite exact graph statements. Numerical optimization is unnecessary for their proof. A new universal bound still requires combining enough valid cuts with a globally certified upper-bound argument.
