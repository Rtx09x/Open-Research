# RE-02: audit of the arbitrary-k fixed-basis theorem and a sharp obstruction to greedy common-OPT learning

**Research note | 26 October 2026 | exact-arithmetic construction; no claim of literature novelty or peer review**

## Executive status

The supplied arbitrary-`k` orthonormal-frame coefficient proof passes the conditioning audit **subject to its explicitly prescribed fixed bases, square `2k` probe banks, and independent full Haar `O(k)` complement orientations**. It yields the stated uniform carried bound 20 and the `(20L+3)` fixed-basis squared-error factor. Its coefficient bank may be generated *after* learning bases using a statistically independent fresh query bank, provided its conditional law is exactly that of the proof.

The attempted bridge from an unknown-basis learner to RE-02 via the **weighted residual ledger** fails for a natural, fully specified learner: the algorithm which takes the exact top-`k` left and right singular subspaces of *each current off-diagonal block row/column*, then double-compresses and recurses. This is the full-entry greedy HSS basis selection analyzed by Amsel et al. Its loss is `Omega(L)` times the unrestricted optimum, and its *weighted* ledger is `Omega(L^2)` times the optimum on the family below. The obstruction extends **verbatim to every rank `k>=1`** by Kronecker product with `I_k`. This is not a lower bound for other learners or the full RE-02 query model.

Surprisingly, the independent `4k` square-frame **coefficient decoder** on these bad greedy bases has **exact expected total squared error `4L`**, despite the failed ledger growing quadratically: the general weighted upper bound is genuinely too loose for this family. The correct remaining bridge may therefore need a **learner-dependent covariance ledger**, rather than a per-birth-level worst-case weighting.

## 1. Audit of the submitted 20-energy argument

In the given one-live-child branch coordinates, the normalized row and column states obey the exact flux energy contraction

`J=||X-Z||_F^2+||Y||_F^2+||W||_F^2` with `J_next<=J` pointwise.

For a pure transpose-detail source `(X,Y,Z,W)=(0,0,0,W0)` whose amplitude is fixed independently of the *row-bank Haar orientations*, the normalized retained row-bank coordinate has the form

`Z_next=R^T Z A + R_perp^T H^T W A`,

where `H` is fresh Haar `O(k)` conditional on the bottom-up normalized state, the **opposite complete frame bank**, and the fixed transfer matrices. The two cross products have zero conditional expectation, and

`E[H^T M H]=(tr M/k)I` for deterministic `M`.

Therefore, with `c^2=||W0||_F^2`,

`E[Z_next Z_next^T] <= (c^2/k)(R^T R+R_perp^T R_perp)=(c^2/k)I`.

This is a **matrix Loewner bound**, not scalar sign averaging, and requires full Haar isotropy for `k>1`. With `C=X-Z`, `E J<=c^2`, `E||Z||^2<=c^2`, Cauchy gives `E S<=5c^2`.

The key conditioning distinction is that the pure detail source at a node is initialized as `W0^T Q_node`, i.e. **frame-adapted**. Its normalized amplitude `W0` cannot be an arbitrary sample array depending on the same Haar gauge. In a top-down frame realization, the bottom-up normalized recurrence cancels yet-unused ancestor gauges, making the current state independent of the next gauge. A fixed forward bank can be conditioned on while averaging the independent row bank. This justifies the specific one-bank lemma, not unconditional claims for adaptive training probes.

Decomposing arbitrary one-bank-independent input into the **fixed spatial left hierarchical-wavelet basis** gives one pure detail source per node. Central signs of the Haar orientations separate distinct emission nodes in expected squared energy; the signal born at a deeper node includes a sign absent from a source born at an ancestor. Root-active data are carried without loss. This establishes the bound 5 for arbitrary one-bank-independent input.

Fine-sign characters `1`, `sigma_j`, `tau_i`, `sigma_j tau_i` separate the `aa`, `ad`, `da`, and `dd` sectors. For an `ad` column or `dd` block, split its carried data into two **opposite-bank conditionable** pure-detail/one-bank sources. Each has bound 5 times its squared amplitude. The Hilbert-space triangle inequality gives 20 jointly; conditional isotropy bounds anchor amplitudes. Induction on `aa` closes the uniform estimate `E S_cut<=20||A||^2`. The coefficient spaces are orthogonal, giving `(20L+3)||A-P_C A||^2` squared-error bound.

**Audit qualification:** the report supplies an analytic conditioning argument. We did not independently formalize the general Haar filtration construction in a proof assistant. The argument explicitly uses previous independently checked exact flux identities and uses *fixed* spatial nested bases. None of this proves independence of the training bank from bases learned from that training bank.

## 2. Exact lower-bound family for full-entry two-sided greedy SVD

### Theorem

For every integer `L>=3`, set `k=1`, `N=2^(L+1)`, with zero-based coordinate vectors, and define

```
x_L = sum_{j=0}^{L-1} e_{2^j}
w_L = e_{2^L}
z_L = e_{3*2^(L-1)}
A_L = x_L w_L^T + (3/2) e_0 z_L^T.
```

Let the **full-entry two-sided greedy SVD learner** at each nonroot level take for every current `2x2` block index `i`:

- `U_i`: the top left singular vector of the block row with its own diagonal block removed;
- `V_i`: the top right singular vector of the block column with its own diagonal block removed;
- `A_next = U^T A_current V`, and repeat.

The diagonal blocks are identically zero throughout this instance, so the usual diagonal correction `D_i` is zero at every stage. The relevant nonzero singular directions are unique. Tie choices in zero-data blocks do not affect the stated residuals or the exact greedy approximation.

Then:

1. `OPT_HSS,1(A_L)^2 = 9/4` exactly;
2. at every compression level `ell=1,...,L`, the orthogonal off-model squared residual born at that level equals `||E_ell||_F^2=1`;
3. the greedy retained approximation is `(3/2)e_0 z_L^T`, hence its squared error is `L`;
4. with weights `w_ell=3+20(L-ell+1)`, the common-OPT ledger is

   `sum_{ell=1}^L w_ell ||E_ell||_F^2 = 10L^2+13L`.

In particular,

`W_L / (L * OPT_HSS,1(A_L)^2) = (40L+52)/9 -> infinity`.

This is a rigorous failure of the weighted common-OPT condition for **this learner**, even under exact entry access. It does **not** refute every training algorithm, and does not refute RE-02.

### Arbitrary-rank amplification (exact)

For **any integer `k>=1`**, replace the example by

`A_{L,k}=A_L tensor I_k`, of dimension `2^(L+1)k`.

The left-right root interaction has `k` singular values `sqrt(L)` and `k` singular values `3/2`. Its best rank-`k` squared tail is `9k/4`, attained by globally rank-`k` `(x_Lw_L^T) tensor I_k`. Every local Gram matrix in the above induction becomes the scalar `2x2` Gram matrix tensored with `I_k`. In the competing block, the `k` eigenvalues `9/4` are strictly above the `k` eigenvalues `1`; thus the **optimal `k`-dimensional subspace is unique as a projector**, even though an orthonormal basis inside it may be rotated. The same induction preserves the perturbation and discards a `k`-dimensional signal block at each level. Consequently

```
OPT_HSS,k(A_{L,k})^2 = 9k/4,
||E_ell||_F^2 = k  for every ell,
||A_{L,k}-B_greedy||_F^2 = kL,
W_{L,k} = k(10L^2+13L).
```

The ratio to `L*OPT_HSS,k^2` is still `(40L+52)/9`. This strengthens the exact obstruction to **all target ranks**. `kronecker_extension_check.py` separately corroborates the block-SVD induction in dense floating-point arithmetic for `k=2,3,4` and `L=3,4,5`; the proof is the Kronecker spectral identity, not those runs.

### Proof of the optimum

The two summands of `A_L` lie in the interaction between the root's left and right halves. They have orthogonal row factors `x_L` and `e_0`, and orthogonal column factors `w_L` and `z_L`. Hence the root off-diagonal block has nonzero singular values `sqrt(L)` and `3/2`.

An HSS rank-one matrix must have rank at most one across this root cut. By the Eckart–Young theorem, its squared Frobenius error is at least `min(L,9/4)=9/4`. Equality is attained by globally rank-one `H*=x_L w_L^T`, itself valid HSS. QED.

### Inductive greedy compression proof

At the beginning of round `t=0,...,L-1`, the compressed matrix has dimension `N_t=2^(L-t+1)` and the form

```
A^[t] = (3/2)e_0 e_{z_t}^T
      + sum_{j=0}^{L-t-1} e_{2^j} e_{w_t}^T,
w_t=2^(L-t),        z_t=3*2^(L-t-1).
```

The `2x2` block row indexed by the first pair `{0,1}` has orthogonal row vectors with squared norms `9/4` and `1`. The unique best left singular direction is `e_0`, so it discards exactly the `e_1e_{w_t}^T` signal with squared energy 1.

Every other nonzero block row contains only one signal coordinate and therefore preserves it exactly. In the column tree, `w_t` and `z_t` are in **different** `2x2` column blocks for `t<=L-2`. The corresponding right singular vectors retain both column coordinates exactly. Consequently the next compressed matrix is

```
A^[t+1] = (3/2)e_0 e_{z_t/2}^T
        + sum_{j=1}^{L-t-1} e_{2^(j-1)} e_{w_t/2}^T,
```

which is the same formula at round `t+1`. When `t=L-1`, `N_t=4`, `w_t=2`, `z_t=3`; they are in the same final right block. Its column singular energies are `1` and `9/4`, so the column side chooses the noise coordinate. The left side simultaneously discards the last unit signal. The root retains only `(3/2)e_0e_1^T` in root coordinates.

Every level's discarded block is orthogonal to the fixed class and all other levels' discarded blocks. Thus the residual squared norms are all exactly 1, and lifting the root restores `(3/2)e_0z_L^T`. The claimed formulas follow by summing the weights. QED.

**Relation to literature.** Amsel et al. (SIMAX 2026 / arXiv:2505.16937v2, Section 3.4, Theorem 12) give an explicit `(2-epsilon)` lower bound for the exact greedy HSS approximation and note a gap to their `O(L)` upper factor. This exact family yields a depth-linear lower bound for the specified full-entry greedy rule. Literature novelty has not been comprehensively established.

### Why this is not an information-theoretic query lower bound

On this family the **entire** matrix has rank `2k`, not high global rank. With `2k` forward probes supported on the right half and `2k` transpose probes supported on the left, the root off-diagonal block `M` can be recovered **exactly almost surely**: with `Y=M Omega`, `Z=M^T Psi`, and `C=Psi^T Y`, the square `2k`-by-`2k` matrix `C` is nonsingular almost surely and

`M=Y C^{-1} Z^T`.

A rank-`k` SVD of this known `M` selects the correct signal, attaining the optimum on the family. This restricted construction involves only `4k` total products and polynomial arithmetic in exact real arithmetic; it is **not a general noisy HSS theorem** and an inverse in this procedure can have severe moments off this exact low-rank class. Its purpose is to demonstrate that the greedy counterexample obstructs **local decision-making**, not the possibility of an `O(k)`-query non-greedy learner.

## 3. The weighted ledger is stricter than the true coefficient risk

There is an exact second calculation for the **fresh independent `2k+2k=4` query orthonormal-frame coefficient decoder**, using the greedy bases from the above input, with a canonical coordinate completion `e_0` at every zero-data block and root square frames equal to `I_2`.

Write `H*=x_Lw_L^T` and `E_noise=(3/2)e_0z_L^T`. In this fixed-basis class `P_C(A_L)=E_noise`, `H*` is orthogonal to `C`, and the decoder is exact on `C`. By linearity,

`R_C(A_L)=E_noise+R_C(H*)`.

The output coefficient spaces are orthogonal, and `H*` is orthogonal to the class, so

`E||A_L-R_C(A_L)||_F^2 = L + E||R_C(H*)||_F^2`.

### Proposition: exact expected energy `3L`

For every `L>=3`, the square orthonormal-frame decoder just specified satisfies

`E||R_C(H*)||_F^2 = 3L`

and therefore

`E||A_L-R_C(A_L)||_F^2 = 4L`.

**Proof by detail-sign accounting.** Each rank-one source `e_{2^j}w_L^T` has its row index rejected as a detail coordinate in level `j+1`. The column index `w_L` remains active down the right column tree until it becomes a detail coordinate at the final level. The prescribed coordinate bases and root `I_2` imply that all active left test rows equal `e_0^T`, active right test rows equal `e_1^T`, and their complement detail rows are centered independent signed copies of `e_1^T` and `e_0^T`, respectively.

For this single source, the carry formulas give exactly one magnitude-one `D_da` coefficient when its row is rejected, exactly one magnitude-one `D_ad` coefficient at the final compression, and exactly one magnitude-one root-core coefficient. All other coefficients vanish. This remains valid if the row detail is born at the final compression: the two local coefficients then occur at that same level. Hence the **individual-source** total coefficient energy is exactly 3.

For distinct indices `j`, the row-detail complement orientations at their birth nodes contain distinct independent central signs `tau_j`. The final-level `D_ad` coefficients and root-core coefficients are each sums of terms proportional to these signs, so cross terms vanish in expected squared norm. The earlier `D_da` coefficients are at distinct levels and are already Frobenius-orthogonal. It follows that the expected coefficient energies by stage are

```
levels 1,...,L-1:          1 each
level L:                   L+1
root core:                 L
sum:                        3L.
```

All square frame entries are signed coordinate basis vectors, so no inverse or limiting argument is involved. The accompanying independent integer Walsh polynomial propagation checks the identity algebraically through `L=10` using exactly **4092** independent sign variables in the largest case, *without enumerating their sign assignments*. This finite check corroborates, but is not the basis for, the induction above. QED.

**Important:** `4L` is *within* RE-02's desired scaling; the counterexample obstructs the **particular sufficient weighted ledger**, not the actual approximation requirement. Indeed the generic weighted bound is `10L^2+13L` on this instance while the exact expected squared output error is `4L`.

## 4. Stronger replacement reduction: learner-aware coefficient covariance

For a fixed learned-basis linear class `C`, let `P_C` be its Frobenius-orthogonal projector and let `R_C` be the random linear coefficient decoder from an independent postselection query bank. Define the deterministic, positive semidefinite operator

`Q_C = E_coeff[R_C^* R_C]`

with expectation conditional on the chosen bases; the adjoint here is for the Frobenius inner product on the matrix space. Then the exact **conditional squared-risk operator** is

`K_C = (I-P_C) [I+Q_C] (I-P_C)`.

Since `R_C` is exact on `C` and outputs in `C`, the orthogonal error identity proves, without approximation,

`E_coeff ||A-R_C(A)||_F^2 = <A,K_C A>_F`.

For an optimal `H*` and `E=A-H*`, Young's inequality and the fixed-basis theorem give

`E_train E_coeff ||A-R_C(A)||^2`
`<= 2 E_train <H*,K_C H*> + 2(20L+3)||E||^2`.

Thus a **different sufficient unknown-basis condition** is

`E_train <H*,K_{C(A,training)}H*> <= C L ||A-H*||^2`.

This criterion accounts for *which* off-model residual the learner creates and its correlation with the coefficient-scattering operator. It avoids forcing every birth-level contribution to pay its worst-case remaining-depth budget. Our example satisfies this signal condition (`<H*,K_C H*>=4L`) even though the proposed weighted signal condition fails (`10L^2+13L`).

This is a reduction, **not** proof of the remaining signal condition for a usable constant-query learner. It is the precise next bridge worth analyzing after the weighted route is obstructed.

## 5. A concrete constant-query risk-selection primitive

Here is a separate, proved operation that may be useful when evaluating *two different globally selected basis trees*, not just the local greedy tree.

**Two-candidate Gaussian validation lemma.** Let `B_1,B_2` be arbitrary random candidate matrices, independently constructed without using the validation probes. Let `g_1,...,g_12` be independent `N(0,I_N)` vectors, and compute

`V_i=(1/12) sum_t ||(A-B_i)g_t||_2^2`.

Choose `hat i=argmin_i V_i`. Then, conditional on the candidates,

`E_validation ||A-B_hat i||_F^2 <= sqrt(21/5) min_i ||A-B_i||_F^2`.

This uses exactly **12 additional forward products** with `A`, independent of depth, and polynomial arithmetic to multiply candidates by each vector. If each candidate uses `O(k)` training/recovery queries, the resulting portfolio still uses `O(k)` total queries for integer `k>=1`.

**Proof.** Put `R_i=||A-B_i||_F^2`. For positive `R_i`, sample covariance gives

`E V_i^2 <= (1+2/12)R_i^2=(7/6)R_i^2`.

Diagonalize the Gram matrix of `A-B_i`. Then `V_i/R_i` is a convex combination of independent `chi^2_12/12` variables. Jensen for `x -> x^(-2)` yields

`E(R_i/V_i)^2 <= 12^2/[(12-2)(12-4)]=9/5`.

With `*` the truly best candidate, `R_hat <= V_* max_i(R_i/V_i)` by empirical minimization. Cauchy–Schwarz and `max(a^2,b^2)<=a^2+b^2` imply

`E R_hat <= sqrt[(7/6)*(2*9/5)]R_* = sqrt(21/5)R_*`.

If one residual is zero, the validation identifies it almost surely, so the claim follows by continuity. QED.

The lemma does not manufacture a good candidate. It rigorously permits two independently learned/reconstructed alternatives to be compared from 12 new forward matvecs without any **additional depth factor in the risk**.

## 6. Scope and remaining gap

**Proved:** prescribed-basis coefficient conditioning audit (subject to stated Haar and flux identities); exact all-depth greedy SVD lower-bound family; `Omega(L^2)` failure of the proposed weighted common-OPT certificate for the greedy learner; exact `4L` postselection output risk for its canonical coordinate realization; two-candidate holdout lemma.

**Not proved:** an unrestricted algorithm using `O(k)` total forward-plus-transpose products and attaining `O(L)OPT_HSS^2`; a learner-dependent signal covariance bound `E <H*,K_C H*> <= CL OPT^2` for any general learning rule; or a global optimization procedure that can locate the right nested bases from constant query banks in polynomial arithmetic.

The greedy SVD failure is a failure of local optimality as a design principle. The `4L` recovery identity shows that the *weighted* bridge is not necessary, and warns against interpreting its failure as failure of the overall two-pass algorithm.

## 7. Reproduction and evidence levels

Exact proof/certificate files:

- `exact_greedy_counterexample.py`: rational arithmetic checks of the full-entry SVD comparison and each orthogonal level loss, `L=3,...,8`.
- `walsh_coeff_exact.py`: integer Walsh-monomial propagation, with exact expected coefficient energy and carried energies, `L=3,...,10`. No sampling or floating point is used.
- `walsh_individual.py`: independently computes every individual signal's contribution in the same Walsh setting.

Independent corroboration, not proof:

- `independent_dense_verify.py`: dense NumPy SVD reconstruction, independent of rational greedy implementation, `L=3,...,7`.
- `coefficient_test.py`: independently implements the stochastic square-frame decoder directly and averages Monte Carlo samples; its estimates agree with exact `3L` expected coefficient energy.
- `global_lookahead_sanity.py`: independent finite-dimensional check of the exact root rank-`2k` recovery identity and optimal rank-`k` tail; not a robustness proof.
- `kronecker_extension_check.py`: independent dense-SVD checks of the arbitrary-`k` extension, `k=2,3,4` and `L=3,4,5`.
- `greedy_experiment.py`: exploratory random dense HSS+noise trials, which did **not** find the obstruction; included to distinguish failed generic search from the structural construction.

Commands (run from this directory):

```
python exact_greedy_counterexample.py
python walsh_coeff_exact.py
python walsh_individual.py
python independent_dense_verify.py      # requires numpy
python kronecker_extension_check.py    # requires numpy
python global_lookahead_sanity.py      # requires numpy
python coefficient_test.py              # requires numpy
```

## Primary references

- Amsel, Chen, Duman Keles, Halikias, Musco, Musco, Persson, *Quasi-optimal Hierarchically Semi-separable Matrix Approximation*, SIMAX (2026), especially §3 and §4: https://arxiv.org/html/2505.16937v2
- Levitt–Martinsson, *Linear-Complexity Black-Box Randomized Compression of Rank-Structured Matrices*, SISC (2024), Algorithm 4.1: https://arxiv.org/pdf/2205.02990v3
- RE-02 problem statement: https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/randomized-and-low-rank-approximation/RE-02/README.md
- Submitted new result: user-provided `Pasted text(7).txt`, 26 October 2026, arbitrary-`k` fixed-basis Haar-frame 20-energy proof (not human peer-reviewed).
