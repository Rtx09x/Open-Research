# RE-02 greedy-basis and common-OPT bridge certificate

**Main report:** `RE02_bridge_audit_and_counterexample.md`

**Exact mathematical conclusion:** Full-entry, two-sided local greedy SVD basis learning has a rank-`k`, depth-`L` family with squared error `kL`, unrestricted HSS rank-`k` squared optimum `9k/4`, and common-OPT weighted residual ledger `k(10L^2+13L)`. This does not imply failure of every query algorithm. See the proof and scope in the report.

**Second theorem for `k=1` canonical coordinate completions:** Fresh 4-query square-orthonormal-frame coefficient recovery on this family's greedy bases has expected squared error exactly `4L`, not order `L^2`.

## Exact certificates (Python standard library only)

```bash
python exact_greedy_counterexample.py
python walsh_coeff_exact.py
python walsh_individual.py
```

The first checks rational block Grams and loss identities. The second computes expectations by expanding Rademacher-sign characters algebraically and using orthogonality, never Monte Carlo; it checks `L=3,...,10`, with 4092 independent signs at `L=10` represented symbolically, not enumerated. For each `L`, the exact output coefficient energies are `[1]*(L-1)+[L+1,L]` and carried sample energy is `2L` at every cut.

## Independent floating-point corroboration (not proof)

```bash
python -m pip install -r requirements.txt
python independent_dense_verify.py
python kronecker_extension_check.py
python global_lookahead_sanity.py
python coefficient_test.py
```

See `exact_counterexample.json`, `walsh_coefficient_moments.json`, and SHA-256 checksums.

No external data, network access, paid services, or messages are needed.
