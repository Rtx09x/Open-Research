"""Monte Carlo diagnostic only: given exact greedy bases on the sparse
counterexample, run fixed-basis square-orthonormal-frame LM coefficient decoder
on pure off-model signal E=x e_w^T. Tests are not a proof."""
import sys,numpy as np
from fractions import Fraction
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from exact_greedy_counterexample import run

def greedy_basis_coords(L):
    from exact_greedy_counterexample import F
    n=2**(L+1); A={(2**t,2**L):F(1) for t in range(L)}; A[0,3*2**(L-1)]=F(3,2)
    bas=[]
    for level in range(L):
        m=n//2; u=[];v=[]
        for b in range(m):
            rowe=[sum(x*x for (i,j),x in A.items() if i==2*b+p and j//2!=b) for p in (0,1)]
            cole=[sum(x*x for (i,j),x in A.items() if j==2*b+p and i//2!=b) for p in (0,1)]
            u.append(int(rowe[1]>rowe[0]));v.append(int(cole[1]>cole[0]))
        bas.append((np.asarray(u),np.asarray(v)))
        A={(i//2,j//2):x for (i,j),x in A.items() if i%2==u[i//2] and j%2==v[j//2]}
        n=m
    return bas

def sim_one(L,bases,rng):
    n=2**(L+1)
    Obanks=[None]*(L+1);Pbanks=[None]*(L+1)
    Obanks[L]=np.eye(2);Pbanks[L]=np.eye(2)
    for t in range(L-1,-1,-1):
        u,v=bases[t]
        m=len(u)
        Om=np.empty((2*m,2));Ps=np.empty((2*m,2))
        for b in range(m):
            F=Obanks[t+1][b]; P=Pbanks[t+1][b]
            G=rng.choice([-1.,1.])*np.array([-F[1],F[0]])
            Q=rng.choice([-1.,1.])*np.array([-P[1],P[0]])
            Om[2*b+v[b]]=F;Om[2*b+1-v[b]]=G
            Ps[2*b+u[b]]=P;Ps[2*b+1-u[b]]=Q
        Obanks[t]=Om;Pbanks[t]=Ps
    Y=np.zeros((n,2));Z=np.zeros((n,2))
    w=2**L
    for j in range(L):
        Y[2**j]+=Obanks[0][w]
        Z[w]+=Pbanks[0][2**j]
    total_coeff=0.; coeff_by_level=[]; s_by_level=[]
    for t in range(L):
        s_by_level.append(np.sum(Y**2)+np.sum(Z**2));u,v=bases[t];m=len(u)
        Yn=np.zeros((m,2));Zn=np.zeros((m,2)); dnorm=0.
        for b in range(m):
            yf=Y[2*b+u[b]];yd=Y[2*b+1-u[b]]
            zf=Z[2*b+v[b]];zd=Z[2*b+1-v[b]]
            F=Obanks[t][2*b+v[b]];G=Obanks[t][2*b+1-v[b]]
            P=Pbanks[t][2*b+u[b]];Q=Pbanks[t][2*b+1-u[b]]
            dda=yd@F;ddd=yd@G;dad=P@zd
            dnorm+=dda*dda+ddd*ddd+dad*dad
            Yn[b]=yf-dad*G; Zn[b]=zf-dda*Q
        coeff_by_level.append(dnorm);total_coeff+=dnorm
        Y=Yn;Z=Zn
    root=np.linalg.norm(Y)**2; total_coeff+=root
    s_by_level.append(np.sum(Y**2)+np.sum(Z**2))
    return total_coeff,coeff_by_level,s_by_level,root

if __name__=='__main__':
    rng=np.random.default_rng(273)
    for L in range(1,10):
        if L<3:continue
        bases=greedy_basis_coords(L)
        ns=300 if L>=8 else 1000
        arr=np.array([sim_one(L,bases,rng)[0] for z in range(ns)])
        print('L',L,'E||R_C(E)||²',arr.mean(),'variance',arr.std()/np.sqrt(ns),'full error',arr.mean()+L,'ratio OPT=2.25',(arr.mean()+L)/2.25)
