"""Exact rational certificate for failure of the common-OPT weighted ledger
for the full-entry, two-sided block-row/block-column greedy SVD learner.
Works in the coordinate diagonal-covariance family; all decisions checked
by exact integer/rational Gram matrices, no floating point or SVD.

Hierarchy N=2^(L+1), k=1. A=sum_{t=1}^L e_{2^(t-1)} e_w^T + a e_0 e_{w'}^T;
w=2^L (right half first quarter), w'=3*2^(L-1) (right half second quarter).
"""
from fractions import Fraction as F
from pathlib import Path


def gram_is_diagonal(A, dim=2):
    # A as coordinate->rational, independent two row/column coordinate slices
    # For every 2x2 block row/column external Gram should be diagonal.
    n=max(max(i,j) for i,j in A)+1 if A else 0
    assert n %2==0
    nb=n//2
    for b in range(nb):
        for p in range(2):
            for q in range(p+1,2):
                crossr=sum(A.get((2*b+p,j),F(0))*A.get((2*b+q,j),F(0)) for j in range(n) if j//2!=b)
                crossc=sum(A.get((i,2*b+p),F(0))*A.get((i,2*b+q),F(0)) for i in range(n) if i//2!=b)
                assert crossr==0 and crossc==0,(b,crossr,crossc)

def run(L,a=F(3,2),verbose=False):
    assert L>=3 and 1<a*a<L
    n=2**(L+1)
    x=[2**t for t in range(L)]
    w=2**L; wp=3*2**(L-1)
    A={(r,w):F(1) for r in x}
    A[0,wp]=a
    E=[]; bases=[]; discarded=[]
    for level in range(1,L+1):
        m=n//2
        assert m>=2
        # Exact top singular vectors of offdiag block rows/cols: diagonal Gram.
        choices_u=[]; choices_v=[]
        for b in range(m):
            rowe=[sum(v*v for (i,j),v in A.items() if i==2*b+p and j//2!=b) for p in (0,1)]
            cole=[sum(v*v for (i,j),v in A.items() if j==2*b+p and i//2!=b) for p in (0,1)]
            cr=sum(A.get((2*b,j),F(0))*A.get((2*b+1,j),F(0)) for j in range(n) if j//2!=b)
            cc=sum(A.get((i,2*b),F(0))*A.get((i,2*b+1),F(0)) for i in range(n) if i//2!=b)
            assert cr==0 and cc==0,('non-diagonal covariance',level,b,cr,cc)
            choices_u.append(0 if rowe[0]>=rowe[1] else 1)
            choices_v.append(0 if cole[0]>=cole[1] else 1)
        new={}; loss=F(0); lost=[]
        for (i,j),v in A.items():
            if i//2==j//2:
                # diagonal block is unrestricted and its coordinate structure
                # projects only into coarse diagonal; never arises here
                pass
            if i%2==choices_u[i//2] and j%2==choices_v[j//2]:
                new[(i//2,j//2)] = new.get((i//2,j//2),F(0))+v
            else:
                # discrepancy support off-diagonal, orthogonal to coarse class
                assert i//2!=j//2,(level,i,j,'diagonal loss needs accounting')
                loss+=v*v
                lost.append((i,j,v))
        E.append(loss); bases.append((choices_u,choices_v)); discarded.append(lost)
        A=new;n=m
        if verbose:
            print(f'level {level}: loss {loss}, surviving {sorted(A.items())}, lost {lost}')
    assert n==2
    assert E==[F(1)]*L,(L,E)
    # Weighted coefficient estimate specified in user's dossier
    weights=[F(3+20*(L-level+1)) for level in range(1,L+1)]
    W=sum(w*e for w,e in zip(weights,E))
    expected=F(3*L+10*L*(L+1))
    assert W==expected
    # Since x is perpendicular to e0 and w != w', the left-right root block
    # has orthogonal rank-one terms, singular values sqrt(L),a.
    opt2=a*a
    return dict(L=L,a=str(a),N=2**(L+1),losses=[str(e) for e in E],
                weights=[str(w) for w in weights],weighted=str(W),
                optimal_squared=str(opt2),weighted_over_L_opt=str(W/(L*opt2)),
                fixed_distance_squared=str(sum(E)),
                selected_left_path_rows=[b[0][0] for b in bases],
                surviving=dict((str(k),str(v)) for k,v in A.items()))

if __name__=='__main__':
    import json
    out=[]
    for L in (3,4,5,6,7,8):
        item=run(L)
        out.append(item)
        print('L=',L,'N=',item['N'],'E=',item['losses'],
              'W=',item['weighted'],'OPT^2=',item['optimal_squared'],
              'W/(L OPT^2)=',item['weighted_over_L_opt'])
    with open(str(Path(__file__).resolve().parent/'exact_counterexample.json'),'w') as f: json.dump(out,f,indent=2)
