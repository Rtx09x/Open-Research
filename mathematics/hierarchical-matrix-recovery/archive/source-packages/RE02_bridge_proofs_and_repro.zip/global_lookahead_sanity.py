"""Numerical diagnostic of exact rank-2k root-cross reconstruction from 2k
forward + 2k transpose queries. NOT a robust noisy-HSS algorithm."""
import numpy as np

def check(k,L,seed):
    rng=np.random.default_rng(seed)
    half=(2**L)*k
    M=np.zeros((half,half))
    for j in range(L):
        M[(2**j)*k:((2**j)+1)*k,0:k]=np.eye(k)
    M[0:k,(2**(L-1))*k:(2**(L-1)+1)*k]=1.5*np.eye(k)
    s=2*k
    O=rng.normal(size=(half,s));P=rng.normal(size=(half,s))
    Y=M@O;Z=M.T@P;C=P.T@Y
    Mh=Y@np.linalg.solve(C,Z.T)
    rel=np.linalg.norm(M-Mh)/np.linalg.norm(M)
    sv=np.linalg.svd(Mh,compute_uv=False)
    tail=float(np.sum(sv[k:]**2))
    return rel,tail

if __name__=='__main__':
    for k in (1,2,3):
        for L in (3,4,5):
            rel,tail=check(k,L,212+L+k)
            assert rel<1e-9,(k,L,rel)
            assert abs(tail-2.25*k)<1e-8,(k,L,tail)
            print('PASS',k,L,'reconstruction rel',f'{rel:.3e}','best rank-k tail',f'{tail:.9f}')
