import numpy as np


def full_access_greedy(A,k=1):
    A=A.copy(); N=A.shape[0]; L=int(np.log2(N//k))-1
    level=[]
    for depth in range(L):
        d=2*k; m=A.shape[0]//d
        U=[];V=[]
        for i in range(m):
            other=np.r_[0:i*d,(i+1)*d:A.shape[0]]
            if other.size==0: raise ValueError
            ri=A[i*d:(i+1)*d][:,other]
            ci=A[other,i*d:(i+1)*d]
            U.append(np.linalg.svd(ri,full_matrices=True)[0][:,:k])
            V.append(np.linalg.svd(ci,full_matrices=True)[2].T[:,:k])
        # squared projection residual for all offdiagonal blocks
        E2=0.
        for i in range(m):
            for j in range(m):
                if i==j:continue
                block=A[i*d:(i+1)*d,j*d:(j+1)*d]
                proj=U[i]@(U[i].T@block@V[j])@V[j].T
                E2+=np.sum((block-proj)**2)
        Ac=np.zeros((m*k,m*k))
        for i in range(m):
            for j in range(m):
                Ac[i*k:(i+1)*k,j*k:(j+1)*k]=U[i].T @ A[i*d:(i+1)*d,j*d:(j+1)*d] @ V[j]
        level.append(E2)
        A=Ac
    return np.array(level)

def make_hss(k,L,rng,coeff_scale=1):
    assert k==1
    A=rng.normal(size=(2*k,2*k))*coeff_scale
    for t in range(L):
        m=A.shape[0]//k
        U=[];V=[]
        for i in range(m):
            u=rng.normal(size=(2*k,k));u=np.linalg.qr(u)[0]
            v=rng.normal(size=(2*k,k));v=np.linalg.qr(v)[0]
            U.append(u);V.append(v)
        An=np.zeros((m*2*k,m*2*k))
        for i in range(m):
            for j in range(m):
                An[2*i*k:2*(i+1)*k,2*j*k:2*(j+1)*k]= U[i]@A[i*k:(i+1)*k,j*k:(j+1)*k]@V[j].T
        for i in range(m):
            D=rng.normal(size=(2*k,2*k))*coeff_scale
            # drop active-active
            An[2*i*k:2*(i+1)*k,2*i*k:2*(i+1)*k] += D - U[i]@(U[i].T@D@V[i])@V[i].T
        A=An
    return A

def simulate(seed=21,Lmax=6, trials=50):
    rng=np.random.default_rng(seed)
    for L in range(1,Lmax+1):
        N=2**(L+1); mx=(-1,None)
        rows=[]
        for t in range(trials):
            H=make_hss(1,L,rng)
            E=rng.normal(size=(N,N)); E/=np.linalg.norm(E)
            H/=np.linalg.norm(H)
            for alpha in [.1,.5,1.,2.,5.,10.]:
                A=alpha*H+E
                vals=full_access_greedy(A)
                weights=np.arange(L,0,-1)
                ratio=np.dot(vals, weights)/L # denominator noise 1
                rows.append((ratio,alpha,vals))
                if ratio>mx[0]: mx=ratio,(t,alpha,vals)
        print('L',L,'max weighted ratio',mx[0],'alpha,vals',mx[1][1:], 'max dist squared',sum(mx[1][2]))

if __name__=='__main__':sim=simulate()
