"""Independent numerical implementation of full-access exact local SVD, no
imports from rational verifier. Only corroboration; not the proof certificate."""
import numpy as np

def dense_instance(L):
    n=2**(L+1); A=np.zeros((n,n));
    for t in range(L):A[2**t,2**L]=1.
    A[0,3*2**(L-1)]=1.5
    return A

def greedy(A):
    n=A.shape[0];k=1;L=int(np.log2(n))-1
    bases=[];level=[]
    for ell in range(L):
        m=n//2
        U=[];V=[]
        for b in range(m):
            idx=np.r_[0:2*b,2*b+2:n]
            r=A[2*b:2*b+2,:][:,idx]
            c=A[idx,2*b:2*b+2]
            U.append(np.linalg.svd(r, full_matrices=True)[0][:,:1]);
            V.append(np.linalg.svd(c, full_matrices=True)[2].T[:,:1])
        E=0;Anew=np.zeros((m,m))
        for i in range(m):
            for j in range(m):
                block=A[2*i:2*i+2,2*j:2*j+2]
                ab=float((U[i].T@block@V[j])[0,0]);Anew[i,j]=ab
                if i!=j:E+=np.linalg.norm(block)**2-ab**2
        level.append(E); bases.append((U,V)); A=Anew;n=m
    return np.array(level),A,bases

if __name__=='__main__':
    for L in range(3,8):
        e,Aout,_=greedy(dense_instance(L));print('L',L,'E',e,'root',Aout,'check',np.allclose(e,1), 'error',sum(e))
