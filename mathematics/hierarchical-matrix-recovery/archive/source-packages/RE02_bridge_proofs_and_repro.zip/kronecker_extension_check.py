"""Independent dense numerical corroboration (not proof) of tensor-I_k
extension of full-entry greedy SVD obstruction. Requires numpy."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
from greedy_experiment import full_access_greedy
from independent_dense_verify import dense_instance

if __name__=='__main__':
    for k in (2,3,4):
        for L in (3,4,5):
            A=np.kron(dense_instance(L),np.eye(k))
            losses=full_access_greedy(A,k)
            assert np.allclose(losses,k,atol=1e-9,rtol=1e-9), (k,L,losses)
            print(f'PASS k={k} L={L} losses={losses.tolist()}')
