"""Exact Walsh-polynomial expectation of fixed-basis orthonormal-frame
LM coefficient recovery on greedy counterexample's pure signal E.
Uses integer coefficients and bitwise-XOR characters. No floating point,
no Monte Carlo or exhaustive enumeration of all 2^#signs outcomes.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from exact_greedy_counterexample import F

def greedy_basis_coords(L):
    n=2**(L+1)
    A={(2**t,2**L):F(1) for t in range(L)}
    A[0,3*2**(L-1)]=F(3,2)
    result=[]
    for t in range(L):
        m=n//2
        ui=[];vi=[]
        for b in range(m):
            rowe=[sum(x*x for (i,j),x in A.items() if i==2*b+p and j//2!=b) for p in (0,1)]
            cole=[sum(x*x for (i,j),x in A.items() if j==2*b+p and i//2!=b) for p in (0,1)]
            assert sum(A.get((2*b,j),F(0))*A.get((2*b+1,j),F(0)) for j in range(n) if j//2!=b)==0
            assert sum(A.get((i,2*b),F(0))*A.get((i,2*b+1),F(0)) for i in range(n) if i//2!=b)==0
            ui.append(int(rowe[1]>rowe[0])); vi.append(int(cole[1]>cole[0]))
        result.append((ui,vi))
        A={(i//2,j//2):x for (i,j),x in A.items() if i%2==ui[i//2] and j%2==vi[j//2]}
        n=m
    return result

def add(p,q,scale=1):
    if not p:return {m:scale*x for m,x in q.items() if x*scale}
    o=p.copy()
    for k,v in q.items():
        o[k]=o.get(k,0)+scale*v
        if o[k]==0:del o[k]
    return o

def shift(p,mask,coef):
    return {m^mask:coef*v for m,v in p.items()}

def sqnorm(p): return sum(v*v for v in p.values())

# frame row is (which standard basis column 0/1, sign coeff +/- 1, Walsh monomial integer mask)
def perp(F,bit):
    ch,coeff,mask=F
    return (1-ch,coeff*(-1 if ch==1 else 1),mask^(1<<bit))

def make_frames(bases):
    L=len(bases); O=[None]*(L+1);P=[None]*(L+1)
    O[L]=[(0,1,0),(1,1,0)];P[L]=[(0,1,0),(1,1,0)]
    bit=0
    for t in range(L-1,-1,-1):
        ui,vi=bases[t];m=len(ui);O[t]=[None]*(2*m);P[t]=[None]*(2*m)
        for b in range(m):
            F=O[t+1][b];G=perp(F,bit);bit+=1
            T=P[t+1][b];Q=perp(T,bit);bit+=1
            O[t][2*b+int(vi[b])]=F
            O[t][2*b+1-int(vi[b])]=G
            P[t][2*b+int(ui[b])]=T
            P[t][2*b+1-int(ui[b])]=Q
    return O,P,bit

def mul_scalar(p,frame):
    ch,coeff,mask=frame
    return shift(p,mask,coeff)

def dot(y,frame):
    ch,coeff,mask=frame
    return mul_scalar(y[ch],frame)

def scalar_times_frame(s,frame):
    ch,coeff,mask=frame
    out=[{},{}];out[ch]=mul_scalar(s,frame)
    return out

def run(L,verbose=False):
    bas=greedy_basis_coords(L)
    O,P,num_sign=make_frames(bas)
    n=2**(L+1)
    Y=[[{},{}] for z in range(n)];Z=[[{},{}] for z in range(n)]
    w=2**L
    for j in range(L):
        row=2**j
        ch,coeff,mask=O[0][w];Y[row][ch]=add(Y[row][ch],{mask:coeff})
        ch,coeff,mask=P[0][row];Z[w][ch]=add(Z[w][ch],{mask:coeff})
    coeff_expected=[]; carried_expected=[]
    for t in range(L):
        ui,vi=bas[t];m=len(ui)
        carried_expected.append(sum(sqnorm(z) for row in Y+Z for z in row))
        NY=[[{},{}] for z in range(m)];NZ=[[{},{}] for z in range(m)]
        e=0
        for b in range(m):
            ya=Y[2*b+int(ui[b])];yd=Y[2*b+1-int(ui[b])]
            za=Z[2*b+int(vi[b])];zd=Z[2*b+1-int(vi[b])]
            F=O[t][2*b+int(vi[b])];G=O[t][2*b+1-int(vi[b])]
            T=P[t][2*b+int(ui[b])];Q=P[t][2*b+1-int(ui[b])]
            dda=dot(yd,F);ddd=dot(yd,G);dad=dot(zd,T)
            e+=sqnorm(dda)+sqnorm(ddd)+sqnorm(dad)
            dadG=scalar_times_frame(dad,G)
            ddaQ=scalar_times_frame(dda,Q)
            NY[b]=[add(ya[c],dadG[c],-1) for c in range(2)]
            NZ[b]=[add(za[c],ddaQ[c],-1) for c in range(2)]
        coeff_expected.append(e)
        Y,Z=NY,NZ
    carried_expected.append(sum(sqnorm(z) for row in Y+Z for z in row))
    root=sum(sqnorm(z) for row in Y for z in row)
    coeff_expected.append(root)
    total=sum(coeff_expected)
    assert coeff_expected == [1]*(L-1)+[L+1,L], (L,coeff_expected)
    assert all(v==2*L for v in carried_expected), (L,carried_expected)
    assert total==3*L
    if verbose: print('L',L, 'signs',num_sign,'coeff',coeff_expected,'carried',carried_expected,'total',total)
    return {'L':L,'signs':num_sign,'expected_coeff_per_stage':coeff_expected,
            'expected_carried':carried_expected,'expected_coeff_total':total,
            'expected_full_error':total+L}

if __name__=='__main__':
    import json
    ans=[]
    for L in range(3,11):
        obj=run(L,True);ans.append(obj)
    with open(str(Path(__file__).resolve().parent/'walsh_coefficient_moments.json'),'w') as f:json.dump(ans,f,indent=2)
