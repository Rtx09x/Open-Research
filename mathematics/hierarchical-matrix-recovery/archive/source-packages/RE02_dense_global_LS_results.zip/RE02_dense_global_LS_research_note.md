# Global least squares with fixed dense HSS bases: exact tree Schur reduction and Haar holdout inequalities

**26 October 2026. Scope:** The bases are arbitrary *prescribed orthonormal nested bases* and are independent of both probe banks. The candidate samples `A @ Omega`, `A.T @ Psi` with two independent top-down Haar tree frames of width `s >= 2k`, and minimizes the joint squared measurement residual over the exact associated fixed-basis HSS **linear space**. This note does **not** prove its conjectured depth-independent expected-risk factor and does **not** give an algorithm for unknown-basis RE-02. There is no claim of literature novelty or formal peer review.

## Summary, with evidence classification

1. **Theorem 1 (proved): exact sparse constrained tree reduction.** The original *global* least-squares problem, including **every additional width-`s-2k` measurement**, is an exactly equivalent tree-local quadratic in two `k x s` boundary states at each nonroot node. Every local `dd` coefficient and the root `2k x 2k` core can be analytically eliminated. The optimization has constant-sized separator `2ks` independent of tree depth and can be solved by matrix-valued quadratic Schur messages. This is not a decomposition of the coefficient space into an incorrectly independent entrywise support envelope.
2. **Theorem 2 (proved): depth-independent conditional ancestor holdout covariance and small ball.** For any fixed deterministic family of descendant `ad` coefficients, and any ancestor, the component of their interference *outside* that ancestor's local `2k`-row frame obeys the conditional two-sided second-moment bounds `(s-3k)/(s-k)` and `(s-2k)/(s-k)`, an unconditional/conditional fourth-moment bound `3`, and a quantitative small-ball bound `(s-3k)^2/[12(s-k)^2]` for `s>3k`. There is an exact transpose-bank analogue.
3. **Theorem 3 (proved): conditional inverse-Haar holdout moment.** At `s>4k+1`, for **one fresh descendant** frame and an arbitrary ancestral holdout projector, the conditional expectation of the inverse `k x k` holdout Gram is bounded above by `(s-2k-1)/(s-4k-1) I_k`. At width `8k` this is at most `5/3 I_k` for all `k>=1`. A sharper exact formula holds for an immediate child.
4. **Theorem 4 (proved): deterministic noncontractivity of raw ancestor coupling.** Across `r` complete descendant levels, its squared Hilbert-space operator norm is **at least `rk/s` for every realization**, even though its fixed-coefficient holdout has good moments. Consequently a bare depth-independent `||K||<1`/Neumann proof based on this uneliminated coupling is impossible. This does **not** refute the global LS conjecture.
5. **Exact reproduction:** a non-coordinate `L=2,k=1,s=4` calculation with rational rotations, rational orthogonal frames, and arbitrary rational data confirms both the tree-state identities and *the analytically reduced original LS objective* in `sympy` with exact equality. Numerical checks independently reconstruct global dense LS, the reduced LS minimizer, matrix-valued Parseval/transfer identities, and Haar inverse moments. Numerical samples have not produced a divergent-risk family. They are not proof of bounded risk.

**Unresolved decisive step:** The random coefficient estimates produced by *global* LS depend on all descendant Haar frames. Theorems 2–3 are valid when the coefficients entering the local holdout are fixed before those orientations (or are suitably predictable); they cannot simply be applied to the optimizers of the global constrained quadratic. Prove the required joint Schur/Green-function inverse-noise estimate, or exhibit a fixed matrix residual causing it to diverge. A single-node small-ball result is not a uniform smallest-singular-value bound.

## 1. Precise physical wavelet and coefficient notation

At each nonroot node `v`, the fixed row and column local bases are `U_v,V_v in R^(2k x k)`, with orthonormal columns; choose orthonormal complements `U_v^perp,V_v^perp`. Let `H_v^U,J_v^U in R^(N x k)` be the *physical lifted* row active/detail embeddings and `H_v^V,J_v^V` the column active/detail embeddings. They are supported on the physical dyadic interval of `v`. For an internal node with children `a,b`, the physical lifts are

`H_v^U = diag(H_a^U,H_b^U) U_v`, `J_v^U = diag(H_a^U,H_b^U) U_v^perp`,

and analogously with `V`. At a finest leaf `diag(H_a,H_b)` means the local `2k` physical coordinate embedding. At the root, `H_0^U,H_0^V` have `2k` columns and concatenate the active embeddings of its two children. The collections of all nonroot detail vectors plus the root active vectors are complete orthonormal bases of physical row/column space.

Each fixed-class matrix has the unique *orthogonal coefficient decomposition*

```
B = H_0^U B_0 (H_0^V)^T
  + sum_{v != root} [
      J_v^U D_da,v (H_v^V)^T
    + J_v^U D_dd,v (J_v^V)^T
    + H_v^U D_ad,v (J_v^V)^T ].
```

All `D_*` are `k x k`; `B_0` is `2k x 2k`. This expression is the **exact class**, not a wavelet support envelope. Distinct summands are Frobenius-orthogonal. Accordingly

`||B||_F^2 = ||B_0||_F^2 + sum_v(||D_da,v||_F^2+||D_dd,v||_F^2+||D_ad,v||_F^2)`.

The forward (`V`-side) top-down orthonormal bank satisfies

`F_v = (H_v^V)^T Omega`, `G_v=(J_v^V)^T Omega`,

and the transpose (`U`-side) bank satisfies

`P_v=(H_v^U)^T Psi`, `Q_v=(J_v^U)^T Psi`.

For each nonroot node `[F_v;G_v]` and `[P_v;Q_v]` have orthonormal rows. At the root, `F_0=(H_0^V)^T Omega`, `P_0=(H_0^U)^T Psi` have `2k` orthonormal rows. The `G_v` and `Q_v` are generated by independent uniform `k`-frames in the orthogonal complements of their inherited `F_v` and `P_v`, respectively. Thus `Omega,Psi` are `N x s` with exactly `2s` forward-plus-transpose queries.

Define actual observed wavelet channels

`y_v=(J_v^U)^T(A Omega)`, `z_v=(J_v^V)^T(A^T Psi)`,

and root channels `y_0=(H_0^U)^T(A Omega)`, `z_0=(H_0^V)^T(A^T Psi)`.

## 2. Theorem 1: exact tree-state equations and global least-squares elimination

For every nonroot node `v`, introduce two boundary states `h_v,t_v in R^(k x s)`. For children `a,b`, define `h_c=[h_a;h_b]` and `t_c=[t_a;t_b]` (size `2k x s`); at a leaf these are zero.

**The exact measurement synthesis is**

```
h_v = D_ad,v G_v + U_v^T h_c

t_v = D_da,v^T Q_v + V_v^T t_c

hat y_v = D_da,v F_v + D_dd,v G_v + (U_v^perp)^T h_c

hat z_v = D_ad,v^T P_v + D_dd,v^T Q_v + (V_v^perp)^T t_c.
```

At the root,

`hat y_0 = B_0 F_0 + [h_left;h_right]`,

`hat z_0 = B_0^T P_0 + [t_left;t_right]`.

*Proof.* A row detail `J_v^U` is orthogonal to all other row details and to all row actives at its ancestors. Among all `ad` terms, only strict descendants of `v` contribute to `J_v^U` because their physical active vectors can overlap it. Their sum can be projected through the two child active spaces, producing `(U_v^perp)^T h_c`. The `da` and `dd` coefficients at `v` supply the two remaining terms. The transpose-bank equation is symmetric. Projection into the retained active row space gives the recursive state `h_v`, and similarly `t_v`. At the root only the root core and the accumulated active states remain. This proves all identities by induction. Because all row-detail channels plus root-active channels are an **orthogonal** decomposition in each bank, the sum of their squared sketch residuals equals the original global LS objective exactly. QED.

This already gives a tree factor graph with separator `(h_v,t_v)` of dimension `2ks`, and local coefficient dimension `3k^2`, independent of depth. It can be solved with finite-dimensional quadratic KKT/Schur elimination, including affine feasibility constraints; no claim about uniform conditioning follows merely from bounded separator dimension.

### Stronger explicit elimination of `D_dd,v` and `B_0`

For any tentative states, define

```
Y_v = y_v - (U_v^perp)^T h_c
Z_v = z_v - (V_v^perp)^T t_c
eta_v  = h_v - U_v^T h_c
zeta_v = t_v - V_v^T t_c.
```

The states are realizable by local coefficients if and only if

`eta_v = eta_v G_v^T G_v`, `zeta_v = zeta_v Q_v^T Q_v`.

On that feasible affine-linear subspace, the coefficients are necessarily

`D_ad,v = eta_v G_v^T`, `D_da,v = Q_v zeta_v^T`.

Write the two ancestor holdout projectors

`Pi_v^Omega = I_s-F_v^T F_v-G_v^T G_v`,

`Pi_v^Psi   = I_s-P_v^T P_v-Q_v^T Q_v`.

Since the frame rows are orthogonal, the locally optimal shared `dd` coefficient is

`D_dd,v^LS = 1/2 [Y_v G_v^T + (Z_v Q_v^T)^T]`.

Eliminating it produces the exact nonnegative local quadratic

```
Phi_v(h_v,t_v,h_a,t_a,h_b,t_b)
 = ||Y_v Pi_v^Omega||_F^2 + ||Z_v Pi_v^Psi||_F^2
 + ||Y_v F_v^T - Q_v zeta_v^T||_F^2
 + ||Z_v P_v^T - G_v eta_v^T||_F^2
 + (1/2)||Y_v G_v^T - (Z_v Q_v^T)^T||_F^2.
```

At the root, set `Y_0=y_0-[h_left;h_right]` and `Z_0=z_0-[t_left;t_right]`. Eliminating `B_0` yields

```
Phi_0
= ||Y_0(I_s-F_0^T F_0)||_F^2
 +||Z_0(I_s-P_0^T P_0)||_F^2
 +(1/2)||Y_0 F_0^T-(Z_0 P_0^T)^T||_F^2,

B_0^LS=1/2[Y_0 F_0^T+(Z_0 P_0^T)^T].
```

**Exact equivalence:** minimize `sum_{v != root} Phi_v + Phi_0` over all node states `(h_v,t_v)` subject to the local `eta,zeta` row-space constraints. The resulting `D_ad,D_da,D_dd,B_0` synthesize **exactly the same global LS minimizer** as the original full matrix/class problem. This is a sparse **matrix-valued Schur/resolvent formulation**, not merely the old LM nilpotent `K` recursion. Every extra overdetermined measurement appears explicitly as a positive holdout term, and all row/column ties remain in the constraints.

The subtree value function conditional on `(h_v,t_v)` is a convex quadratic, possibly equal to `+infinity` outside a linear feasible subspace. Summing child value functions with `Phi_v` and eliminating the child states defines an exact bottom-up quadratic message. Only `2ks` boundary coordinates per node are carried; all operations are on matrices of dimensions polynomial in `k,s` rather than `N`. This supplies a precise finite-width stochastic Schur-complement object for the remaining expected inverse/error analysis.

## 3. Theorem 2: Haar ancestor-holdout covariance and small ball

Fix any nonroot ancestor `v`. Condition on its column-bank frames (and their ancestors), so the `s x s` projector `Pi=Pi_v^Omega` is now deterministic of rank `s-2k`. Fix arbitrary **deterministic** `k x k` `ad` coefficient matrices `D_w`, one for each selected strict descendant `w` of `v`. With the prescribed physical row bases, define deterministic transfer matrices

`T_vw=(J_v^U)^T H_w^U`, `X_w=T_vw D_w`,

`S_v = sum_{w strict descendant} X_w G_w Pi`, `sigma^2=sum_w ||X_w||_F^2`.

The descendant `G_w` are generated top-down, conditionally centered and Haar in `F_w^perp`, and the `X_w` are independent of those probes. For `s>3k`, let

`alpha=(s-3k)/(s-k)`, `beta=(s-2k)/(s-k)`.

**Theorem:** for *all* such fixed coefficients, all prescribed nested bases, and all depths,

```
alpha sigma^2 <= E[||S_v||_F^2 | ancestor frames] <= beta sigma^2,
E[||S_v||_F^4 | ancestor frames] <= 3 sigma^4,
P(||S_v||_F^2 >= (alpha/2) sigma^2 | ancestor frames)
       >= alpha^2/12    (when sigma>0).
```

The symmetric statement holds for row-bank `Q_w` and ancestor transpose holdout `Pi_v^Psi` with `da` coefficients.

*Second-moment proof.* Topologically order selected descendants so every ancestor orientation is revealed before its descendants. The matrix increments `X_w G_w Pi` have zero conditional mean, hence distinct increments are orthogonal in expected Frobenius inner product. Conditional on `F_w`, isotropy of the Haar Stiefel frame gives, for every fixed symmetric `s x s` matrix `R`,

`E[G_w R G_w^T | F_w] = tr((I-F_w^T F_w) R)/(s-k) I_k`.

Apply this with `R=Pi`. Because `tr Pi=s-2k` and `0 <= tr(F_w Pi F_w^T)<=k`, the scalar ratio lies between `alpha` and `beta` for **every** inherited `F_w`. Summation proves the conditional second-moment inequalities. No independence of *nonancestor* `F_w` and `Pi` was asserted; `Pi` is fixed earlier in the filtration.

*Fourth-moment proof.* Set `a_w=||X_w||_F`, so `||X_w G_w Pi||_F<=a_w` pointwise. Conditional on earlier frames, each increment is centrally symmetric (`G_w` and `-G_w` have the same law), so terms with an odd power of the newest increment vanish. Expanding `||S_previous+increment||_F^4` bounds its conditional expectation by

`||S_previous||_F^4 + 6 a_w^2 ||S_previous||_F^2 + a_w^4`.

The martingale second moment before this step is at most the sum of preceding `a_j^2`. Telescoping yields `E||S_v||_F^4<=3(sum_w a_w^2)^2=3 sigma^4`. Conditional Paley–Zygmund, with `W=||S_v||_F^2`, yields the stated small-ball probability. QED.

**For `s=8k`,** `alpha=5/7`, `beta=6/7`, so the fixed-coefficient projected interference retains at least `5/7` of its natural energy *in conditional expectation*, with small-ball probability at least `25/588` of retaining at least `5/14`.

**Restriction:** coefficients selected *after* observing their own descendant Haar frames are not covered. The global LS solution chooses them after seeing all measurements. This distinction is the core unresolved gap.

## 4. Theorem 3: a uniform conditional inverse moment for fresh detail holdout

Fix the same ancestor projector `Pi=Pi_v^Omega`, and any strict descendant `w`. Condition on all frames needed to determine `Pi` and the inherited `F_w`, but **not** the fresh `G_w`. Let

`T_w = G_w Pi G_w^T`, an `k x k` positive-semidefinite matrix.

**Theorem:** if `s>4k+1`, then `T_w` is positive definite almost surely and

`E[T_w^{-1} | Pi,F_w] <= [(s-2k-1)/(s-4k-1)] I_k`.

For an *immediate child* `w` of `v`, `F_w` lies in the row span of `[F_v;G_v]`, and the sharper **equality** holds:

`E[T_w^{-1} | Pi,F_w] = [(s-2k-1)/(s-3k-1)] I_k`, provided `s>3k+1`.

*Proof.* The row space `F_w^perp` has dimension `d=s-k`. Its intersection with the rank-`s-2k` holdout subspace `range(Pi)` has dimension at least `m=s-3k`. Choose an `m`-dimensional subspace `H` in that intersection. Since `Pi` dominates the projector `P_H`,

`T_w >= G_w P_H G_w^T`,

so inverse order reverses. In orthonormal coordinates on `F_w^perp`, `G_w` is a uniform `k x d` Stiefel row frame. For a fixed coordinate projector of rank `m` (`m>k+1`), represent it as

`G=(Z Z^T)^{-1/2}Z`, `Z=[Z_1 Z_2]`,

where `Z_1` is `k x m` and `Z_2` is `k x (d-m)`, independent standard Gaussian. Rotational invariance makes `E(G P_H G^T)^{-1}` a scalar multiple of `I_k`. Taking its trace and cyclically rotating matrices gives

`tr[(G P_H G^T)^{-1}] = k + tr[(Z_1 Z_1^T)^{-1} Z_2 Z_2^T]`.

The inverse-Wishart first moment `E(Z_1 Z_1^T)^{-1}=I_k/(m-k-1)` is finite for `m>k+1`. Thus

`E(G P_H G^T)^{-1}=[(d-k-1)/(m-k-1)] I_k`.

Substituting `d=s-k`, `m=s-3k` proves the bound. When `w` is an immediate child, `F_w` is entirely within the ancestor's `2k`-dimensional frame span, so `range(Pi)` is itself contained in `F_w^perp`. Take `m=s-2k` to obtain the exact formula. QED.

At `s=8k` the generic upper ratio is `(6k-1)/(4k-1)<=5/3`. This prevents an *isolated* descendant Gram inverse from developing a depth-driven inverse-Wishart tail. **It does not control the inverse of the coupled multilevel Schur complement.**

## 5. Theorem 4: why uneliminated cross-coupling cannot be a contraction

Fix a nonroot node `v` with `r` full levels of descendants. Let `D_w` range over *all* `k x k` `ad` blocks on those `r` levels. For a **fixed realized column tree frame**, consider the linear map

`T_v : (D_w)_w -> sum_w (J_v^U)^T H_w^U D_w G_w in R^(k x s)`.

At any single descendant level, the physical active embeddings `H_w^U` are an orthonormal decomposition of a subspace containing `J_v^U`. Therefore

`sum_{w at that depth} (J_v^U)^T H_w^U (H_w^U)^T J_v^U = I_k`.

Writing the vectorization of each summand as `(G_w^T tensor T_vw) vec(D_w)` and noting `||G_w||_F^2=k`, the squared **Hilbert-Schmidt norm** of `T_v` is

`||T_v||_HS^2 = sum_w ||G_w||_F^2 ||T_vw||_F^2 = r k^2`.

Since the output has only `k s` real coordinates,

`||T_v||_op^2 >= ||T_v||_HS^2/(ks) = rk/s`.

This is **deterministic**, for every prescribed dense hierarchy and every frame realization. With width `s=ck`, the uneliminated cross-action grows at least as `sqrt(r/c)` in operator norm. A hoped-for constant small-gain/Neumann argument cannot simply declare this raw coupling contractive.

Likewise a **single ancestral holdout** has only `k(s-2k)` output coordinates, while `m` independently variable descendant `ad` blocks have `mk^2` coefficients. If `m>(s-2k)/k`, a nonzero, *probe-dependent* coefficient combination lies in that one holdout's kernel. This is not a kernel of the full measurement system and does not refute global LS; it proves that fixed-source small-ball bounds cannot be promoted to simultaneous realization-wise bounds at one ancestor.

These two facts identify why the local moment lemmas must enter a *joint tree Schur/resolvent* proof rather than a termwise or immediate contraction proof.

## 6. Evidence and reproduction instructions

`exact_rational_tree.py`: sympy exact rational arithmetic; non-coordinate rank-one local rotations at `L=2` and `s=4`, rational orthonormal test frames, integer/rational local coefficients and arbitrarily chosen rational `A`. Checks exact physical-vs-tree predictions, physical-vs-wavelet objective, and analytic elimination of `dd` and root core. No floating-point arithmetic.

`check_tree_states.py`: independently checks all state identities numerically for `L=1..4`, `k=1,2`, four basis families (Haar, pi/4, coordinate, near-coordinate), and two independent seeds. Largest absolute errors around `2e-15`.

`check_reduced_ls.py`: constructs dense `C` and full measurement matrix, solves global LS, independently constructs the analytically reduced regression over `da/ad` coefficients only, and verifies identical output. Checks `L=1..3,k=1` and `L=1..2,k=2` with Haar, balanced, and coordinate bases. Output differences below `4e-14`.

`check_transfer_parseval.py`: verifies the per-depth Parseval identity and exact squared Hilbert-Schmidt value `r k^2`; examples up to `L=5,k=1` and `L=4,k=2`, four basis families.

`check_holdout.py`: Monte Carlo diagnostic for conditional moments and the **exact** inverse-Haar/Wishart moment constants. Not a proof; the proof is in Sections 3–4.

`dense_ls.py`: independent generator of the entire dense fixed HSS coefficient space and top-down Haar tree banks, global LS normal equations, plus stress tests on a fixed off-class tensor of opposite-root-child detail wavelets. At width 8 and `k=1`, sample mean reconstruction energies on this fixed unit residual are approximately `0.20–0.24 (L=2)`, `0.28 (L=3)`, `0.34–0.35 (L=4)`, `0.39–0.42 (L=5)` across the tested basis families. These estimates are limited-sample diagnostics with no uniform significance or theorem attached.

Dependencies: Python, NumPy, SciPy, SymPy. All tests use only local CPU code and explicit seeded randomness. To run: `bash verify.sh` from this directory; source files and raw logs are included in the ZIP.

## 7. Precisely unresolved theorem and best next inequality

Let `C` be an arbitrary prescribed fixed *dense* HSS space; generate two independent Haar tree frames of width `s=ck` with fixed `c`, and solve the exact reduced tree quadratic from Section 2. For every deterministic `E orthogonal to C`, we still need

`E_{Omega,Psi}[||B_LS(E)||_F^2] <= C_1 ||E||_F^2`, with absolute `C_1`.

Because the coefficient subspaces are Frobenius orthogonal, `||B_LS(E)||_F^2` is exactly the sum of squared coefficients recovered from the minimizing states, so this statement is equivalent to the requested constant-factor fixed-basis risk theorem.

**Sharper research reduction:** It is enough to control the *noise-forced Schur messages* from the explicit local `Phi_v` quadratic, in a way that remains valid when descendants' optimal states and coefficients depend jointly on their Haar frames and the fixed noise `E`. Every message acts on a `2ks`-dimensional boundary, but its random precision and forcing are statistically dependent and share ancestral frames. Sections 3–4 give conditional small-ball and inverse-moment bounds for each fresh innovation and show that a single raw cross-action's operator norm is unbounded with depth. Neither property alone controls the **joint** message inverse times its correlated forcing.

No fixed input/bases family with provably unbounded **actual expected global-LS risk** was found; no complete proof of uniform constant-factor risk was obtained. In particular, observed or constructed ill-conditioned frame realizations are not evidence of unbounded expectation.

The entire analysis assumes bases known **before** probes and exact arithmetic. It does not select unknown bases and does not reduce the original RE-02 unrestricted HSS optimum. Only `2s` matvecs are used by the candidate, and its output stays in the prescribed rank-`k` HSS class.
