# Reproducible dense HSS global-LS research continuation

The main mathematical document is [RE02_dense_global_LS_research_note.md](RE02_dense_global_LS_research_note.md). This is a rigorous **partial** result, **not** a solution of the all-depth expected-risk conjecture or unknown-basis RE-02.

To rerun all controls locally:

```bash
python -m pip install -r requirements.txt
bash verify.sh
```

`verify.sh` generates the raw logs under `logs/`, and fails on any failed exact-arithmetic or numerical assertion. The exact-rational certificate uses SymPy alone; the other scripts use NumPy and SciPy. No network calls or paid services are required. All random experiments use fixed seeds.

The code constructs the actual prescribed dense nested HSS *linear class*; it does not replace it with its larger wavelet support envelope. The `check_reduced_ls.py` reconstruction test compares two independent implementations of original dense global LS and the reduced state-space LS.

Numerical experiments are diagnostic only. The main theorems in the document have complete analytic proofs and do not depend on their results.
