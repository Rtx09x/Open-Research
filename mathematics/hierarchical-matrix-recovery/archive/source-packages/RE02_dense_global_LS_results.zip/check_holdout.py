"""Diagnostic only: Haar holdout, fourth moment, inverse-Wishart moments."""
import numpy as np
from dense_ls import random_bases,tree_frame,wavelet_bases

def check_inverse(k=1,s=8,trials=15000,seed=42):
    rng=np.random.default_rng(seed)
    d=s-k;m=s-3*k
    if m<=k+1:raise ValueError('infinite inverse expectation in comparison minor')
    sums=[]
    for t in range(trials):
        Z=rng.standard_normal((k,d))
        B=Z[:,:m]@Z[:,:m].T
        J=Z@Z.T
        sums.append(np.trace(np.linalg.solve(B,J))/k)
    target=(s-2*k-1)/(s-4*k-1)
    return np.mean(sums),np.std(sums)/np.sqrt(trials),target

def check_holdout(L=4,k=1,s=8,mode='pi4',trials=550,seed=20):
    rng=np.random.default_rng(seed)
    bs=random_bases(L,k,rng,mode)
    wb,_=wavelet_bases(L,k,bs)
    dictionary=[]
    for bank in range(2):dictionary.append({(t,i):(w,h) for t,i,w,h in wb[bank]})
    t_v=L-1; i_v=0
    Wu_v,_=dictionary[0][t_v,i_v]
    descendants=[]
    for t in range(t_v):
        for i in range(2**(L-t-1)):
            _,Hu_w=dictionary[0][t,i]
            H=Wu_v.T@Hu_w
            D=rng.standard_normal((k,k))/np.sqrt(2**(t_v-t))
            X=H@D
            descendants.append((t,i,X))
    sigma2=sum(np.linalg.norm(x)**2 for _,_,x in descendants)
    assert sigma2>0
    ratios=[]
    for it in range(trials):
        Om=tree_frame(L,k,bs,1,s,rng)
        Wv,Hv=dictionary[1][t_v,i_v]
        loc=np.vstack((Hv.T@Om,Wv.T@Om))
        Pi=np.eye(s)-loc.T@loc
        S=np.zeros((k,s))
        for t,i,X in descendants:
            Ww,_=dictionary[1][t,i]
            Gw=Ww.T@Om
            S+=X@Gw@Pi
        ratios.append(np.linalg.norm(S)**2/sigma2)
    alpha=(s-3*k)/(s-k)
    return float(np.mean(ratios)),float(np.mean(np.asarray(ratios)**2)),alpha,3.

if __name__=='__main__':
    for k in (1,2,3):
        e,se,target=check_inverse(k,8*k,trials=20000)
        print('Wishart inverse control','k',k,'s',8*k,'sample mean %.5f +/- %.5f'% (e,se),'exact',target)
    for mode in ('coordinate','pi4','haar','canted'):
        e,e2,lo,hi=check_holdout(mode=mode)
        print('Holdout',mode,'E W/sigma² ~',round(e,4),'E W²/sigma⁴ ~',round(e2,4),'proved boundaries',round(lo,5),'and',hi)
        assert e>=lo-.05 and e2<=hi+.1
