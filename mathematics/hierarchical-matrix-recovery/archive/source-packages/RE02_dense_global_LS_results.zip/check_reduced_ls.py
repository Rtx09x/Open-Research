"""Verify reduced tree-state least-squares equals full dense linear LS."""
import numpy as np
from dense_ls import random_bases,coeff_matrices,tree_frame,wavelet_bases,complement,normal

def setup(L,k,mode,seed,s):
    rng=np.random.default_rng(seed)
    bases=random_bases(L,k,rng,mode)
    C=coeff_matrices(L,k,bases)
    waves,roots=wavelet_bases(L,k,bases)
    maps=[]
    for bank in (0,1): maps.append({(t,i):(w,h) for t,i,w,h in waves[bank]})
    Om=tree_frame(L,k,bases,1,s,rng)
    Ps=tree_frame(L,k,bases,0,s,rng)
    A=rng.standard_normal((C.shape[1],C.shape[2]))
    d=len(C)
    frees=[];sites={};p=0
    for t in range(L):
        for i in range(2**(L-t)):
            sites[t,i]=p
            frees.extend(list(range(p,p+k*k))+list(range(p+2*k*k,p+3*k*k)))
            p+=3*k*k
    return bases,C,maps,roots,Om,Ps,A,np.array(frees,int),sites

def eliminate(A,bases,C,maps,roots,Om,Ps,free,sites,vals):
    k=bases[0][0].shape[2];L=len(bases);s=Om.shape[1]
    d=np.zeros(len(C));d[free]=vals
    h={};g={}
    for t in range(L):
        for i in range(2**(L-t)):
            idx=sites[t,i]
            da=d[idx:idx+k*k].reshape(k,k)
            ad=d[idx+2*k*k:idx+3*k*k].reshape(k,k)
            U,V=bases[t][0][i],bases[t][1][i]
            Wu,Hu=maps[0][t,i];Wv,Hv=maps[1][t,i]
            G=Wv.T@Om;Q=Wu.T@Ps
            if t==0:
                hc=np.zeros((2*k,s));gc=hc.copy()
            else:
                hc=np.vstack([h[t-1,2*i],h[t-1,2*i+1]])
                gc=np.vstack([g[t-1,2*i],g[t-1,2*i+1]])
            h[t,i]=ad@G+U.T@hc
            g[t,i]=da.T@Q+V.T@gc
            cy=Wu.T@A@Om-complement(U).T@hc
            cz=Wv.T@A.T@Ps-complement(V).T@gc
            dd=(cy@G.T+(cz@Q.T).T)/2
            d[idx+k*k:idx+2*k*k]=dd.ravel()
    y0=roots[0].T@A@Om-np.vstack([h[L-1,0],h[L-1,1]])
    z0=roots[1].T@A.T@Ps-np.vstack([g[L-1,0],g[L-1,1]])
    F0=roots[1].T@Om;P0=roots[0].T@Ps
    broot=(y0@F0.T+(z0@P0.T).T)/2
    d[-4*k*k:]=broot.ravel()
    B=np.einsum('a,aij->ij',d,C)
    residual=np.concatenate([((A-B)@Om).ravel(),((A-B).T@Ps).ravel()])
    return B,residual,d

def run(L,k=1,mode='haar',seed=2,s=None):
    if s is None:s=8*k
    bas,C,maps,roots,Om,Ps,A,free,sites=setup(L,k,mode,seed,s)
    xfull,G,_=normal(C,Om,Ps,A)
    Bfull=np.einsum('a,aij->ij',xfull,C)
    zer=np.zeros(len(free))
    B0,r0,_=eliminate(A,bas,C,maps,roots,Om,Ps,free,sites,zer)
    J=[]
    for t in range(len(free)):
        e=np.zeros(len(free));e[t]=1
        _,re,_=eliminate(A,bas,C,maps,roots,Om,Ps,free,sites,e)
        J.append(re-r0)
    J=np.stack(J,axis=1)
    opt=np.linalg.lstsq(J,-r0,rcond=None)[0]
    Bred,rd,_=eliminate(A,bas,C,maps,roots,Om,Ps,free,sites,opt)
    err=np.linalg.norm(Bred-Bfull)
    return err,np.linalg.norm(rd)**2,np.linalg.norm(A-Bred)**2,len(free),len(C)

if __name__=='__main__':
    for L,k in [(1,1),(2,1),(3,1),(1,2),(2,2)]:
        for mode in ['haar','pi4','coordinate']:
            e,res,physical,nfree,nfull=run(L,k,mode,7)
            print(f'L={L} k={k} mode={mode}, reduced vars={nfree}/{nfull}, delta_full_LS={e:.3e}, sketched residual={res:.5f}, physical sq.err={physical:.5f}')
            assert e<2e-9
    print('ALL REDUCED/ORIGINAL LS EQUIVALENCE CONTROLS PASS')
