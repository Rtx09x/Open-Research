"""Exact geometric identity and numerical HS/op bounds on ancestor transfer."""
import numpy as np
from dense_ls import random_bases,tree_frame,wavelet_bases

def transfer(L,k,s,mode,seed=11):
    rng=np.random.default_rng(seed)
    bs=random_bases(L,k,rng,mode)
    waves,_=wavelet_bases(L,k,bs)
    maps=[{(t,i):(w,h) for t,i,w,h in waves[bank]} for bank in (0,1)]
    v=(L-1,0)
    W,_=maps[0][v]
    Om=tree_frame(L,k,bs,1,s,rng)
    cols=[];parseval=[]
    for t in range(L-1):
        Hsum=np.zeros((k,k));weights=[]
        for i in range(2**(L-1-t)):
            _,Hu=maps[0][t,i]
            Wc,_=maps[1][t,i]
            M=W.T@Hu
            G=Wc.T@Om
            cols.append(np.kron(G.T,M))
            Hsum+=M@M.T
            weights.append(np.linalg.norm(M)**2)
        assert np.max(np.abs(Hsum-np.eye(k)))<1e-12
        parseval.append(sum(weights))
    T=np.concatenate(cols,axis=1)
    hs=float(np.linalg.norm(T)**2)
    lam=float(np.linalg.eigvalsh(T@T.T)[-1])
    target=(L-1)*k*k
    assert abs(hs-target)<1e-10
    assert lam+1e-12>=(L-1)*k/s
    return parseval,hs,lam,(L-1)*k/s

if __name__=='__main__':
    for L,k,s in [(3,1,8),(4,1,8),(5,1,8),(4,2,16)]:
        for mode in ('coordinate','pi4','haar','canted'):
            pars,hs,top,lb=transfer(L,k,s,mode)
            print(f'L={L} k={k} s={s} {mode}: per-depth Parseval={pars}, HS²={hs:.8f}, op²={top:.8f}, certified lower={lb:.8f}')
    print('ALL PARSEVAL/TRANSFER CONTROLS PASS')
