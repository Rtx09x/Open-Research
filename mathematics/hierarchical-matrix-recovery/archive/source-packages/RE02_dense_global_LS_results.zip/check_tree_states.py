"""Independent check of exact tree-state factorization for global dense HSS LS."""
import numpy as np
from dense_ls import (random_bases,coeff_matrices,tree_frame,wavelet_bases,complement)

def verify(L,k,mode,seed=5,s=None):
    if s is None:s=8*k
    rng=np.random.default_rng(seed)
    bases=random_bases(L,k,rng,mode)
    C=coeff_matrices(L,k,bases)
    d=rng.integers(-9,10,size=len(C)).astype(float)/7
    B=np.einsum('a,aij->ij',d,C)
    Om=tree_frame(L,k,bases,1,s,rng)
    Ps=tree_frame(L,k,bases,0,s,rng)
    waves,root=wavelet_bases(L,k,bases)
    # w[r or c][t * number-of-nodes + index]  indexing explicit dictionary
    maps=[]
    for bank in range(2):
        maps.append({(t,i):(W,H) for t,i,W,H in waves[bank]})
    terms={}; idx=0
    for t in range(L):
        m=2**(L-t)
        for i in range(m):
            da=d[idx:idx+k*k].reshape(k,k);idx+=k*k
            dd=d[idx:idx+k*k].reshape(k,k);idx+=k*k
            ad=d[idx:idx+k*k].reshape(k,k);idx+=k*k
            terms[t,i]=(da,dd,ad)
    broot=d[idx:].reshape(2*k,2*k)
    assert len(d)-idx==4*k*k
    h={};g={}
    err=[]
    for t in range(L):
        m=2**(L-t)
        for i in range(m):
            U,V=bases[t][0][i],bases[t][1][i]
            Ud,Vd=complement(U),complement(V)
            Wu,Hu=maps[0][t,i]; Wv,Hv=maps[1][t,i]
            F=Hv.T@Om; G=Wv.T@Om
            P=Hu.T@Ps; Q=Wu.T@Ps
            da,dd,ad=terms[t,i]
            if t==0:
                hc=np.zeros((2*k,s));gc=np.zeros((2*k,s))
            else:
                hc=np.vstack([h[t-1,2*i],h[t-1,2*i+1]])
                gc=np.vstack([g[t-1,2*i],g[t-1,2*i+1]])
            ycalc=da@F+dd@G+Ud.T@hc
            zcalc=ad.T@P+dd.T@Q+Vd.T@gc
            yphys=Wu.T@(B@Om)
            zphys=Wv.T@(B.T@Ps)
            err.append((np.max(abs(ycalc-yphys)),np.max(abs(zcalc-zphys))))
            h[t,i]=ad@G+U.T@hc
            g[t,i]=da.T@Q+V.T@gc
    hc=np.vstack([h[L-1,0],h[L-1,1]])
    gc=np.vstack([g[L-1,0],g[L-1,1]])
    yc=broot@(root[1].T@Om)+hc
    zc=broot.T@(root[0].T@Ps)+gc
    err.append((np.max(abs(yc-root[0].T@B@Om)),np.max(abs(zc-root[1].T@B.T@Ps))))
    return float(np.max(err)),B,Om,Ps,bases

if __name__=='__main__':
    for L in range(1,5):
        for k in (1,2):
            for mode in ('haar','pi4','coordinate','canted'):
                for seed in (3,29):
                    e,*_=verify(L,k,mode,seed)
                    print(f'L={L} k={k} {mode} seed={seed}: max residual={e:.2e}')
                    assert e<1e-10
    print('ALL NUMERICAL FACTORIZATION CONTROLS PASS')
