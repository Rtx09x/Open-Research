"""Dense fixed-basis HSS spaces, orthonormal tree-frame probes, global least squares."""
import numpy as np

def haar_stiefel(n,k,rng):
    q,r=np.linalg.qr(rng.standard_normal((n,k)))
    return q*np.sign(np.diag(r))[None,:]

def haar_o(k,rng):
    Q=haar_stiefel(k,k,rng)
    return Q

def complement(V):
    from scipy.linalg import null_space
    return null_space(V.T)

def random_bases(L,k,rng,mode='haar'):
    bs=[]
    for t in range(L):
        m=2**(L-t)
        banks=[]
        for bank in range(2):
            if mode=='coordinate':
                q=np.tile(np.eye(2*k)[:,:k],(m,1,1))
            elif mode=='pi4':
                q=np.tile(np.vstack((np.eye(k),np.eye(k)))/np.sqrt(2),(m,1,1))
            elif mode=='haar':
                q=np.stack([haar_stiefel(2*k,k,rng) for i in range(m)])
            elif mode=='canted':
                angles=rng.uniform(.0,.2,size=m)
                q=np.stack([np.vstack([np.eye(k)*np.cos(a),np.eye(k)*np.sin(a)]) for a in angles])
            else: raise ValueError(mode)
            banks.append(q)
        bs.append(tuple(banks))
    return bs

def blockdiag(mats):
    import scipy.linalg
    return scipy.linalg.block_diag(*mats)

def coeff_matrices(L,k,bs):
    """Returns orthonormal C basis as shape (d,N,N); includes root."""
    n=(2**(L+1))*k
    Ur=np.eye(n); Vc=np.eye(n)
    mats=[]
    for t in range(L):
        U,V=bs[t]
        m=U.shape[0]
        for i in range(m):
            u=U[i]; v=V[i]; ud=complement(u);vd=complement(v)
            ip=slice(2*i*k,2*(i+1)*k)
            # local D_da=ud e_a^T, D_dd=ud vd^T, D_ad=u vd^T
            for left,right in [(ud,v),(ud,vd),(u,vd)]:
                for a in range(k):
                    for b in range(k):
                        E=np.zeros((2*m*k,2*m*k))
                        E[ip,ip]=np.outer(left[:,a],right[:,b])
                        mats.append(Ur@E@Vc.T)
        Ur=Ur@blockdiag(U); Vc=Vc@blockdiag(V)
    for i in range(2*k):
        for j in range(2*k):
            E=np.zeros((2*k,2*k));E[i,j]=1.
            mats.append(Ur@E@Vc.T)
    C=np.asarray(mats)
    assert C.shape==(3*k*k*((2**(L+1))-2)+4*k*k,n,n),C.shape
    return C

def tree_frame(L,k,bs,bank,s,rng):
    # Root: deterministic two orthogonal k-frames.
    n=(2**(L+1))*k
    root=np.eye(s)[:2*k,:]
    F=root.copy()
    for t in reversed(range(L)):
        Qnodes=bs[t][bank]
        m=len(Qnodes)
        Fchild=np.empty((2*k*m,s))
        for i in range(m):
            ff=F[i*k:(i+1)*k]
            qperp=complement(ff.T).T
            gg=haar_stiefel(s-k,k,rng).T@qperp
            vv=Qnodes[i]; ww=complement(vv)
            Fchild[(2*i)*k:(2*i+2)*k]= vv@ff+ww@gg
        F=Fchild
    assert F.shape==(n,s)
    return F

def normal(C,Om,Ps,E=None):
    # array basis C contains d,N,N.
    Bf=C@Om
    Bt=C.transpose(0,2,1)@Ps
    d=len(C)
    K=np.vstack((Bf.reshape(d,-1).T, Bt.reshape(d,-1).T))
    G=K.T@K
    if E is not None:
        b=np.concatenate([(E@Om).ravel(),(E.T@Ps).ravel()])
        rhs=K.T@b
        x=np.linalg.solve(G,rhs)
        return x,G,rhs
    return G

def check_case(L,k=1,s=None,mode='haar',seed=1):
    if s is None:s=8*k
    rng=np.random.default_rng(seed)
    bs=random_bases(L,k,rng,mode)
    C=coeff_matrices(L,k,bs)
    n=C.shape[1]
    gram0=np.einsum('aij,bij->ab',C,C)
    assert np.max(abs(gram0-np.eye(len(C))))<1e-10, np.max(abs(gram0-np.eye(len(C))))
    E=rng.standard_normal((n,n));E-=np.einsum('a,aij->ij',np.einsum('aij,ij->a',C,E),C);E/=np.linalg.norm(E)
    Om=tree_frame(L,k,bs,1,s,rng)
    Ps=tree_frame(L,k,bs,0,s,rng)
    x,G,rhs=normal(C,Om,Ps,E)
    assert np.min(np.linalg.eigvalsh(G))>1e-9
    return np.linalg.norm(x)**2,np.linalg.eigvalsh(G)[0],bs,C,E

if __name__=='__main__':
    for L in range(1,5):
        for m in ['haar','pi4','coordinate']:
            a,b,*_=check_case(L,mode=m)
            print(L,m,'risk',a,'small gram',b,flush=True)

def wavelet_bases(L,k,bs):
    n=2**(L+1)*k
    waves=[[],[]]
    rootacts=[]
    for bank in range(2):
        lift=np.eye(n)
        for t in range(L):
            Qnodes=bs[t][bank]
            m=len(Qnodes)
            for i in range(m):
                w=lift[:,2*i*k:2*(i+1)*k]@complement(Qnodes[i])
                h=lift[:,2*i*k:2*(i+1)*k]@Qnodes[i]
                waves[bank].append((t,i,w,h))
            lift=lift@blockdiag(Qnodes)
        rootacts.append(lift)
    return waves,rootacts

def stress_test():
    for L in range(2,6):
        for mode in ('coordinate','pi4','haar'):
            rng=np.random.default_rng(12345+L)
            bs=random_bases(L,1,rng,mode)
            C=coeff_matrices(L,1,bs)
            w,root=wavelet_bases(L,1,bs)
            row=w[0][-2][2][:,0];col=w[1][-1][2][:,0]
            E=np.outer(row,col)
            c0=np.einsum('aij,ij->a',C,E)
            assert max(abs(c0))<1e-10
            trials=100 if L<5 else 45
            data=[]
            for it in range(trials):
                Om=tree_frame(L,1,bs,1,8,rng);Ps=tree_frame(L,1,bs,0,8,rng)
                x,G,_=normal(C,Om,Ps,E)
                data.append(np.linalg.norm(x)**2)
            print('stress',L,mode,'mean',round(np.mean(data),4),'std',round(np.std(data),4),'max',round(max(data),4),flush=True)

if __name__=='__main__':
    stress_test()
