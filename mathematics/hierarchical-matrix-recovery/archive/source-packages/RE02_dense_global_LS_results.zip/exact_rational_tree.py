"""Exact rational, non-coordinate verification of the global LS tree-state factorization."""
import sympy as S
from functools import reduce

def rot(a,b):
    assert a*a+b*b==1
    return S.Matrix([a,b]),S.Matrix([-b,a])

def householder_complement(f,j):
    s=f.rows; e=S.eye(s)[:,0]; diff=e-f
    if diff==S.zeros(s,1):return S.eye(s)[:,j]
    H=S.eye(s)-2*diff*diff.T/(diff.T*diff)[0]
    g=H[:,j]
    assert (f.T*g)[0]==0 and (g.T*g)[0]==1
    return g

def build():
    L=2;n=8;s=4
    pairs_r=[[(3,4,5),(5,12,13),(8,15,17),(7,24,25)],[(5,12,13),(3,4,5)]]
    pairs_c=[[(12,5,13),(15,8,17),(4,3,5),(24,7,25)],[(4,3,5),(12,5,13)]]
    b=[]
    for t in range(L):
        uv=[]
        for pairs in (pairs_r[t],pairs_c[t]):
            uv.append([rot(S.Rational(a,d),S.Rational(c,d)) for a,c,d in pairs])
        b.append(uv)
    # build physical orthogonal wavelets and actives
    maps=[{},{}];root=[]
    for bank in (0,1):
        lift=S.eye(n)
        for t in range(L):
            for i,(u,w) in enumerate(b[t][bank]):
                lc=lift[:,2*i:2*i+2]
                maps[bank][t,i]=(lc*w,lc*u)
            lift=lift*S.diag(*[u for u,w in b[t][bank]])
        root.append(lift)
    # probe top-down: root rows standard e_0,e_1
    probes=[]
    for bankbasis in (1,0):
        F=S.eye(s)[:2,:]
        for t in reversed(range(L)):
            new=[]
            for i,(u,w) in enumerate(b[t][bankbasis]):
                f=F[i,:].T
                j=1+((i+2*t+bankbasis)%(s-1))
                g=householder_complement(f,j)
                Q=u*f.T+w*g.T
                new.extend([Q[0,:],Q[1,:]])
            F=S.Matrix.vstack(*new)
        probes.append(F)
    Om,Ps=probes
    terms={};B=S.zeros(n,n)
    for t in range(L):
        for i in range(2**(L-t)):
            a=S.Rational(1+2*i+3*t,2)
            d=S.Rational(-2+i+t,3)
            c=S.Rational(2-3*i+t,5)
            terms[t,i]=(a,d,c)
            Wu,Hu=maps[0][t,i];Wv,Hv=maps[1][t,i]
            B+=Wu*a*Hv.T+Wu*d*Wv.T+Hu*c*Wv.T
    Broot=S.Matrix([[S.Rational(2,3),-1],[S.Rational(5,7),S.Rational(1,2)]])
    B+=root[0]*Broot*root[1].T
    h={};g={};err=[]
    for t in range(L):
        for i in range(2**(L-t)):
            ur,wr=b[t][0][i]; vc,wc=b[t][1][i]
            Wu,Hu=maps[0][t,i];Wv,Hv=maps[1][t,i]
            F=Hv.T*Om; G=Wv.T*Om;P=Hu.T*Ps;Q=Wu.T*Ps
            da,dd,ad=terms[t,i]
            if t==0:
                hc=S.zeros(2,s);gc=S.zeros(2,s)
            else:
                hc=S.Matrix.vstack(h[t-1,2*i],h[t-1,2*i+1]);gc=S.Matrix.vstack(g[t-1,2*i],g[t-1,2*i+1])
            y=da*F+dd*G+wr.T*hc
            z=ad*P+dd*Q+wc.T*gc
            err.extend(list(y-Wu.T*B*Om));err.extend(list(z-Wv.T*B.T*Ps))
            h[t,i]=ad*G+ur.T*hc
            g[t,i]=da*Q+vc.T*gc
    yc=Broot*(root[1].T*Om)+S.Matrix.vstack(h[L-1,0],h[L-1,1])
    zc=Broot.T*(root[0].T*Ps)+S.Matrix.vstack(g[L-1,0],g[L-1,1])
    err.extend(list(yc-root[0].T*B*Om));err.extend(list(zc-root[1].T*B.T*Ps))
    assert all(z==0 for z in err), [(q,S.simplify(q)) for q in err if q!=0][:5]
    # Arbitrary rational data A checks equality of full and rotated LS objectives
    A=S.Matrix(8,8,lambda i,j: S.Rational((i+3*j+7)%11-5, i+j+2))
    physical=sum(x*x for x in (A-B)*Om)+sum(x*x for x in (A-B).T*Ps)
    transformed=S.Integer(0)
    for t in range(L):
        for i in range(2**(L-t)):
            Wu,Hu=maps[0][t,i];Wv,Hv=maps[1][t,i]
            Y=Wu.T*(A-B)*Om
            Z=Wv.T*(A-B).T*Ps
            transformed+=sum(x*x for x in Y)+sum(x*x for x in Z)
    transformed+=sum(x*x for x in root[0].T*(A-B)*Om)
    transformed+=sum(x*x for x in root[1].T*(A-B).T*Ps)
    assert physical==transformed
    # Eliminate all local dd blocks and the shared root core EXACTLY for arbitrary A,
    # holding the ad/da coefficients and their boundary states fixed.
    B_min=S.zeros(n,n)
    reduced=S.Integer(0)
    I_s=S.eye(s)
    for t in range(L):
        for i in range(2**(L-t)):
            ur,wr=b[t][0][i]; vc,wc=b[t][1][i]
            Wu,Hu=maps[0][t,i];Wv,Hv=maps[1][t,i]
            F=Hv.T*Om; G=Wv.T*Om;P=Hu.T*Ps;Q=Wu.T*Ps
            da,dd,ad=terms[t,i]
            if t==0:
                hc=S.zeros(2,s);gc=S.zeros(2,s)
            else:
                hc=S.Matrix.vstack(h[t-1,2*i],h[t-1,2*i+1]);gc=S.Matrix.vstack(g[t-1,2*i],g[t-1,2*i+1])
            cy=Wu.T*A*Om-wr.T*hc
            cz=Wv.T*A.T*Ps-wc.T*gc
            eta=h[t,i]-ur.T*hc;zeta=g[t,i]-vc.T*gc
            assert eta==ad*G and zeta==da*Q
            projy=I_s-F.T*F-G.T*G
            projz=I_s-P.T*P-Q.T*Q
            dx=cy*G.T-(cz*Q.T).T
            local=(sum(x*x for x in cy*projy)+sum(x*x for x in cz*projz)
                +sum(x*x for x in cy*F.T-Q*zeta.T)
                +sum(x*x for x in cz*P.T-G*eta.T)
                +sum(x*x for x in dx)/2)
            reduced+=local
            dd_best=(cy*G.T+(cz*Q.T).T)/2
            B_min+=Wu*da*Hv.T+Wu*dd_best*Wv.T+Hu*ad*Wv.T
    rooty=root[0].T*A*Om-S.Matrix.vstack(h[L-1,0],h[L-1,1])
    rootz=root[1].T*A.T*Ps-S.Matrix.vstack(g[L-1,0],g[L-1,1])
    F0=root[1].T*Om;P0=root[0].T*Ps
    rootdelta=rooty*F0.T-(rootz*P0.T).T
    reduced+=sum(x*x for x in rooty*(I_s-F0.T*F0))
    reduced+=sum(x*x for x in rootz*(I_s-P0.T*P0))
    reduced+=sum(x*x for x in rootdelta)/2
    broot_best=(rooty*F0.T+(rootz*P0.T).T)/2
    B_min+=root[0]*broot_best*root[1].T
    rawmin=sum(x*x for x in (A-B_min)*Om)+sum(x*x for x in (A-B_min).T*Ps)
    assert reduced==rawmin,('Reduced cost failed',S.simplify(reduced-rawmin))
    print('EXACT rational L=2 k=1 s=4: PASS')
    print('non-coordinate transfer tests; all 2*(6+2)*4 scalar prediction identities exact')
    print('independent residual-objective decomposition exact')
    print('elimination of all local dd + root core: exact reduced quadratic equals physical LS cost')
    print('physical rational matrix objective numerator length:',len(str(S.together(physical).as_numer_denom()[0])))
    return True

if __name__=='__main__':build()
