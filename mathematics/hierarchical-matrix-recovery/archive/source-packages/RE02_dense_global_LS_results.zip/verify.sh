#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
export OPENBLAS_NUM_THREADS=1
python exact_rational_tree.py > logs/exact_rational.log
python check_tree_states.py > logs/tree_states.log
python check_reduced_ls.py > logs/reduced_global_LS.log
python check_transfer_parseval.py > logs/transfer_parseval.log
python check_holdout.py > logs/holdout_and_inverse_moments.log
printf '%s\n' 'All verification scripts completed; inspect logs/ for diagnostics.'
