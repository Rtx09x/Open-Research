# RE-02 scalar unknown-basis learning: verified restricted theorems

**Scope:** The unrestricted constant-query unknown-basis rank-one HSS theorem remains OPEN. These are exact query-model learning guarantees for genuinely unknown nested bases on two comparator subclasses. All queries count A and A^T separately. No fixed-basis coefficient bank is used for training.

## Theorem A: four-query learner for rank-one-competitive matrices

Fix any dyadic HSS hierarchy with leaf size two. Write
\(d_1(A)^2=\min_{\operatorname{rank} X\le 1}\|A-X\|_F^2\)
and \(e(A)^2=\operatorname{OPT}_{\rm HSS,1}(A)^2\). Draw an \(N\times3\) independent standard Gaussian matrix \(\Omega\), query **three forward products** \(Y=A\Omega\), and let \(\hat u\) be a unit leading left singular vector of \(Y\). Query **one transpose product** \(z=A^T\hat u\), set \(\widehat B=\hat u z^T\), and construct row and column nested scalar bases from the restrictions of \(\hat u\) and \(z\), with deterministic completions for vanishing restrictions. Let \(\mathcal C_T\) denote the resulting rank-one fixed-basis HSS linear class. Then for every fixed real \(A\),

\[
\mathbb E_T\operatorname{dist}(A,\mathcal C_T)^2
\le \mathbb E\|A-\widehat B\|_F^2
\le 13\,d_1(A)^2.
\tag{A}
\]

Consequently, on the rigorously identified nontrivial subclass \(d_1(A)^2\le\kappa e(A)^2\) for any fixed absolute \(\kappa\), the training target holds in the *stronger depth-independent form* \(\mathbb E\operatorname{dist}(A,\mathcal C_T)^2\le13\kappa e(A)^2\), with \(q_0=4\). This includes all noisy inputs whose optimal (or equally good) HSS rank-one comparator is globally rank one: then \(\kappa=1\). The noise itself is arbitrary deterministic noise; no stochastic-noise assumption is used.

**Proof.** Let \(A=\sigma u v^T+E\) be its optimal global rank-one SVD truncation, with \(Ev=0\), \(\|E\|_F=d_1(A)\), and \(\|u\|=\|v\|=1\). Put \(g=v^T\Omega\) and \(F=E\Omega\). Gaussian orthogonal invariance and \(Ev=0\) imply that \(g\sim N(0,I_3)\) is independent of \(F\), and \(\mathbb E\|F\|_F^2=3\|E\|_F^2\). Let \(P=\hat u\hat u^T\). The leading left singular vector minimizes \(\|(I-P)Y\|_F\) among rank-one left orthogonal projections, so

\[
\|(I-P)Y\|_F\le \|(I-uu^T)Y\|_F
=\|(I-uu^T)F\|_F\le\|F\|_F.
\]

But \(Y=\sigma u g+F\), hence \(\sigma\|(I-P)u\|\|g\|\le2\|F\|_F\). Since \(\mathbb E\|g\|^{-2}=1/(3-2)=1\), independence yields \(\mathbb E[\sigma^2\|(I-P)u\|^2]\le4\cdot3\|E\|_F^2\). The single transpose query sets \(\widehat B=PA\). The two terms in \((I-P)A=\sigma(I-P)uv^T+(I-P)E\) are Frobenius-orthogonal because \(Ev=0\), so \(\mathbb E\|A-PA\|_F^2\le(12+1)\|E\|_F^2\). Finally, a globally rank-one matrix \(PA=\hat u z^T\) lies in the scalar HSS class whose nested bases consist of the normalized restrictions of its factors. This gives (A). If \(A=0\), choose any deterministic bases; the conclusion is immediate. \(\square\)

The same proof for \(s>2\) forward queries plus one transpose gives \(\mathbb E\operatorname{dist}(A,\mathcal C_T)^2\le(1+4s/(s-2))d_1(A)^2\).

### Information obstruction: zero transpose queries are insufficient

For any \(q<N-2\), **no randomized adaptive forward-only learner using at most \(q\) products \(A\omega\)** can guarantee zero projection error for every globally rank-one matrix \(A\) (hence cannot meet the zero-OPT requirement of full RE-02). To see this, fix a known \(u\in\mathbb R^N\) with every entry nonzero and sample \(v\sim N(0,I_N)\), setting \(A=uv^T\). Each forward response reveals at most the single scalar \(v^T\omega\); even if queries are adaptive, conditional on the resulting transcript and the algorithm's random seed, \(v\) retains a nondegenerate Gaussian law along an affine space of dimension at least \(N-q>2\). A rank-one fixed-basis HSS class \(\mathcal C_T\) has only one prescribed physical column direction in each of the two root children. Thus every globally rank-one \(uv^T\in\mathcal C_T\), with this fixed dense \(u\), requires \(v\) to lie in the **at-most-two-dimensional span** of those two root-child directions. Such a fixed 2D space has conditional Gaussian probability zero. Fubini implies failure for some fixed \(v\). This does **not** lower-bound the total number of queries when transpose products are allowed, but explains why the single adaptive transpose query in Theorem A carries essential missing right-side information.

### Surgical undersampling test (not a query-model lower bound)

For the **same spectral-then-transpose learner** using only \(s=2\) forward Gaussian columns, choose \(L=1,N=4\) and \(A_\varepsilon[0:2,2:4]=\operatorname{diag}(1,\varepsilon)\), with all other entries zero, \(0<\varepsilon<1/16\). Its HSS optimum squared is exactly \(\varepsilon^2\). Write the relevant Gaussian test rows \(g,h\in\mathbb R^2\), so \(Y_{0:2}=[g;\varepsilon h]\). Let \(\theta\) be the leading left singular-vector angle from \(e_0\). On the event \(8\varepsilon\le\|g\|\le1\), \(1\le\|h\|\le2\), and \(|\langle g,h\rangle|/(\|g\|\|h\|)\ge1/2\), the exact 2x2 eigenvector formula implies \(\sin^2\theta\ge\varepsilon^2/(8\|g\|^2)\). Gaussian polar coordinates then give \(\mathbb E\sin^2\theta\ge c\varepsilon^2\log(1/\varepsilon)\) for an absolute \(c>0\). The learned HSS class's top-right block has row range \(\hat u\), so its projection error is at least \(\sin^2\theta\). Thus this particular 2-forward/1-transpose variant has no uniform constant-factor projection guarantee even at depth one. It **does not** rule out other three-query algorithms.

## Theorem B: high-global-rank, unknown-basis matrices of known bounded row support

For each physical row \(i\), let a known set \(S_i\subseteq\{1,\ldots,N\}\) satisfy \(|S_i|\le d\), where \(d\) is an absolute constant independent of \(N,L\). Denote by \(\mathcal S\) the **linear support class** \(\{H:H_{ij}=0\text{ if }j\notin S_i\}\). Draw an \(N\times s\) standard Gaussian \(\Omega\), with \(s=2d+2\), and make exactly \(s\) **forward products** \(Y=A\Omega\). Independently for each row compute

\[
\widetilde a_{i,S_i}=Y_{i,:}\,\Omega_{S_i,:}^{\dagger},\qquad
\widetilde a_{i,S_i^c}=0.
\]

(If \(S_i=\varnothing\), set the row to zero.) Let \(\widetilde A\) collect these reconstructed rows. For every deterministic \(A\),

\[
\mathbb E\|A-\widetilde A\|_F^2
=\sum_i\left(1+\frac{d_i}{s-d_i-1}\right)\|A_{i,S_i^c}\|_2^2
\le2\operatorname{dist}(A,\mathcal S)^2,
\tag{B1}
\]

where \(d_i=|S_i|\). **Proof:** \(Y_i\Omega_{S_i}^{\dagger}=A_{i,S_i}+A_{i,S_i^c}\Omega_{S_i^c}\Omega_{S_i}^{\dagger}\). Conditional on \(\Omega_{S_i}\), the last term has covariance \(\|A_{i,S_i^c}\|_2^2(\Omega_{S_i}\Omega_{S_i}^T)^{-1}\), so its expected squared norm equals \(\frac{d_i}{s-d_i-1}\|A_{i,S_i^c}\|_2^2\) by the inverse-Wishart expectation; errors on and off support are orthogonal. Summing proves (B1). \(\square\)

Now use **only arithmetic on the explicit surrogate** \(\widetilde A\) to obtain any globally optimal HSS-rank-one approximation \(B_\mathrm{HSS}\) (finite semialgebraic global optimization is sufficient; computational efficiency was explicitly secondary). Extract its orthonormal nested row/column bases and output only these bases, defining \(\mathcal C_T\). Whenever \(\operatorname{dist}(A,\mathcal S)^2\le\kappa\operatorname{OPT}_{\rm HSS,1}(A)^2\), the triangle inequality and (B1) give

\[
\boxed{\mathbb E\operatorname{dist}(A,\mathcal C_T)^2\le(1+2\sqrt{2\kappa})^2\operatorname{OPT}_{\rm HSS,1}(A)^2.}\tag{B2}
\]

For \(\kappa=1\) this is a depth-independent squared factor \((1+2\sqrt2)^2<15\), with \(q_0=2d+2\) **forward-only** matvecs. In particular, (B2) holds when an optimal HSS comparator has support in \(\mathcal S\). To avoid global semialgebraic optimization, use the explicit-entry Amsel et al. greedy HSS algorithm on \(\widetilde A\), whose deterministic squared approximation guarantee is \(2L\operatorname{OPT}_{\rm HSS,1}(\widetilde A)^2\); that gives the required \(O(L)\) conclusion with a polynomial-time postprocessing procedure, still without additional matvecs.

**Nontrivial high-global-rank example.** For \(N=2^{L+1}\), put arbitrary dense (unknown) vectors \(u_j,v_j\in\mathbb R^2\) into disjoint sibling leaves and define

\[
H=\sum_{j=0}^{N/4-1}(u_j\text{ on rows }4j,4j+1)
(v_j\text{ on columns }4j+2,4j+3)^T.
\]

This is HSS rank one (each off-diagonal nonroot row/column block has rank at most one), but for nonzero vectors its **global rank is \(N/4\)**. It is supported on a known two-columns-per-row pattern (\(d=2\)) yet its nonzero leaf bases are unknown arbitrary directions. The theorem therefore learns suitable bases with **six forward queries**, even after arbitrary deterministic off-support noise is added, comparing to any optimal HSS comparator that remains in that support class.

## Theorem C: bounded global-rank comparator, including nontrivial rank-two HSS signals

This is a different attack from Theorem A. Fix any **absolute** integer \(r\ge2\), and let \(d_r(A)^2=\min_{\operatorname{rank}X\le r}\|A-X\|_F^2\). Assume \(d_r(A)^2\le\kappa e(A)^2\) for an absolute \(\kappa\); in particular this holds with \(\kappa=1\) if there is an optimal HSS rank-one comparator of global rank at most \(r\). Set \(s=2r+2\). Draw an \(N\times s\) Gaussian \(\Omega\), query \(Y=A\Omega\) using \(s\) forward products, compute an orthonormal basis \(Q\) of \(\operatorname{range}(Y)\), and query \(A^TQ\) with at most \(s\) transpose products. The full \(N\times N\) **surrogate** \(X=QQ^TA\) is now explicitly represented as \(Q(A^TQ)^T\), with no more oracle access. Run the deterministic full-entry greedy rank-one HSS algorithm **only on this surrogate**, and return the nested bases of its output \(B_X\), defining \(\mathcal C_T\). The complete training budget is at most \(2s=4r+4\), constant for fixed \(r\).

Put \(a_r=1+r/(r+1)<2\). The rigorous guarantee is

\[
\boxed{\mathbb E\operatorname{dist}(A,\mathcal C_T)^2\le\left[(1+\sqrt2)\sqrt{a_r\kappa}+\sqrt2\right]^2 L\,e(A)^2.}\tag{C1}
\]

In particular for \(\kappa=1\), (C1) is at most \((12+8\sqrt2)L e(A)^2\). This is a polynomial-arithmetic training algorithm (the surrogate can be materialized and passed to the published deterministic explicit greedy HSS algorithm).

**Gaussian range-finder proof.** Partition the SVD relative to the top \(r\) singular vectors as \(A=U\operatorname{diag}(\Sigma_1,\Sigma_2)V^T\), and set \(\Omega_1=V_1^T\Omega\), \(\Omega_2=V_2^T\Omega\). Almost surely \(\Omega_1\in\mathbb R^{r\times s}\) has full row rank. The matrix \(A\Omega\Omega_1^\dagger V_1^T\) belongs to \(\operatorname{range}(Y)\) and differs from \(A\) in two Frobenius-orthogonal right-singular sectors, giving the pointwise upper bound

\[
\|(I-QQ^T)A\|_F^2\le\|\Sigma_2\|_F^2+\|\Sigma_2\Omega_2\Omega_1^\dagger\|_F^2.
\]

The two Gaussian blocks are independent, and the inverse-Wishart identity gives \(\mathbb E\|\Omega_1^\dagger\|_F^2=r/(s-r-1)=r/(r+1)\). Therefore
\(\mathbb E\|A-X\|_F^2\le a_r d_r(A)^2\le a_r\kappa e(A)^2\).

Let \(\delta=\|A-X\|_F\) and let \(H^*\) be an optimal HSS comparator. The deterministic greedy theorem of Amsel et al. gives \(\|X-B_X\|_F\le\sqrt{2L}\operatorname{dist}(X,\mathrm{HSS}_1)\le\sqrt{2L}(\delta+e(A))\). Because \(B_X\in\mathcal C_T\), \(\operatorname{dist}(A,\mathcal C_T)\le(1+\sqrt{2L})\delta+\sqrt{2L}e(A)\). Minkowski's inequality for the random \(\delta\) yields (C1). \(\square\)

**Why this is not only the globally rank-one case.** With \(N=16\), \(H=e_0e_8^T+e_4e_6^T\) has **global rank two** but every dyadic nonroot external block-row and block-column has rank at most one. Thus it is rank-one HSS, and the theorem learns its unknown nested bases exactly when noise vanishes, using 12 total queries. The same holds for arbitrary fixed noisy perturbations, with the stated expected relative projection bound.

If computational efficiency is completely disregarded, replacing the greedy step by a globally optimal HSS approximation to the explicit surrogate \(X\) improves (C1) to the **depth-independent** bound \((1+2\sqrt{a_r\kappa})^2e(A)^2\). This uses a full semialgebraic optimization of an *explicitly reconstructed surrogate*, not entry access to \(A\); (C1) needs no such optimization.

## What remains open

None of these theorems covers all HSS-rank-one matrices. In particular, an exact HSS matrix may have arbitrarily large global rank *and* dense per-row interaction support, making both structural surrogates fail to have error controlled by \(\operatorname{OPT}_{\rm HSS}\). The remaining unknown-basis task is to control a genuinely hierarchical learner that estimates dense external interaction bases from reused matvec banks without declaring compressed probes independent of adaptively selected bases. The provided 6-query/801-factor fixed-basis coefficient theorem can be applied after training on either established subclass using a **fresh independent** bank; it does not solve the general training problem.

Primary context (not novelty claims): Amsel et al., arXiv:2505.16937v2, Theorem 6 and Algorithm 1; Levitt--Martinsson, SISC 46 (2024), A1747--A1763; Yesypenko, arXiv:2610.04574; Do--Chen, arXiv:2610.16913.
