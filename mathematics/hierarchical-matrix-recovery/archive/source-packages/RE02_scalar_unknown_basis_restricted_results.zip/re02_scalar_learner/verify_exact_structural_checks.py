"""Exact structural sanity checks for restricted RE-02 results.

These checks verify the HSS and unknown-basis support examples and an algebraic
row-regression identity. Expectation inequalities are mathematical proofs in
RE02_scalar_unknown_basis_restricted_theorems.md, NOT derived from the tests.
Run: python verify_exact_structural_checks.py  (requires sympy)
"""
import sympy as sp


def hss_external_rank_checks(H, leaf_size=2):
    N = H.rows
    assert N == H.cols and N % leaf_size == 0
    n = leaf_size
    checked = []
    while n < N:
        for first in range(0, N, n):
            I = list(range(first, first + n))
            Ic = [j for j in range(N) if j not in I]
            rr = H.extract(I, Ic).rank()
            cr = H.extract(Ic, I).rank()
            assert rr <= 1 and cr <= 1, (first, n, rr, cr)
            checked.append((n, first, rr, cr))
        n *= 2
    return checked


def construct_dense_leaf_matching(L):
    N = 2 ** (L + 1)
    H = sp.zeros(N)
    for j in range(N // 4):
        # All coefficients nonzero; varying vectors ensure bases are not coordinate.
        u = sp.Matrix([j + 1, j + 2])
        v = sp.Matrix([j + 3, 2*j + 1])
        for a in range(2):
            for b in range(2):
                H[4*j+a, 4*j+2+b] = u[a]*v[b]
    return H


def check_row_regression():
    N = 8
    s = 6
    A = sp.Matrix(N, N, lambda i,j: (i+1)*(j+2) - (i*j) % 3)
    Omega = sp.Matrix(N, s, lambda i,j: (i+1)**j + (i+2)*j + (i*j) % 5)
    S = [0, 3]
    G = Omega.extract(S, list(range(s)))
    assert G.rank() == len(S)
    Gdagger = G.T * (G * G.T).inv()
    row = 2
    outside = [j for j in range(N) if j not in S]
    y = A.extract([row], list(range(N))) * Omega
    lhs = y * Gdagger
    rhs = A.extract([row], S) + A.extract([row], outside) * Omega.extract(outside, list(range(s))) * Gdagger
    assert lhs == rhs
    return True


def main():
    for L in range(2, 6):
        H = construct_dense_leaf_matching(L)
        checked = hss_external_rank_checks(H)
        assert H.rank() == H.rows // 4
        print(f"PASS L={L}: N={H.rows}, global rank={H.rank()}, checks={len(checked)}")
    H2 = sp.zeros(16)
    H2[0,8] = 1
    H2[4,6] = 1
    assert H2.rank() == 2
    hss_external_rank_checks(H2)
    print("PASS rank-two global HSS-rank-one example")
    assert check_row_regression()
    print("PASS exact rowwise sketch-regression identity")

if __name__ == "__main__":
    main()
