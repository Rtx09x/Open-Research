# Correlated matrix anchor at width 3k: rigorous reductions and bounds

**Status (26 October 2026):** The desired absolute, rank-independent constant is neither proved nor refuted. New rigorous results, conditional only on the user-provided audited black-box source moment bounds, are: (i) universal `100 sqrt(15) k` anchor bound for arbitrary rank and depth; (ii) the exact `2` bound for all off-path row-wavelet inputs, which form a large physical subspace; (iii) reduction of the remaining problem to the single ancestor path with exact diagonal cancellation of the randomized cross-scale frame Gram matrix; (iv) a dimension-independent scalar anchor bound `100 sqrt(15)` and its transpose counterpart. No claim of novelty.

## Setup and notation

Let `s=3k,d=2k`. Given prescribed nested row/column bases, let `P in R^{n_c x s}` be the *coarse transpose/row-bank* test, partitioned into `k x s` active row blocks `P_i`. Let `G_j in R^{k x s}` be the fresh fine forward detail. Fix deterministic `A in R^{n_c x k}` with block `A[j]=0`. Define

`B=P_j P^T A`, `L(M)=D_coarse(E_j M G_j,0)`, and `T(A)=L(B)`.

All expectations below use the *actual* Haar O(2k) tree-frame law. Banks are independent; `B` and `L` are NOT independent. The audited input facts used as black boxes are:

- For every *deterministic* `M`, `E||L(M)||_F^2 <=4||M||_F^2`, and `E||L(M)||_F^4 <= 50000||M||_F^4`. The fourth bound follows because `L` is the strict-ancestor part of the full inverse response `V_j`, whose coefficient blocks are Frobenius orthogonal.
- `E||B||_F^4 <=3||A||_F^4`.

## Theorem A. Universal dimension-dependent bound

For every `k,L`, every prescribed real nested basis hierarchy, and every fixed `A` with `A[j]=0`, one has

`E||T(A)||_F^2 <=100 sqrt(15) k ||A||_F^2`.

The same bound holds after interchanging forward/transpose banks.

**Proof.** Condition on all coarse tree frames. The fine `G_j` is independent Haar in `F_j^perp`, so its row covariance is

`E_G[(G_j)_{ap}(G_j)_{bq}] = delta_ab Pi_pq/d`, `Pi=I_s-F_j^T F_j`.

The decoder is linear, so for every `M` the conditional output energy depends only on `MM^T`. More explicitly, let `D_{ap}=D_coarse(E_j e_a e_p^T,0)` for `a=1,...,k,p=1,...,s`, and define a positive-semidefinite `k x k` matrix

`W_ab=(1/d) sum_{p,q} Pi_pq <D_{ap},D_{bq}>_F`.

Then exactly `E_G ||L(M)||_F^2=tr(W MM^T)`.

For each deterministic matrix unit `M_a=e_a e_1^T`, `W_aa=E_G||L(M_a)||^2`. Jensen and the audited fourth source bound give `E W_aa^2 <= 50000`. Consequently

`E(tr W)^2 <= k sum_a E W_aa^2 <=50000 k^2`.

The random `B` is independent of the *fine* `G_j`, even though it depends on the entire coarse row bank. Since `W` is PSD,

`E||L(B)||^2 = E tr(W BB^T) <= E[(trW)||B||_F^2]`

`<=sqrt(E(trW)^2 E||B||_F^4) <=sqrt(50000*3) k||A||_F^2`.

This is `100 sqrt(15) k||A||^2`. No independence between `W` and `B` was assumed. QED.

For `k=1`, this proves the *requested absolute anchor estimate* with `C_a=100 sqrt(15)`, including the transpose analogue.

## Theorem B. Dimension-free control of all off-path wavelets

Construct the **deterministic physical row-wavelet orthogonal transform** `U_wave` from the fixed nested row bases. In its coordinates, the row-bank probe decomposes into (a) the root two active `k`-row frames combined into `R in R^{2k x s}`, and (b) one Haar detail `Q_v in R^{k x s}` for every nonroot internal node `v`. Write the fixed input's wavelet coefficients as `H_root in R^{2k x k}`, and `H_v in R^{k x k}`.

Let `path(j)` be the nonroot ancestors of the physical coarse row block `j`, and define the path part `A_parallel` to consist of the root coefficients and those `H_v` with `v in path(j)`. Define `A_perp` from all the remaining details. Since a wavelet at `v` is physically supported only in its own subtree, `A_perp[j]=0` and `A_parallel[j]=0`.

Then exactly

`E||T(A)||^2=E||T(A_parallel)||^2 + E||T(A_perp)||^2`, and

`E||T(A_perp)||^2 <=(4k/d)||A_perp||^2=2||A_perp||^2`.

This is for arbitrary rank `k`, arbitrary fixed transfers, and the stated full Haar law.

**Proof.** A source localized initially in block `j` propagates only through ancestors of `j` under the **actual blockwise decoder**, because each local diagonal coefficient and carried state is computed blockwise. Thus `L` and `P_j` depend only on the two banks restricted to that ancestor path and the independent fine `G_j`. They do not depend on the fresh orientations within any off-path subtree.

For a wavelet node `v` off the path, its contribution to `B` is `B_v=P_j Q_v^T H_v`. Conditional on the ancestor frames and on all path randomness, the freshly sampled `Q_v` has centered Haar second moment

`E[(Q_v)_{ap}(Q_v)_{bq}] =delta_ab (I_s-P_v^T P_v)_{pq}/d`.

Set `K_v=P_j(I_s-P_v^TP_v)P_j^T`, so `0<=K_v<=I_k`. In vectorized coordinates,

`Cov(vec B_v | path, P_v)=(H_v^TH_v) tensor K_v /d`

(up to the irrelevant permutation of Kronecker factors). Therefore for the fixed *conditional* linear response map `L`, positivity and `K_v<=I` give

`E_{Q_v}||L(B_v)||^2 <=(1/d) sum_{a=1}^k sum_{r=1}^k ||L(e_a e_r^T H_v)||^2`.

All `e_a e_r^T H_v` are deterministic before the probes. The native strict-source second-moment bound thus gives

`E||L(B_v)||^2 <=(4/d) sum_{a,r}||e_a e_r^T H_v||^2 = 4k/d ||H_v||^2 =2||H_v||^2`.

Reveal orientations in off-path subtrees in a topological parent-before-child order, conditioning on the entire ancestor-path bank. Each `Q_v` is a centered martingale difference. `L` and `P_j` are measurable with respect to the path variables, and a later off-path `Q_w` is centered even if its inherited frame depends on an earlier `Q_v`. Therefore different `L(B_v)` are pairwise orthogonal **in expected Frobenius inner product**, and each is orthogonal to `T(A_parallel)`. Sum the per-node bounds and apply physical Parseval. QED.

**Exact scope:** This already proves the desired constant `C_a=2` on the large deterministic subspace `A_parallel=0`. That subspace has physical row dimension `n_c-(L_c+1)k` for `n_c=2^{L_c}k` and hence `k(n_c-(L_c+1)k)` real matrix dimensions. (At the shallowest tree this dimension can be zero.)

## Theorem C. Path-only cross-scale Gram reduction

Let the physical-wavelet synthesis matrix restricted to the root and ancestor path have block row `C=(C_0,C_1,...,C_m)` at physical row `j`, with `C_0` of shape `k x 2k` and all other `C_v` of shape `k x k`. Let `S=(S_0;S_1;...;S_m)` be the actual **random** row-bank wavelet test frames along the path, with `S_0=R`, `S_v=Q_v`. Let `H` be the stacked *deterministic* path wavelet coefficients.

Then

`C C^T=I_k`, `||H||_F^2=||A_parallel||_F^2`, `C H=A_parallel[j]=0`, and

`B_parallel=P_j P^T A_parallel=C S S^T H = C(S S^T-I)H`.

In block form, since each `S_vS_v^T=I`,

`B_parallel=sum_{v != w} C_v S_v S_w^T H_w`.

This is a **cross-scale frame-Gram fluctuation only**: every same-wavelet term cancels exactly because the physical `j` block of `A` is zero.

Consequently the absolute-rank-independent anchor target is **equivalent** to bounding

`E||L(C(S S^T-I)H)||_F^2 <=C_path ||H||_F^2`

for every realizable prescribed path transfer chain and deterministic `H` satisfying `CH=0`. Theorem B then gives the whole anchor estimate with `C_a=max(2,C_path)`. Conversely a whole-anchor bound restricts to the path. This reduces the arbitrary physical input from `n_c*k` dimensions to at most `L_c*k^2` degrees of freedom after the block-zero constraint, without altering the joint Haar law or assuming independence from the inverse.

**Remaining gap.** Prove a uniform path-kernel estimate for the simultaneous fluctuations `S_v S_w^T` and the correlated inverse map `L`. The deterministic-source moment and random-anchor fourth moment cannot accomplish it alone.

## Abstract moment-only obstruction (not a tree counterexample)

For any `k>=2`, let `v,h` be independent uniform unit vectors in `R^k`, and let `h0` be a fixed unit vector. Define

`L_{v,h}(M)=k v^T M h`, and `B_v=v h0^T`.

For any deterministic `M`, `E|L(M)|^2=||M||_F^2`. The spherical fourth moment identity gives `E|L(M)|^4<=9||M||_F^4`. Also `E||B||_F^4=1`. Yet

`E|L(B)|^2=k`.

This model even has independent `v`/`h` banks and right-orthogonal isotropy after averaging `h`. It **does not** have the Haar nested-tree response or the structural form `B=P_jP^TA` for fixed `A`; it only proves that source fourth moments plus anchor fourth moments, in isolation, cannot establish an absolute `k`-uniform correlation bound.

## Reproducibility

- `anchor_checks.py`: constructs the exact width-3k bank geometry and blockwise decoder; checks physical-wavelet transform and the cross-scale cancellation at `k=1,2` and depths 2--4 to machine precision.
- `exact_covariance_verifier.py`: exact SymPy-rational verification of the conditional Haar **second-moment formula** using a finite signed-permutation 2-design, `k=2,s=6`, with conditional energy `2048/25` and its sharp PSD-dominance upper comparison `128`. This is an exact algebra control, not a replacement for full Haar moment estimates.
- `anchor_monte_carlo.py`: seeded non-proof holdout-style checks for path/off-path orthogonality and off-path `<=2` at `k=1,2`, depth 3--4.
- `path_spectrum.py`: separate train/holdout diagnostic for the finite-dimensional path operator. All observed values are strictly empirical and are **not** evidence of a universal bound.

The proofs above use user-provided audited lemmas as black boxes; none of those source-moment proofs was reproduced or independently certified here. The arbitrary-k absolute anchor is still open.
