# Correlated anchor research artifacts

Run:

```
python anchor_checks.py
python exact_covariance_verifier.py
python anchor_monte_carlo.py
python path_spectrum.py
```

Requires Python 3, NumPy, SciPy, SymPy. The exact symbolic verifier has no sampling.

**The desired constant independent of k remains OPEN.** See `ANCHOR_RESEARCH_NOTE.md` for proved bounds and the path-only equivalence.
