"""Reproducible independent checks of the exact tree-frame correlated anchor.
Checks do not replace the proofs. Uses seeded NumPy Haar frames.
"""
import numpy as np
from dataclasses import dataclass


def orth(A):
    Q, _ = np.linalg.qr(A, mode='reduced')
    return Q

def haar(d, rng):
    X = rng.standard_normal((d,d)); Q,R=np.linalg.qr(X)
    Q=Q*np.sign(np.diag(R))[None,:]
    return Q

def complement(F):
    # rows F orthonormal k by s, stable nullspace via full SVD
    u,ss,vh=np.linalg.svd(F, full_matrices=True)
    return vh[F.shape[0]:]

def transfers(k, rng, variant):
    if variant == 'coordinate':
        return np.eye(2*k)
    if variant == 'balanced':
        I=np.eye(k);return np.block([[I,I],[I,-I]])/np.sqrt(2)
    return haar(2*k,rng)

@dataclass
class Bank:
    leaf: np.ndarray
    detail: dict
    root: np.ndarray


def make_bank(L,k,rng,transfers_by_node):
    """n=2**L k-coordinate cut blocks; root has two active children."""
    s=3*k; I=np.eye(s); child_rows={(0,):I[:k],(1,):I[k:2*k]}
    detail={}; node_rows={};
    for depth in range(1,L):
        for node in [p for p in child_rows if len(p)==depth]:
            F=child_rows[node]; node_rows[node]=F
            C=complement(F); G=haar(2*k,rng)[:k]@C
            detail[node]=G
            W=transfers_by_node[node]
            child= W @ np.vstack([F,G])
            child_rows[node+(0,)]=child[:k]
            child_rows[node+(1,)]=child[k:]
    leaves=np.vstack([child_rows[tuple((i>>b)&1 for b in range(L-1,-1,-1))] for i in range(2**L)])
    return Bank(leaves,detail,I[:2*k])


def all_transfers(L,k,rng,variant):
    return {tuple((i>>b)&1 for b in range(depth-1,-1,-1)):transfers(k,rng,variant) for depth in range(1,L) for i in range(2**depth)}


def node_of(i, L, depth):
    return tuple((i>>b)&1 for b in range(L-1,L-depth-1,-1))


def physical_wavelet_analysis(A,L,k,trans):
    """Root coordinate array and all (node, detail) coordinate arrays."""
    blocks={tuple((i>>b)&1 for b in range(L-1,-1,-1)):A[i*k:(i+1)*k,:] for i in range(2**L)}
    details={}
    for depth in range(L-1,0,-1):
        nxt={}
        for j in range(2**depth):
            n=tuple((j>>b)&1 for b in range(depth-1,-1,-1))
            v=np.vstack([blocks[n+(0,)],blocks[n+(1,)]])
            z=trans[n].T@v
            nxt[n]=z[:k];details[n]=z[k:]
        blocks=nxt
    root=np.vstack([blocks[(0,)],blocks[(1,)]])
    return root,details


def physical_wavelet_synthesis(root, details,L,k,trans):
    blocks={(0,):root[:k],(1,):root[k:]}
    for depth in range(1,L):
        nxt={}
        for n in list(blocks):
            if len(n)!=depth:continue
            d=details.get(n,np.zeros_like(blocks[n]))
            ch=trans[n]@np.vstack([blocks[n],d]);nxt[n+(0,)]=ch[:k];nxt[n+(1,)]=ch[k:]
        blocks=nxt
    return np.vstack([blocks[tuple((i>>b)&1 for b in range(L-1,-1,-1))] for i in range(2**L)])


def wavelet_probe_identities(bank,trans,L,k):
    root,d=physical_wavelet_analysis(bank.leaf,L,k,trans)
    err=max(np.linalg.norm(root-bank.root), max([np.linalg.norm(d[n]-bank.detail[n]) for n in d],default=0))
    return err


def energy_output(Y,Z,FO,PO,L,k,tu,tv):
    """Implement EXACT D_coarse specified in request using local formula.
    The root uses FORWARD core, no new transpose query.
    Inputs Y,Z are physical-active by s arrays.
    """
    n=2**L; s=FO.shape[1];res=0.; blocksY=[Y[i*k:(i+1)*k,:].copy() for i in range(n)];blocksZ=[Z[i*k:(i+1)*k,:].copy() for i in range(n)]
    framesF=[FO[i*k:(i+1)*k,:].copy() for i in range(n)];framesP=[PO[i*k:(i+1)*k,:].copy() for i in range(n)]
    for depth in range(L-1,0,-1):
        nextY=[];nextZ=[];nextF=[];nextP=[]
        for q in range(2**depth):
            n=tuple((q>>b)&1 for b in range(depth-1,-1,-1))
            U=tu[n][:,:k]; Wu=tu[n][:,k:]; V=tv[n][:,:k];Wv=tv[n][:,k:]
            yy=np.vstack(blocksY[2*q:2*q+2]);zz=np.vstack(blocksZ[2*q:2*q+2])
            om=np.vstack(framesF[2*q:2*q+2]);ps=np.vstack(framesP[2*q:2*q+2])
            ya=U.T@yy;yd=Wu.T@yy;za=V.T@zz;zd=Wv.T@zz
            f=V.T@om;g=Wv.T@om;p=U.T@ps;r=Wu.T@ps
            dda=yd@f.T;ddd=yd@g.T;dad=p@zd.T
            res+=np.linalg.norm(dda)**2+np.linalg.norm(ddd)**2+np.linalg.norm(dad)**2
            nextY.append(ya-dad@g)
            nextZ.append(za-dda.T@r)
            nextF.append(f);nextP.append(p)
        blocksY,blocksZ,framesF,framesP=nextY,nextZ,nextF,nextP
    yroot=np.vstack(blocksY); omroot=np.vstack(framesF)
    res+=np.linalg.norm(yroot@omroot.T)**2
    return res


def fresh_detail(frame, rng,k):
    return haar(2*k,rng)[:k]@complement(frame)


def test(seed=20261026):
    rng=np.random.default_rng(seed)
    out=[]
    for L,k,typ in [(2,1,'mixing'),(3,1,'balanced'),(4,1,'mixing'),(3,2,'mixing'),(4,2,'balanced')]:
        tu=all_transfers(L,k,rng,typ);tv=all_transfers(L,k,rng,typ)
        f=make_bank(L,k,rng,tv);p=make_bank(L,k,rng,tu)
        errF=wavelet_probe_identities(f,tv,L,k);errP=wavelet_probe_identities(p,tu,L,k)
        j=0; A=rng.standard_normal((2**L*k,k));A[j*k:(j+1)*k]=0
        R,H=physical_wavelet_analysis(A,L,k,tu)
        recon=physical_wavelet_synthesis(R,H,L,k,tu)
        # Decompose offpath and path wavelet sources exactly
        path=[node_of(j,L,depth) for depth in range(1,L)]
        Hpath={v:H[v] for v in path}
        Hoff={v:H[v] for v in H if v not in Hpath}
        Apath=physical_wavelet_synthesis(R,Hpath,L,k,tu)
        Aoff=physical_wavelet_synthesis(np.zeros_like(R),Hoff,L,k,tu)
        G=fresh_detail(f.leaf[j*k:(j+1)*k],rng,k)
        def evaluate(A):
            B=p.leaf[j*k:(j+1)*k]@(p.leaf.T@A)
            Y=np.zeros((2**L*k,3*k));Y[j*k:(j+1)*k]=B@G
            return energy_output(Y,np.zeros_like(Y),f.leaf,p.leaf,L,k,tu,tv)
        Ball=p.leaf[j*k:(j+1)*k]@(p.leaf.T@A)
        Bpath=p.leaf[j*k:(j+1)*k]@(p.leaf.T@Apath)
        Boff=p.leaf[j*k:(j+1)*k]@(p.leaf.T@Aoff)
        # Purely offdiag cross-scale path Gram
        Cj=rootphysical=physical_wavelet_analysis(np.eye(2**L*k)[j*k:(j+1)*k].T,L,k,tu)
        Croot, Cdetails = Cj
        Croot=Croot.T;Cdetails={v:X.T for v,X in Cdetails.items()}
        dim_err=np.linalg.norm(Croot@R+sum((Cdetails[v]@H[v] for v in path),start=np.zeros((k,k))))
        path_rows=[(Croot,p.root,R)] + [(Cdetails[v],p.detail[v],H[v]) for v in path]
        Bcross=sum((Cp@Sp@Sq.T@Hq for i,(Cp,Sp,Hp) in enumerate(path_rows) for q,(Cq,Sq,Hq) in enumerate(path_rows) if i!=q),start=np.zeros((k,k)))
        out.append((L,k,typ,errF,errP,np.linalg.norm(A-recon),np.linalg.norm(A-Apath-Aoff),np.linalg.norm(Ball-Bpath-Boff),np.linalg.norm(Bcross-Bpath),dim_err,evaluate(A)))
    print(' L k type       frame errs  synth errs  B cross errs   anchor output')
    for row in out:
        L,k,typ,eF,eP,eA,ePart,eB,eCross,eZero,en=row
        assert max(eF,eP,eA,ePart,eB,eCross,eZero)<1e-10, row
        print(f'{L:2d} {k:2d} {typ:9s} {max(eF,eP):.2e}  {max(eA,ePart):.2e}  {max(eB,eCross,eZero):.2e}  {en:.7f}')
    print('PASS: exact structural identities checked against generated dense tree frames and decoder')
if __name__=='__main__': test()

def decoder_vector(Y,Z,FO,PO,L,k,tu,tv):
    """Packed mutually Frobenius-orthogonal output coefficients."""
    n=2**L;blocksY=[Y[i*k:(i+1)*k,:].copy() for i in range(n)];blocksZ=[Z[i*k:(i+1)*k,:].copy() for i in range(n)]
    framesF=[FO[i*k:(i+1)*k,:].copy() for i in range(n)];framesP=[PO[i*k:(i+1)*k,:].copy() for i in range(n)]
    coeff=[]
    for depth in range(L-1,0,-1):
        nextY=[];nextZ=[];nextF=[];nextP=[]
        for q in range(2**depth):
            n=tuple((q>>b)&1 for b in range(depth-1,-1,-1))
            U=tu[n][:,:k];Wu=tu[n][:,k:];V=tv[n][:,:k];Wv=tv[n][:,k:]
            yy=np.vstack(blocksY[2*q:2*q+2]);zz=np.vstack(blocksZ[2*q:2*q+2])
            om=np.vstack(framesF[2*q:2*q+2]);ps=np.vstack(framesP[2*q:2*q+2])
            ya=U.T@yy;yd=Wu.T@yy;za=V.T@zz;zd=Wv.T@zz
            f=V.T@om;g=Wv.T@om;p=U.T@ps;r=Wu.T@ps
            dda=yd@f.T;ddd=yd@g.T;dad=p@zd.T
            coeff.extend([dda.flatten(),ddd.flatten(),dad.flatten()])
            nextY.append(ya-dad@g);nextZ.append(za-dda.T@r)
            nextF.append(f);nextP.append(p)
        blocksY,blocksZ,framesF,framesP=nextY,nextZ,nextF,nextP
    coeff.append((np.vstack(blocksY)@np.vstack(framesF).T).flatten())
    return np.concatenate(coeff)
