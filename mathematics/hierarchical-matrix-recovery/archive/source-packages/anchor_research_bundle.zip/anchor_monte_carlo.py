"""Seeded non-proof diagnostics of path/offpath anchor decomposition.
The theorem is analytic; Monte Carlo merely catches implementation errors.
"""
import numpy as np
from anchor_checks import (all_transfers,make_bank,physical_wavelet_analysis,
 physical_wavelet_synthesis,fresh_detail,energy_output,node_of)

def trial_case(L,k,seed,ntrial=300):
    rng=np.random.default_rng(seed)
    tu=all_transfers(L,k,rng,'mixing');tv=all_transfers(L,k,rng,'mixing')
    j=0;n=2**L*k
    A=rng.normal(size=(n,k));A[j*k:(j+1)*k]=0
    R,H=physical_wavelet_analysis(A,L,k,tu)
    path={node_of(j,L,dep) for dep in range(1,L)}
    off={v:H[v] for v in H if v not in path}
    Apath=physical_wavelet_synthesis(R,{v:H[v] for v in path},L,k,tu)
    Aoff=physical_wavelet_synthesis(np.zeros_like(R),off,L,k,tu)
    assert np.linalg.norm(A-Apath-Aoff)<1e-10
    assert np.linalg.norm(Aoff[j*k:(j+1)*k])<1e-10
    normOff=np.linalg.norm(Aoff)**2
    av=np.zeros(4)
    for _ in range(ntrial):
        f=make_bank(L,k,rng,tv);p=make_bank(L,k,rng,tu)
        G=fresh_detail(f.leaf[j*k:(j+1)*k],rng,k)
        def En(B):
            b=p.leaf[j*k:(j+1)*k]@(p.leaf.T@B)
            y=np.zeros((n,3*k));y[j*k:(j+1)*k]=b@G
            return energy_output(y,np.zeros_like(y),f.leaf,p.leaf,L,k,tu,tv)
        v0=En(Apath);v1=En(Aoff);v2=En(A)
        av+=np.array([v0,v1,v2,(v2-v0-v1)/2])
    av/=ntrial
    return (L,k,ntrial,normOff,av)
if __name__=='__main__':
    for args in [(3,1,800),(4,1,500),(3,2,500),(4,2,200)]:
        L,k,t=args
        L,k,t,normOff,av=trial_case(L,k,641001+L*31+k,t)
        print(f'k={k} L={L} trials={t}: offpath E energy/input={av[1]/normOff:.3f} (theory <=2), cross={av[3]:+.3g}, fullE={av[2]:.3f}')
