"""Fraction-exact finite 2-design control for off-path Haar covariance.
A finite signed coordinate law is used ONLY to verify the universal
second-moment tensor identity. The theorem itself applies to full Haar O(2k).
"""
from sympy import Rational, Matrix, zeros, eye, simplify
from itertools import permutations, product
k=2;s=6;d=s-k
r=Rational(3,5);t=Rational(4,5)
e=eye(s)
Pj=Matrix.vstack(e[0,:],e[1,:])
Pv=Matrix.vstack(r*e[0,:]+t*e[2,:],r*e[1,:]+t*e[3,:])
C=Matrix.vstack(-t*e[0,:]+r*e[2,:],-t*e[1,:]+r*e[3,:],e[4,:],e[5,:])
assert Pv*Pv.T==eye(k) and C*C.T==eye(d) and Pv*C.T==zeros(k,d)
H=Matrix([[2,1],[3,-1]])
K=Matrix([[1,2,3,-1],[0,1,2,4],[2,0,-1,3],[3,-2,1,0],[-1,4,0,2]])
vec=lambda B: Matrix([B[a,b] for a in range(k) for b in range(k)])
qs=[]
for idxs in permutations(range(d),k):
    for signs in product((-1,1),repeat=k):
        qs.append(Matrix.vstack(*[sgn*C[idx,:] for idx,sgn in zip(idxs,signs)]))
raw=sum(( (K*vec(Pj*Q.T*H)).dot(K*vec(Pj*Q.T*H)) for Q in qs),Rational(0))/len(qs)
proj=Pj*(eye(s)-Pv.T*Pv)*Pj.T
cov=Matrix(k*k,k*k, lambda i,j:proj[i//k,j//k]*(H.T*H)[i%k,j%k]/d)
calculated=sum((K.T*K)[i,j]*cov[j,i] for i in range(k*k) for j in range(k*k))
up=Rational(0)
for a in range(k):
    for row in range(k):
        M=zeros(k,k)
        for b in range(k):M[a,b]=H[row,b]
        z=K*vec(M);up+=z.dot(z)/d
assert simplify(raw-calculated)==0
assert up>=calculated
print('PASS exact signed-permutation 2-design covariance:',raw)
print('PASS PSD domination upper bound:',up,'>=',raw)
print('The exact algebra is valid for full Haar by the same second-moment identity.')
