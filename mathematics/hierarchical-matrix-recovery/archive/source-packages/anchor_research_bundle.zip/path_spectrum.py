"""Train/holdout spectral diagnostics ONLY; no conjecture from finite spectra."""
import numpy as np
from scipy.linalg import null_space
from anchor_checks import (all_transfers,make_bank,physical_wavelet_synthesis,fresh_detail,
 decoder_vector,node_of)

def test(L,k,typ,trials=150,seed=20261026):
    rng=np.random.default_rng(seed+L*200+k)
    tu=all_transfers(L,k,rng,typ);tv=all_transfers(L,k,rng,typ)
    path={node_of(0,L,dep) for dep in range(1,L)}
    n=2**L*k; pcount=(L+1)*k
    # map path wavelet coefficients -> physical row coordinates
    W=np.zeros((n,pcount));r0=np.zeros((2*k,1));d0={p:np.zeros((k,1)) for p in path}
    for p in range(pcount):
        r=r0.copy();d={i:v.copy() for i,v in d0.items()}
        if p<2*k:r[p]=1
        else:
            dep=(p-2*k)//k+1;a=(p-2*k)%k
            d[node_of(0,L,dep)][a]=1
        W[:,p]=physical_wavelet_synthesis(r,d,L,k,tu).ravel()
    assert np.linalg.norm(W.T@W-np.eye(pcount))<1e-10
    null=null_space(W[:k,:]);W0=W@null
    assert np.linalg.norm(W0[:k,:])<1e-10
    dim=W0.shape[1]*k
    all_inputs=[]
    for a in range(W0.shape[1]):
        for b in range(k):
            A=np.zeros((n,k));A[:,b]=W0[:,a];all_inputs.append(A)
    assert len(all_inputs)==dim
    arr=[]
    for idx in range(trials):
        f=make_bank(L,k,rng,tv);p=make_bank(L,k,rng,tu)
        G=fresh_detail(f.leaf[:k],rng,k)
        T=[]
        for A in all_inputs:
            B=p.leaf[:k]@(p.leaf.T@A)
            Y=np.zeros((n,3*k));Y[:k]=B@G
            T.append(decoder_vector(Y,np.zeros_like(Y),f.leaf,p.leaf,L,k,tu,tv))
        T=np.stack(T,axis=1);arr.append(T.T@T)
    m=trials//2;train=np.mean(arr[:m],axis=0);hold=np.mean(arr[m:],axis=0)
    lam,vec=np.linalg.eigh(train);vv=vec[:,-1]
    return L,k,dim,trials,lam[-1],vv@hold@vv,np.linalg.eigvalsh(hold)[-1]

if __name__=='__main__':
    for L,k,typ,ntrials in [(3,1,'mixing',600),(4,1,'balanced',600),(5,1,'mixing',300),(3,2,'mixing',300),(4,2,'mixing',100)]:
        vals=test(L,k,typ,ntrials)
        print('L=%d k=%d pathdim=%d trials=%d, train-max=%.3f, holdout-risk=%.3f, holdout-max=%.3f'%vals)
