# C7 physical fiber-closure and clique-lift certificates (26 October 2026)

## Status and scope

No code meeting 135093 in C7^10 and no unrestricted Shannon-capacity theorem was obtained. This artifact gives two *exact*, externally replayable **restricted induced-subchannel** clique-cover certificates based on the true physical relation, without terminal labels or approximation:

```
P382 = I0 union I30, I30 = (I0 - C30_old) union C30_new
P392 = P382 union all five P4 supports (20 physical five-words)
W382 = Z union (P382 x P382)    |W382| = 151284
W392 = Z union (P392 x P392)    |W392| = 159024
```

Z is Itty--Rosin--Carstensen--Reichman's seven-rectangle C7^10 code (134753 words). Here `x` is concatenation of two five-word blocks, **not** coordinatewise arithmetic. Confusability of five-words is coordinatewise difference in `{0,1,6}` modulo seven (equality included). A C7^10 word is a pair of five-word integers.

- W382 has exactly 134753 confusability cliques in a **partition**, and Z itself is a 134753-independent set. Hence its restricted Shannon capacity per ten-coordinate block is exactly 134753.
- W392 has a verified partition into exactly 134849 confusability cliques. Its restricted capacity per ten-coordinate block is at most 134849, and at least 134753 by Z. The upper rate on the original physical C7 scale is `< 3.258252770`, below both the known global lower bound and the target `3.258841`.

For all integers t>=1, the product of the listed physical cliques is a partition of each W^t into at most `bound^t` confusable cliques. Every independent set picks at most one word from each cell. No upper bound on unrestricted C7 is asserted.

## Reconstructing the physical data

The supplied `I0.txt` and `X.txt` are 367-element sorted lists from BPZ/Tandon's pinned exact data and retain the original attribution in NOTICE. The checker tests known FNV64 checksums and verifies that both are physically independent.

Fixed sets:

```
R = {15996,13065,10708,15075,13677,14329,1553,6110}
H = {1553,3716,13158,13358,14027,14329,14733,15996}
V = {6110,10708,12277,13065,13677,15075,15910,16046}
B = I0 - R
Xh = {x in X: x physically confusable with some h in H}
Xv = {x in X: x physically confusable with some v in V}
X0 = X - (Xh union Xv)
Z = (B x B) union (R x X0) union (H x Xh) union (V x Xv)
    union (X0 x R) union (Xh x V) union (Xv x H)
```

The checker reconstructs all seven rectangles, verifies independent family sets, checks all 21 cross-rectangle separation conditions *physically*, and checks the rectangles are disjoint. The computed sizes are `B=359`, `X0=322`, `Xh=26`, `Xv=19`, `Z=134753`.

C30 flip:

```
old = [215,1376,2053,4440,5367,5708,6545,7244,10551,10780,
       10879,12095,12824,15887,16580]
new = [1425,1669,2046,2616,5709,6546,6894,8157,9645,10544,
       10829,12481,13174,14572,16237]
```

Five P4 components, listed in physically confusable path order:

```
1553 15910 13158 10708
3716 6110 6494 8888
14329 12277 14733 15075
13065 13358 16046 15996
14027 13677 15685 15384
```

The checker independently verifies that the physical confusability graph induced on P392 is exactly `342 K1 + 5 P4 + C30` (45 edges; degree histogram 342 degree-zero, 10 degree-one, 40 degree-two).

## The non-Cartesian clique-cover lifting rule

Suppose P partitions into t physical confusability cliques G_0,...,G_(t-1). Their Cartesian products are a clique partition of P^2 into t^2 cliques, cell index `i*t + j`.

Given an independent code Z, each z in Z cap P^2 must be contained in a different product cell. For each `z=(x,y)` outside P^2, choose either a distinct unoccupied product cell indexed (i,j) such that `x` is physically confusable with **every** element of G_i and `y` is physically confusable with **every** element of G_j, or leave z as a singleton. All cliques remain confusable after attachment. If r words are left as singletons, we obtain exactly t^2+r confusability cliques partitioning `Z union P^2`.

In both supplied cases t=367, |Z cap P^2|=129393, |Z\P^2|=5360.

- `C30_382_cover.txt`: 367 `G` lines and 5360 `A x y cell-index` lines; 5296 attached and 64 unmatched `-1`. Total `134689+64=134753`. **Exactly tight** against Z.
- `C30_P4_392_cover.txt`: 367 `G` lines and 5360 `A` lines; 5200 attached and 160 unmatched. Total `134689+160=134849`, **below 135093**.

These attachments were found by bipartite matching but the complete witnesses are recorded. **Verification does not call a solver or SciPy**, and all geometrical clique claims are tested directly from physical mod-seven coordinates.

## Replay

```
python verify.py
```

No dependency besides Python 3.9+ standard library. Expected:

```
C30_382_cover.txt PASS: ... attached= 5296 , singleton extras= 64 , all-length ceiling= 134753
C30_P4_392_cover.txt PASS: ... attached= 5200 , singleton extras= 160 , all-length ceiling= 134849
ALL PHYSICAL AND MATHEMATICAL CERTIFICATE CHECKS PASSED.
```

A complete verification checks family independence and rectangle separation; the two cover lists; each original codeword's cell; no attachment collisions; every attachment's 1-to-2-by-1-to-2 physical confusability; and exact total clique counts.

## Boundary of this theorem and the next construction gate

The 392-word alphabet includes all physical words occurring in the 486 maximum codes of the prior exactly enumerated 842-word low-conflict closure. It **does not** include all 842 low-conflict words and does not include every auxiliary X or transformed auxiliary word.

This result therefore excludes even arbitrary non-Cartesian length-ten codes over P392^2 *together with* the published Z, not merely individually rotated/changed variants. It does NOT exclude codes using sufficiently many original-channel words outside W392.

By adjoining arbitrary outsiders as singleton cliques, any code `C` with `|C| >= 135093` must contain at least `135093 - 134849 = 244` distinct length-ten words outside W392, even if every one of its other words lies within W392. This is an exact necessary condition, not a sufficient one. The independently stated old A-cover gives a *different* necessary condition: at least 60 words outside `A=I0^2 union Z union T(Z)`. Since A and W392 are not nested, both tests can be imposed in an exact candidate audit.

A coarse weighted-theta pre-screen follows immediately for a fiber interface `P392 x U3`, where U3 = I0 union X union T(I0): `theta(P392)*theta(U3) <= 367*(363+2sqrt(5)) = 134862.273895... < 135093`. This covers arbitrary non-Cartesian fibers within that mixed interface. For `P392 x U4`, the known fractional clique cover only bounds `367*369.000000413 >135093`, so it is not excluded by that gate. Crucially, the matched W392 bound remains stronger for its own (nonproduct) alphabet.

An additional distinct, now **fully certified**, multi-neighbor fiber probe uses the 15 opposite-C30 words as outer words with the independent 367-element fibers `I0`, `I30`, `X`, `T(I0)` or `T(X)`. These outer words each have two physical blockers in the original base. For each resulting physically independent 15-by-367 reservoir Q, all 5505 points lie outside Z and an explicit 5505-edge **matching into Z** is saved as `C30_15x367_matching_NAME.txt`. The standard-library verifier checks that the 5505 left endpoints exhaust the rectangle, that the right endpoints are distinct words of Z, and that every matched pair is physically confusable. Therefore every one of these five induced subchannels `Z union Q` has **exact** restricted Shannon capacity 134753 per ten-coordinate block, not merely solver-observed delta zero. This does NOT exclude point-dependent mixtures of different inner sources or substantially richer outsider alphabets.

## Attribution

- Sven Polak and Alexander Schrijver (2019): original 367-word C7^5 independent construction, arXiv:1808.07438.
- Pjotr Buys, Sven Polak and Jeroen Zuiddam (2026): source-word auxiliary/private-pair data and seven-family framework, `ShannonBounds/BaseC7Data.lean` pinned commit `aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`.
- Nathaniel Itty, Christopher D. Rosin, Chase Carstensen, Daniel Reichman (2026): seven-rectangle 134753-word C7^10 construction and general set-valued fiber precedents, arXiv:2607.21517. We reconstructed, not invented, their published code.
- Ravi Tandon (2026): distributed source and heterogeneous-substitution context, arXiv:2608.30273, pinned source `data/base_c7.json` at commit `c753408492dde92a239708986d16c15dbf6c3235`.
- The public July 18 2026 radius-five exclusion is due to prior work documented at gokhanmergen.com; not claimed here.

The new claim relative to the supplied dossier is the two **physical mixed-alphabet clique partitions** with their exact attachments. Literature priority has not been established, and this is not human peer review or a Lean formalization.
