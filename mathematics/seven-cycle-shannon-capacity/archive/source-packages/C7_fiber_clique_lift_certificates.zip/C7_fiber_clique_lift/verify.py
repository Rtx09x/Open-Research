#!/usr/bin/env python3
"""Independent exact verification of physical C7^10 clique-cover certificates.
Standard library only. Five-words are little-endian base-7 integers.
All graph, matching and partition claims are checked, not solver statuses.
"""
from itertools import combinations
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent
POW=(1,7,49,343,2401)

def words(name): return tuple(map(int,(ROOT/name).read_text().split()))
def coords(w): return tuple((w//p)%7 for p in POW)
_cache={}
def conf(a,b):
    if a not in _cache: _cache[a]=coords(a)
    if b not in _cache: _cache[b]=coords(b)
    return all((i-j)%7 in (0,1,6) for i,j in zip(_cache[a],_cache[b]))
def indep(S):
    t=sorted(S)
    assert all(not conf(a,b) for a,b in combinations(t,2)), 'non-independent component'
def sep(A,B):
    return all(not conf(a,b) for a in A for b in B)
def fnv(seq):
    h=14695981039346656037
    for v in seq:
        for b in (v&255,v>>8): h=((h^b)*1099511628211)&((1<<64)-1)
    return f'{h:016x}'
I0=set(words('I0.txt'));X=set(words('X.txt'))
assert len(I0)==len(X)==367
assert fnv(sorted(I0))=='58f37df92b29739e'
assert fnv(sorted(X))=='f32ee31dad6d596e'
indep(I0);indep(X)
R={15996,13065,10708,15075,13677,14329,1553,6110}
H={1553,3716,13158,13358,14027,14329,14733,15996}
V={6110,10708,12277,13065,13677,15075,15910,16046}
B=I0-R
Xh={x for x in X if any(conf(x,h) for h in H)}
Xv={x for x in X if any(conf(x,v) for v in V)}
assert len(B)==359 and len(Xh)==26 and len(Xv)==19 and not Xh&Xv
X0=X-(Xh|Xv)
assert len(X0)==322
rects=((B,B),(R,X0),(H,Xh),(V,Xv),(X0,R),(Xh,V),(Xv,H))
# Independent rectangles: independently check every family, every rectangle pair,
# and actual (rather than merely symbolic) disjointness of all constituent words.
for a,b in rects:indep(a);indep(b)
for i,(a,b) in enumerate(rects):
    for c,d in rects[i+1:]:
        assert sep(a,c) or sep(b,d), f'cross-rectangle collision {i}'
Z=set()
for a,b in rects:
    for x in a:
        for y in b:
            pair=(x,y)
            assert pair not in Z,'overlapping rectangles'
            Z.add(pair)
assert len(Z)==134753

flip_out={215,1376,2053,4440,5367,5708,6545,7244,10551,10780,10879,12095,12824,15887,16580}
flip_in={1425,1669,2046,2616,5709,6546,6894,8157,9645,10544,10829,12481,13174,14572,16237}
assert len(flip_out)==len(flip_in)==15 and flip_out<=I0
I30=(I0-flip_out)|flip_in
indep(I30)
C30=flip_out|flip_in
P382=I0|I30
P4paths=(
 (1553,15910,13158,10708),
 (3716,6110,6494,8888),
 (14329,12277,14733,15075),
 (13065,13358,16046,15996),
 (14027,13677,15685,15384),
)
P4={v for path in P4paths for v in path}
P392=P382|P4
assert len(P382)==382 and len(P392)==392 and not P4&C30
# Exact physical induced-subgraph component signature of P392.
deg={x:0 for x in P392}
for x,y in combinations(sorted(P392),2):
    if conf(x,y):deg[x]+=1;deg[y]+=1
assert Counter(deg.values())=={0:342,1:10,2:40}
assert sum(deg.values())//2==45
for path in P4paths:
    assert all(conf(path[i],path[i+1]) for i in range(3))
    assert not conf(path[0],path[2]) and not conf(path[0],path[3]) and not conf(path[1],path[3])
assert all(sum(conf(x,y) for y in C30 if y!=x)==2 for x in C30)


def check_cover(fname,P,unmatched_expected):
    rows=(ROOT/fname).read_text().splitlines()
    groups=[];assign=[]
    for row in rows:
        if row.startswith('#') or not row.strip():continue
        bits=row.split()
        if bits[0]=='G':
            assert len(bits) in (2,3)
            groups.append(tuple(map(int,bits[1:])))
        elif bits[0]=='A':
            assert len(bits)==4
            assign.append(tuple(map(int,bits[1:])))
        else:raise AssertionError(('bad line',row))
    assert len(groups)==367
    assert len({x for g in groups for x in g})==len(P)
    assert {x for g in groups for x in g}==P
    assert sum(map(len,groups))==len(P)
    assert all(len(g)==1 or (len(g)==2 and conf(*g)) for g in groups)
    index={x:i for i,g in enumerate(groups) for x in g}
    # Every z already in P^2 occupies exactly one product-clique cell.
    occupied=set()
    for x,y in Z:
        if x in P and y in P:
            k=index[x]*367+index[y]
            assert k not in occupied, 'Z not independent inside group product'
            occupied.add(k)
    outside=sorted((x,y) for x,y in Z if x not in P or y not in P)
    assert len(occupied)==129393 and len(outside)==5360
    assert [(x,y) for x,y,k in assign]==outside, 'outside Z coverage mismatch'
    used_cells=set(occupied); unmatched=[]
    for x,y,k in assign:
        if k==-1:
            unmatched.append((x,y));continue
        assert 0<=k<367**2 and k not in used_cells, ('duplicate or occupied cell',k)
        i,j=divmod(k,367)
        assert all(conf(x,u) for u in groups[i]),('left clique conflict',x,i)
        assert all(conf(y,v) for v in groups[j]),('right clique conflict',y,j)
        used_cells.add(k)
    assert len(unmatched)==unmatched_expected
    # Cartesian products of group cliques partition P^2; each assigned z
    # is confusable with its entire selected cell, and unassigned z is singleton.
    num_cliques=367**2+len(unmatched)
    assert num_cliques>=len(Z)
    print(fname, 'PASS: |P|=',len(P),', cells=',367**2,
          ', inside Z=',len(occupied),', attached=',5360-len(unmatched),
          ', singleton extras=',len(unmatched),', all-length ceiling=',num_cliques)
    return num_cliques

assert check_cover('C30_382_cover.txt',P382,64)==134753
assert check_cover('C30_P4_392_cover.txt',P392,160)==134849


def T_word(word):
    a,b,c,d,e=coords(word)
    return (2-b)%7 + 7*d + 49*a + 343*((2-c)%7) + 2401*e

# Different construction class: genuine two-neighbor outer C30 words paired
# with one of five independently verified 367-word physical inner codes.
# Each matched Z word absorbs exactly one outsider in a physical clique,
# excluding improvement from any of these five independent rectangles.
indep(flip_in)
for name,inner in (
    ('I0',I0),('I30',I30),('X',X),
    ('TI0',{T_word(y) for y in I0}),
    ('TX',{T_word(y) for y in X}),
):
    assert len(inner)==367
    indep(inner)
    Q={(x,y) for x in flip_in for y in inner}
    S=Q-Z
    assert len(Q)==len(S)==5505
    matchfile=ROOT/f'C30_15x367_matching_{name}.txt'
    pairs=[]
    for line in matchfile.read_text().splitlines():
        if line.startswith('#') or not line.strip():continue
        parts=line.split()
        assert len(parts)==4
        x,y,a,b=map(int,parts)
        pairs.append(((x,y),(a,b)))
    assert len(pairs)==5505
    assert {left for left,right in pairs}==S
    assert len({right for left,right in pairs})==5505
    assert all(right in Z and conf(left[0],right[0]) and conf(left[1],right[1])
               for left,right in pairs)
    print('C30_15x367_matching_'+name+'.txt',
          'PASS: independent outsider reservoir 5505, saturated by 5505 physical edges')
print('ALL PHYSICAL AND MATHEMATICAL CERTIFICATE CHECKS PASSED.')
