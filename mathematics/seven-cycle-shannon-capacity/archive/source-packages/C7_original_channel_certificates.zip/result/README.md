# C7 original-channel interface study (26 October 2026)

## Scope and status

**Target:** a rigorously checkable construction for `Theta(C7) >= 3.258841`, above the certified `3.258840995943983166` all-length ceiling of the previous six-label, length-125 interface. This iteration **does not meet that target**. It does not settle `alpha(C7^5)` or `Theta(C7)`.

The reproducible work below studies the original five-coordinate channel words and their true physical confusability, not the earlier six-label abstraction. It produces two exact all-length **restricted-alphabet** obstructions, a quantitative larger four-code alphabet reduction, and a local-exchange cross-check. All statements are scoped to the specified induced graphs or exchange families.

Original data: the 367-word independent set `I0` of Polak and Schrijver; BPZ's auxiliary 367-word set `X`, both distributed in Tandon's reproducing repository. The files `data/I0.txt`, `data/X.txt` are **complete explicit finite lists** of little-endian base-7 integers in `[0,16806]`.

For physical words `a,b`, write `a ~ b` when each coordinate difference modulo seven belongs to `{0,1,6}`. This is the closed confusability relation in the fifth strong power of `C7`. Two distinct words can coexist in a code precisely when **not** confusable.

Define the coordinate transformation (an automorphism of the fifth-power confusability graph):

```
T(a,b,c,d,e) = ((2-b) mod 7, d, a, (2-c) mod 7, e).
```

We work with three nested original-channel alphabets:

```
U2 = I0 | X                                # size 702
U3 = I0 | X | T(I0)                        # size 704
U4 = I0 | X | T(I0) | T(X)                 # size 1009
```

The distinction between `Theta(C7^5[U])` and unrestricted `Theta(C7)` is essential. Restricting the physical alphabet is a subchannel, not an original-channel upper bound.

## Theorem 1. U2 has all-length capacity exactly 367

`I0` and `X` each have 367 elements, and their intersection has 32. The other 335 words on each side can be placed in 335 disjoint **confusable** pairs, each pair containing one word from `I0-X` and one from `X-I0`. The 32 common words are singletons. These are 367 physical confusability cliques partitioning `U2`.

For any `k`, the `367^k` Cartesian products of those 367 cliques partition `U2^k` into confusable cliques. An independent set meets every cell at most once. Thus `alpha(C7^{5k}[U2^k]) <= 367^k`. Conversely `I0^k` attains `367^k`. Therefore, writing `H2=C7^5[U2]`,

```
Theta(H2) = 367.
```

The 335 pairs are certified as 331 residual pairs plus four pairs extracted from the two cycles listed in Theorem 2. See `data/triple_pentagon_certificate.json` and `verify_triple_theta.py`.

## Theorem 2. U3 has a smaller-than-target all-length theta ceiling

The transformation supplies just two previously absent physical words:

```
T(I0) - (I0 | X) = {6494, 13358}.
```

The **704** words of `U3` admit a disjoint partition into:

- 32 singleton vertices;
- 331 physically-confusable pairs;
- two ordered five-cycles in the **confusability** graph:

```
(6494, 8888, 6773, 6828, 4092)
(13358, 13065, 11062, 10677, 13364)
```

Every consecutive pair in both cycles is confusable, including the closing pair. Other physical confusability edges, including potential chords, are simply deleted for the upper-bound argument.

Let `H3=C7^5[U3]`. The spanning subgraph consisting of those partition components is `32 K1 + 331 K2 + 2 C5`. The Lovasz theta function is additive under disjoint union, is monotone nonincreasing under adding edges, and satisfies `theta(K1)=theta(K2)=1` and `theta(C5)=sqrt(5)`. Consequently:

```
theta(H3) <= 32 + 331 + 2 sqrt(5) = 363 + 2 sqrt(5)
           = 367.4721359549995793928...
           < 367.5 < (3.258841)^5
```

Hence for every `k >= 1`,

```
alpha(C7^{5k}[U3^k]) <= (363 + 2 sqrt(5))^k.
Theta(H3) <= 363 + 2 sqrt(5).
Theta(H3)^(1/5) < 3.258703767738 < 3.258841.
```

This **rejects the entire three-set physical alphabet**, including arbitrary long block codes inside it, without assuming any particular seven-family BPZ substitution. Its numerical ceiling is *weaker than a statement about unrestricted C7*: it only bounds this chosen subalphabet.

An interesting gate distinction: a fractional confusability-clique cover has exact optimum 368 on U3. A dual of weight one on the 32 common isolated words and weight one-half on each of the other 672 words gives lower bound `32+672/2=368` (every physical clique contains at most two exclusive words and at most one common vertex). The partition supplies a matching fractional upper bound, by giving each pentagon edge weight one-half, every pair weight one, and each singleton weight one. **Fractional clique cover 368 cannot exclude a 368-code or the rate threshold, whereas theta does.** `verify_triple_theta.py` checks the dual preconditions directly in the physical graph and the full finite partition.

## Theorem 3. A concrete next decision problem that is not screened out

Adding the fourth independent physical orbit code `T(X)` yields:

```
U4 = I0 | X | T(I0) | T(X)
|U4| = 1009
# physical-confusability edges in C7^5[U4] = 5394
# maximal cliques = 3698 (2674 triangles, 1022 pairs, 2 singletons)
```

The package includes a feasible **fractional physical clique cover** of exact weight

```
369000000413 / 1000000000 = 369.000000413.
```

Every clique (all size at most three) is listed with a nonnegative integer weight on the common denominator `10^9`. All word incidences and the total weight are checked using integer arithmetic. For an independent code in `U4^k`, expand the product of the per-coordinate weighted covers: each codeword has total cover multiplicity at least one, and each Cartesian product of physical cliques meets the code at most once. Summing gives exactly the displayed power bound. Tensoring the weighted physical clique cover proves for arbitrary `k`:

```
alpha(C7^{5k}[U4^k]) <= (369000000413 / 10^9)^k,
```

which corresponds to the original-coordinate rate ceiling

```
< 3.261409060140.
```

**This does not reject `3.258841`**, and there is currently no independently verified infeasibility certificate for a 368-set in `U4`. The graph's finite decision formulation is:

> Find `{0,1}` values `z_v` for the 1009 explicitly enumerated words `v`, subject to `z_u+z_v <= 1` for every one of the 5394 physically confusable edges and `sum_v z_v >= 368`.

The exact graph and its constraints are generated without access to the earlier label interface in `verify_four_code_gate.py`. The file `data/four_code_fractional_cover.json` gives an independent, solver-free all-length upper certificate. A separately found 377-clique *integral* cover is saved in `data/union4_clique_cover.json` and verified, but is weaker.

Known radius-five local exclusion implies a 368-word solution must delete **at least six** words of the original `I0`. Thus a correct solver can add the valid cut `sum_{v in I0} z_v <= 361` to this decision problem. An optional, explicitly noncertifying SciPy/HiGHS MILP run reported **infeasible** for `>=368` even without the radius-five cut (5 branch-and-bound nodes in about 27 seconds). No exact UNSAT proof object was produced; therefore this numerical solver verdict is **not asserted as a theorem**. `explore_u4_milp.py` reproduces the model and checks any proposed independent set against the physical graph. The key remaining gap is between an existing physical 367-independent set and the current provable single-use bound `alpha(U4) <= 369` (from fractional cover `<370`).

## Reproduced local obstructions, with priority corrected

Original-channel neighborhoods of all 16,440 words outside `I0` were constructed exactly. The size histogram is reproduced by `verify_k4.py` and appears in its assertions. For any set `R` of at most four removed `I0` words, define `W(R)={y not in I0: N_I0(y) subset R}`. The new direct audit certifies the **stronger structural finite property** that `W(R)` partitions into at most four cliques of the *physical* confusability graph. This directly precludes four-for-five exchange. It checks 568,119 support envelopes, of which 3,842 have at least five individually eligible outsiders (maximum eight), and separately runs a five-independent-set test.

**No four-for-five exchange is not a new discovery.** A public 18 July 2026 certificate already ruled out up to four removals, and a subsequent certificate ruled out **up to five removals**, examining 850,951 relevant five-word neighborhood unions. We independently reproduced part of this established obstruction and obtained the additional clique-partition property; we do not assert publication novelty for the latter.

`verify_u4_k5.py` gives a sharper *U4-only* fact: among 20,509 center-five envelopes in U4 containing at least one U4-outside word of neighborhood size four or five, **none** even has six individually eligible U4 outsiders. This is a finite pool-count obstruction, distinct from claims about all 16,807 physical words.

## Why the next attack has changed

The exact U2 matching and U3 two-pentagon certificates show that extra nonseparated physical structures **exist**, but do not automatically supply positive capacity gains. In particular, a fractional bound can falsely appear to leave room when a stronger theta bound closes the interface.

The first **not yet exactly certified** physical subproblem in this particular natural automorphism expansion is `alpha(C7^5[U4]) >= 368`. A numerical integer solver strongly disfavors it but supplies no independent exact exclusion proof. It lies above the previous six-label terminal representation and is not ruled out by the current cover gate. Failure to find it does not imply it exists; achieving it would give a **much larger** lower bound `368^(1/5) ≈ 3.259639438693`, safely exceeding the target. Any candidate integer words need only 67,528 explicit pair tests to certify.

If U4 is ultimately blocked by a stronger theta certificate or a resolved exact 368-MIS, the reduction points toward a **new physical family** beyond `I0, X, T(I0), T(X)`, not parameter tuning on the exhausted old weighted label interface.

## Replay

Python 3.9+; **standard library only**. From this directory:

```
python verify_all.py
```

Or run each step separately:

```
python original.py
python verify_published_367.py
python verify_triple_theta.py
python verify_four_code_gate.py
python verify_k4.py
python verify_u4_k5.py
```

All exact membership, pair separation, clique and incidence checks are independent of SciPy/MILP. The fractional clique-cover weights were found numerically but the stored, outward-rounded rational cover **is checked exactly**. The U3 theta proof uses the classical mathematical identity `theta(C5)=sqrt(5)`, plus the explicitly checked finite component decomposition; no numerical SDP is trusted.

The suite also independently reconstructs the Polak--Schrijver code by mapping the 382-word circular seed, retaining its 327 nonconflicting words, and adjoining exactly the 40 published extension words. The result agrees **term-for-term** with `I0`, so the July 2026 radius-five certificate cited above applies to this exact word set, not merely a potentially different maximum code. The full independent reconstruction is in `verify_published_367.py`.

Word-list provenance: source `data/base_c7.json` from [`tandonravi/C7-Shannon-Capacity-Heterogeneous-Recursion`](https://github.com/tandonravi/C7-Shannon-Capacity-Heterogeneous-Recursion), Git blob SHA `946a3e26ab528bd40c81e6558fb07d8fd09366fa`. Each original array is kept in the published sorted integer order. Exact FNV64 checksums against that source array, independently computed from its GitHub connector response, are `58f37df92b29739e` (`I0`) and `f32ee31dad6d596e` (`X`). This is an integrity cross-check, not a collision-resistant authenticity guarantee.

### Source attribution

1. S. C. Polak and A. Schrijver, *New lower bound on the Shannon capacity of C7 from circular graphs*, Information Processing Letters 143 (2019), 37–40. https://arxiv.org/abs/1808.07438
2. P. Buys, S. Polak and J. Zuiddam, *Shannon capacity of odd cycles* formalization and seven-family construction, source: https://github.com/spectra-research/shannon-capacity-lean .
3. R. Tandon, *Strengthening Recursive Constructions for Zero-Error Shannon Capacity*, https://arxiv.org/html/2608.30273v1 and https://github.com/tandonravi/C7-Shannon-Capacity-Heterogeneous-Recursion .
4. G. Mergen, *The Shannon Capacity of the 7-Cycle*, 18 July 2026 prior no-four/no-five local exchange certificates: https://www.gokhanmergen.com/information-theory-problems/problems/shannon-capacity-c7.html .
5. L. Lovász, *On the Shannon capacity of a graph*, IEEE Transactions on Information Theory 25 (1979), 1–7: `theta(C5)=sqrt(5)` and the general theta method.

**Research integrity:** New relative to our preceding dossier are the explicit U2/U3 physical clique partitions, theta obstruction, U4 gate and its reproducible finite graph. Publication priority has not been established. Solver timeout and apparent numerical near-feasibility are not proofs. None of these restricted-family results upper-bounds unrestricted `Theta(C7)`.

License and attribution notices for reused source arrays are included as `NOTICE.txt` and `LICENSE-APACHE-2.0.txt`.
