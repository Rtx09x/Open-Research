"""OPTIONAL NUMERICAL SEARCH, NOT A PROOF OF INFEASIBILITY.
Requires scipy, numpy, networkx. Implements finite 368-MIS decision over U4.
All exact theorem verifiers run without these dependencies.
"""
from time import perf_counter
from itertools import combinations
from original import I0, X, T, confusable

def main():
    import numpy as np
    import networkx as nx
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import coo_matrix
    words=sorted(set(I0)|set(X)|set(map(T,I0))|set(map(T,X)))
    graph=nx.Graph()
    graph.add_nodes_from(range(len(words)))
    graph.add_edges_from((i,j) for i,a in enumerate(words) for j,b in enumerate(words[i+1:],i+1) if confusable(a,b))
    assert len(words)==1009 and graph.number_of_edges()==5394
    cliques=list(nx.find_cliques(graph))
    assert len(cliques)==3698
    n=len(words)
    rows=[];cols=[]
    for k,clique in enumerate(cliques):
        for i in clique:
            rows.append(k);cols.append(i)
    row_target=len(cliques)
    for i in range(n):
        rows.append(row_target);cols.append(i)
    A=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(cliques)+1,n)).tocsr()
    lb=np.r_[np.zeros(len(cliques)),368]
    ub=np.r_[np.ones(len(cliques)),np.inf]
    print(f'U4: {n} vertices, {graph.number_of_edges()} edges, {len(cliques)} maximal cliques')
    print('Checking >=368 with binary variables and exact-integer coefficients')
    t=perf_counter()
    result=milp(c=np.zeros(n),integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(A,lb,ub),options={'time_limit':90,'disp':False,'mip_rel_gap':0})
    print('elapsed',round(perf_counter()-t,3),'status',result.status,result.message)
    if result.x is not None:
        candidate=[w for w,v in zip(words,result.x) if v>.5]
        if len(candidate)>=368 and all(not confusable(a,b) for a,b in combinations(candidate,2)):
            print('EXACTLY CHECKED INDEPENDENT SET:',candidate)
        else:
            print('No verified independent 368-set returned')
    else:
        print('NO CONSTRUCTION. Even solver infeasible status is not an exact unsat certificate.')

if __name__=='__main__':main()
