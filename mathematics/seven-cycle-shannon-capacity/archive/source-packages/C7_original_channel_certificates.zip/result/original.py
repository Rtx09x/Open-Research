"""Physical five-coordinate objects, encoded little-endian in base 7.
Transcribed from the public BPZ/Tandon base data, see README.
This module uses only the Python standard library.
"""
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def read_words(filename):
    return tuple(map(int, (ROOT/'data'/filename).read_text().split()))

I0 = read_words('I0.txt')
X = read_words('X.txt')

POWERS = (1, 7, 49, 343, 2401)
def coords(word):
    return tuple((word//p)%7 for p in POWERS)
def encode(x):
    return sum(a*p for a,p in zip(x, POWERS))
def T(word):
    a,b,c,d,e=coords(word)
    return encode(((2-b)%7, d, a, (2-c)%7, e))
def confusable(x,y):
    return all((x//p-y//p)%7 in (0,1,6) for p in POWERS)

def fnv64(seq):
    h=14695981039346656037
    for v in seq:
        for b in (v&255,v>>8):
            h=((h^b)*1099511628211)&((1<<64)-1)
    return f'{h:016x}'

def verify_source_data():
    assert len(I0)==len(X)==367
    assert tuple(sorted(set(I0)))==I0 and tuple(sorted(set(X)))==X
    assert min(I0)>=0 and max(I0)<7**5 and min(X)>=0 and max(X)<7**5
    assert fnv64(I0)=='58f37df92b29739e', 'I0 source mismatch'
    assert fnv64(X)=='f32ee31dad6d596e', 'X source mismatch'
    assert all(not confusable(a,b) for i,a in enumerate(I0) for b in I0[i+1:])
    assert all(not confusable(a,b) for i,a in enumerate(X) for b in X[i+1:])

if __name__=='__main__':
    verify_source_data()
    print('PASS: physical source-word FNV checks and 2 x 67161 independent pairs')
