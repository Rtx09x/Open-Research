"""Exact offline certificate suite for the original-channel C7 study."""
from original import verify_source_data
from verify_published_367 import verify as published
from verify_triple_theta import verify as triple
from verify_four_code_gate import verify as four
from verify_k4 import verify as k4
from verify_u4_k5 import verify as u4k5

if __name__ == '__main__':
    verify_source_data()
    print('Source physical-code data PASSED')
    published()
    triple()
    four()
    k4()
    u4k5()
    print('ALL CHECKS PASSED')
