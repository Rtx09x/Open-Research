"""Exact, solver-independent fractional clique-cover certificate on U4.
U4 = I0 union X union T(I0) union T(X), an explicitly finite subgraph
of the actual C7 strong fifth power, not the old six-label abstraction.
"""
from pathlib import Path
import json
from itertools import combinations
from original import I0,X,T,confusable,verify_source_data
ROOT=Path(__file__).resolve().parent

def verify():
    verify_source_data()
    groups=[set(I0),set(X),set(map(T,I0)),set(map(T,X))]
    U=set().union(*groups)
    assert len(U)==1009
    E={(a,b) for i,a in enumerate(sorted(U)) for b in sorted(U)[i+1:] if confusable(a,b)}
    assert len(E)==5394
    # Independent physical reconstruction of maximal-clique profile.
    neighbors={a:set() for a in U}
    for a,b in E:
        neighbors[a].add(b);neighbors[b].add(a)
    max_pairs=sum(not (neighbors[a]&neighbors[b]) for a,b in E)
    triples={(a,b,c) for a,b in E for c in (neighbors[a]&neighbors[b]) if c>b}
    assert len(triples)==2674 and max_pairs==1022
    assert all(not (neighbors[a]&neighbors[b]&neighbors[c]) for a,b,c in triples), 'unexpected K4'
    assert sum(not ns for ns in neighbors.values())==2
    assert max_pairs+len(triples)+2==3698
    fractional=json.loads((ROOT/'data/four_code_fractional_cover.json').read_text())
    Q=fractional['denominator']; total=0;count={v:0 for v in U}
    for c in fractional['clique_weights']:
        vertices=c['vertices'];numer=c['weight']
        assert numer>=0 and 1<=len(vertices)<=3 and len(set(vertices))==len(vertices)
        assert set(vertices)<=U
        assert all(confusable(a,b) for a,b in combinations(vertices,2))
        total+=numer
        for v in vertices:count[v]+=numer
    assert total==fractional['total_weight_numerator']==369000000413
    assert Q==10**9 and min(count.values())>=Q
    assert total < 370*Q
    integer=json.loads((ROOT/'data/union4_clique_cover.json').read_text())['cliques']
    assert len(integer)==377 and set().union(*(set(c) for c in integer))==U
    assert all(1<=len(c)<=3 and len(set(c))==len(c) and all(confusable(a,b) for a,b in combinations(c,2)) for c in integer)
    print('PASS: U4 exactly 1009 physical words, 5394 edges, 3698 maximal cliques')
    print('PASS: 883 weighted physical cliques cover every vertex at weight >=1')
    print('PASS: fractional clique bound',total,'/',Q,'(<370), checked by integer sums')
    print('PASS: independent integral 377-clique cover also verified')
    print('Therefore alpha(U4^k) <= (369000000413/1000000000)^k for all k')
    return total,Q
if __name__=='__main__':verify()
