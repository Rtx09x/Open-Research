"""Exact four-for-five obstruction at the length-five physical C7 level.
Only standard library; reconstructs all 16807 words' I0-neighborhood supports.
Proves: for every removed subset R of I0 of size at most 4, the set
 W(R)={y outside I0: N(y) intersection I0 subset R}
can be partitioned into at most four confusability cliques.

The enclosure enumeration is exact; see README for its short completeness proof.
"""
from itertools import combinations
from collections import defaultdict, Counter
from hashlib import sha256
from time import perf_counter
from original import I0,confusable,verify_source_data


def candidates_by_support():
    inside=set(I0)
    by=defaultdict(list)
    degrees=Counter()
    for y in range(7**5):
        if y in inside:continue
        s=tuple(i for i,x in enumerate(I0) if confusable(x,y))
        assert s, 'published code is not maximal'
        degrees[len(s)]+=1
        if len(s)<=4:
            by[s].append(y)
    assert degrees=={1:8,2:254,3:1505,4:3039,5:3712,6:3897,7:2842,8:921,9:199,10:61,11:2}
    return by,degrees


def support_envelopes(by):
    # Case A: an inserted word has support size 3 or 4.
    # Every admissible deleted four-set is the word's four-support or
    # its three-support plus an arbitrary additional center.
    R=set()
    for s in by:
        if len(s)==4:R.add(s)
        elif len(s)==3:
            for j in range(len(I0)):
                if j not in s:R.add(tuple(sorted(s+(j,))))

    # Case B: all inserted words have support size <= 2.
    # At most one outside word has a given singleton support; and at most
    # TWO have the same two-element support (verified separately).
    edges=sorted(s for s in by if len(s)==2)
    priv=sorted(s[0] for s in by if len(s)==1)
    assert len(edges)==244 and len(priv)==8
    assert all(len(by[s])<=2 for s in edges)
    assert all(len(by[(i,)])==1 for i in priv)
    adj=defaultdict(set)
    for a,b in edges:adj[a].add(b);adj[b].add(a)
    for i,(a,b) in enumerate(edges):
        # Any five outside words supported on <=4 centers use either
        # two DIFFERENT two-element supports, or at least three singleton supports.
        for c,d in edges[i+1:]:
            U={a,b,c,d}
            if len(U)==4:
                R.add(tuple(sorted(U)))
            elif len(U)==3:
                R.add(tuple(sorted(U)))
                # A fourth center that contributes an eligible word must
                # be an available singleton center or attached by another edge.
                available=set(priv)
                for v in U: available.update(adj[v])
                for v in available-U:R.add(tuple(sorted(U|{v})))
            else:raise AssertionError('duplicate edge support')
        for q in combinations(priv,3):
            U={a,b}|set(q)
            if len(U)<=4:R.add(tuple(sorted(U)))
    return R


def physical_candidates(R,by):
    return [y for sz in range(1,len(R)+1) for s in combinations(R,sz) for y in by.get(s,())]


def clique_cover4(xs):
    # Exhaustive backtracking for a partition of xs into <=4 cliques
    # of the PHYSICAL confusability graph, NOT the former six-label abstraction.
    if len(xs)<=4:return [[x] for x in xs]
    neigh={x:{y for y in xs if x!=y and confusable(x,y)} for x in xs}
    order=sorted(xs,key=lambda x:(len(neigh[x]),x))
    groups=[]
    def rec(k):
        if k==len(order):return [list(g) for g in groups]
        x=order[k]
        for g in groups:
            if all(y in neigh[x] for y in g):
                g.append(x)
                found=rec(k+1)
                if found is not None:return found
                g.pop()
        if len(groups)<4:
            groups.append([x])
            found=rec(k+1)
            if found is not None:return found
            groups.pop()
        return None
    ret=rec(0)
    if ret is not None:
        assert sorted(x for grp in ret for x in grp)==sorted(xs)
        assert all(confusable(a,b) for g in ret for a,b in combinations(g,2))
    return ret


def has_5_independent(xs):
    # Independent mathematical audit of the clique-partition test:
    # exact maximum 5-clique test in the SEPARATION graph on <=8 vertices.
    if len(xs)<5:return False
    n=len(xs);adj=[0]*n
    for i in range(n):
        for j in range(i+1,n):
            if not confusable(xs[i],xs[j]):
                adj[i]|=1<<j;adj[j]|=1<<i
    def dfs(bits,chosen):
        if chosen==5:return True
        if bits.bit_count()+chosen<5:return False
        while bits:
            b=bits&-bits; i=b.bit_length()-1; bits^=b
            if dfs(bits&adj[i],chosen+1):return True
        return False
    return dfs((1<<n)-1,0)


def verify():
    t=perf_counter()
    verify_source_data()
    by,degrees=candidates_by_support()
    R=support_envelopes(by)
    assert len(R)==568119
    hist=Counter();nchecked=0;sha=sha256()
    for r in sorted(R):
        Y=physical_candidates(r,by)
        if len(Y)<5:continue
        nchecked+=1;hist[len(Y)]+=1
        cover=clique_cover4(Y)
        assert cover is not None, ('five-out candidate not clique-coverable',r,Y)
        assert not has_5_independent(Y), ('five-out candidate actually independent',r,Y)
        sha.update((','.join(map(str,r))+'|'+','.join(map(str,sorted(Y)))+'\n').encode())
    assert nchecked==3842 and hist=={5:3594,6:205,7:41,8:2}
    print('PASS: source list and 16,440 outside words; all neighborhood degrees checked')
    print('PASS: exhaustive support envelopes:',len(R),'candidate-rich envelopes:',nchecked)
    print('PASS: all candidate sets partitionable into <=4 physical confusability cliques')
    print('PASS: separate 5-independent brute recursion confirms no missed exchange')
    print('PASS: size counts',dict(sorted(hist.items())))
    print('CERTIFICATE HASH sha256',sha.hexdigest())
    print('ELAPSED %.2f s'%(perf_counter()-t))
    return sha.hexdigest()

if __name__=='__main__':verify()
