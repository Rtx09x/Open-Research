"""Independent Polak--Schrijver original code reconstruction, matching our source I0.
The 382-point circular seed, shift, quantization, conflict removal, and 40
appended base-seven words follow the published construction / July 2026 replay.
"""
from original import I0, confusable, encode
EXTENSION = '''
00521 01005 02533 03565 04052 04365 04624 04660 05046 05225
10534 14246 15435 22524 24615 24651 32046 34035 34043 36525
40040 41246 42530 43514 45641 50531 51456 52400 52563 53050
53142 53320 53412 56340 61505 62425 64154 64340 65105 66025
'''

def verify():
    shift=(40,123,40,123,40)
    seed={encode(tuple(((t*pow(7,j,382)+shift[j])%382)*2//109 for j in range(5))) for t in range(382)}
    assert len(seed)==382
    core={v for v in seed if all(u==v or not confusable(u,v) for u in seed)}
    extension={encode(tuple(map(int,s))) for s in EXTENSION.split()}
    assert len(core)==327 and len(extension)==40 and core.isdisjoint(extension)
    assert tuple(sorted(core|extension))==I0
    print('PASS: 382 mapped circular seed, 327 clean points, 40 appended words reconstruct exact I0')
    return True
if __name__=='__main__':verify()
