"""Independent, standard-library check of physical C7 length-five theta obstruction.
No solver, optimizer, networkx or cached adjacency matrix is trusted.
"""
import json
from pathlib import Path
from original import I0,X,T,confusable,verify_source_data


def verify():
    verify_source_data()
    A,B = set(I0),set(X)
    C=set(map(T,I0))
    U=A|B|C
    assert len(A&B)==32 and len(A|B)==702
    assert len(C)==367 and len(C&B)==365 and len(U)==704
    cert=json.loads((Path(__file__).resolve().parent/'data/triple_pentagon_certificate.json').read_text())
    shared=set(cert['shared'])
    assert len(shared)==32 and shared==A&B
    pentagons=cert['pentagons']
    assert len(pentagons)==2
    assert {p[0] for p in pentagons}==C-(A|B), 'new words are exactly the two extra transformed words'
    assert all(p[1] in A-B and p[3] in A-B and p[2] in B-A and p[4] in B-A for p in pentagons)
    assert all(len(p)==5 and len(set(p))==5 for p in pentagons)
    for p in pentagons:
        assert all(confusable(p[i],p[(i+1)%5]) for i in range(5)), f'not a 5-cycle: {p}'
    edges=cert['matched_edges']
    assert len(edges)==331
    assert all(len(e)==2 and e[0] in A-B and e[1] in B-A for e in edges)
    assert all(confusable(*e) for e in edges)
    pieces=[{x} for x in shared]+[set(edge) for edge in edges]+[set(p) for p in pentagons]
    counted=set()
    for piece in pieces:
        assert counted.isdisjoint(piece),'certificate pieces overlap'
        counted |= piece
    assert counted==U, 'certificate pieces do not cover exact physical union'
    # The restriction on A union B has 335 cross-confusable pairs, using two matching
    # edges per pentagon, plus 32 singletons.
    two_pairs=[tuple(e) for e in edges]
    two_pairs += [(p[1],p[2]) for p in pentagons]
    two_pairs += [(p[3],p[4]) for p in pentagons]
    assert len(two_pairs)==335 and all(confusable(*e) for e in two_pairs)
    flat=[v for e in two_pairs for v in e]
    assert len(set(flat))==670 and set(flat)==(A|B)-shared
    # 32 isolated shared words: exact dual certificate for fractional clique cover 368.
    assert all(not confusable(s,v) for s in shared for v in U-{s})
    # A physical clique has size at most two: check every possible triple.
    # Use exact adjacency intersections rather than trusting an LP solver.
    neighbors={v:{u for u in U-{v} if confusable(u,v)} for v in U}
    assert not any((neighbors[v] & neighbors[w]) for v in U for w in neighbors[v] if v<w), 'a physical confusability triangle invalidates dual'
    # The pentagon + matching + singleton partition gives the all-length
    # Lovasz-theta upper bound 32+331+2*sqrt(5) = 363+2*sqrt(5) < 367.5.
    assert (9/4)**2 > 5
    target_num=3258841
    assert 2*target_num**5 > 735*(10**30), '367.5 must be < (3.258841)^5'
    print('PASS: two-code partition into 335 K2 + 32 K1: theta=367 exactly')
    print('PASS: triple physical union: 32 K1, 331 K2, 2 C5')
    print('PASS: all 704 words covered disjointly; 341 physical edge checks')
    print('PASS: weighted theta ceiling 363+2 sqrt(5) < 367.5 < 3.258841^5')
    print('PASS: exact fractional clique cover value is 368 (primal/dual certificates)')
    return True

if __name__=='__main__':verify()
