"""Exhaustive 5-for-6 exchanges in the *four-code union*, not globally.
The union contains only two outside candidates of degree <=2 and none of degree3,
so any six-out exchange must contain a degree4 or degree5 outside candidate.
"""
from original import I0,X,T,confusable,verify_source_data
from itertools import combinations
from collections import defaultdict,Counter

def verify():
 verify_source_data()
 base=set(I0)
 U=base|set(X)|set(map(T,I0))|set(map(T,X))
 by=defaultdict(list);hist=Counter()
 for y in U-base:
  s=tuple(i for i,x in enumerate(I0) if confusable(y,x))
  hist[len(s)]+=1
  if len(s)<=5:by[s].append(y)
 assert len(U-base)==642
 assert hist=={1:1,2:1,4:56,5:181,6:242,7:110,8:43,9:8}
 eligibleR=set()
 for s in by:
  if len(s)==5:eligibleR.add(s)
  if len(s)==4:
   for j in range(len(I0)):
    if j not in s:eligibleR.add(tuple(sorted(s+(j,))))
 print('unions candidate centers',len(eligibleR),flush=True)
 histCandidates=Counter(); n=0
 for R in sorted(eligibleR):
  words=[y for z in (1,2,3,4,5) for ss in combinations(R,z) for y in by.get(ss,())]
  if len(words)<6:continue
  n+=1;histCandidates[len(words)]+=1
  # pairwise separation DFS
  Q=len(words);nonconf=[0]*Q
  for i in range(Q):
   for j in range(i+1,Q):
    if not confusable(words[i],words[j]):nonconf[i]|=1<<j;nonconf[j]|=1<<i
  def dfs(bits,depth):
   if depth==6:return True
   if depth+bits.bit_count()<6:return False
   while bits:
    b=bits&-bits;i=b.bit_length()-1;bits^=b
    if dfs(bits&nonconf[i],depth+1):return True
   return False
  assert not dfs((1<<Q)-1,0),'six distinct physical independent words found'
 print('PASS: exhaustive absence of 5-for-6 exchanges in U4; candidate-rich R',n,'hist',histCandidates)
 return len(eligibleR),n
if __name__=='__main__': verify()
