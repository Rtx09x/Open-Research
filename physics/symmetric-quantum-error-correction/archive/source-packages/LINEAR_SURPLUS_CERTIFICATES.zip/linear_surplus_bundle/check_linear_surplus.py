#!/usr/bin/env python3
"""Exact finite-field certificates for the m=3t, g=t+1 sharp family.

No optimizer, numerical residual, symbolic package, or external input.
Polynomial q(X) is written in the Newton/binomial basis
q(X)=sum_a u[a]*binom(X,a). The module verifies that the quadratic
forms forced by low-degree real polynomial interpolation have only the
trivial common complex root, for t=4,...,8.
"""
from fractions import Fraction
from itertools import combinations_with_replacement
from math import comb, factorial, gcd, lcm
from functools import reduce
from hashlib import sha256
from pathlib import Path
import json

PRIME = 101


def falling(a, r):
    if r < 0 or a < r:
        return 0
    return factorial(a) // factorial(a-r)


def forms_for(t):
    m, g, D = 3*t, t+1, t-1
    n, nvar = m*g, t
    forms = []
    labels = []
    for e in (0, 1):
        edge_indices = list(range(e, m, 2))
        M = len(edge_indices)
        k = M-D-2
        assert k >= 0
        # R(j) has degree at most 2k; finite differences
        # of j^r R(j) of order M-1 must therefore vanish.
        for r in range(2*D+3-M):
            coef = {(a, b): Fraction(0) for a in range(nvar)
                    for b in range(a, nvar)}
            for j, i in enumerate(edge_indices):
                A2 = comb(m, i)*comb(m, i+1)*falling(n-g*i, g)*falling(g*(i+1), g)
                weight = Fraction((-1)**j * A2 * j**r, comb(M-1, j))
                left = [comb(i, a) if a <= i else 0 for a in range(nvar)]
                right = [comb(i+1, a) if a <= i+1 else 0 for a in range(nvar)]
                for a in range(nvar):
                    for b in range(a, nvar):
                        v = left[a]*right[b]
                        if a != b:
                            v += left[b]*right[a]
                        if v:
                            coef[(a, b)] += weight*v
            den = reduce(lcm, (x.denominator for x in coef.values()), 1)
            ints = {ab: int(c*den) for ab, c in coef.items()}
            common = reduce(gcd, (abs(v) for v in ints.values()), 0)
            assert common
            ints = {ab: v//common for ab, v in ints.items()}
            first = next(v for v in ints.values() if v)
            if first < 0:
                ints = {ab:-v for ab,v in ints.items()}
            assert any(ints.values())
            forms.append(ints)
            labels.append([e, r])
    assert len(forms) == t+2
    return forms, labels


def macaulay(t, forms, degree):
    monomials = list(combinations_with_replacement(range(t), degree))
    multipliers = list(combinations_with_replacement(range(t), degree-2))
    columns = {mono: j for j, mono in enumerate(monomials)}
    for form in forms:
        for m in multipliers:
            row = [0]*len(monomials)
            for (a, b), coeff in form.items():
                if coeff:
                    column = columns[tuple(sorted(m + (a, b)))]
                    row[column] = (row[column]+coeff)%PRIME
            yield row


def rank_mod_prime(rows, ncol, p):
    pivots = {}
    nrow=0
    for row in rows:
        nrow += 1
        for j in sorted(pivots):
            c = row[j]
            if c:
                base=pivots[j]
                for k in range(j, ncol):
                    row[k]=(row[k]-c*base[k])%p
        newpivot=next((k for k,v in enumerate(row) if v),None)
        if newpivot is not None:
            v=pow(row[newpivot],-1,p)
            for k in range(newpivot,ncol):
                row[k]=(row[k]*v)%p
            pivots[newpivot]=row
            if len(pivots)==ncol:
                break
    return len(pivots), nrow, len(pivots)==ncol


def verify_known7():
    # Reduced coefficients q_w=c_w/sqrt(comb(n,w)).
    # alpha=sqrt(3/10), beta=sqrt(1/30), alpha*beta=1/10.
    zero = (0, 0)
    q0=[zero]*8; q1=[zero]*8
    q0[0]=(1,0); q0[5]=(0,1)
    q1[2]=(0,1); q1[7]=(-1,0)
    def inner(x,y):
        return Fraction(3,10)*x[0]*y[0]+Fraction(1,10)*(x[0]*y[1]+x[1]*y[0])+Fraction(1,30)*x[1]*y[1]
    def gram(u,v,a,b):
        return sum((comb(5,l)*inner(u[l+a],v[l+b]) for l in range(6)), Fraction(0))
    for a in range(3):
        for b in range(3):
            assert gram(q0,q0,a,b)==gram(q1,q1,a,b)
            assert gram(q0,q1,a,b)==0
    # Deliberately invalid control: reverse the sign of the last amplitude.
    bad=q1.copy();bad[7]=(1,0)
    assert any(gram(q0,bad,a,b)!=0 for a in range(3) for b in range(3))
    return 'PASS full physical two-erasure KL, with corrupted-sign rejection'


def main():
    log={'prime':PRIME, 'controls':verify_known7(),'checks':[]}
    expected={4:3, 5:4, 6:4, 7:5, 8:5}
    for t, degree in expected.items():
        forms, labels = forms_for(t)
        ncol=comb(t+degree-1, degree)
        numrows=(t+2)*comb(t+degree-3, degree-2)
        rank,visited,full=rank_mod_prime(macaulay(t,forms,degree),ncol,PRIME)
        assert full and rank==ncol, (t,rank,ncol)
        # Confirm nonzero quadratic constraints reject q(X)=1.
        assert any(f[(0,0)] for f in forms)
        coeffs=[[f[(a,b)] for a in range(t) for b in range(a,t)] for f in forms]
        digest=sha256(json.dumps(coeffs,separators=(',',':')).encode()).hexdigest()
        result=dict(t=t,m=3*t,g=t+1,n=3*t*(t+1),vars=t,
                    quadrics=len(forms),degree=degree,rows=numrows,
                    columns=ncol,rank_mod_101=rank,
                    visited_rows=visited,
                    primitive_form_sha256=digest,labels=labels)
        log['checks'].append(result)
        print(f"t={t}: n={result['n']}, {len(forms)} quadrics, "
              f"Macaulay degree {degree}, matrix {numrows}x{ncol}, "
              f"rank over F_101 = {rank}, PASS",flush=True)
    with open(Path(__file__).resolve().parent / 'linear_surplus_exact_results.json','w') as f:
        json.dump(log,f,indent=2)
    print(log['controls'])

if __name__=='__main__':
    main()
