#!/usr/bin/env python3
"""Exact rational checks for all numerical constants in the analytic theorem."""
from fractions import Fraction as F
from math import factorial


def exp_lower(x,n):
    return sum((x**i / factorial(i) for i in range(n+1)),F(0))

def exp_upper(x,n):
    # For 0<=x<n+2, ratios of the omitted exponential terms
    # are bounded by x/(n+2), so a geometric majorant applies.
    return exp_lower(x,n)+(x**(n+1)/factorial(n+1))/(1-x/F(n+2))

# log(5) < 1.61 by e^1.61>5; log(12/5)>0.87 by e^0.87<12/5
assert exp_lower(F(161,100),12)>5
assert exp_upper(F(87,100),12)<F(12,5)
assert F(87,100)>F(161,100)**2/3

# e < 11/4, and e^7.3 > 4400/3 > 16e/(3/100).
assert exp_upper(F(1),12)<F(11,4)
assert exp_lower(F(73,10),60)>F(4400,3)

# For t>=10000 and 0<=s<=t/1000, m+1<=3.0011 t.
y=F(30011,10000)
a_lower=2/y+2/y**2
assert a_lower>F(887,1000),(a_lower,F(887,1000))
# m>=3t, c=(m-1)/2 gives upper on t*a_t.
t=10000
at_upper=F(2,3)+F(4,9*t)+F(2,1)/(F(3)-F(1,t))**2
assert at_upper < F(9,10)

# c/t>=1.49, central amplitude loss <=0.001t.
epsilon=F(3,100)
assert F(9,10)*epsilon**2/(1-(epsilon/F(149,100))**2) < F(1,1000)

# Floor(D/2) ensures delta>=.995 for all t>=10000.
assert F(3,4)/F(995,1000) < F(755,1000)
# Uniform tail exponent decreases for u>=1; it is negative at u=1.
tail=F(755,1000)-F(887,1000)*(1-epsilon)**2+F(74,1000)
assert tail < F(-1,200),tail
# Derivative <=0 for u>=1
assert 2*(F(755,1000)-F(887,1000))+2*F(887,1000)*epsilon <0
# (3.001)t parity grid, q polynomial interpolation: 4*m/t<16.
assert 4*F(3001,1000)<16
print('PASS all exact logarithmic, gamma-curvature and tail exponent constants')
print('tail margin at u=1:',tail, 'approximately',float(tail))
print('a_lower:',a_lower, 'a_upper(t10000):',at_upper)
