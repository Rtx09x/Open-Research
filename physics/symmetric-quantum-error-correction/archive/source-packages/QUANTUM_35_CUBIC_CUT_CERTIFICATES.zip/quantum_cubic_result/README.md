# Unrestricted 35-qubit cubic moment cut: proof and exact certificates

**Main result:** Every fully symmetric complex rank-two 35-qubit code correcting three arbitrary physical-qubit errors obeys the exact rational-coefficient 53-block three-copy inequality derived in `THEOREM_AND_STATUS.md`. The cubic inequality holds for *every* complex rank-two projector, independently of KL. The new 35-qubit cut rejects one saved numerical pseudo-moment point but does **not** prove the n=35 relaxation, or the original code problem, infeasible.

Files:

- `THEOREM_AND_STATUS.md`: precise self-contained theorem/proof/limitations.
- `check_a2_n35_dual.py` and `a2_n35_farkas_dual.json`: standalone standard-library exact residual Farkas certificate of `a2<9/40`.
- `check_cubic_cut.py`: standalone standard-library exact factorial/Racah and rational-interval reconstruction of third-moment inequalities.
- `emit_rational_cut.py` and `n35_rational_cubic_cut.json`: portable exact rational 53-block SDP linear cut; no expensive model rerun required.
- `check_small_spin_controls.py`: optional independent small-spin CG and exact physical seven-qubit KL verification (`numpy`,`sympy`).
- `data/`: three original numerical pseudo-moment records copied byte-for-byte from the supplied `QUANTUM_PROOFS_AND_CERTIFICATES(1).zip`; see recorded SHA256 in the checker output. **They are NOT physical quantum codes or exact feasible points**.

Execute the first three Python scripts with only the Python standard library. Every reported inequality uses exact fractions and integer-square-root interval arithmetic. `emit_rational_cut.py` recomputes and verifies its own output bytes.
