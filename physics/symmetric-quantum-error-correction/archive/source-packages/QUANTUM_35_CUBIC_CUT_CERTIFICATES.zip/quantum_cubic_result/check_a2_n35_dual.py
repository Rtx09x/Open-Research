#!/usr/bin/env python3
"""Exact rational 35-qubit scalar/shadow enumerator upper bound a_2<9/40.
No external dependencies, no LP solver, no floating point.
Racah normalization from the uploaded research packet, Sect. 2A.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial as fact
from pathlib import Path
import json

NQ=35;T=3
@lru_cache(None)
def racah(n,r,k):
    pref=F(fact(n-r)*fact(r)**2,fact(n+r+1))*F(fact(n-k)*fact(k)**2,fact(n+k+1))
    return pref*sum((F((-1)**z*fact(z+1),fact(z-n-r)**2*fact(z-n-k)**2*fact(2*n-z)*fact(n+r+k-z)**2)
            for z in range(max(n+r,n+k),min(2*n,n+r+k)+1)),F(0))

def verify():
    d=json.loads((Path(__file__).parent/'a2_n35_farkas_dual.json').read_text())
    n=d['n'];t=d['t'];N=n+1;den=d['denominator']
    assert (n,t,NQ,T)==(35,3,35,3)
    M=[[(-1)**(n+r+k)*(2*r+1)*racah(n,r,k) for k in range(N)] for r in range(N)]
    H=[[2*M[r][k]-int(r==k) for k in range(N)] for r in range(N)]
    shadow=[[(-1)**k*M[r][k] for k in range(N)] for r in range(N)]
    E=[[F(int(k==0)) for k in range(N)], [F(1)]*N] + H[1:2*t+1]
    b=[F(1),F(N,2)] + [F(0)]*(2*t)
    G=[[F(int(k==r)) for k in range(N)] for r in range(N)] + H[2*t+1:] + shadow
    lam=[F(x,den) for x in d['equality_multipliers_numerators']]
    yy={i:F(num,den) for i,num in d['inequality_multipliers_sparse_numerators']}
    assert len(lam)==len(E) and all(y>=0 for y in yy.values()) and max(yy)<len(G)
    # e_2=E^T lam - G^T y + err; a>=0 and sum(a)=N/2.
    errs=[F(int(j==2)) -sum(lam[k]*E[k][j] for k in range(len(E)))
          +sum(yy[k]*G[k][j] for k in yy) for j in range(N)]
    eps=max(map(abs,errs))
    upper=sum(lam[k]*b[k] for k in range(len(E)))+F(N,2)*eps
    print('Exact Farkas residual max < 1/900000:',eps<F(1,900000))
    print('Rigorous rational bound: a_2 <=',str(upper),'=',float(upper))
    assert eps<F(1,900000)
    assert upper<F(9,40)
    c=F(n*(n+2),4)
    quadratic_factor=F(64,405)*c**3*(4*c-3)
    assert quadratic_factor*F(9,40)<40000**2
    print('Therefore every complex n=35, t=3 physical KL code obeys a2<9/40 and |Tr(Z O)|<40000*a1.')
    print('PASS')
if __name__=='__main__':verify()
