#!/usr/bin/env python3
"""Exact-rational interval certification of an unrestricted cubic projector inequality.

No NumPy, SymPy, solver, or unverified floating-point mathematical operation.
Input decimal JSON values are interpreted EXACTLY as decimal rationals. They are
pseudo-moment data, never asserted to be exact feasible moments.
"""
from __future__ import annotations
import hashlib, json, math
from fractions import Fraction as Fr
from decimal import Decimal
from pathlib import Path
from functools import lru_cache

ROOT=Path(__file__).resolve().parent
S=24                     # precision of each signed recoupling entry
SCALE=10**S
XSCALE=10**30            # all shipped JSON decimals are exactly integral at this scale

@lru_cache(maxsize=None)
def fac(n:int)->int:
    assert n>=0
    return math.factorial(n)

@lru_cache(maxsize=None)
def sixj_sum_and_delta(a:int,b:int,c:int,d:int,e:int,f:int):
    """Exact signed 6j = signed rational S * sqrt(positive rational Delta).

    Arguments are doubled spins, following the Racah finite factorial formula.
    """
    delta=Fr(1)
    for x,y,z in [(a,b,c),(a,e,f),(d,b,f),(d,e,c)]:
        if (x+y+z)%2 or min(x+y-z,x-y+z,-x+y+z)<0:
            return Fr(0), Fr(0)
        delta *= Fr(fac((x+y-z)//2)*fac((x-y+z)//2)*fac((-x+y+z)//2),fac((x+y+z)//2+1))
    lo=[(a+b+c)//2,(a+e+f)//2,(d+b+f)//2,(d+e+c)//2]
    hi=[(a+b+d+e)//2,(a+c+d+f)//2,(b+c+e+f)//2]
    out=Fr(0)
    for z in range(max(lo),min(hi)+1):
        out += Fr((-1)**z*fac(z+1),
            math.prod(fac(z-v) for v in lo)*math.prod(fac(v-z) for v in hi))
    return out,delta

@lru_cache(maxsize=None)
def swap23_integer(n:int,J2:int,L:int,K:int)->int:
    # Published/documented basis convention: (-1)^n sqrt((2L+1)(2K+1)) {j j L; j J K}
    sign_sum, delta = sixj_sum_and_delta(n,n,2*L,n,J2,2*K)
    if sign_sum==0:return 0
    mag2 = sign_sum**2*delta*(2*L+1)*(2*K+1)
    val = math.isqrt((mag2.numerator*SCALE*SCALE)//mag2.denominator)
    # Difference |integer/SCALE - exact F| < 1/SCALE.
    return val*((-1 if sign_sum<0 else 1)*(-1 if n%2 else 1))

def decimal_fixed(d:Decimal)->int:
    z=d*XSCALE
    assert z==z.to_integral_value(), (d,z)
    return int(z)

def ffmt(z:Fr,precision=12)->str:
    neg='-' if z<0 else ''
    x=abs(z);scale=10**precision
    scaled=(x.numerator*scale)//x.denominator
    return neg+str(scaled//scale)+'.'+str(scaled%scale).zfill(precision)

def check(path:Path, expected_violation:bool):
    raw=path.read_bytes(); data=json.loads(raw,parse_float=Decimal)
    n=int(data['n']);N=n+1;c=Fr(n*(n+2),4)
    assert data['normalization']=='X_J=(2J+1)Z_J; sum TrX=8'
    a1=Fr(data['a'][1]);a2=Fr(data['a'][2])
    assert a1>0 and a2>0
    rhs=Fr(64,405)*c**3*(4*c-3)*a1*a1*a2
    total=0;mass=Fr(0)
    for block in data['blocks']:
        J2=block['J2'];Ls=block['Ls'];X=block['X'];d=len(Ls)
        assert len(X)==d and all(len(row)==d for row in X)
        assert all(abs(X[i][j]-X[j][i])<Decimal('1e-14') for i in range(d) for j in range(i))
        F=[[swap23_integer(n,J2,L,K) for K in Ls] for L in Ls]
        xnums=[2*L*(L+1)-n*(n+2) for L in Ls]
        signs=[(-1)**(n-L) for L in Ls]
        for i in range(d):
            for j in range(d):
                dec=X[i][j];mass+=abs(Fr(dec))
                if not dec:continue
                # X13_ij=sum_k F_ik x_k F_jk; x_k=xnums[k]/4
                xx=sum(F[i][k]*xnums[k]*F[j][k] for k in range(d))
                # O_ij=[(x_i+x_j)/2-c/3*sign_i*sign_j] X13_ij
                # coefficient denominator 24
                coef=3*(xnums[i]+xnums[j])-2*n*(n+2)*signs[i]*signs[j]
                total+=decimal_fixed(dec)*coef*xx
    z=Fr(total,96*XSCALE*SCALE*SCALE)
    eps=Fr(1,SCALE)
    err=mass*Fr(4,3)*c*(n+1)*c*eps*(2+eps)
    lo=max(Fr(0),abs(z)-err);hi=abs(z)+err
    violates=lo*lo>rhs
    print('\n',path.name,'SHA256',hashlib.sha256(raw).hexdigest())
    print('n=',n,'sum of abs X entries=',ffmt(mass,8))
    print('|Tr Z O| interval = [',ffmt(lo),',',ffmt(hi),']')
    print('squared rhs =',ffmt(rhs,12))
    print('signed exact rational margin lower =',ffmt(lo*lo-rhs,12))
    print('outside necessary inequality:',violates)
    assert violates==expected_violation
    return (n,violates,lo,hi,rhs)

if __name__=='__main__':
    check(ROOT/'data/n35_logical_pseudo.json',True)
    check(ROOT/'data/n35_baseline_pseudo.json',False)
    check(ROOT/'data/n36_baseline_pseudo.json',True)
    print('\nPASS: every displayed interval is derived from integer factorials, exact decimal rationals, and isqrt bounds.')
