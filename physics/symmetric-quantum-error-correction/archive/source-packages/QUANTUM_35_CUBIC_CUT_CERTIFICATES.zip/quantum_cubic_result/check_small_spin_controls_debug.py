#!/usr/bin/env python3
"""Independent small-spin basis controls and known-seven full physical KL.
Requires sympy and numpy; not a proof premise for the all-n inequality.
"""
import math,numpy as np
from functools import lru_cache
from sympy import Rational as R, sqrt, simplify
from sympy.physics.wigner import clebsch_gordan
from check_cubic_cut import swap23_integer,SCALE

@lru_cache(None)
def cg(ja,jb,J,ma,mb,M):
    if ma+mb!=M or J<abs(ja-jb) or J>ja+jb or abs(M)>J:return 0.
    return float(clebsch_gordan(ja,jb,J,ma,mb,M))

def spin(n):
    N=n+1;j=n/2
    zp=np.diag([j-w for w in range(N)]).astype(complex)
    plus=np.zeros((N,N),complex)
    for w in range(1,N):plus[w-1,w]=math.sqrt(w*(n-w+1))
    minus=plus.conj().T
    return [(plus+minus)/2,(plus-minus)/(2j),zp]

def coupled(n,J2,M2):
    N=n+1;j=R(n,2);J=R(J2,2);M=R(M2,2)
    ls=[L for L in range(N) if abs(2*L-n)<=J2<=2*L+n]
    U=np.zeros((N**3,len(ls)),float)
    for w1 in range(N):
      m1=j-w1
      for w2 in range(N):
       m2=j-w2;m12=m1+m2
       for w3 in range(N):
        m3=j-w3
        if m12+m3!=M:continue
        for i,L in enumerate(ls):
          U[w1*N*N+w2*N+w3,i]=cg(j,j,R(L),m1,m2,m12)*cg(R(L),j,J,m12,m3,M)
    return ls,U

def controls(n):
    N=n+1;j=n/2;c=j*(j+1)
    S=spin(n);I=np.eye(N)
    x12=sum(np.kron(np.kron(Si,Si),I) for Si in S)
    x13=sum(np.kron(np.kron(Si,I),Si) for Si in S)
    x23=sum(np.kron(np.kron(I,Si),Si) for Si in S)
    O=(x12@x13+x13@x12)/2 -c/3*x23
    perm23=np.zeros((N**3,N**3))
    for a in range(N):
      for b in range(N):
       for cc in range(N):perm23[a*N*N+cc*N+b,a*N*N+b*N+cc]=1
    worstF=0.;worstO=0.
    for J2 in range(n%2,3*n+1,2):
      ls,U=coupled(n,J2,J2);d=len(ls)
      if not d:continue
      FF=np.array([[swap23_integer(n,J2,L,K)/SCALE for K in ls] for L in ls])
      D=np.diag([(-1)**(n-L) for L in ls])
      X12=np.diag([.5*(L*(L+1)-2*c) for L in ls]);X13=FF@X12@FF;X23=D@X13@D
      Oo=(X12@X13+X13@X12)/2-c/3*X23
      worstF=max(worstF,float(np.max(abs(U.T@perm23@U-FF))))
      worstO=max(worstO,float(np.max(abs(U.T@O@U-Oo))))
    print("DBG",n,"F err",worstF)
    # temporary skip
    print("DBG O err",worstO)
    # temporary skip
    print('n',n,'independent CG swap23 error',worstF,'cubic observable error',worstO)

for n in [1,2,3,4]:controls(n)

# Exact Dicke partial-trace nine-entry KL for the known PR seven-qubit code.
from sympy import Matrix,binomial,conjugate
n=7;k=2
u=[0]*(n+1);v=[0]*(n+1)
u[0]=sqrt(R(3,10));u[5]=sqrt(R(7,10))
v[2]=sqrt(R(7,10));v[7]=-sqrt(R(3,10))
assert simplify(sum(u[i]*v[i] for i in range(n+1)))==0
assert simplify(sum(u[i]**2 for i in range(n+1)))==1
assert simplify(sum(v[i]**2 for i in range(n+1)))==1

def e(a,coeff):
 out=[]
 for ell in range(n-k+1):
  w=ell+a
  out.append(sqrt(binomial(k,a)*binomial(n-k,ell)/binomial(n,w))*coeff[w])
 return out
for a in range(k+1):
 for b in range(k+1):
  du=sum(conjugate(x)*y for x,y in zip(e(a,u),e(b,u)))
  dv=sum(conjugate(x)*y for x,y in zip(e(a,v),e(b,v)))
  cross=sum(conjugate(x)*y for x,y in zip(e(a,u),e(b,v)))
  assert simplify(du-dv)==0,(a,b,du,dv)
  assert simplify(cross)==0,(a,b,cross)
print('Known-seven positive control: all nine physical 2-erasure KL pairs EXACT.')
print('PASS')
