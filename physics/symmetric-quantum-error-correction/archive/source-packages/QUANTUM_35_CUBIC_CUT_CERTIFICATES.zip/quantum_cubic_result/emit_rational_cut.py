#!/usr/bin/env python3
"""Produce an exact rational necessary n=35 cut in the supplied full J,L block convention.

For all actual rank-two correcting-three codes at n=35:
   -40000*a1-1/100000 <= sum_J trace(X_J O_Jhat) <= 40000*a1+1/100000.
O_Jhat is the rational matrix whose entries are integers / 100000000.
"""
from pathlib import Path
import json
from fractions import Fraction as F
from check_cubic_cut import swap23_integer,SCALE

n=35; N=n+1; DEN=10**8
out={'n':n, 't':3, 'block_normalization':'X_J=(2J+1)Z_J; sum Tr(X_J)=8',
 'matrix_entry_denominator':DEN, 'a1_coefficient':40000,
 'rational_error_slack_numerator':1, 'rational_error_slack_denominator':100000,
 'blocks':[]}
for J2 in range(n%2,3*n+1,2):
  Ls=[L for L in range(n+1) if abs(2*L-n)<=J2<=2*L+n];d=len(Ls)
  FF=[[swap23_integer(n,J2,L,K) for K in Ls] for L in Ls]
  xnums=[2*L*(L+1)-n*(n+2) for L in Ls]
  signs=[(-1)**(n-L) for L in Ls]
  upper=[]
  for i in range(d):
    for j in range(i,d):
      xx=sum(FF[i][k]*xnums[k]*FF[j][k] for k in range(d))
      fac=3*(xnums[i]+xnums[j])-2*n*(n+2)*signs[i]*signs[j]
      coef=(fac*xx*DEN)//(96*SCALE*SCALE)
      upper.append([i,j,coef])
  out['blocks'].append({'J2':J2,'Ls':Ls,'upper':upper})

p=Path(__file__).parent/'n35_rational_cubic_cut.json'
p.write_text(json.dumps(out,separators=(',',':')))
print('wrote',p, 'bytes',p.stat().st_size, 'blocks',len(out['blocks']))

# Entirely rational operator error bound, no irrational evaluation.
# |F_ij-Fhat_ij| < 10^-24; ||F-Fhat||op <= N*10^-24.
# With |x_L| <= c and |coefficient| <=4c/3:
# ||O-Ohat||op <= N*[1e-8+(4c/3)*N*c*eps*(2+eps)]
# Since each physical X_J is PSD and sum_J Tr X_J=8, the expectation error
# is bounded by eight times the RHS.
c=F(n*(n+2),4);eps=F(1,SCALE)
err=8*N*(F(1,DEN)+F(4,3)*c*N*c*eps*(2+eps))
assert err<F(1,100000),str(err)
print('uniform actual-code evaluation error <',float(err),' < 1e-5')

# Check input pseudo points as EXACT decimals against emitted rational cut.
from decimal import Decimal
for f in ['n35_logical_pseudo.json','n35_baseline_pseudo.json']:
 a=json.loads((Path(__file__).parent/'data'/f).read_text(),parse_float=Decimal)
 blocks={b['J2']:b for b in a['blocks']}
 val=F(0)
 for b in out['blocks']:
  X=blocks[b['J2']]['X']
  for i,j,num in b['upper']:
   val+= F(num,DEN)*F(X[i][j])*(1 if i==j else 2)
 slack=F(40000)*F(a['a'][1])+F(1,100000)
 print(f,'|rational LHS| approx=',round(float(abs(val)),6), 'RHS approx=',round(float(slack),6),'violation=',round(float(abs(val)-slack),6))
 assert (abs(val)>slack)==('logical' in f)
print('PASS rational cut reproduction')
