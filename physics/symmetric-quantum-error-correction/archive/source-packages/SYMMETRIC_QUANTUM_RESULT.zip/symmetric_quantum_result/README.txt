SYMMETRIC QUANTUM ERROR CORRECTION: VERIFIED PARTIAL RESULT
Date: 26 October 2026

The unrestricted conjecture n_min(t)=3t^2+3t+1 is NOT settled here.

Main new result relative to the supplied packet:
Any sequence of fully symmetric t-error-correcting logical-qubit codes
that has a disjoint-support logical basis on a uniform Dicke grid of
2t+2+o(t) available positions must satisfy

  liminf n/t^2 >= sqrt(16-8B) > 3.1753094928980864,

where B is the explicitly defined one-variable maximum in RESULT.md.
Arbitrary complex phases, arbitrary disjoint logical labels, zero
coefficients, every positive integer grid spacing, and arbitrary offset
and padding are allowed. The collective spin axis may depend on t.

If the grid runs from weight 0 through weight n, the stronger bound is

  liminf n/t^2 >= 4-2c_* > 3.2283372002.

Consequently coefficient 3 in this class requires a linear surplus of
grid positions beyond 2t+2. These are construction-family obstructions,
NOT unrestricted bounds on n_min(t).

Supplementary unrestricted result:
For any K>=2 dimensional symmetric code correcting k erasures, the common
normalized erased marginal satisfies

  G_k >= (K-1)^k/(n)_k times I_(k+1).

RESULT.md contains the unified statements, full mathematical argument,
scope, dependence on the supplied work, and exact verification details.
The proofs/ directory contains the longer component derivations and
independent audits. The checkers/ directory contains reproducible exact
controls and their results. No private repository or SDP solver is needed.

Run all standard-library checks:
  python run_checks.py

Include the supplementary exact loss controls (requires SymPy 1.14.0):
  python run_checks.py --with-loss

The infinite-sequence conclusions are analytic. Finite computations
certify constants and test conventions, positive examples and invalid
controls; they do not extrapolate existence or nonexistence to all t.

Publication priority has not been established. No new code at a shorter
length, unrestricted length exclusion, or all-t construction is claimed.
