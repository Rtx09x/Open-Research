#!/usr/bin/env python3
"""Exact controls for the amplitude-robust phase-family entropy obstruction.

Standard library only. No floating-point value is used in an assertion.
"""
from fractions import Fraction as Q
from math import comb, factorial, isqrt
import json
from pathlib import Path

TERMS = 70

def scale(I, a):
    a=Q(a)
    return (a*I[0],a*I[1]) if a>=0 else (a*I[1],a*I[0])

def add(*Is):
    return (sum((x[0] for x in Is),Q(0)),sum((x[1] for x in Is),Q(0)))

def log_unit(x):
    assert Q(1)<=x<=Q(2)
    z=(x-1)/(x+1)
    z2=z*z
    zz=z
    result=Q(0)
    for j in range(TERMS):
        result+=2*zz/(2*j+1)
        zz*=z2
    tail=2*zz/((2*TERMS+1)*(1-z2))
    return result,result+tail

LOG2=log_unit(Q(2))

def log_interval(x):
    x=Q(x); assert x>0
    k=0
    while x>2:
        x/=2;k+=1
    while x<1:
        x*=2;k-=1
    return add(log_unit(x),scale(LOG2,k))

def G(c,v):
    assert 0<c<v<1
    return add(scale(log_interval(v+c),(v+c)/2),
               scale(log_interval(v-c),-(v-c)/2),
               scale(log_interval(c),-c),
               scale(log_interval((1+v)/(1-v)),-v),
               scale(log_interval(1-v*v),-c/2))

def Gv(c,v):
    return add(scale(log_interval((v+c)/(v-c)),Q(1,2)),
               scale(log_interval((1+v)/(1-v)),-1),
               (-(2-c)*v/(1-v*v),)*2)

def outer(I, digits=30):
    scale_=10**digits
    lo=(I[0]*scale_).numerator//(I[0]*scale_).denominator
    hi=-((-I[1]*scale_).numerator//(-I[1]*scale_).denominator)
    return [str(Q(lo,scale_)),str(Q(hi,scale_))]

cL=Q('0.3858313997')
cU=Q('0.3858313999')
vL=Q('0.413366112770314304890887824416')
vU=Q('0.413366112940249009747232835687')
low=G(cL,vL)
upper_point=G(cU,vU)
derivative=Gv(cU,vU)
tan_left=add(upper_point,scale(derivative,cU-vU))
tan_right=add(upper_point,scale(derivative,1-vU))
assert low[0]>0
assert tan_left[1]<0 and tan_right[1]<0
assert 4-2*cU>Q('3.22')

# The elementary factorial bound used in the interpolation proof, tested on
# a finite range as an arithmetic control; the proof is analytic.
for r in range(1,50):
    # e<3 yields r! >= (r/3)^r as a weaker exact rational control.
    assert factorial(r)*3**r >= r**r


def test_amplitude(m,t,qfunc,epsilon=Q(1,4)):
    ell=m-2*t-1
    s=Q(m-1,2)
    qs=[Q(qfunc(Q(i))) for i in range(m+1)]
    assert min(qs)>=0 and max(qs)>0
    # Degree <=ell in a literal finite-difference reconstruction.
    difference=qs[:]
    for _ in range(ell+1):
        difference=[b-a for a,b in zip(difference,difference[1:])]
    assert all(x==0 for x in difference)
    ps=[Q(comb(m,i))*qs[i] for i in range(m+1)]
    for degree in range(2*t+1):
        assert sum(((-1)**i*ps[i]*i**degree for i in range(m+1)),Q(0))==0
    h=[qs[i]*qs[i+1] for i in range(m)]
    controls=[]
    for e in [0,1]:
        nodes=[i for i in range(e,m,2) if abs(Q(i)-s)<=epsilon*s]
        assert len(nodes)>2*ell
        i0=max(nodes,key=lambda i:h[i]);assert h[i0]>0
        bound=(24/epsilon)**(2*ell)
        for i in range(m):assert h[i]<=h[i0]*bound
        controls.append({'parity':e,'central_nodes':len(nodes),'selected_i':i0,
                         'has_zero_h':any(x==0 for x in h)})
    # Deliberate invalid control: corrupt a single squared amplitude. It no
    # longer satisfies even the zeroth diagonal KL equation.
    bad=ps[:];bad[0]+=1
    assert sum(((-1)**i*bad[i] for i in range(m+1)),Q(0))!=0
    return {'m':m,'t':t,'ell':ell,'parities':controls}

amp_tests=[
    test_amplitude(201,98,lambda i:(i-100)**2+Q(1,10**100)),
    test_amplitude(200,98,lambda i:(2*i-199)**2+1),
    test_amplitude(201,98,lambda i:(i-100)**2),
    test_amplitude(205,100,lambda i:(i-99)**2*(i-100)**2),
]


def binom(n,k):return comb(n,k) if 0<=k<=n else 0

def falling(n,k):
    if k<0:return Q(0)
    if k>n:return 0
    return factorial(n)//factorial(n-k)


def physical_positive_control():
    # Explicit phase-gnu t=11 control. Algebraic edge values are stored as
    # (real coefficient, real radicand, imaginary coefficient, imaginary
    # radicand); path integration supplies actual unit codeword phases.
    t=11;g=2*t;m=2*t+1;n=m*g;k=2*t
    p=[Q(comb(m,i),2**(m-1)) for i in range(m+1)]
    assert sum(p[::2])==sum(p[1::2])==1
    A=[p[i]*p[i+1]*falling(n-g*i,g)*falling(g*i+g,g) for i in range(m)]
    assert all(A[i]==A[2*t-i] for i in range(m))
    B=A[t-2]-A[t]/4
    assert B>0
    zero=Q(0);one=Q(1)
    z={t:(one,A[t],zero,one),
       t-2:(Q(-1,2),A[t],one,B),
       t+2:(Q(-1,2),A[t],-one,B)}
    for i in range(t):
        if i==t-2:continue
        z[i]=(one,A[i],zero,one)
        z[2*t-i]=(-one,A[i],zero,one)
    assert len(z)==m
    for i,(a,R,b,S) in z.items():assert a*a*R+b*b*S==A[i]
    def radical_sums(z_,e):
        re={};im={}
        for i in range(e,m,2):
            a,R,b,S=z_[i]
            re[R]=re.get(R,Q(0))+a
            im[S]=im.get(S,Q(0))+b
        return {r:a for r,a in re.items() if a},{r:a for r,a in im.items() if a}
    for e in [0,1]:assert radical_sums(z,e)==({},{})
    # Verify each of the k+1 physical diagonal entries by literal binomials.
    for a in range(k+1):
        vals=[p[i]*comb(k,a)*Q(binom(n-k,g*i-a),comb(n,g*i)) for i in range(m+1)]
        assert sum(vals[::2])==sum(vals[1::2])
    # Full support-difference audit: only cross edges with shift +/-g can
    # survive, and their Kraus row indices must be (0,k) or (k,0).
    edge_pairs=[]
    for i in range(m+1):
        for j in range(m+1):
            if i==j:continue
            if abs(g*i-g*j)<=k:
                assert abs(i-j)==1 and i%2!=j%2
                assert abs(g*i-g*j)==k
                edge_pairs.append((i,j))
    assert len(edge_pairs)==2*m
    for i in range(m):
        w=g*i
        physical_square=p[i]*p[i+1]*Q(comb(n-k,w)**2,comb(n,w)*comb(n,w+g))
        assert physical_square*falling(n,k)**2==A[i]
    # Wrong edge phase: reverse edge zero, giving a nonzero sum -2sqrt(A0).
    bad=z.copy();a,R,b,S=bad[0];bad[0]=(-a,R,-b,S)
    bad_re,bad_im=radical_sums(bad,0)
    assert bad_re=={A[0]:Q(-2)} and bad_im=={}
    return {'t':t,'n':n,'k_erased':k,'all_diagonal_entries':k+1,
            'surviving_directed_support_pairs':len(edge_pairs),
            'both_cross_sums_exact_zero':True,
            'wrong_edge_phase_exact_nonzero':True}

positive=physical_positive_control()

def padded_physical_controls():
    cases=[(3,4,7,3,5),(4,5,9,0,5),(2,3,5,2,4)]
    checked=0
    for t,g,m,b,r in cases:
        n=b+g*m+r;k=2*t;D=k-g
        for i in range(m):
            w=b+g*i
            for a in range(D+1):
                lhs=Q(binom(n-k,w-a)**2,comb(n,w)*comb(n,w+g))
                rhs=Q(falling(n-w,g)*falling(w+g,g)
                      *(falling(w,a)*falling(n-w-g,D-a))**2,
                      falling(n,k)**2)
                assert lhs==rhs
                checked+=1
    # Separate shifted/padded gnu positive control, with separation g>2t.
    t=1;g=3;m=3;b=2;r=3;n=b+g*m+r;k=2*t
    ps=[Q(comb(m,i),2**(m-1)) for i in range(m+1)]
    assert sum(ps[::2])==sum(ps[1::2])==1
    for a in range(k+1):
        vals=[ps[i]*comb(k,a)*Q(binom(n-k,b+g*i-a),comb(n,b+g*i))
              for i in range(m+1)]
        assert sum(vals[::2])==sum(vals[1::2])
    assert g>k  # All off-diagonal physical Gram entries vanish by support.
    return {'padded_factorial_identities':checked,
            'shifted_padded_positive_control':{'t':t,'n':n,'b':b,'r':r},
            'status':'PASS'}

padded=padded_physical_controls()
result={
 'claim':'amplitude-robust uniform-grid asymptotic obstruction; no unrestricted lower bound',
 'log_series_terms':TERMS,
 'c_star_open_interval':[str(cL),str(cU)],
 'coefficient_open_interval':[str(4-2*cU),str(4-2*cL)],
 'lower_test':{'c':str(cL),'v':str(vL),'G_interval':outer(low)},
 'upper_test':{'c':str(cU),'v':str(vU),'G_interval':outer(upper_point),
               'Gv_interval':outer(derivative),
               'tangent_at_c_interval':outer(tan_left),
               'tangent_at_1_interval':outer(tan_right)},
 'amplitude_controls':amp_tests,
 'physical_positive_control':positive,
 'padded_physical_controls':padded,
 'status':'PASS'
}
out=Path(__file__).with_name('amplitude_entropy_certificate.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
