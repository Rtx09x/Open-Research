"""Exact stdlib controls for the arbitrary-disjoint-label extension.
Finite controls accompany, but do not replace, the uniform written proof.
"""
from fractions import Fraction as Q
from math import comb, factorial
from pathlib import Path
import json

def sign(x):return 1 if x>0 else -1 if x<0 else 0

def edge_set(q,lo,hi):
 return [i for i in range(lo,hi+1) if q(i)*q(i+1)>0 and (-1)**i*sign(q(i))==1]

def check_irregular(q,ell,t=200):
 m=2*t+1+ell
 low=-4*m;high=5*m
 S=edge_set(q,low,high);Sset=set(S)
 # Verify the discrepancy on every interval in an independently generated range.
 aa=-50;bb=m+50
 prefix=[0]
 for i in range(aa,bb+1):prefix.append(prefix[-1]+(i in Sset))
 for a in range(aa,bb+1):
  for b in range(a,bb+1):
   count=prefix[b-aa+1]-prefix[a-aa]
   assert abs(2*count-(b-a+1))<=3*ell+1
 center=m//2
 J=[i for i in S if abs(i-center)<=20]
 i0=max(J,key=lambda i:q(i)*q(i+1))
 rs=[i-i0 for i in S if i>i0]
 ss=[i0-i for i in reversed(S) if i<i0]
 d=t//4;E=4*ell+4
 assert d>E
 assert all(abs(r-2*j)<=3*ell+1 for j,r in enumerate(rs,1))
 assert all(abs(r-2*j)<=3*ell+1 for j,r in enumerate(ss,1))
 first=Q((10*t)**(2*E),factorial(E)**2)
 checks=0
 for xseq,yseq in [(rs,ss),(ss,rs)]:
  for l,x in enumerate(xseq,1):
   if l<=d or x>=m:continue
   # Only keep outputs that really belong to the physical grid.
   i=i0+x if xseq is rs else i0-x
   if not 0<=i<m:continue
   p=Q(1)
   for j in range(d):p*=Q((x-xseq[j])*(x+yseq[j]),xseq[j]*yseq[j])
   L=l+2*E;dd=d-E
   bound=first*comb(L+dd,dd)*comb(L-1,dd)
   assert p>=0 and p<=bound
   checks+=1
 assert checks>0
 return {'t':t,'m':m,'degree_bound':ell,'selected_center':i0,'tail_checks':checks,
         'all_interval_discrepancy_checked':True}

controls=[]
# These signed polynomials deliberately reverse the logical label pattern
# on long intervals and include holes and noninteger roots.
controls.append(check_irregular(lambda i:(i-150)*(i-250),2))
controls.append(check_irregular(lambda i:(2*i-301)*(2*i-499),2))
controls.append(check_irregular(lambda i:(i-100)*(i-210)*(i-300),3))
controls.append(check_irregular(lambda i:(i-180)**2*(i-225),3))

# Positive full physical KL control with non-prescribed logical labels.
t=2;k=2*t;g=5;m=7;b=3;n=b+m*g+4
q=lambda i:(i-2)*(i-5)
weights=[comb(m,i)*abs(q(i)) for i in range(m+1)]
labels=[(-1)**i*sign(q(i)) for i in range(m+1)]
Zp=sum(w for w,l in zip(weights,labels) if l==1)
Zm=sum(w for w,l in zip(weights,labels) if l==-1)
assert Zp==Zm and Zp>0
p=[Q(w,Zp) for w in weights]
for degree in range(k+1):
 assert sum(labels[i]*p[i]*(b+g*i)**degree for i in range(m+1))==0
for a in range(k+1):
 value=[]
 for i in range(m+1):
  w=b+g*i
  choose=comb(n-k,w-a) if 0<=w-a<=n-k else 0
  value.append(p[i]*comb(k,a)*Q(choose,comb(n,w)))
 assert sum(v for v,l in zip(value,labels) if l==1)==sum(v for v,l in zip(value,labels) if l==-1)
# Every nonzero off-diagonal Kraus matrix element would shift support by <=k;
# positive spacingg>k rules them out for either logical direction.
assert all(abs(g*i-g*j)>k for i in range(m+1) for j in range(m+1) if i!=j and weights[i] and weights[j])
# Corrupt one nonzero logical sign: even the zeroth scalar condition fails.
bad=labels[:];j=next(i for i,w in enumerate(weights) if w);bad[j]*=-1
assert sum(bad[i]*p[i] for i in range(m+1))!=0
out={'PASS':True,'irregular_root_controls':controls,
 'physical_positive_control':{'t':t,'n':n,'g':g,'offset':b,'padding':4,'q':'(i-2)(i-5)',
                              'full_physical_KL':True,'wrong_label_rejected':True},
 'scope':'Arbitrary disjoint logical labels on a uniform grid; not unrestricted codes.'}
Path(__file__).with_name('disjoint_label_controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
