"""Independent stdlib exact interval audit of the phase theorem's threshold.
No numeric residual is accepted as a proof. Uses rational atanh-series tails.
"""
from fractions import Fraction as Q
from math import comb, factorial
import json
from pathlib import Path

def add(a,b):return (a[0]+b[0],a[1]+b[1])
def mul(a,b):
    s=[x*y for x in a for y in b]
    return min(s),max(s)
def scale(a,r):return mul(a,(r,r))
def neg(a):return (-a[1],-a[0])
def sub(a,b):return add(a,neg(b))
def logr(x,terms=36):
    assert x>0
    e=0
    while x<1:x*=2;e-=1
    while x>=2:x/=2;e+=1
    def unit(a):
        z=(a-1)/(a+1)
        s=sum((2*z**(2*j+1)/Q(2*j+1) for j in range(terms)),Q(0))
        tail=2*z**(2*terms+1)/(Q(2*terms+1)*(1-z*z))
        return s,s+tail
    return add(unit(x),scale(unit(Q(2)),Q(e)))
def G(c,v):
    a=scale(logr(v+c),v+c)
    a=sub(a,scale(logr(v-c),v-c))
    a=sub(a,scale(logr(c),2*c))
    a=scale(a,Q(1,2))
    a=sub(a,scale(logr((1+v)/(1-v)),v))
    return sub(a,scale(logr(1-v*v),c/2))
def Gv(c,v):
    a=scale(logr((v+c)/(v-c)),Q(1,2))
    a=sub(a,logr((1+v)/(1-v)))
    b=(2-c)*v/(1-v*v)
    return sub(a,(b,b))

# Rational candidate evaluation; sign enclosures below prove all claims.
cL=Q(3858313997,10**10);cU=Q(3858313999,10**10)
vL=Q(413366112770314304890887824416,10**30)
vU=Q(413366112940249009747232835687,10**30)
GL=G(cL,vL);GU=G(cU,vU);du=Gv(cU,vU)
# Concavity: tangent is an upper bound on the entire v in [cU,1].
max_slope=max(a*b for a in du for b in (cU-vU,1-vU))
MU=GU[1]+max_slope
assert GL[0]>Q(79,10**12)
assert MU<-Q(93,10**12)
assert Q(322,100)<4-2*cU
# Independent exact finite-difference amplitude checks, including nodal holes
# and a negative interval between consecutive integer roots.
for t in (1,2,4,8):
    for ell in (0,1,2,3,4):
        m=2*t+1+ell
        polynomials=[lambda i:Q(1)]
        if ell>=1:polynomials.append(lambda i:Q(i+1))
        if ell>=2:
            a=m//2
            polynomials.extend([lambda i,a=a:Q((i-a)**2),lambda i,a=a:Q((i-a)*(i-a-1))])
        for q in polynomials:
            assert all(q(i)>=0 for i in range(m+1))
            for r in range(2*t+1):
                assert sum((-1)**i*comb(m,i)*q(i)*i**r for i in range(m+1))==0
# Deliberately invalid amplitude sequence fails the diagonal conditions.
t=3;m=7
bad=[Q(comb(m,i)) for i in range(m+1)];bad[0]+=1
assert sum((-1)**i*bad[i] for i in range(m+1))!=0
# Root-annihilator exact value at integer nodes, both directions.
for d in range(1,8):
    for l in range(-12,13):
        p=Q(1)
        for r in range(1,d+1):p*=1-Q(l*l,r*r)
        expected=1 if l==0 else 0 if abs(l)<=d else comb(abs(l)+d,d)*comb(abs(l)-1,d)
        assert abs(p)==expected
out={
 'PASS':True,
 'threshold_interval':[str(cL),str(cU)],
 'positive_test_margin_lower':'79/10^12',
 'negative_global_tangent_margin_upper':'-93/10^12',
 'log_terms':36,
 'all_checks':'Exact rational arithmetic; threshold, nodal-hole amplitudes, invalid amplitude control, root-annihilator values',
 'scope':'Independent audit of phase-family theorem only; no unrestricted n_min claim.'}
Path(__file__).with_name('entropy_independent_result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
