"""Independent exact certificate for the padded-grid Gaussian obstruction.
Only Python standard library. No float is used by an asserted comparison.
"""
from fractions import Fraction as Q
import json
from pathlib import Path


def ln_interval(x, terms=80):
    x=Q(x)
    assert x>0
    exponent=0
    while x>=2:
        x/=2
        exponent+=1
    while x<1:
        x*=2
        exponent-=1
    def unit(y):
        v=(y-1)/(y+1)
        power=v
        partial=Q(0)
        for j in range(terms):
            partial+=2*power/(2*j+1)
            power*=v*v
        remainder=2*power/((2*terms+1)*(1-v*v))
        return partial,partial+remainder
    a,b=unit(x)
    p,q=unit(Q(2))
    if exponent>=0:
        return a+exponent*p,b+exponent*q
    return a+exponent*q,b+exponent*p


def times(a,I):
    return (a*I[0],a*I[1]) if a>=0 else (a*I[1],a*I[0])


def plus(A,B):return A[0]+B[0],A[1]+B[1]

def minus(A,B):return A[0]-B[1],A[1]-B[0]

def text_interval(I):
    # Fixed outward rational enclosure, solely for readable saved output.
    den=10**45
    lo=(I[0]*den).__floor__()
    hi=(I[1]*den).__ceil__()
    return [str(Q(lo,den)),str(Q(hi,den))]

z=Q('1.0842778882313335')
BL=Q('0.7396762030389118')
BU=Q('0.7396762030389120')
f=times(Q(1,2),minus(times(z+1,ln_interval(z+1)),times(z-1,ln_interval(z-1))))
fp=times(Q(1,2),ln_interval((z+1)/(z-1)))
assert f[0]/(z*z)>BL
h=minus(f,(BU*z*z,BU*z*z))
hp=minus(fp,(2*BU*z,2*BU*z))
abs_hp=max(abs(hp[0]),abs(hp[1]))
# For H(u)=f(u)-BU*u², H'' <= -2*BU. Its global upper bound
# is H(z)+H'(z)²/(4*BU), valid on (1,infinity) and by continuity at1.
global_upper=h[1]+abs_hp**2/(4*BU)
assert global_upper<0
CL=Q('3.1753094928980864')
CU=Q('3.1753094928980869')
assert CL*CL<16-8*BU
assert CU*CU>16-8*BL

# Mode bound at the worst m=32 endpoint, with the stronger proof that
# omits the unnecessary -4/(3m) term.
mode_log=ln_interval(Q(12,5))
assert mode_log[0]>Q(14,17)
assert Q(14,17)>Q(16,23)+Q(1,24)

# Exact finite algebra controls for the optimization identity and positivity
# of the derivative numerator on lambda>=1. The uniform proof is written
# separately, not inferred from these controls.
for C in [Q(2),Q(5,2),Q(3),Q(7,2),Q(4)]:
    lam=C/2
    assert (1+2*lam**3/C**2)*(2-lam)==2-C*C/8
for a in range(1,21):
    lam=1+Q(a-1,10)
    assert 1-lam**2*(3-2*lam)==(lam-1)**2*(2*lam+1)

out={'status':'PASS','arithmetic':'Python integers and Fraction only',
     'z_test':str(z),'B_interval':[str(BL),str(BU)],
     'f_interval':text_interval(f),'fprime_interval':text_interval(fp),
     'lower_excess_interval':text_interval((f[0]/(z*z)-BL,f[1]/(z*z)-BL)),
     'strong_concavity_global_upper':text_interval((global_upper,global_upper)),
     'sqrt_16_minus_8B_interval':[str(CL),str(CU)],
     'mode_log_interval':text_interval(mode_log),
     'mode_inequality':'log(12/5) > 14/17 > 1/24+16/23',
     'uniform_derivative_identity':'1-lambda²(3-2lambda)=(lambda-1)²(2lambda+1)'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
