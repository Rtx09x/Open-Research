"""Exact normalization, full-KL and invalid controls for quantitative loss bound.
Requires SymPy. Does not import or modify the supplied proof bundle.
"""
from pathlib import Path
import json
from math import comb
import sympy as S


def simp(M):
    return M.applyfunc(S.simplify)


def loss(n, k, a):
    E = S.zeros(n-k+1, n+1)
    for w in range(n+1):
        ell = w-a
        if 0 <= ell <= n-k:
            E[ell,w] = S.sqrt(S.Rational(comb(k,a)*comb(n-k,ell),comb(n,w)))
    return E


def gram(n, k, C):
    EC = [loss(n,k,a)*C for a in range(k+1)]
    matrices = [[simp(A.conjugate().T*B) for B in EC] for A in EC]
    G = S.Matrix(k+1,k+1,lambda a,b: matrices[a][b][0,0])
    ok = all(simp(matrices[a][b]-G[a,b]*S.eye(C.cols)) == S.zeros(C.cols)
             for a in range(k+1) for b in range(k+1))
    return ok, G, matrices


def check_code(n, k, C):
    assert simp(C.conjugate().T*C) == S.eye(C.cols)
    out = []
    for r in range(1,k+1):
        ok,G,_ = gram(n,r,C)
        assert ok
        assert S.trace(G) == 1
        c = S.Rational((C.cols-1)**r, S.prod(n-i for i in range(r)))
        # These positive controls have diagonal loss Gram matrices; this is
        # tested, not assumed by the theorem or the physical KL check above.
        assert G == S.diag(*G.diagonal())
        mn = min(G.diagonal())
        assert mn >= c
        out.append({'k':r, 'Gram_diagonal':[str(x) for x in G.diagonal()],
                    'lambda_min':str(mn), 'proved_lower_bound':str(c),
                    'full_physical_KL':True})
    return out


def directional(m,v):
    D = S.zeros(m,m+1)
    for w in range(m+1):
        if w < m: D[w,w] = v[0]*S.sqrt(m-w)
        if w > 0: D[w-1,w] = v[1]*S.sqrt(w)
    return D


C7=S.zeros(8,2)
C7[0,0]=S.sqrt(S.Rational(3,10)); C7[5,0]=S.sqrt(S.Rational(7,10))
C7[2,1]=S.sqrt(S.Rational(7,10)); C7[7,1]=-S.sqrt(S.Rational(3,10))
known7=check_code(7,2,C7)

C25=S.zeros(26,2)
for a in range(6): C25[5*a,a%2] = S.sqrt(S.Rational(comb(5,a),16))
gnu25=check_code(25,4,C25)

C10=S.zeros(11,3)
for a in range(3):
    C10[2*a,a]=1/S.sqrt(2)
    C10[10-2*a,a]=1/S.sqrt(2)
rank3=check_code(10,1,C10)

# Complex erased vector p=(x+i*y)*(x-y)/sqrt(3), ||p||_B=1.
v1=(1/S.sqrt(2),S.I/S.sqrt(2)); v2=(1/S.sqrt(2),-1/S.sqrt(2))
q=S.Matrix([1/S.sqrt(3),(S.I-1)/S.sqrt(6),-S.I/S.sqrt(3)])
assert simp(q.conjugate().T*q)[0] == 1
D1=directional(7,v1); D2=directional(6,v2)
R=D2*D1
alpha=2/S.sqrt(3)
Eq=sum((q[a]*loss(7,2,a) for a in range(3)),S.zeros(6,8))
assert simp(Eq-alpha*R/S.sqrt(42)) == S.zeros(6,8)
lam1=simp(C7.conjugate().T*D1.conjugate().T*D1*C7)
lam2=simp(C7.conjugate().T*R.conjugate().T*R*C7)
assert lam1==S.Rational(7,2)*S.eye(2)
assert lam2==S.Rational(21,2)*S.eye(2)
Cpost=simp(D1*C7/S.sqrt(S.Rational(7,2)))
postok,Gpost,_=gram(6,1,Cpost)
assert postok
assert simp(C7.conjugate().T*Eq.conjugate().T*Eq*C7)==S.eye(2)/3
complex_factor={'Bombieri_norm_squared':'1', 'product_unit_factor_Bombieri_norm_squared':'3/4',
                'alpha_squared':'4/3', 'sequential_unscaled_norms':['1','7/2','21/2'],
                'sequential_ratio_bounds':['7/2 >= 1','3 >= 1'],
                'postselected_code_remaining_one_erasure_KL':postok,
                'erased_vector_probability':'1/3',
                'direction_sensitive_proved_bound':str(S.Rational(4,3)/42)}

# Deliberately invalid control: equal diagonal marginals do NOT suffice.
Cats=S.zeros(8,2)
Cats[0,0]=Cats[7,0]=Cats[0,1]=1/S.sqrt(2); Cats[7,1]=-1/S.sqrt(2)
catok,catG,catmat=gram(7,2,Cats)
assert not catok
assert all(catmat[a][b][0,0]==catmat[a][b][1,1] for a in range(3) for b in range(3))
assert catmat[0][0][0,1] == S.Rational(1,2)
assert catG.rank()==2

# K=1 is essential to a positive bound: a coherent state has singular marginal.
Coherent=S.zeros(8,1); Coherent[0,0]=1
oneok,oneG,_=gram(7,2,Coherent)
assert oneok and oneG.rank()==1

out={'status':'PASS', 'arithmetic':'exact SymPy integers, rationals, and radicals',
     'known7_k2':known7,'standard_gnu25_k4':gnu25,'rank3_n10_k1':rank3,
     'complex_factor_and_postselection':complex_factor,
     'invalid_cat_plane':{'equal_diagonal_marginals':True,'logical_cross_entry':'1/2',
                          'full_KL_rejected':True,'diagonal_marginal_rank':2},
     'excluded_K1_coherent_control':{'marginal_rank':1,'strict_positivity_requires_K_ge_2':True}}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
