# A macroscopic amplitude-freedom barrier for uniform-grid symmetric codes

## Status and scope

This is a new derivation relative to the supplied packet. It is a necessary-condition theorem for a specified construction family, not an unrestricted lower bound for symmetric quantum codes and not a resolution of the minimum-length conjecture. The proof uses the packet's exact physical phase-moment bridge, whose short derivation is reproduced below, and an elementary interpolation lemma. No numerical feasibility or rank assumption enters the theorem.

The family allows arbitrary complex phases, arbitrary disjoint assignments of grid nodes to the two logical vectors, every diagonal-KL-compatible amplitude distribution, missing nodes, either parity of the grid size, and no reflection or time-reversal condition. It fixes the uniform grid geometry and the physical length at its last node. It does not cover overlapping logical supports. Collective single-qubit rotations preserve the assertion, so the axis may vary with t.

## Theorem

For each member of an unbounded sequence of positive integers t, let

    g >= 1,  m >= 2t+1,  n=mg,

and let a code have orthonormal vectors

    |0> = sum_(i in I_0) c_i |D_n^(gi)>,
    |1> = sum_(i in I_1) c_i |D_n^(gi)>,
    I_0 intersect I_1 is empty.

Zero coefficients are allowed. Suppose the code corrects arbitrary errors on at most t physical qubits, and

    ell := m-2t-1 = o(t).

Define, for 0<c<v<1,

    F(c,v) = ((v+c)log(v+c)-(v-c)log(v-c)-2c log c)/2,
    G(c,v) = F(c,v)-v log((1+v)/(1-v))-(c/2)log(1-v^2),
    M(c)   = max_(c<v<1) G(c,v).

There is a unique c_* in (0,1) such that M(c_*)=0. Every such sequence obeys

    limsup (2t-g)/t <= c_*,
    liminf n/t^2 >= 4-2c_*.

Exact rational logarithm certificates below give

    0.3858313997 < c_* < 0.3858313999,
    3.2283372002 < 4-2c_* < 3.2283372006.

In particular the limiting coefficient is strictly greater than 3.22 (and 3.2). Thus arbitrary sublinear additional amplitude freedom cannot make this uniform-grid family attain 3t^2+o(t^2). Any sequence in this family with n=3t^2+o(t^2) must instead have liminf ell/t>0. This last assertion concerns sequences within the displayed geometry; it is not an obstruction to the packet's dense octahedral/PR codes or arbitrary complex symmetric subspaces.

## 1. Exact physical necessity and all amplitudes

We first prove the theorem when I_0 and I_1 are respectively the even and odd nodes; Section 7 then removes that restriction with a complete signed-amplitude and irregular-root argument.

Write k=2t. The normalized k-erasure Kraus operators are

    E_a |D_n^w> = sqrt[binom(k,a)binom(n-k,w-a)/binom(n,w)] |D_(n-k)^(w-a)>,

with out-of-range binomial coefficients zero. The scalar-compression conditions on E_a^* E_b are full physical Knill-Laflamme for a symmetric code. Equivalently they detect every operator on k physical sites. No condition is replaced by anticoherence.

Let p_i=|c_i|^2. The diagonal physical conditions imply

    sum_i (-1)^i p_i i^r=0,  0<=r<=2t.

The finite-difference identity and the dimension of the Vandermonde kernel give exactly

    p_i=binom(m,i)q(i),  deg q<=ell,

where q is real, q(i)>=0 for i=0,...,m, and q is not zero. The normalization of q incorporates the common logical norm. Necessity does not assume positivity between the grid nodes.

For the nontrivial case g<=2t put D=2t-g. A fixed physical Kraus index difference g isolates precisely the adjacent support transitions, for every positive g. When 2g<=2t, other shifts impose further conditions; we do not discard the shift-g conditions and do not use the additional conditions. For lower weight w and upper weight w+g, factorial cancellation gives

    binom(n-k,w-a)/sqrt[binom(n,w)binom(n,w+g)]
       = sqrt[(n-w)_g(w+g)_g]/(n)_k
         * (w)_a(n-w-g)_(D-a).

For a=0,...,D, the polynomials (w)_a(n-w-g)_(D-a) span all polynomials of degree at most D: their evaluations at w=0,...,D are triangular with positive diagonal. Thus, separately for each edge-index parity e, physical KL requires

    sum_(i congruent e mod 2) a_i eta_i P(i)=0
                       for every polynomial deg P<=D,                 (1)

where |eta_i|=1 and

    a_i^2 = W_i h(i),
    W_i = binom(m-1,i)^2 product_(a=1)^(g-1)(gi+a)(g(m-1-i)+a),
    h(i) = q(i)q(i+1).

A positive common factor (mg)^2 has been removed from a_i^2. At a zero amplitude, eta_i may be arbitrary. The identity for W follows by cancelling the two adjacent binomial coefficients against the ladder factors. All subsequent arguments use only this necessary consequence of the full physical equations.

## 2. Sublinear amplitude degree is exponentially negligible

Let s=(m-1)/2, which may be integral or half-integral. Then ell=2(s-t)=o(s), and h is a nonzero real polynomial of degree r<=2ell, nonnegative on the edge nodes i=0,...,2s.

Fix 0<epsilon<1/4 and one parity e. In the central parity window

    J={i: i congruent e mod 2, |i-s|<=epsilon s},

choose i_0 where h is largest. For all sufficiently large s, J contains more than 2ell nodes, so h(i_0)>0. This also handles missing support nodes.

We claim the global node bound

    0 <= h(i)/h(i_0) <= (24/epsilon)^(2ell).                         (2)

For r=0 this is immediate. Otherwise let J have M nodes. For sufficiently large s, M-1>=epsilon s/2 and M-1>=r. Select r+1 nodes of J at the equal physical spacing

    Delta=2 floor((M-1)/r) >= epsilon s/(2r).

For any physical edge node x, every numerator factor in its Lagrange basis is at most 2s in absolute value. The j-th denominator is Delta^r j!(r-j)!. Hence

    |h(x)|/h(i_0)
      <= (2s/Delta)^r sum_(j=0)^r 1/[j!(r-j)!]
      = (4s/Delta)^r/r!
      <= (8r/epsilon)^r/r!
      <= (8e/epsilon)^r <= (24/epsilon)^(2ell).

Here r!>=(r/e)^r follows by integrating log x, and e<3. No lower bound for h at the exact center was assumed. Taking square roots, the amplitude modulation costs at most exp[ell log(24/epsilon)]=exp(o(s)) for fixed epsilon.

## 3. Exact factorial-weight estimates

Set S=s+1 and x=i-s. Divide sqrt(W_i) by its analytic central value sqrt(W(s)). The resulting positive function at the nodes has the exact extension A(x)=exp[-Q(x)], where

    Q(z)=sum_(l=0)^infinity -log(1-z^2/(s+1+l)^2)
          +(1/2)sum_(a=1)^(g-1)-log(1-z^2/(s+a/g)^2).

This follows from the gamma product for the central binomial ratio; it holds also for half-integral s. All even Taylor coefficients of Q are nonnegative. Its quadratic coefficient is at most 2/s because g<=2t<=2s. Therefore for |x|<=epsilon s,

    A(x) >= exp[-2 epsilon^2 s/(1-epsilon^2)].                       (3)

For a bound on the whole physical interval put v=x/S and beta=(g-1)/(2S). The generalized central binomial value satisfies

    binom(2s,s) >= 2^(2s)/(2s+1).

Indeed its smooth gamma interpolation is maximal at s by convexity of log Gamma and is at least the largest of the 2s+1 ordinary binomial coefficients. The elementary binomial entropy estimate consequently gives, uniformly including the physical endpoints,

    binom(2s,s+x)/binom(2s,s)
       <= 4(2s+1) exp[-S{2log2-2H((1+v)/2)}].

One way to see the factor 4 is to use |x|/s>=|x|/S and replace s by S, losing at most exp(2log2). Each remaining product radius is smaller than S, so

    A(x) <= 4(2s+1) exp[-S Q_beta(v)],                              (4)
    Q_beta(v)=2log2-2H((1+v)/2)-beta log(1-v^2).

These are finite inequalities, not Stirling approximations. Here H(u)=-u log u-(1-u)log(1-u), with its continuous endpoint values.

## 4. A phase balance test centered where the actual amplitude is large

Set d=floor(D/2), c=2d/S, and use the real polynomial

    P(i)=product_(r=1)^d [1-(i-i_0)^2/(2r)^2].

It has degree 2d<=D, equals 1 at i_0, and vanishes at every other same-parity node within distance 2d. For i=i_0+2l with |l|>d,

    |P(i)|=binom(|l|+d,d)binom(|l|-1,d)
           <= exp[S F(c,u)],  u=|i-i_0|/S,                         (5)

where F(c,u) is the formula in the theorem, defined also for u>=c outside u<1. Equation (5) is the ordinary binomial entropy upper bound, replacing the second binomial by binom(|l|,d). At u=c use the continuous convention 0 log0=0.

Apply (1) and isolate its i_0 term. The triangle inequality, (2)-(5), and the at most 2s+1 tail nodes imply

    1 <= 4(2s+1)^2
       * exp[ell log(24/epsilon)+2epsilon^2 s/(1-epsilon^2)]
       * exp[S B(c,beta,epsilon)],                               (6)

where B is the supremum of

    F(c,|v-y|)-Q_beta(v)

over |y|<=epsilon, |v|<1 and |v-y|>=c. Enlarging the physical ranges to these continuous ranges can only increase the upper bound. If there are no surviving tail nodes then (1) is already impossible.

## 5. The limiting exponent and its unique threshold

To contradict the claimed limsup, it suffices to consider a subsequence with D/t tending to delta>c_*. This forces g<=2t eventually. If delta>1, choose fixed epsilon<min(1/4,delta-1). Every physical edge lies within distance (1+epsilon)s of i_0, while 2d/s tends to delta>1+epsilon, so the annihilating polynomial kills every other edge and (1) is immediately impossible. It remains to treat delta in (0,1]. Since s/t tends to 1,

    c -> delta,  beta -> 1-delta/2.

For delta in (0,1), the uniform limit as epsilon decreases to zero of the exponent supremum in (6) is

    M(delta)=max_(delta<v<1) [F(delta,v)-Q_(1-delta/2)(v)].

This is exactly G in the theorem: elementary simplification gives

    Q_(1-c/2)(v)=v log((1+v)/(1-v))+(c/2)log(1-v^2).

For rigor concerning the endpoints, beta is eventually bounded below, for example by 1/3. The entropy part of Q_beta is nonnegative, so Q_beta(v) tends to +infinity uniformly as |v| tends to 1. Meanwhile F is bounded and uniformly continuous for c in a compact subinterval of (0,1], |v-y| in [c,1+epsilon]. Thus one first removes a fixed endpoint neighborhood, then applies ordinary uniform continuity on the remaining compact set. If delta=1, the precise assertion is lim_(epsilon->0) limsup_(subsequence) B(c,beta,epsilon)=-infinity: surviving tails satisfy |v|>=c-epsilon, which approaches 1 as the limits are taken in that order. Choose epsilon first sufficiently small to force a negative exponent, then take sufficiently large indices of the subsequence. No nonuniform endpoint Stirling limit is used.

For 0<c<1, G is strictly concave in v:

    G_v = (1/2)log((v+c)/(v-c))
            -log((1+v)/(1-v))-(2-c)v/(1-v^2),
    F_vv=-c/(v^2-c^2)<0,
    Q_beta''=2/(1-v^2)+2beta(1+v^2)/(1-v^2)^2>0.

Its derivative goes from +infinity to -infinity. Hence there is a unique interior maximizing v(c), depending smoothly on c. By the envelope theorem (or differentiating the stationary value),

    d/dc [M(c)/c]
       = -(2-c)v(c)^2/[c^2(1-v(c)^2)] < 0.                         (7)

Indeed c G_c-G=v[log((1+v)/(1-v))-(1/2)log((v+c)/(v-c))], and the stationary equation gives (7). Also M(c)/c tends to +infinity as c decreases to zero (evaluate at v=sqrt(c)), and to -infinity as c increases to one (the logarithmic endpoint term diverges uniformly on v>c). There is therefore exactly one zero c_*.

If delta>c_*, M(delta)<0. Choose a fixed sufficiently small epsilon so that B in (6), together with 2epsilon^2/(1-epsilon^2), remains strictly negative for all large indices of the subsequence. The remaining logarithmic terms divided by S vanish because ell=o(s) and log s=o(s). The right side of (6) then tends to zero, a contradiction. Thus every subsequential limit of D/t is at most c_*. The length statement follows from

    n/t^2=(m/t)(g/t)=(2+o(1))(2-D/t).

For the final amplitude-freedom corollary, if a sequence with n/t^2->3 had liminf ell/t=0, select a subsequence with ell/t->0 and apply the theorem; its limiting length coefficient would have to be at least 4-2c_*>3, a contradiction.

This completes the alternating-label case. Section 7 supplies the precise extension to the arbitrary disjoint assignments in the theorem.

## 6. Exact threshold certification and reproducibility

The standard-library checker `../checkers/check_amplitude_entropy.py` uses rational arithmetic for logarithm intervals. For x>0 it first rescales x by a power of two into [1,2], then uses

    log x = 2 sum_(j>=0) z^(2j+1)/(2j+1),  z=(x-1)/(x+1),

with the explicit geometric upper bound on the positive tail. All resulting comparisons are strict rational comparisons.

At c_L=3858313997/10^10, evaluating G at a specified rational v_L gives a positive lower bound. At c_U=3858313999/10^10, strict concavity bounds the maximum by the tangent at a specified rational v_U:

    M(c_U) <= max{G(c_U,v_U)+G_v(c_U,v_U)(c_U-v_U),
                  G(c_U,v_U)+G_v(c_U,v_U)(1-v_U)} < 0.

The tangent derivative is enclosed rather than rounded. Together with (7), these two finite certificates imply the displayed root interval. Approximate decimals play no role in the proof.

The checker also tests the exact polynomial-amplitude parametrization and the central interpolation lemma on even/odd grid sizes, including a deliberately tiny central amplitude and actual zero-amplitude nodes, and rejects a deliberately nonpolynomial modulation. A separate positive physical control verifies the phase construction at t=11, g=22, m=23 against all physical diagonal entries and the two surviving cross-edge sums; a wrong edge phase is rejected. These controls test the formulas and scope, not the infinite-sequence conclusion, which is analytic.

## 7. Removing the prescribed alternating assignment

For an arbitrary disjoint assignment, let epsilon_i=+1 or -1 be the logical label and p_i its squared amplitude, with signed value zero at an unused node. Diagonal physical KL and the same Vandermonde kernel give

    epsilon_i p_i=(-1)^i binom(m,i)q(i), deg q<=ell,

for a nonzero real polynomial q. Hence p_i=binom(m,i)|q(i)| and epsilon_i=(-1)^i sign q(i) at used nodes. The polynomial q may have either sign and may vanish at nodes.

Fix oriented cross edges from logical zero below to logical one above, and extend their index set to all integers by

    S={i in Z:q(i)q(i+1)>0 and (-1)^i sign q(i)=+1}.

Only its physical part is used in Kraus sums; the extension outside the grid defines test-polynomial roots. On any L consecutive integer edge indices,

    |#(S intersect interval)-L/2|<=(3ell+1)/2.                     (8)

At most 2ell edges contain a real root of q and can fail to have constant nonzero sign at their endpoints. The remaining edges have at most ell+1 constant-sign blocks, with S alternating on each. The errors from the blocks and deleted edges are at most (ell+1)/2 and ell respectively. This proves (8), including integer roots and holes. Also S has no consecutive indices, since two consecutively oriented cross edges would give their shared node two different logical labels.

For h(i)=q(i)q(i+1), the central window |i-s|<=epsilon s contains epsilon s+O(ell+1) indices of S and eventually more than 2ell. Select i_0 maximizing h there, so h(i_0)>0. Quantile-selected interpolation nodes from S are separated by at least epsilon s/(2r) for r=deg h, using (8) and minimum spacing two. The Lagrange proof of Section 2 therefore still gives, with a harmless fixed constant,

    |h(i)|/h(i_0)<=(36/epsilon)^(2ell)=exp(o(s)).

No positivity away from S is needed. The fixed physical shift g gives exactly (1) with its sum now over S intersect [0,m-1], where a_i=sqrt(W_i h(i)); (2)-(4) and the full Kraus normalization remain unchanged.

Let r_j and s_j be the ordered positive and negative distances from i_0 to other points of S. Equation (8) gives

    |r_j-2j|, |s_j-2j|<=3ell+1.

Use the degree-2d polynomial

    P(i_0+x)=product_(j=1)^d(1-x/r_j)(1+x/s_j), d=floor(D/2).

It equals one at i_0 and kills the nearest d oriented edges on both sides, including possible roots outside the physical grid. Fix E=4ell+4=o(s); when D/t tends to a positive value, d>E eventually. At a surviving positive edge x=r_l, l>d, split the product at j=E. Because r_j,s_j>=j and all first-E roots and physical distances are O(s), the first E factors are bounded by

    (10S)^(2E)/(E!)^2=exp(o(S)), S=s+1.

This follows from E log(S/E)=o(S), and remains valid when ell is as large as t/log t. For j>E,

    r_l-r_j<=2(l-j+E), r_l+s_j<=2(l+j+E),
    r_j s_j>=4(j-E)^2.

With J=l+2E the remaining product is at most

    binom(J+d-E,d-E)binom(J-1,d-E)
       <=exp[S F(2(d-E)/S,2J/S)].

The negative-tail argument exchanges r and s. The first entropy parameter tends to the original limiting delta; the second differs from |i-i_0|/S by o(1), uniformly over physical tails. All surviving distances are at least delta S-o(S). F is uniformly continuous on the relevant bounded sets, including u=c with 0log0=0. Thus the old parity-root estimate acquires only a uniform o(S) in its logarithm. The central amplitude comparison also contributes only o(S).

The strict negative exponent argument of Section 5 is unchanged. If delta>1, r_d and s_d both exceed all physical distances from the chosen center for sufficiently small fixed epsilon, so every other physical oriented edge is killed. If delta=1, the same iterated epsilon-limit confines survivors to the endpoint region where Q_beta diverges. For 0<delta<1 the threshold remains exactly M(delta)=0. Therefore the coefficient 4-2c_* holds for all disjoint logical assignments as stated.

The independent standard-library checker `../checkers/check_disjoint_labels.py` tests signed q with holes and noninteger roots, the discrepancy inequality, 395 exact irregular-root comparisons, and a full physical t=2,n=42 padded positive example with an intentionally wrong logical-label control. These finite checks corroborate the formulas; this section supplies the uniform proof.

## Relation to supplied work and literature

The packet's `phase_polynomial_equivalence.md` and `amplitude_extended_phase_interface.md` supply the exact adjacent-transition moment formulation; `phase_family_leading_barrier_candidate.md` supplies the central-root phase-balance idea for fixed binomial amplitudes. The earlier `amplitude_extended_degree_gate.md` proved only a leading coefficient at least 3 under sublinear extra amplitudes and assumed odd m. The new part here is the moving-center interpolation argument that makes the entropy obstruction robust against arbitrary nonnegative amplitude polynomials of sublinear degree, with the complete threshold calculation, both grid parities, missing nodes, all integer gaps, and arbitrary disjoint logical assignments. The signed-amplitude extension shows diagonal KL itself forces all but O(ell) local label decisions to alternate. The removal of g>t is justified because the physical shift-g equations remain necessary even when further support transitions are present.

The diagonal polynomial mechanism itself is established in Ouyang, arXiv:1604.07925v4, Lemma 3.2 and Theorem 5.1. The present theorem is not a priority claim for polynomial-amplitude codes, weighted polynomial arguments, or entropy bounds. A literature search does not establish novelty.

### Primary source links checked for this derivation

- Yingkai Ouyang, *Permutation-invariant qudit codes from polynomials*, arXiv:1604.07925v4, Lemma 3.2 and Theorem 5.1: https://arxiv.org/html/1604.07925v4 . These establish the prior polynomial moment mechanism, not the entropy obstruction proved here.
- NIST DLMF 5.8.5: https://dlmf.nist.gov/5.8.E5 . Its gamma-product identity yields the centered exact factorial product used in Section 3.
- NIST DLMF 5.15.1: https://dlmf.nist.gov/5.15.E1 . The positive trigamma series establishes the needed log-Gamma convexity and the central quadratic-coefficient bound.

## Inherited minimal-support corollary

When exactly 2t+2 Dicke rows are nonzero, disjoint logical supports follow from diagonal physical KL and need not be assumed. For an arbitrary isometric encoding frame write its rank-one row Gram matrices as (p_i I+b_i dot sigma)/2. Each coordinate of b_i lies in the one-dimensional Vandermonde kernel, so b_i=c_i v for one fixed nonzero real vector v. A logical unitary aligning v with sigma_z makes every rank-one row Gram diagonal, hence each row belongs to only one logical vector. The signs of the inverse-Vandermonde coefficients alternate. This classification is already supplied in `scientific/phase3/minimal_axis_support_gate.md`, Section 1; it is not a new result of this derivation. Applying the new theorem then excludes leading3 uniformly spaced minimal-axis-support codes without an extra logical-support restriction. For a positive surplus ell, the diagonal Bloch data may be vector-valued polynomials and no such general disjoint-support reduction is asserted.
