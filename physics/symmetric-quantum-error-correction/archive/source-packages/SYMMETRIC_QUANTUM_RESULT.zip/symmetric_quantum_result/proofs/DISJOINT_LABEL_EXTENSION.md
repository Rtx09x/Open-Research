# Removing the prescribed alternating logical split

## Precise extension

The padded uniform-grid obstruction remains valid if the two codewords have
**arbitrary disjoint logical supports** on the grid, instead of being assigned
to its even and odd indices in advance. The theorem still does not cover two
codewords with overlapping Dicke support, arbitrary nonuniform grids, or a
linear surplus of grid nodes.

Assume `m=2t+1+ell`, `ell=o(t)`, grid weights `b+gi` (`0<=i<=m`),
`b>=0`, `g>=1`, and `n>=b+gm`. Suppose two orthonormal codewords with disjoint
supports in this grid correct `t` arbitrary physical-qubit errors. Then the
padded theorem's lower bound is unchanged:

`liminf n/t^2 >= sqrt(16-8 B)`,

where

`B=max_{z>=1} f(z)/z^2`,
`f(z)=((z+1)log(z+1)-(z-1)log(z-1))/2`.

In particular its coefficient is approximately `3.175309492898086864`.

The additional argument below is independent of the Gaussian curvature
calculation. It supplies the exact missing replacement for the parity-lattice
annihilator and for the moving-center amplitude comparison.

## 1. Diagonal KL forces only sublinearly many logical-label defects

At a nonzero grid coefficient let `epsilon_i=+1` if it belongs to logical zero,
and `epsilon_i=-1` if it belongs to logical one, and let `p_i` be its squared
modulus. Put `epsilon_i p_i=0` at an unused node. The diagonal physical KL
conditions give

`sum_i epsilon_i p_i i^a=0`, `0<=a<=2t`.

The finite-difference Vandermonde kernel, with no positivity assumption, gives

`epsilon_i p_i=(-1)^i binom(m,i) q(i)`, `deg q<=ell`,

for a nonzero real polynomial `q`. Thus at every used node

`p_i=binom(m,i)|q(i)|`,
`epsilon_i=(-1)^i sign q(i)`.

An adjacent edge has two nonzero endpoints with opposite logical labels
exactly when `q(i)q(i+1)>0`. For such an edge define its orientation by the
logical label at the lower endpoint. Fix orientation `+`, and extend its edge
set to all integers using the same polynomial:

`E_+={i in Z: q(i)q(i+1)>0 and (-1)^i sign q(i)=+1}`.

This extension outside the physical grid serves only to define polynomial
roots; it adds no code amplitudes or physical assumptions.

For any finite integer interval of `L` consecutive edge indices,

`| #(E_+ intersect interval)-L/2 | <= (3ell+1)/2`.       (1)

Indeed an edge which is not contained in a root-free interval of `q` contains
at least one real root of `q` in its closed unit interval. Each real root
belongs to at most two such integer edges. Hence at most `2ell` edges are bad.
On the remaining edges there are at most `ell+1` consecutive blocks, each with
constant sign of `q`, and `E_+` alternates on each block. Each block contributes
at most `1/2` to the discrepancy from half its length. The missing edges
contribute at most `ell`. This proves (1). Multiple roots and integer roots
are included, and a polynomial nonnegative at nodes is not assumed.

The identical statement holds for orientation `-`.

## 2. Moving-center polynomial comparison still holds

Let `h(i)=q(i)q(i+1)`, of degree at most `2ell`. Let the baseline edge-amplitude
mode from the padded proof be `mu`, and fix a small positive `epsilon`. In the
integer window `|i-mu|<=epsilon t`, (1) supplies

`# E_+ = epsilon t+O(ell+1)`.

For all sufficiently large indices this exceeds `2ell`. Choose `i0` among
these orientation-`+` edges where `h` is largest. Then `h(i0)>0`.

The needed Lagrange comparison does not require equally spaced interpolation
nodes. Let `r=deg h`, and choose `r+1` nodes by taking approximately equal
quantiles of the ordered `E_+` nodes in this window. Since all nodes are
distinct integers, consecutive selected nodes have physical separation at
least a constant times `epsilon t/r`. Therefore the denominator of their
`j`th Lagrange polynomial is at least

`Delta^r j!(r-j)!`, with `Delta>=c epsilon t/r`,

while every numerator factor is at most `m=O(t)`. Summing the Lagrange bounds
and using `r!>=(r/e)^r` gives, with an absolute constant `C`,

`|h(i)|/h(i0) <= (C/epsilon)^(2ell)`                 (2)

at every physical grid edge. This is `exp(o(t))` for fixed `epsilon`.

All selected interpolation values are positive and at most `h(i0)`. The
polynomial `h` may be negative on bad edges; the absolute-value estimate (2)
remains valid there and no positivity between nodes is used.

## 3. A phase-annihilator on the actual irregular oriented edge set

By the fixed physical shift-`g` Kraus equations, separately on each
orientation,

`sum_{i in E_+ intersect [0,m-1]} A(i) sqrt(h(i)) eta_i P(i)=0`

for every real polynomial of degree at most `D=2t-g`, with `|eta_i|=1`.
Here `A(i)` is the padded baseline amplitude. This is a necessary condition
for every `g<=2t`; additional error overlaps at smaller spacings do not
contribute to the fixed shift-`g` rows.

Order the positive and negative distances to other edges of `E_+` from `i0`:

`0<r_1<r_2<...`, `0<s_1<s_2<...`,

so `i0+r_j` and `i0-s_j` lie in `E_+`. Equation (1) implies

`|r_j-2j|<=3ell+1`, `|s_j-2j|<=3ell+1`.              (3)

Let `d=floor(D/2)` and put

`P(i0+x)=product_{j=1}^d (1-x/r_j)(1+x/s_j)`.

This polynomial has degree `2d<=D`, equals one at `i0`, and kills the nearest
`d` oriented edges on each side, including any roots lying outside the
physical grid. The roots outside the grid merely strengthen the test
polynomial and do not change the phase moment identity.

We show that its asymptotic entropy is the same as for the uniform parity
lattice. Put `E=4ell+4=o(t)`. Along any subsequence where `D/t->delta>0`,
we eventually have `d>E`. At a surviving positive oriented node `x=r_l`,
`l>d`,

`|P(i0+r_l)|=product_{j=1}^d [(r_l-r_j)(r_l+s_j)/(r_j s_j)]`.

For `j<=E`, use `r_j,s_j>=j`, (3), and `r_l<=m=O(t)` for a physical node.
The product of these first `E` factors is bounded by

`(10t)^(2E)/(E!)^2 = exp(o(t))`.                    (4)

The constant ten can be replaced by any sufficiently large fixed constant;
for large `t`, `m<3t` and `E<t`, so ten suffices.

For `j>E`, (3) gives

`r_l-r_j <= 2(l-j+E)`,
`r_l+s_j <= 2(l+j+E)`,
`r_j s_j >= 4(j-E)^2`.

Writing `h=j-E` and `L=l+2E`, their product is therefore at most

`product_{h=1}^{d-E} [(L-h)(L+h)/h^2]`
`=binom(L+d-E,d-E) binom(L-1,d-E)`.                (5)

The elementary binomial entropy bound applies to (5). The effective degree
parameter `2(d-E)/t` tends to `delta`; by (3), `2L/t` differs from the actual
scaled distance `r_l/t` by `O(E/t)=o(1)`. The entropy function

`F(c,u)=((u+c)log(u+c)-(u-c)log(u-c)-2c log c)/2`

is uniformly continuous on the compact ranges in question, including `u=c`
with the convention `0 log 0=0`. Thus (4)-(5) prove, uniformly over all
surviving physical positive nodes,

`log|P(i0+r_l)| <= t F(delta,max(delta,r_l/t))+o(t)`.           (6)

The same proof with `r` and `s` interchanged treats negative nodes. Also every
surviving distance is at least `delta t-o(t)` by (3).

## 4. Finish by the padded Gaussian estimate

Normalize the phase equation at `i0`. Estimate (2) contributes only `exp(o(t))`;
the baseline normalization at `i0`, chosen within `epsilon t` of its mode,
contributes `exp(O(epsilon^2 t))`. Its strong log concavity gives the same
limiting Gaussian exponent as in the padded alternating-label proof.
Combining it with (6), then sending `epsilon` to zero, yields the same
necessary inequality

`(1+2lambda^3/C^2)(2-lambda) <= B`,

where `lambda=g/t` and `C=n/t^2` are subsequential limits. The cases and
minimization in the padded theorem are unchanged, giving

`C >= sqrt(16-8B)`.

No claim is made for overlapping logical supports: their diagonal weights
would be differences of two nonnegative distributions, and the phase
orientation reduction above would no longer follow.


## Alternative proof of the irregular-root entropy: a discrete log potential

The following gives the same conclusion without selecting an equal number of
roots on each side. Put `R=D-(4ell+4)>0` and take all roots

`S_t={r in E_+: 0<|r-i0|<=R}`.

By (1), `#S_t<=R+3ell/2<=D`. Define

`P(i)=product_{r in S_t} (i-r)/(i0-r)`.

Then `P(i0)=1`, and every other surviving oriented physical node has
`|i-i0|>R`. The scaled root measure

`nu_t=(1/t) sum_{r in S_t} delta_((r-i0)/t)`

converges weakly to `(1/2) 1_[-delta,delta](v) dv`, where `D/t->delta>0`.
Indeed (1) bounds the discrepancy on every interval by `O(ell+1)=o(t)`, and
`R/t->delta`.

At a surviving integer output `i`, putting `u=(i-i0)/t`,

`(1/t)log|P(i)|=integral [log|u-v|-log|v|] dnu_t(v)`.

The two logarithmic singularities are uniformly integrable. Distinct integer
roots give at most two roots at each positive integer distance `j` from `i`
or from `i0`. Consequently for each fixed `0<eta<1`,

`(1/t) sum_{1<=|i-r|<=eta t} |log(|i-r|/t)|`
` <= (2/t) sum_{j=1}^{floor(eta t)} log(t/j)`
` <= 2eta(1-log eta)+o(1)`,

uniformly in the output. The same bound holds at the denominator center. The
last inequality follows from `K!>=(K/e)^K`; rounding contributes only
`O(log(t)/t)`. The limiting Lebesgue integrals have the same vanishing tail
bound as `eta` tends to zero.

For fixed `eta`, replace `log|x|` by `log max(|x|,eta)`. These truncated kernels
are uniformly Lipschitz on every bounded output range. Weak convergence,
using a finite net in the output variable, therefore gives convergence
uniformly in `u`. The preceding tail estimates then remove the truncation.
The physical output range is bounded because `m/t->2`.

It follows uniformly over surviving physical outputs that

`(1/t)log|P(i)| = Phi_delta(u)+o(1)`,

where

`Phi_delta(u)=(1/2) integral_{-delta}^{delta}
             [log|u-v|-log|v|] dv`.

This continuous even function equals `F(delta,|u|)` for `|u|>=delta`.
Every surviving output satisfies `|u|>=R/t=delta-o(1)`, which gives exactly
the entropy estimate needed in the padded proof. This argument also covers
endpoints and integer roots of `q`; no asymptotic Stirling approximation is
used.

## Unpadded sharpening also keeps arbitrary disjoint labels

If `b=0` and `n=mg`, the same extension applies to the sharper unpadded entropy
bound

`liminf n/t^2 >= 4-2c_* > 3.2283372002`,

where `c_*` is the unique positive zero of the maximized exact factorial
entropy exponent defined in `AMPLITUDE_ENTROPY_THEOREM.md`.
The baseline amplitudes satisfy the exact algebraic identity

`A(i)=mg sqrt(W_i)`.

Thus the unpadded gamma-product and binomial-entropy estimates are unchanged.
Only two uses of the prescribed parity lattice occur in that proof: the
moving-center amplitude estimate and the roots of the phase test polynomial.
Sections 2 and 3 above replace them by the same asymptotic estimates, with an
additional uniform `o(t)` in the logarithm. This does not change any strict
negative exponent used to exclude a limiting ratio above `c_*`.

The restriction `g>t` can also be removed. If `g>2t` along a subsequence, then
`n/t^2>=4-o(1)`, already above the claimed bound. Otherwise the adjacent shift
`g` equations still apply. If `D/t->delta>1`, choose a fixed center window
radius `epsilon t` with `epsilon<delta-1`. The irregular-root test eventually
kills every physical oriented edge other than its center, making its phase
moment equation impossible. If `delta=1`, the remaining tails are confined
to shrinking endpoint neighborhoods as `epsilon` is sent to zero; the
unpadded factorial-weight exponent tends to minus infinity there, as already
proved in the unpadded theorem. Hence only `0<delta<1` needs its threshold
calculation. The case `delta=0` automatically has length coefficient four.

Therefore the stronger coefficient applies to all integer spacings and
arbitrary disjoint logical assignments on the unpadded uniform grid with
`m=2t+1+o(t)`.
