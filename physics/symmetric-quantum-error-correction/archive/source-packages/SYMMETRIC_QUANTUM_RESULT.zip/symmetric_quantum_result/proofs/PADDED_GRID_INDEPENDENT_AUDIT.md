# Independent audit of the arbitrary-padding uniform-grid obstruction

**Audit conclusion:** the root's proposed padded-grid extension is valid under its stated uniform-grid / parity-support / sublinear-extra-node assumptions. It is a restricted construction-family obstruction, not an unrestricted lower bound. The exact asymptotic coefficient is

\[
\sqrt{16-8B},\qquad
B=\max_{z\ge1}\frac{(z+1)\log(z+1)-(z-1)\log(z-1)}{2z^2}.
\]

An independently written standard-library rational checker certifies

\[
0.7396762030389118<B<0.7396762030389120,
\]
\[
3.1753094928980864<\sqrt{16-8B}<3.1753094928980869.
\]

I inspected the packet's physical adjacent-transition bridge and the phase agent's unpadded amplitude theorem before auditing the extension. The checks below are analytic; the rational checker controls the only numerical constant and several normalization identities.

## 1. Exact padded baseline

Let the support weights be `w_i=b+gi`, `i=0,...,m`, with `b,r>=0`, `n=b+mg+r`, `t<g<=2t`, and `m=2t+1+ell`. Write the diagonal-KL-compatible probabilities as `p_i=binom(m,i)q(i)`, where `deg q<=ell` and `q(i)>=0` at all nodes. No positivity of `q` between nodes is needed.

For adjacent cross edges, `h(i)=q(i)q(i+1)` has degree at most `2ell`, is nonnegative at the edge nodes, and the phase magnitude has the exact baseline

\[
A(x)^2=\binom mx\binom m{x+1}
\prod_{j=1}^g(b+gx+j)(n-b-gx-g+j),\quad 0\le x\le m-1.
\]

Both binomials are continued by Gamma functions. All factors are strictly positive on this interval, including when either padding is zero. The full physical KL conditions imply the same separate even-/odd-edge annihilation of every polynomial of degree at most `D=2t-g`. The offset `b` merely makes the affine change of variable `w=b+gi`; it does not change the polynomial span.

## 2. Global strong log-concavity

Put `L=log A`. The binomial contribution to `-L''` is

\[
\tfrac12[\psi_1(x+1)+\psi_1(x+2)+\psi_1(m-x)+\psi_1(m-x+1)].
\]

The positive series for trigamma gives `psi_1(u)>=1/u`. Pair the first and fourth denominators, and the second and third; both pairs sum to `m+2`. The reciprocal AM-HM inequality then gives a total at least `4/(m+2)`.

For each ladder pair let `u_j=b+gx+j`, `v_j=n-b-gx-g+j`. Then `u_j+v_j=n-g+2j<=n+g`, and

\[
\tfrac12g^2(u_j^{-2}+v_j^{-2})\ge4g^2/(n+g)^2.
\]

Summing proves, for every admissible padding and every `x` in the full physical interval,

\[
L''(x)\le-\kappa,\qquad
\kappa=\frac4{m+2}+\frac{4g^3}{(n+g)^2}.
\]

No asymptotic estimate enters this inequality.

## 3. Uniform location of the mode

At `x=m/4`, the derivative of the binomial contribution is

\[
\tfrac12[\psi(3m/4+1)-\psi(m/4+1)
+\psi(3m/4)-\psi(m/4+2)].
\]

Integrating `psi_1(u)>=1/u`, and noting that both upper arguments exceed the respective lower arguments for `m>=4`, gives the stronger bound

\[
B'(m/4)\ge\log\frac{3m}{m+8}.
\]

Thus the root's additional subtraction `4/(3m)` is safe but unnecessary. The ladder derivative is at least

\[
-\frac{g}{2(3m/4-1)}\ge-\frac{m}{2(3m/4-1)}.
\]

The logarithmic lower bound increases with `m`, whereas the magnitude of the negative term decreases. At `m=32`, positivity follows already from

\[
\log(12/5)>14/17>16/23.
\]

The rational checker also verifies the weaker original comparison with `1/24+16/23`.

Reflection `x -> m-1-x` interchanges the paddings `b` and `r`. Hence the derivative is negative at `3m/4-1`, and strong concavity puts the unique mode `x_*` inside `(m/4,3m/4-1)`, in particular inside the claimed `[m/4,3m/4]`.

## 4. Local lower control near the mode

On `[m/8,7m/8]`, `psi_1(u)<=1/u+1/u²` bounds the magnitude of the binomial second derivative by

\[
16/m+128/m^2\le20/m \quad(m\ge32).
\]

Each ladder denominator is at least `gm/16` there, so the ladder contribution is at most `256g/m²<=256/m`. Therefore

\[
-L''(x)\le276/m\le138/t.
\]

For a parity node `i_0` within `epsilon*t` of the mode, with `epsilon<1/8`, the segment between it and the mode stays in the displayed central interval for all large parameters. Taylor's theorem yields

\[
A(i_0)\ge A(x_*)\exp(-69\epsilon^2t).
\]

The root's `70 epsilon² t` budget is conservative.

## 5. Moving-center amplitude interpolation

Choose `i_0` to maximize `h` among same-parity nodes within `epsilon*t` of the mode. Because `deg h<=2ell=o(t)`, this window eventually contains more nodes than the degree, so `h(i_0)>0`, even with missing support nodes.

If `r_h=deg h>0`, choose `r_h+1` equally spaced window nodes, with spacing at least `epsilon*t/(2r_h)`. For sufficiently large parameters `m<=3t`. Lagrange interpolation then gives the safe global bound

\[
0\le h(i)/h(i_0)\le(36/\epsilon)^{2\ell}
\]

on all physical edge nodes. This is the same argument as the unpadded lemma, with constants adapted to a window of width `epsilon*t`. Its square-root contribution is `exp(o(t))` for each fixed epsilon. Any fixed larger constant is equally adequate. A literal claim of the old constant24 should either retain its original scaling convention or be replaced by36; the asymptotic theorem is unaffected.

## 6. Tail estimate without a hidden uniform-limit step

Set `d=floor(D/2)`, `c_t=2d/t`, and use the same parity-root polynomial centered at `i_0`. At a surviving tail node set `u=|i-i_0|/t>=c_t`. The elementary binomial entropy inequality gives

\[
\log|P(i)|\le tF(c_t,u),\qquad
F(c,u)=c f(u/c),
\]
\[
f(z)=\tfrac12[(z+1)\log(z+1)-(z-1)\log(z-1)].
\]

Put `a_t=kappa*t/2`. Gaussian decay from the true mode, plus the local normalization and amplitude bound, yields a tail summand bounded by

\[
\exp\{o(t)+70\epsilon^2t+t[F(c_t,u)-a_t(u-\epsilon)^2]\}.
\]

This remains valid for either side of the mode because `|i_0-x_*|/t<=epsilon`.

By the definition of `B`, for every `u>=c>0`,

\[
F(c,u)\le B u^2/c.
\]

Therefore, when `epsilon<c`,

\[
F(c,u)-a(u-\epsilon)^2
\le[B/c-a(1-\epsilon/c)^2]u^2.
\]

This direct estimate avoids an unnecessary moving-domain supremum limit. If along a subsequence `g/t->lambda`, `n/t²->C<4`, and `ell/t->0`, then

\[
c_t\to\delta=2-\lambda>0,\qquad
a_t\to1+2\lambda^3/C^2.
\]

If their limiting product exceeds `B`, choose fixed epsilon sufficiently small so the last coefficient stays negative and its negative contribution, using `u>=c_t`, also dominates `70 epsilon²`. The polynomial number of tail nodes and `exp(o(t))` modulation cannot compensate. The necessary phase balance fails. Thus

\[
(1+2\lambda^3/C^2)(2-\lambda)\le B.
\]

The case `delta=0` implies `lambda=2`, and padding already forces `C>=2lambda=4`; it cannot occur in the subsequences used to prove a lower coefficient below4.

## 7. Optimization over arbitrary padding

Padding nonnegativity gives `C>=2lambda`, while `lambda>=1`. For `2<=C<4`, therefore `1<=lambda<=C/2`. The derivative in lambda of the left side is

\[
-1+\frac{4\lambda^2(3-2\lambda)}{C^2}\le0,
\]

because

\[
1-\lambda^2(3-2\lambda)=(\lambda-1)^2(2\lambda+1)\ge0
\]

and `C>=2`. Its minimum occurs at `lambda=C/2`, where the expression equals `2-C²/8`. Consequently `2-C²/8<=B`, or

\[
C\ge\sqrt{16-8B}.
\]

A hypothetical sequence with smaller liminf has a bounded convergent subsequence of `n/t²` and, after another extraction, of `g/t`; the argument applies to that subsequence. No convergence of either padding separately is needed.

## 8. Independent certification of B

The derivative of `f(z)/z²` has numerator `H(z)=z f'(z)-2f(z)`, with

\[
H'(z)=-z/(z²-1)-\tfrac12\log((z+1)/(z-1))<0.
\]

It tends to positive infinity at1 and negative infinity at infinity, so there is a unique maximum. The checker does not trust a numerical optimizer for its value. At the exact rational test point `z=1.0842778882313335`, it certifies `f(z)/z²>B_L`. For the upper bound it sets `J(z)=f(z)-B_U z²`; since `J''<=-2B_U`,

\[
\sup_{z\ge1}J(z)\le J(z_0)+J'(z_0)^2/(4B_U).
\]

Exact rational logarithm intervals make this last expression strictly negative, proving `B<B_U` globally. Rational square comparisons certify the coefficient interval. The checker is `check_padding_constant.py`; its actual output is `check_padding_constant.json`, status PASS.
