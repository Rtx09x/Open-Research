# Uniform-grid symmetric codes require macroscopic freedom beyond minimal support

## Theorem: arbitrary spacing, arbitrary padding, arbitrary disjoint logical assignment

Let t tend to infinity through any sequence of positive integers. For each t, suppose a two-dimensional complex code C_t contained in Sym^n(C^2) has an orthonormal basis supported on a uniform Dicke grid

    w_i=b+gi,  0<=i<=m,
    b>=0, g>=1, r>=0, n=b+gm+r,
    m=2t+1+ell, ell=o(t).

Assume the two basis vectors have disjoint supports on that grid. The assignment of nodes to the two logical vectors is arbitrary, their phases are arbitrary complex unit phases, and any grid nodes may be unused. The offset b, spacing g, and padding r may depend on t. No upper bound on either padding is assumed. The basis axis may also vary, since collective single-qubit rotations preserve physical error weights.

If every C_t corrects arbitrary errors on at most t physical qubits, then

    liminf n/t^2 >= C_* := sqrt(16-8B),
    B := max_(z>=1) f(z)/z^2,
    f(z) := ((z+1)log(z+1)-(z-1)log(z-1))/2,

where 0log0=0. The maximizer is unique. Exact rational logarithm certificates establish

    .7396762030389118 < B < .7396762030389120,
    3.1753094928980864 < C_* < 3.1753094928980869.

Thus this entire construction class cannot attain n=3t^2+o(t^2), even with arbitrary phases, arbitrary disjoint logical assignments, arbitrary grid offset and padding, and all amplitude freedom allowed by diagonal physical Knill-Laflamme.

This is a restricted-family theorem. It does not cover overlapping logical Dicke supports, nonuniform supports, or a linear or larger surplus ell of nominal grid nodes. It does not establish an unrestricted bound n_min(t)>=C_* t^2 and does not settle n_min(t)=3t^2+3t+1.

## 1. Full physical necessity

Use unit-normalized Dicke vectors. For k=2t erased qubits, the normalized Kraus maps are

    E_a|D_n^w> = sqrt[binom(k,a)binom(n-k,w-a)/binom(n,w)] |D_(n-k)^(w-a)>,
    0<=a<=k,

with out-of-range binomials zero. A symmetric code correcting t arbitrary physical errors has scalar compression of all E_a^*E_b. Thus both logical diagonal Gram matrices agree and every logical cross Gram entry vanishes. These are physical equations, including the off-diagonal logical conditions.

Let p_i be the squared magnitude at node i and epsilon_i=+1 or -1 indicate its logical assignment, putting epsilon_i p_i=0 at an unused node. The diagonal equations span all polynomials in w of degree at most 2t, and the affine substitution w=b+gi preserves that span. Therefore

    sum_i epsilon_i p_i i^a=0,  0<=a<=2t.

The finite-difference identity and Vandermonde kernel dimension give the exact parametrization

    epsilon_i p_i=(-1)^i binom(m,i)q(i),  deg q<=ell,                 (1)

for a nonzero real polynomial q. Hence at every used node

    p_i=binom(m,i)|q(i)|,
    epsilon_i=(-1)^i sign q(i).

No positivity of q at all nodes or between nodes is assumed.

When g<=2t, put D=2t-g. A fixed Kraus-index difference g isolates exactly adjacent grid nodes, regardless of whether additional shifts such as 2g are also detectable. For w and w+g, factorial cancellation gives

    binom(n-k,w-a)/sqrt[binom(n,w)binom(n,w+g)]
     = sqrt[(n-w)_g(w+g)_g]/(n)_k
       * (w)_a(n-w-g)_(D-a),  0<=a<=D.                            (2)

The displayed polynomials span all degrees through D: their evaluation matrix at w=0,...,D is triangular with positive diagonal a!(n-g-a)_(D-a). Thus the full physical cross conditions imply, separately for each logical orientation,

    sum_i A(i)sqrt(h(i)) eta_i P(i)=0,  deg P<=D,                  (3)

where the sum is over its adjacent cross edges, |eta_i|=1,

    h(i)=q(i)q(i+1)>0,
    A(x)^2=binom(m,x)binom(m,x+1)
            product_(u=1)^g(b+gx+u)(r+g(m-x-1)+u).                (4)

The binomials in A are continued by Gamma functions. All factors in (4) are positive on 0<=x<=m-1. Equation (3) is necessary for every allowed complex code in the stated family; extra error-overlap equations can only impose additional conditions.

## 2. Logical labels can deviate from alternation only sublinearly often

Fix the orientation from logical zero at the lower endpoint to logical one at the upper endpoint. Extend its set of edge indices to all integers by

    S={i in Z : q(i)q(i+1)>0 and (-1)^i sign q(i)=+1}.             (5)

This extension merely supplies roots of test polynomials; it introduces no physical amplitudes outside the grid.

For any interval of L consecutive integer edge indices,

    | #(S intersect interval)-L/2 | <= (3ell+1)/2.                (6)

Indeed, each edge failing q(i)q(i+1)>0 contains a real root of q in its closed unit interval. At most 2ell integer edges are bad, since a root belongs to at most two such intervals. The remaining edges form at most ell+1 blocks on which the sign of q is constant; within each block S selects alternating edges. Their total discrepancy is at most (ell+1)/2 and removing the bad edges costs at most ell. This proves (6), including integer and multiple roots.

Two edges of S cannot be consecutive: the upper endpoint of an oriented cross edge belongs to logical one and cannot simultaneously be the lower logical-zero endpoint of the same orientation. Thus distinct indices of S are separated by at least two.

## 3. Exact global curvature and a uniformly central mode

Let L(x)=log A(x). The trigamma series gives

    1/u <= psi_1(u) <= 1/u+1/u^2,  u>0.

The binomial contribution to -L'' is

    [psi_1(x+1)+psi_1(x+2)+psi_1(m-x)+psi_1(m-x+1)]/2.

Pairing denominators whose sums equal m+2 proves a lower bound 4/(m+2). For each ladder pair put

    U_u=b+gx+u,  V_u=r+g(m-x-1)+u.

Since U_u+V_u=n-g+2u<=n+g and U_u^-2+V_u^-2>=8/(U_u+V_u)^2, (4) gives the exact global inequality

    L''(x)<=-kappa,
    kappa=4/(m+2)+4g^3/(n+g)^2.                                 (7)

For the asymptotic contradiction it suffices to consider g<=2t<=m-1. At x=m/4, integrating psi_1(u)>=1/u shows that the derivative of the binomial part is at least

    log[3m/(m+8)].

The negative part of the ladder derivative has magnitude at most g/[2(3m/4-1)]<=m/[2(3m/4-1)]. For m>=32 the first bound increases and the second decreases; at 32 positivity follows from log(12/5)>14/17>16/23. Reflection x->m-1-x interchanges b and r. Consequently A has a unique mode x_* with

    m/4 < x_* < 3m/4-1.                                         (8)

On the central strip [m/8,7m/8], m>=32, the upper trigamma bound gives binomial curvature at most 20/m. Each ladder denominator is at least gm/16, so ladder curvature is at most 256g/m^2<=256/m. Thus

    0<-L''(x)<=276/m<=138/t.                                    (9)

For a node i_0 within epsilon t of x_*, with fixed epsilon<1/8 and sufficiently large t, Taylor's theorem and (7)-(9) imply

    A(i_0)>=A(x_*) exp(-70epsilon^2 t),
    A(i)<=A(x_*) exp[-kappa(i-x_*)^2/2].                         (10)

Both inequalities are uniform in b and r, which may be arbitrarily large.

## 4. Moving-center amplitude control

In the window |i-x_*|<=epsilon t, (6) gives epsilon t+O(ell+1) indices of S. Since ell=o(t), there are eventually more than 2ell. Choose i_0 in that window maximizing h(i). Then h(i_0)>0.

For r_h=deg h>0, select r_h+1 approximately equally spaced quantiles of these S nodes. Their physical separation is at least Delta>=epsilon t/(2r_h) for all sufficiently large t, using the minimum spacing two and (6). Since m<=3t eventually, every numerator in their Lagrange interpolation basis is at most 3t; its jth denominator is at least Delta^r_h j!(r_h-j)!. Therefore

    |h(i)|/h(i_0)
      <= (6t/Delta)^r_h/r_h!
      <= (12r_h/epsilon)^r_h/r_h!
      <= (36/epsilon)^(2ell).                                  (11)

The constant case is immediate. We used r!>=(r/e)^r and e<3. This is exp(o(t)) for each fixed epsilon, even if h(i) vanishes or is negative away from S. No lower bound at the exact mode or a prescribed node is assumed.

## 5. An exact annihilator on the actual oriented edge set

Order the positive and negative distances from i_0 to other points of S as

    0<r_1<r_2<...,  0<s_1<s_2<... .

The discrepancy (6) gives

    |r_j-2j|<=3ell+1,  |s_j-2j|<=3ell+1.                        (12)

These sequences are infinite because a nonzero polynomial has only finitely many real roots. Set d=floor(D/2) and

    P(i_0+x)=product_(j=1)^d (1-x/r_j)(1+x/s_j).                  (13)

It has degree 2d<=D, is one at i_0, and kills the nearest d oriented edges on each side. Roots outside the physical grid are legitimate polynomial roots and impose no extra physical assumptions.

Here is a uniform bound that preserves the sharp parity-lattice entropy despite the O(ell) logical-label defects. Let E=4ell+4. Along any subsequence where D/t tends to delta>0, eventually d>E. At a surviving positive physical edge x=r_l, l>d, split the product (13) at j=E.

For j<=E, distinct positive integer distances obey r_j,s_j>=j, and all relevant physical distances and first E roots are O(t). Hence these factors have product at most

    (10t)^(2E)/(E!)^2 = exp(o(t)).                              (14)

The last assertion follows from E/t->0 and E log(t/E)=o(t), not the false shortcut E log t=o(t).

For j>E, (12) implies

    r_l-r_j<=2(l-j+E),
    r_l+s_j<=2(l+j+E),
    r_j s_j>=4(j-E)^2.

Writing h=j-E and J=l+2E, the remaining product is at most

    product_(h=1)^(d-E)(J-h)(J+h)/h^2
      =binom(J+d-E,d-E)binom(J-1,d-E).                          (15)

The same argument with r and s exchanged treats negative tails. Ordinary binomial entropy bounds give

    log|P(i)| <= o(t)+t F(c_t,u'_t),
    F(c,u)=[(u+c)log(u+c)-(u-c)log(u-c)-2c log c]/2,
    c_t=2(d-E)/t,
    u'_t=2J/t.                                                 (16)

Uniformly over surviving physical tails, c_t->delta and u'_t differs from the actual scaled distance u=|i-i_0|/t by o(1). Moreover u>=delta-o(1) and u is bounded since m/t->2. The entropy bound is exact before taking these limits.

## 6. The necessary Gaussian-entropy inequality

Take a subsequence with

    n/t^2->C<4,  g/t->lambda.

Padding nonnegativity implies 0<=lambda<=C/2<2, so g<=2t eventually and delta=2-lambda>0. We initially allow C=0; no division by C is needed for the first step.

Let alpha_t be any positive sequence satisfying

    alpha_t<=kappa t/2,  alpha_t->alpha>0.                       (17)

Isolate the i_0 term of the exact phase identity (3). If no tail survives, that identity is already impossible. Otherwise (10), (11), and (16), followed by the triangle inequality, bound each normalized tail by

    exp{o(t)+70epsilon^2 t
              +t[F(c_t,u'_t)-alpha_t(u-epsilon)^2]}.             (18)

There are only O(t) tails. By homogeneity,

    F(c,u)=c f(u/c)<=B u^2/c,  u>=c>0.                         (19)

If alpha delta>B, then alpha-B/delta>0. Since u>=delta-o(1), u is bounded, and u'_t-u=o(1) uniformly, first choose fixed epsilon small enough, then sufficiently large t, so the exponent in (18) is bounded above by a strictly negative constant times t. The 70epsilon^2 t cost is also absorbed by this strict margin. Summing O(t) terms cannot satisfy the normalized phase balance, whose left side is one. Therefore every such curvature limit satisfies alpha delta<=B.

First take alpha_t=2t/(m+2), using only the binomial term in (7). Then alpha=1 and delta<=B<1, so lambda>=2-B>1 and C>=2lambda>2. This rules out C=0 and all lambda<=1 without importing an unrestricted volume bound.

We may now safely use the full curvature sequence. Since C>2,

    kappa t/2 -> 1+2lambda^3/C^2.

The necessary inequality becomes

    (1+2lambda^3/C^2)(2-lambda)<=B.                            (20)

## 7. Optimize over all offsets and paddings

For fixed 2<C<4 and 1<lambda<=C/2, differentiate the left side of (20):

    d/dlambda[(1+2lambda^3/C^2)(2-lambda)]
      =-1+4lambda^2(3-2lambda)/C^2<=0,

because

    1-lambda^2(3-2lambda)=(lambda-1)^2(2lambda+1)>=0.

Its minimum over the allowed interval is therefore attained at lambda=C/2 and equals

    2-C^2/8.

Equation (20) forces 2-C^2/8<=B, or C>=sqrt(16-8B). A sequence with smaller liminf would have a bounded subsequence with convergent n/t^2 and then a convergent subsequence of g/t; the argument above excludes it. If a subsequence has g>2t, its n/t^2 is already at least 4-o(1). This proves the theorem for every integer spacing.

## 8. Exact constants and controls

The function f(z)/z^2 has derivative with numerator H(z)=z f'(z)-2f(z). Since

    f'(z)=log((z+1)/(z-1))/2,
    H'(z)=-z/(z^2-1)-f'(z)<0,

and H goes from positive infinity at 1 to negative infinity, its maximizer is unique. No numerical maximizer is trusted. The standard-library checker `../checkers/check_padding_constant.py` uses exact Fraction logarithm intervals and certifies B_L<B<B_U with

    B_L=.7396762030389118,  B_U=.7396762030389120.

For the lower bound it evaluates at the specified rational z_0=1.0842778882313335. For the upper bound it sets J(z)=f(z)-B_U z^2 and uses J''<=-2B_U to bound

    sup_(z>=1) J(z) <= J(z_0)+J'(z_0)^2/(4B_U)<0.

Rational square comparisons certify the stated C_* interval.

The exact test suite also includes:

- the signed Vandermonde parametrization with holes, sign-changing q, and negative-between-node q;
- oriented-edge discrepancy and 395 exact irregular-root product comparisons;
- a full physical padded t=2,n=42 positive code and a deliberately wrong logical-label control;
- 67 independent physical Kraus/falling-factor identities with padding;
- a full physical shifted/padded t=1,n=14 separated-grid control;
- the packet's t=11,n=506 phase construction, all 23 physical diagonal entries, both exact algebraic cross sums, and a wrong-edge-phase control.

The relevant independently written checkers are `../checkers/check_disjoint_labels.py`, `../checkers/check_padding_constant.py`, and `../checkers/check_amplitude_entropy.py`. Their executed outputs are saved alongside them. Finite controls verify normalization and constants; the all-t obstruction is the analytic proof above.

## Dependencies, attribution, and the remaining gap

The exact physical adjacent-shift bridge and polynomial-amplitude interface are supplied in the packet. Their necessary formulas were independently reconstructed above. Polynomial moment cancellation itself is established in Ouyang, *Permutation-invariant qudit codes from polynomials*, arXiv:1604.07925v4, Lemma 3.2 and Theorem 5.1: https://arxiv.org/html/1604.07925v4 . The trigamma series used for the curvature estimates is NIST DLMF 5.15.1: https://dlmf.nist.gov/5.15.E1 .

The new content relative to the packet is the moving-center interpolation step, its extension to arbitrary disjoint logical assignments, and the global curvature argument that covers arbitrary padding. These remove the proposed escape through sublinear amplitude freedom within this uniform-grid architecture. They do not prove that arbitrary complex symmetric codes can be reduced to this architecture. In particular, overlapping logical supports remain outside the theorem. No claim of literature priority or a solution of the unrestricted minimum problem is made.

## Inherited minimal-support corollary

When exactly 2t+2 Dicke rows are nonzero, disjoint logical supports follow from diagonal physical KL and need not be assumed. For an arbitrary isometric encoding frame write its rank-one row Gram matrices as (p_i I+b_i dot sigma)/2. Each coordinate of b_i lies in the one-dimensional Vandermonde kernel, so b_i=c_i v for one fixed nonzero real vector v. A logical unitary aligning v with sigma_z makes every rank-one row Gram diagonal, hence each row belongs to only one logical vector. The signs of the inverse-Vandermonde coefficients alternate. This classification is already supplied in `scientific/phase3/minimal_axis_support_gate.md`, Section 1; it is not a new result of this derivation. Applying the new theorem then excludes leading3 uniformly spaced minimal-axis-support codes without an extra logical-support restriction. For a positive surplus ell, the diagonal Bloch data may be vector-valued polynomials and no such general disjoint-support reduction is asserted.
