# Uniform spectral interior for symmetric erasure-code marginals

## Statement

Let `C : C^K -> Sym^n(C^2)` be an isometry, with `K >= 2`, and suppose it corrects erasure of `k` physical qubits, where `1 <= k <= n`. No reality, parity, time-reversal, group-covariance or purity assumption is made. Let `G_k` be its common normalized `k`-loss Gram matrix in the Dicke Kraus basis. Equivalently, up to transpose, `G_k` is the common erased marginal on `Sym^k(C^2)`.

Set `(n)_k=n(n-1)...(n-k+1)`. Then

\[
G_k\succeq { (K-1)^k\over(n)_k} I_{k+1}.
\tag{1}
\]

Consequently every eigenvalue lies in

\[
{ (K-1)^k\over(n)_k}\le\lambda\le
1-k{ (K-1)^k\over(n)_k},
\]

and

\[
\kappa(G_k)\le {(n)_k\over(K-1)^k}-k.
\]

For a logical qubit correcting `t` arbitrary physical errors, take `k=2t`, giving `G_(2t) >= I/((n)_(2t))`.

Every nonzero pure postselection vector in `Sym^s(C^2)`, for `s <= k` erased qubits, has a strictly positive success probability independent of the logical input; its surviving image, after normalization, is a `K`-dimensional complex symmetric code correcting the remaining `k-s` erasures. This assertion includes entangled postselection vectors, not only product outcomes.

The theorem is a quantitative strengthening of the supplied full-loss-rank theorem. It does not prove intrinsic collective-spin nondegeneracy and does not improve the supplied numerical lower bound on `n_min(t)`. It supplies an explicit uniform distance from the singular marginal boundary, replacing a qualitative compactness argument. Publication priority has not been established.

## Normalization

Use normalized Fock monomials

\[
 |D_m^w\rangle\longleftrightarrow
 {x^{m-w}y^w\over\sqrt{(m-w)!w!}}.
\]

For `0 <= a <= s`, the normalized loss operator is

\[
 E_{s,a}=\sqrt{\binom sa/(n)_s}\,
 \partial_x^{s-a}\partial_y^a.
\]

Its Dicke coefficient is precisely

\[
 E_{s,a}|D_n^w\rangle
 =\sqrt{\binom sa\binom{n-s}{w-a}/\binom nw}\,
 |D_{n-s}^{w-a}\rangle,
\]

with out-of-range binomials equal to zero. Knill--Laflamme says

\[
 C^*E_{s,a}^*E_{s,b}C=(G_s)_{ab} I_K.
\tag{2}
\]

Erasure correction at `k` implies (2) for every `s <= k`. Kraus completeness gives `Tr G_s=1`.

## 1. Postselection preserves the remaining erasure conditions

Let `R` be any homogeneous constant-coefficient derivative of order `s <= k`. Equation (2) gives `C^*R^*RC=lambda I_K` for some `lambda >= 0`. If `lambda > 0`, define `C_R=RC/sqrt(lambda)`. For any order-`r` loss derivatives `A,B`, where `r+s <= k`,

\[
 C_R^*A^*BC_R
 ={1\over\lambda} C^*(AR)^*(BR)C
\]

is scalar by the original order-`r+s` loss conditions. Thus `C_R` is an isometry and corrects `k-s` erasures. This proof includes every off-diagonal Kraus condition; it does not merely compare diagonal expectations.

## 2. Every normalized directional loss costs at least `K-1` before Kraus scaling

For a unit vector `v=(v_0,v_1) in C^2`, put

\[
 D_v=v_0\partial_x+v_1\partial_y.
\]

On `Sym^m(C^2)`, `D_v^*D_v` is unitarily conjugate to a mode number operator. Its eigenvalues, each simple, are `0,1,...,m`. If a `K`-dimensional isometric subspace `U` has scalar compression `U^*D_v^*D_v U=gamma I_K`, the min--max principle gives

\[
 K-1\le\gamma\le m-K+1.
\tag{3}
\]

For the lower inequality, the `K`-plane intersects the orthogonal complement of the bottom `K-1` eigenvectors nontrivially; the Rayleigh quotient of a nonzero vector in that intersection is at least `K-1`. Scalar compression makes the same quotient equal to `gamma`. The upper inequality follows similarly.

Now take any sequence of unit directions `v_1,...,v_k` and set `R_s=D_(v_s)...D_(v_1)`. Starting from `lambda_0=1`, induction using Sections 1 and 2 proves

\[
 C^*R_s^*R_sC=\lambda_s I_K,
 \qquad \lambda_s\ge (K-1)^s>0.
\tag{4}
\]

At the induction step, the already normalized image `C_(R_s)` corrects at least one more erasure, so the scalar-compression hypothesis of (3) holds. Hence `lambda_(s+1)/lambda_s >= K-1`. This supplies positivity directly; it does not assume the prior qualitative loss-rank theorem.

## 3. Arbitrary complex erased vectors factor with controlled norm

Take an arbitrary unit coefficient vector `q=(q_0,...,q_k)`. Define

\[
 p_q(x,y)=\sum_{a=0}^k q_a\sqrt{\binom ka}\,x^{k-a}y^a.
\]

For the Bombieri norm `||p||_B^2=sum |p_a|^2/binom(k,a)`, one has `||p_q||_B=1`. Over `C`, binary factorization gives

\[
 p_q=\alpha\prod_{i=1}^k(v_{i,0}x+v_{i,1}y),
 \qquad ||v_i||=1.
\tag{5}
\]

The polynomial of a symmetric tensor is normalized by mapping `|D_k^a>` to `sqrt(binomial(k,a)) x^(k-a)y^a`. Under this isometry, the product in (5) corresponds to the orthogonal symmetrization of `v_1 tensor ... tensor v_k`. Orthogonal projection is contractive, so

\[
 \left\|\prod_i(v_{i,0}x+v_{i,1}y)\right\|_B\le1,
 \qquad |\alpha|^2\ge1.
\tag{6}
\]

The product polynomial is nonzero, so its norm is positive. No reality or conjugate-root restriction enters this factorization.

The coherent Kraus combination associated to `q` is

\[
 E_q=\sum_a q_a E_{k,a}
 ={p_q(\partial_x,\partial_y)\over\sqrt{(n)_k}}
 ={\alpha R_k\over\sqrt{(n)_k}}.
\]

Combining (2), (4), and (6),

\[
 q^*G_kq={|\alpha|^2\lambda_k\over(n)_k}
 \ge{(K-1)^k\over(n)_k}.
\]

This holds for every unit complex `q`, proving (1). The eigenvalue upper bound follows from `Tr G_k=1`; the condition-number bound follows by division. The same proof at every `s <= k` establishes positivity for arbitrary pure erased-state postselection, after which Section 1 proves residual correction. This completes the proof.

## Dependencies and checks

The proof uses only exact physical loss normalization, Knill--Laflamme, complex binary factorization, the elementary spectrum of a one-mode number operator, and contraction of orthogonal symmetrization. It is independent of LP monotonicity, scalar enumerators, numerical optimization and a nondegeneracy premise.

The companion checker `check_quantitative_loss.py` independently builds normalized Dicke erasure matrices and verifies full Gram equality and logical off-diagonal zeros for the known seven-qubit code and the standard `gnu` two-error code at length 25. It also checks a dimension-three one-erasure code, the complex two-factor normalization used in the proof, and sequential derivative ratios. Deliberate invalid controls are a cat plane whose two diagonal marginals agree but whose logical cross marginal is nonzero, and a one-dimensional coherent state showing why `K>=2` is essential to strict positivity. All checks use exact SymPy integer/radical arithmetic. They are convention and falsification controls; the uniform proof is analytic.

Reproduction in an ordinary environment with `sympy==1.14.0`: `python ../checkers/check_quantitative_loss.py` from this directory. Run `python run_checks.py --with-loss` from the package root to include this control. Its output is saved in `../checkers/check_quantitative_loss.json`.
