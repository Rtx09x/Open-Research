#!/usr/bin/env python3
"""Run the exact controls supplied with this mathematical result."""
import argparse
import json
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--with-loss', action='store_true',
                        help='also run exact SymPy controls for the loss theorem')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    scripts = [
        'check_amplitude_entropy.py',
        'check_entropy_independent.py',
        'check_padding_constant.py',
        'check_disjoint_labels.py',
    ]
    if args.with_loss:
        try:
            import sympy
        except ImportError:
            parser.error('--with-loss requires SymPy; the verified version is 1.14.0')
        print('SymPy version:', sympy.__version__)
        scripts.append('check_quantitative_loss.py')
    results = []
    for script in scripts:
        result = subprocess.run([sys.executable, str(root / 'checkers' / script)],
                                cwd=root / 'checkers', capture_output=True, text=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
        payload = json.loads(result.stdout)
        assert payload.get('status') == 'PASS' or payload.get('PASS') is True, payload
        results.append({'checker': script, 'result': 'PASS'})
        print(script + ': PASS')
    summary = {
        'status': 'PASS',
        'checks': results,
        'uniform_proof': 'Analytic; finite controls do not prove the all-t limit by sampling.',
        'scope': 'Restricted uniform-grid length obstruction; unrestricted marginal bound.',
        'full_minimum_conjecture_resolved': False,
    }
    (root / 'verification_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('All requested checks passed.')


if __name__ == '__main__':
    main()
