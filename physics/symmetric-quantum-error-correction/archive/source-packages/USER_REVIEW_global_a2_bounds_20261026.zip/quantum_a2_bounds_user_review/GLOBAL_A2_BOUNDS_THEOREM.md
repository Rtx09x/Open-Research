# Global quadrupole restrictions for hypothetical 35- and 36-qubit codes

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

**Status (26 October 2026): internally AI-assisted audit, including separate arithmetic implementations.** External review
and priority are unestablished. This is a necessary-condition theorem, not a
nonexistence theorem. The unrestricted three-error minimum remains between
35 and 37, inclusive.

## 1. Exact scope and conclusion

Let V_j=Sym^n(C²), j=n/2, N=n+1. Let P be the orthogonal projector onto ANY
complex two-dimensional code in V_j correcting three arbitrary qubit errors
(equivalently, detecting all physical operators supported on at most six
qubits). There is no real-amplitude, time-reversal, finite-group, purity, or
nondegeneracy assumption. Decompose End(V_j) into its orthogonal SU(2)
operator-rank spaces, and denote the rank-r component of P by P_r. Define

    a_r = N ||P_r||_HS² / 4.

Then a_0=1, all a_r≥0, and Σ_r a_r=N/2. In particular:

    n=35:  a_2 ≤ 2613/50000 = 0.05226;
    n=36:  a_2 ≤ 2213/20000 = 0.11065.

The certificates actually give the stronger rational upper bounds

    n=35: 10451324947687550484413970959 /
           200000000000000000000000000000;
    n=36: 6915281191915210015028613979 /
           62500000000000000000000000000.

Their decimal values are approximately 0.05225662473843775 and
0.11064449907064336. The decimal displays are not the proof objects.

This substantially shrinks the quadrupole range allowed by the older scalar
bounds (9/40 and 1/3). It does not by itself contradict existence at either
length; zero quadrupole moment is allowed by the conclusion.

## 2. Necessary moments and what the dual uses

Twirl P⊗P⊗P by the spin-j SU(2) action, obtaining Z. It is positive,
permutation-invariant, has trace 8, and annihilates the fully antisymmetric
three-copy sector because rank(P)=2. In total-spin J blocks use the weighted
multiplicity matrix X_J=(2J+1)Z_J. Thus X_J≥0 and Σ_J Tr X_J=8.

The exact rational witnesses are nonnegative combinations of necessary
scalar/shadow inequalities, ordinary moment PSD cones, the logical R/D
cones, finitely many valid logical-complement and Schur supporting
inequalities, and four affine cubic inequalities. Equality multipliers use
normalization, pair marginals, and the lifted six-body Knill–Laflamme
relations. All these are reconstructed in the full multiplicity spaces,
not accepted merely in a numerically chosen subspace or QR basis.

For clarity, write Θ=Y conjugation for time reversal, θ(P)=Y P̄ Y†,
and v_θ=(I⊗Y)vec(P), in the fixed vectorization convention. Use P^(i)
for the projector on physical tensor factor i, distinct from P_r (operator
rank r). Then R is the twirl of |v_θ⟩⟨v_θ|_(13)⊗P^(2), and D is the twirl
of [P^(1)⊗θ(P)^(3)−|v_θ⟩⟨v_θ|_(13)/2]⊗P^(2), hence PSD.
R-complement tests use A⊗I−R≥0, with A=E|v_θ⟩⟨v_θ| in the same gauge. Schur marginal inequalities used here are weaker
consequences of this complement condition; no new fourth-copy strength is
claimed for those rows.

The scalar transform convention is

    M_rk = (−1)^(n+r+k)(2r+1){j j r; j j k},
    H = 2M−I,  S_rk = (−1)^k M_rk.

The code obeys (Ha)_r=0 for 1≤r≤6, (Ha)_r≥0 for r>6,
and Sa≥0. The supplied full-space dual checkers explicitly reconstruct these
coefficients, permutations, pair maps, and lifted KL rows by factorial
Racah sums and outward-rounded Arb arithmetic. The independent checker also
checks each KL vector by the corresponding local Casimir eigen-equation.
Proofs of the necessary maps are included as companion dependency notes.

## 3. Cubic inequalities and arbitrary complex applicability

Write c=j(j+1), Q_ab={J_a,J_b}/2−cδ_ab I/3, and
O_211=Σ_ab Q_ab⊗J_a⊗J_b. Hermiticity makes d_a=Tr(PJ_a) and
q_ab=Tr(PQ_ab) real, even when the code amplitudes are complex. Exact tensor
normalization and the traceless Cauchy inequality give

    |Tr(Z O_211)|² ≤ (64/405)c³(4c−3) a_1² a_2.

The previously exact scalar bounds imply global slopes 40000 at n=35 and
54000 at n=36. The literal rational O_211 matrices have an independently
checked expectation error at most 10^−5, included with POSITIVE sign in each
affine inequality and in the dual constant.

For a unit-HS invariant T_222 with operator rank 2 on each factor,

    |Tr(Z T_222)|² ≤ 128 a_2³/(35 N³).

Indeed the Hermitian spin-2 representation is real, its symmetric square
has rank-2 norm fraction 2/7, and the normalized singlet contributes 1/5.
This is not an assumption that P has real Dicke coefficients. On the prior
range, valid global slopes are 1/238 and 1/200 respectively. Rational matrix
rounding adds 10^−7 to the two signed inequalities. These literal operators
and constants are hash-whitelisted by both checkers. Complete derivations
and internal operator-rounding audits are companion dependencies. The dual
checkers use hash-whitelisted literal operators; replay of their physical
identification is a separate step described in `REPRODUCIBILITY.md`.

## 4. Exact dual residual theorem

The objective is to maximize a_2 with phase-I coordinate fixed EXACTLY zero.
Dual normalization is 1, not 1/N². The collected nonnegative functional is

    F = C − a_2 + r_0 a_0 + Σ_(r≥1) r_r a_r
                   + Σ_J Tr(R_J X_J) ≥ 0.                    (1)

Each supplied PSD contribution is a rational Gram factor, so its positivity
does not depend on floating eigenvalues. Numerical embeddings are rationally
lifted and the final residual is averaged over exact S3 and projected onto
the exact non-wedge³ support. Individual KL rows are valid independently of
the numerical rank-selection procedure.

Let b_0 bound r_0 from ABOVE (not its absolute value); let b_a bound every
|r_r| for r≥1; and let b_Z bound each Hermitian R_J's maximum absolute row
sum. Then the spectral norm of R_J is at most b_Z. Since a_0=1,
Σ_(r≥1)a_r=N/2−1, and Σ_J Tr X_J=8, equation (1) gives

    a_2 ≤ C + b_0 + (N/2−1)b_a + 8b_Z + e_KL.               (2)

The independent replay includes the conservative e_KL=10^−35, after bounding
its independently checked KL-vector defect. Every bound in (2) is rational
and checked directly by Arb interval comparisons. Floating calculations only
propose rational ceilings and have no acceptance authority.

The two witnesses were NOT modified after extraction. Earlier stricter
uniform-entry tolerances failed; their exact reported residual intervals are
retained in `VERIFICATION_HISTORY.md`, without internal filesystem paths. The
final improvement is a sharper valid residual estimate, not changing an
unfavorable coefficient or treating an approximate solution as exact.

| n | C | b_0 | b_a | b_Z |
|---|---|---|---|---|
|35|263532475962718709379/5000000000000000000000|441003/31250000000|86761/62500000000|45319/15625000000|
|36|565731345131909161349/5000000000000000000000|276097/1000000000000|66189/1000000000000|63403/1000000000000|

Including e_KL, these give raw bounds approximately 0.052767409608543744
and 0.11314821065488183. Exact independent fractions appear in the receipts.

## 5. Same-witness nonlinear sharpening

Put x=a_2, κ=√(128/(35N³)), and s=1/238 or 1/200. Let b be the sum of the
two nonnegative 222 multipliers in the SAME witness:

    b_35 = 2244147795503379/500000000000000;
    b_36 = 5205283836067749/500000000000000.

The sharp physical inequality improves each relaxed 222 row by
(s−κ√x)x, retaining the same rational rounding allowance. The analogous
211 improvement is nonnegative on the previously proved range and can be
dropped. Equation (2) therefore strengthens to

    x [1+b(s−κ√x)] ≤ U_raw.                               (3)

If x≤U has already been proved, upper-bounding κ√U supplies a LOWER bound
on the bracket. Consequently

    U_next=min(U, U_raw/[1+b max(0,s−upper(κ√U))])          (4)

is valid, with the quotient rounded UP. Each step is a finite exact rational
induction; no convergence, monotonicity of a cubic, or numerical fixed-point
claim is required. Both checkers use exact integer square-root ceilings and
record every step. Starting from 9/40 or 1/3, at most 20 steps yield the
fractions in Section 1, which lie below the convenient simple rational bounds.

## 6. Immutable proof objects and replay

Witness SHA256:

* n35: 598fdf35e856e56cab8a79b9dfcf989152bd1a6874f7bae7daf063e8035abcbb
* n36: aecc64a6ea7d6b02df4159656e881b12dc9613d1991ad1a2b35f9384c4664260

The companion contains both self-contained checkers (stdlib + python-flint),
original witnesses, independent exact receipts/audit, primary receipts,
normalization/necessity dependencies, and a clean failed-tolerance history.
The original solver, runtime, input/output ZIP, and numerical primal points
are discovery provenance, NOT prerequisites for verifying (1)–(4).

No exact feasible point, code extraction, universal minimum, external
peer-review, or novelty claim is made. A later sector-budget relaxation may
use these bounds, but requires its own applicability and certificate audit.
