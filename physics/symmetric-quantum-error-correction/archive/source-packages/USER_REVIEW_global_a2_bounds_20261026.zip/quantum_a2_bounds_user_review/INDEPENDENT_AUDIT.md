# Internal separate-implementation verification of global quadrupole bounds

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

**PASS, 26 October2026.** For every hypothetical unrestricted complex rank-two symmetric distance-seven code atn35 or36, let

`a2=(n+1)||P_2||_HS²/4`,

where P is its orthogonal code projector and P_2 its operator-rank2 component. The unchanged returned dual witnesses, independently reconstructed in full spin blocks, prove the necessary bounds below. These are NOT length exclusions, codes, or exact feasible-point claims. The35–37 minimum-length bracket is unchanged.

| n | independently certified linear-dual upper (approximately) | same-dual nonlinear bootstrap upper (approximately) | convenient certified rational upper |
|---|---:|---:|---:|
|35|0.052767409608543744|0.05225662473843775|2613/50000 =0.05226|
|36|0.11314821065488183|0.11064449907064336|2213/20000 =0.11065|

The exact, not rounded, upper fractions and all20-or-fewer outward-rational bootstrap steps are in `independent_n35.json` and `independent_n36.json`. The convenient rational comparisons were checked as Fractions. Prior certified bounds were9/40 and1/3.

## Immutable witnesses and independent arithmetic

-35 witness SHA `598fdf35e856e56cab8a79b9dfcf989152bd1a6874f7bae7daf063e8035abcbb`.
-36 witness SHA `aecc64a6ea7d6b02df4159656e881b12dc9613d1991ad1a2b35f9384c4664260`.

These ORIGINAL witness bytes are unchanged. No equality multiplier was secretly repaired, and no new optimization was run. The checker is `check_independent.py`, SHA `0c56e79ac2eb71531d36479a0e39359301f0cad2b8539ec43c0fab8d38f5c3ca`. It imports no discovery-model/solver code. It assembles rational-Gram PSD contributions, exact-factorial Racah/256-bit Arb coefficients, full R/D adjoints and exact symmetry/support projection, signed R-complement terms, Schur test-operator terms, and all hash-whitelisted affine cubic contributions INCLUDING their positive rounding constants. The rank2 objective coefficient is+1 in the residual, and dual normalization is1. Independent local-Casimir checks validate each used low-rank KL vector.

35 completed in38.1seconds;36 in112.9seconds, serially. The36 witness exercises15 Schur supports and38 R-complement supports as well as the four cubic rows. Every supplied PSD factor remains a rational Gram, so numerical eigenbasis/PSD tolerance is not a premise of the proof.

## Transparent residual handling

The initial requested uniform entry tolerance1e-7 failed at a35 moment coefficient9.30095e-7. At explicitly declared1e-5 all35 moment entries passed, but the residual a0 coefficient was1.4112094e-5. Primary and independent collectors agreed exactly; this was not a mathematical-model discrepancy. The exact reported failure intervals are retained in `VERIFICATION_HISTORY.md`; private traceback paths are omitted.

Rather than silently loosening every tolerance or changing the witness, the final check uses a standard sharper residual bound. Write the collected nonnegative functional as

`C-a2 + r0*a0 + sum_(r>=1) r_r*a_r + sum_J Tr(R_J X_J)`,

with a0=1, nonnegative remaining enumerators summing toN/2-1, PSD X_J and total trace8. If signedr0<=b0, every remaining |r_r|<=ba, and every Hermitian R_J has maximum absolute row-sum<=bZ, then

`a2 <= C + b0 + (N/2-1)*ba + 8*bZ`.

All b values are explicit rational upper bounds. Floating point only proposes their rational ceilings; every individual interval comparison is then directly proved by Arb. The checker also adds a conservative1e-35 allowance for its independent KL-vector residual control. No positive actual error is discarded. Exact ceilings are recorded in each receipt.

## Audited nonlinear sharpening from the same dual

The old222 global inequality uses slope s (1/238 at35,1/200 at36). Its exact physical counterpart has slope kappa*sqrt(x), where x=a2 and kappa=sqrt(128/[35N³]). If the nonnegative222 dual multipliers sum tob, replacing both relaxed cuts by their sharper valid versions gives

`x + b(s-kappa*sqrt(x))*x <= C+E`.

The analogous211 improvement is nonnegative on the prior range and is safely dropped. Starting with a provedx<=U, each update

`U_next=min(U,(C+E)/(1+b(s-kappa*sqrt(U))))`

is valid when its denominator is LOWER-bounded by outward arithmetic. The implementation uses upper rational square-root enclosures and upper rational rounding of the quotient. This is a finite induction, not an assumed contraction theorem or a numerical root. The observed improvement is modest; the multiplier sums are approximately4.4883 and10.4106.

## Scope and next-use boundary

The necessary cone/model and cubic normalizations are separately audited. This result sharpens the allowed quadrupole range for all complex codes at each fixed length; it does not impose realness, time reversal or a finite-group ansatz. It may be used as a GLOBAL bound in later valid perspective/secant relaxations. No further solve, interval branch, minimum theorem or novelty claim follows automatically.
