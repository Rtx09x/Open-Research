# Necessary quadrupole bounds — user review package

Read **START_HERE.txt** first. This package concerns necessary restrictions
on hypothetical unrestricted complex, rank-two, permutation-symmetric,
three-error-correcting codes at 35 and 36 qubits. It does not construct a
code or exclude either length. The inherited minimum-length bracket remains
35–37; this package does not re-prove that older bracket.

All checks described here are internally AI-assisted. Separate arithmetic
implementations are not external human peer review; priority is unestablished.

## Reading order

1. `GLOBAL_A2_BOUNDS_THEOREM.md`: precise hypotheses, inequalities and proof budget.
2. `VERIFICATION_HISTORY.md`: original numerical status and failed strict tests.
3. `INDEPENDENT_AUDIT.md`: separate-implementation full-space replay explanation.
4. `REPRODUCIBILITY.md`: actual commands, outputs, prerequisites and boundaries.
5. `dependencies/NECESSITY_NORMALIZATION_EXCERPT.md`,
   `dependencies/general_lift_and_faces.md`, and the Schur/cubic notes:
   analytic applicability, including arbitrary complex projectors.
6. `SOURCE_COMPARISON.json` and `MANIFEST.json`: source hashes, explicitly
   recorded edits and complete release-file integrity data.

The two original witnesses, both principal full-space checkers, all four
principal exact receipts and the scalar dual data are byte-preserved. Four
literal operator inputs are materialized byte-exactly from the witnesses.
Minimal missing operator and analytic dependencies supplement the source ZIP.
Only two ancillary checkers receive recorded input-path corrections; no
scientific arithmetic, witness coefficient or acceptance tolerance changes.

Use `python verify_package.py` for lightweight integrity/receipt checks. That
is packaging QA, **not** a replacement for reading the applicability proof
and running the full interval verification in `REPRODUCIBILITY.md`.
