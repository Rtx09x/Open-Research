# Reproducing the checks

## Environment and safety

Extract the ZIP into a writable disposable directory and change into its
single top-level folder. Preserve the original ZIP. The checkers write
receipts; several dependency commands overwrite their bundled receipts in
that disposable copy. No network service, account, solver, model module or
private filesystem path is needed by these programs.

The main interval checks require Python 3 plus `python-flint` (Arb). The
unchanged separate checker also uses the standard-library Unix `resource`
module: use Linux, macOS or WSL, not unmodified native Windows Python.
The packaging dependency replays passed with Python 3.12.14 and
python-flint 0.9.0. Optional symbolic controls also require SymPy (tested
with 1.14.0). Create an isolated environment and install those packages using
your normal package-management process if they are not already available.
These dependencies are not vendored; dependency installation may need internet.

## 1. Cheap file and receipt integrity check

```sh
python verify_package.py
```

This checks the release manifest, witness/receipt bindings, byte-identical
embedded operator files, exact residual-budget identities, every recorded
finite bootstrap step, and the advertised rational bounds. It does not
reconstruct the full moment coefficients or certify analytic applicability.
Run it before commands that overwrite bundled receipts.

## 2. Necessary scalar bounds and physical cubic operators

```sh
python dependencies/check_a2_bound_independent.py
python dependencies/check_cubic_operator_files_independent.py
```

The first uses only exact standard-library fractions. It reads
`dependencies/a2_interval_duals.json` and writes
`dependencies/check_a2_bound_independent.json`. The original receipt is
preserved separately as `dependencies/a2_bound_independent.json`.

The second reconstructs all four literal 211/222 operators from factorial
Racah expressions with 256-bit Arb arithmetic, checks their identity/rank/
normalization and rounding margins, and reads the four JSON files under
`operators/`. It writes `dependencies/cubic_operator_files_independent.json`.
The bundled original receipt and source hashes are preserved in the ZIP;
compare meaningful fields, not runtime, after a fresh run.

These two ancillary checkers have input-path-only corrections listed in
`SOURCE_COMPARISON.json`. Their arithmetic and acceptance tests are unchanged.
The four operator files are exactly the UTF-8 texts embedded in the original
witnesses, not reserialized numerical data.

Optional exact symbolic normalization controls (require SymPy):

```sh
python dependencies/check_cubic_spin_normalization_exact.py
python dependencies/check_T222_constant_exact.py
```

Each writes its corresponding `.json` alongside the script. These supplement
the analytic proofs rather than replacing those proofs with finite controls.

## 3. Full-space dual and same-witness nonlinear bootstrap

```sh
python check_independent.py witness_n35.json fresh_independent_n35.json
python check_independent.py witness_n36.json fresh_independent_n36.json
python check_primary.py witness_n35.json
python check_primary.py witness_n36.json
```

The primary checker writes `witness_n35_normwise_verified.json` and
`witness_n36_normwise_verified.json`, respectively. The separate checker
writes the explicit output filename. Both main checker scripts are unchanged
source bytes. Do not run Python with `-O`: acceptance checks use assertions.

The original separate-checker runs recorded 38.1 s and 112.9 s, with peak
memory about 214 and 341 MiB. Runtime and memory depend on platform. Expected
separate-receipt fields include `passed_global_a2_upper: true`,
`strict_negative_upper: false`, and final `bootstrap_upper` fractions:

- n=35: `10451324947687550484413970959/200000000000000000000000000000`
- n=36: `6915281191915210015028613979/62500000000000000000000000000`

They are strictly below `2613/50000` and `2213/20000`. The primary receipts
have the same final fractions, but their raw linear upper omits the separate
checker's extra conservative `1e-35` KL defect allowance. Timing, memory and
floating diagnostic displays are not exact acceptance objects.

## What the arithmetic does — and does not — establish

The dual programs assemble full-space coefficients and exact rational-Gram
PSD contributions. They bound residuals outward and reproduce the finite
rational bootstrap. Their cubic inputs are **hash-whitelisted**; that is why
the separate operator reconstruction in step 2 matters. The code also relies
on the mathematical necessity of the scalar, marginal, logical and Schur
maps, explained in the dependency proofs. A passed program is not a substitute
for checking that those maps apply to the intended code problem.

This packaging pass reran only the cheap scalar/operator/symbolic dependencies
and the lightweight exact receipt checks. It did not rerun the expensive
full-space dual calculations or any discovery solve. Existing full-space
receipts are original execution records bound by hashes, not digital signatures
or external attestations. Human proof notes were edited for privacy and clear
references; their original and revised hashes are recorded.

No replay here proves existence or nonexistence at 35 or 36 qubits. The
inherited 35–37 bracket is context, not a result re-established by this ZIP.
