# Verification history, without private execution paths

This is a clean explanation of internally AI-assisted verification, not a
human peer-review report. The literal witnesses, original success receipts
and their numerical discovery metadata are preserved byte-for-byte.

## Discovery was not a proof

Both numerical discovery runs reported `AlmostSolved`, not exact feasibility.
The n=35 witness retains its `Schur_diagnostic_error: AssertionError()`;
its scalar and cubic diagnostic minima include negative values. The n=36
witness likewise retains its small negative cubic diagnostic minimum. These
floats proposed the rational dual witnesses; they do not establish a code,
an exact feasible moment, or a rigorous bound by themselves.

## Failed stricter tests are retained, not erased

The initial n=35 uniform-entry tolerance `1e-7` failed at moment block
`J2=1`, entry `(0,0)`. The original reported interval was

```
[9.300951994215754653007159371778980580468224356789986252856681215322e-7 +/- 1.41e-74]
```

At declared tolerance `1e-5`, all n=35 moment entries passed, but the
constant-enumerator residual (`a0`, index 0) failed with interval

```
[1.411209419009362139917695473251028806584362139917695473251028806584362e-5 +/- 3.48e-75]
```

These exact intervals and test locations are transcribed from the two
source logs. Their private absolute traceback paths and timing boilerplate
are not distributed. Source log hashes are retained in SOURCE_COMPARISON.json.
The two raw logs are not needed for reproducing the successful calculation.

The successful proof uses a different, valid normwise error estimate:
keep a0=1 separately; use total remaining enumerator mass N/2−1; and bound
each Hermitian moment residual by its maximum absolute row sum. Nothing is
set to zero merely because it is small. All rational ceilings are checked
by outward-rounded interval comparisons. The separate checker adds a
conservative 1e-35 allowance for its checked KL-vector defect. Neither
literal dual witness was changed to obtain these checks.

## Operator-rounding tolerance history

The separate literal O211 audit first tried strict entry error <1e-8 at
n=35 and stopped at an error equal to 1e-8 up to interval enclosure. It then
proved the conservative <2e-8 entry bound. This still implies expectation
error below the originally declared 1e-5 slack; the cut constant was not
changed. The 222 entry error bound <1e-10 implies expectation error below
the retained 1e-7 slack. See dependencies/CUBIC_LITERAL_OPERATOR_AUDIT.md.

## Original successful receipts

The separate full-space dual runs recorded about 38.1 s (n=35) and 112.9 s
(n=36), and 556 / 574 checked KL vectors. Their outward-rational bootstrap
histories contain 14 / 17 entries, including the repeated final value.
The primary checker yields the same final fractions; its raw upper lacks
the separate checker's additional 1e-35 allowance. Neither raw upper is
negative, so neither run is a length exclusion.

Historical weaker-model feasibility, failed solves and numerical controls
in the dependency notes remain explicitly historical. They are not used
as substitutes for the current exact dual receipts. No expensive dual
proof run was repeated merely to repackage these files.
