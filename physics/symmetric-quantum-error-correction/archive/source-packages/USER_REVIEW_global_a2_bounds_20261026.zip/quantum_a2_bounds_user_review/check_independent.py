"""Independent GLOBAL a2 upper-bound replay, not an automatic exclusion.
No worker/model imports. Own rational Racah -> Arb; inherited independent
full-space collection plus explicit R/D, complement, Schur, and audited cubic terms.
"""
import json,sys,time,hashlib,resource,math
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
from flint import arb,arb_mat,fmpq,ctx
ctx.prec=256
source=Path(sys.argv[1]);outpath=Path(sys.argv[2]);raw=source.read_bytes();data=json.loads(raw)
n=data['n'];t=data['t'];N=n+1;j=Q(n,2);cspin=Q(n*(n+2),4)
assert data['objective']=='max_a2_upper' and data['dual_normalization']==1
scale=data['scale'];assert type(scale)==int and scale>0;assert (n,t,data['K'],data['distance']) in ((35,3,2,7),(36,3,2,7))
st=time.time()
def ball(x):x=Q(x);return arb(fmpq(x.numerator,x.denominator))
def rat(x):assert type(x)==int;return Q(x,scale)
def eye(d):return arb_mat([[int(a==b)for b in range(d)]for a in range(d)])
def zmat(d):return arb_mat(d,d)
def matrix(x):return arb_mat([[ball(rat(v))for v in row]for row in x])
def symmetric(A):return(A+A.transpose())/2
@lru_cache(None)
def factorial(k):return math.factorial(k)
@lru_cache(None)
def six(a,b,c,d,e,f):
 A,B,C,D,E,F=[int(2*x)for x in(a,b,c,d,e,f)];delta=Q(1)
 for x,y,z in((A,B,C),(A,E,F),(D,B,F),(D,E,C)):
  if(x+y+z)%2 or min(x+y-z,x-y+z,-x+y+z)<0:return arb(0)
  delta*=Q(factorial((x+y-z)//2)*factorial((x-y+z)//2)*factorial((-x+y+z)//2),factorial((x+y+z)//2+1))
 lo=[(A+B+C)//2,(A+E+F)//2,(D+B+F)//2,(D+E+C)//2];hi=[(A+B+D+E)//2,(A+C+D+F)//2,(B+C+E+F)//2]
 value=sum((Q((-1)**z*factorial(z+1),math.prod(factorial(z-l)for l in lo)*math.prod(factorial(h-z)for h in hi))for z in range(max(lo),min(hi)+1)),Q(0))
 return ball(value)*ball(delta).sqrt()
def sign(x):assert x==int(x);return (-1)**int(x)
blocks={}
for J2 in range(n%2,3*n+1,2):
 J=Q(J2,2);ls=[L for L in range(N)if abs(L-j)<=J<=L+j];d=len(ls);I=eye(d)
 swap23=arb_mat([[sign(n)*ball((2*L+1)*(2*K+1)).sqrt()*six(j,j,L,j,J,K)for K in ls]for L in ls])
 swap12=arb_mat([[sign(n-L)*int(a==b)for b in range(d)]for a,L in enumerate(ls)])
 swap13=swap12*swap23*swap12;G=[I,swap12,swap23,swap13,swap12*swap23,swap23*swap12]
 symproj=sum(G,zmat(d))/6;antiproj=(I-swap12-swap23-swap13+swap12*swap23+swap23*swap12)/6
 blocks[J2]={'J':J,'ls':ls,'I':I,'swap13':swap13,'swap23':swap23,'G':G,'sym':symproj,'std':I-symproj-antiproj,'support':I-antiproj,'dual':zmat(d),'ppt':zmat(d)}
 for A in(swap12,swap23,swap13):
  err=A*A-I;assert all(abs(err[a,b])<ball(Q(1,10**55))for a in range(d)for b in range(d))
M=[[sign(n+r+k)*(2*r+1)*six(j,j,r,j,j,k)for k in range(N)]for r in range(N)]
H=[[2*M[r][k]-int(r==k)for k in range(N)]for r in range(N)]
shadow=[[sign(k)*M[r][k]for k in range(N)]for r in range(N)]
a=[arb(0)for _ in range(N)];pair=[arb(0)for _ in range(N)]
y=list(map(rat,data['equality_dual']));constant=y[0]+Q(N,2)*y[1]
for k in range(N):a[k]=-ball(y[0])*int(k==0)-ball(y[1])-sum((ball(y[r+1])*H[r][k]for r in range(1,2*t+1)),arb(0))
it=iter(y[2+2*t:])
for L in range(N):
 sectors=[('sym',Q(4,3)),('std',Q(2,3))]if sign(n-L)==1 else[('std',Q(2))]
 for sector,ratio in sectors:
  yy=ball(next(it));pair[L]+=yy*ball(ratio)
  for block in blocks.values():
   if L in block['ls']:
    ix=block['ls'].index(L);E=zmat(len(block['ls']));E[ix,ix]=1;block['dual']-=yy*symmetric(E*block[sector])
try:next(it);raise AssertionError('equality length')
except StopIteration:pass
zs=data['enumerator_inequality_dual'];assert all(type(x)==int and x>=0 for x in zs);zz=iter(map(rat,zs))
for k in range(N):a[k]+=ball(next(zz))
for r in range(2*t+1,N):
 z=ball(next(zz))
 for k in range(N):a[k]+=z*H[r][k]
for L in range(N):
 z=ball(next(zz))
 for k in range(N):a[k]+=z*shadow[L][k]
try:next(zz);raise AssertionError('inequality length')
except StopIteration:pass
for k in range(N):a[k]+=sum((pair[L]*ball(Q(4,N))*shadow[L][k]for L in range(N)),arb(0))
for item in data['ordinary_PSD']:
 b=blocks[item['J2']];assert item['Ls']==b['ls'];A=matrix(item['basis_U'])*matrix(item['factor']);b['dual']+=A*A.transpose()
# Assemble logical duals in their OUTPUT blocks, then transpose the crossing.
for block in blocks.values():
 block['dual_R']=zmat(len(block['ls']));block['dual_D']=zmat(len(block['ls']))
for item in data['logical_PSD']:
 b=blocks[item['J2']];V=matrix(item['factor']);G=V*V.transpose()
 if item['kind']=='R':
  assert item['Ls']==b['ls'];b['dual_R']+=G
 else:
  assert item['kind']=='D';high=[i for i,L in enumerate(b['ls'])if L>2*t]
  assert item['Ls']==[b['ls'][i]for i in high]
  U=arb_mat([[b['swap23'][i,k]for k in high]for i in range(len(b['ls']))]);b['dual_D']+=U*G*U.transpose()
for item in data.get('R_complement_supports',[]):
 mu=rat(item['multiplier']);assert mu>=0 and item['denominator']>0
 b=blocks[item['J2']];assert b['ls']==item['Ls'];v=arb_mat([[ball(Q(x,item['denominator']))]for x in item['numerators']]);w=b['swap23']*v
 for i,L in enumerate(b['ls']):a[L]+=ball(4*mu/Q(N*(2*L+1)))*w[i,0]**2
 b['dual_R']-=ball(mu)*v*v.transpose()
for J2,b in blocks.items():
 d=len(b['ls']);R=zmat(d);D=zmat(d)
 for p,L in enumerate(b['ls']):
  for q,Lp in enumerate(b['ls']):
   for K2,z in blocks.items():
    if L not in z['ls']or Lp not in z['ls']:continue
    u,v=z['ls'].index(L),z['ls'].index(Lp);coef=sign(n)*six(L,j,b['J'],Lp,j,z['J'])
    R[p,q]+=coef*z['dual_R'][u,v];D[p,q]+=coef*z['dual_D'][u,v]
 b['dual']+=D+symmetric((R-D/2)*b['swap13'])
# First-factor Schur supports, using independently rebuilt operator-rank channels.
def conjugate(X):return {J:b['swap13']*X[J]*b['swap13']for J,b in blocks.items()}
def rankpart(X,r):
 Y={J:zmat(len(b['ls']))for J,b in blocks.items()};norm=arb(0)
 for L in range(N):
  for K in range(L,min(N,L+r+1)):
   if L+K<r:continue
   js=[J for J,b in blocks.items()if L in b['ls']and K in b['ls']]
   u={J:sign(L+j+blocks[J]['J'])*ball((J+1)*(2*r+1)).sqrt()*six(L,j,blocks[J]['J'],j,K,r)for J in js}
   coeff=sum((u[J]*ball(J+1).sqrt()*X[J][blocks[J]['ls'].index(L),blocks[J]['ls'].index(K)]for J in js),arb(0))
   norm+=(1 if L==K else 2)*coeff**2
   for J in js:
    p,q=blocks[J]['ls'].index(L),blocks[J]['ls'].index(K);Y[J][p,q]=Y[J][q,p]=u[J]*coeff/ball(J+1).sqrt()
 return Y,norm
for item in data.get('Schur_supports',[]):
 mu=rat(item['multiplier']);r=item['target_rank'];den=item['denominator'];assert mu>=0 and 0<=r<=n and den>0
 if mu==0:continue
 W={}
 for rec in item['test_blocks']:
  J=rec['J2'];assert rec['Ls']==blocks[J]['ls'];W[J]=arb_mat([[ball(Q(x,den))for x in row]for row in rec['numerators']])
 assert set(W)==set(blocks);U,_=rankpart(conjugate(W),r);U=conjugate(U)
 for k in range(N):
  _,size=rankpart(U,k);a[k]+=ball(4*mu/Q(N*(2*k+1)))*size
 a[r]+=ball(8*mu/N)
 for J,b in blocks.items():b['dual']-=ball(2*mu)*U[J]
APPROVED={'n35_rational_cubic_cut.json':'ddc144086b6f793e8cc00e9b4a75f6b40771a4139367d74493c93ab906fa4388','n36_rational_cubic_cut.json':'dae368180c870dfb163db19c3a8b83b894c5a21d4bbbfb960d09bd4a039c427a','quadrupole_cubic_cut_n35.json':'4c29369ca57646333eb367a47199213c6ce3664081572e428e42ba3e2ea34abc','quadrupole_cubic_cut_n36.json':'abed3a64d7e3c93150b2ec967bd1f86484fc8c020c7b0f90820aafe432618c2b'}
for item in data.get('cubic_supports',[]):
 mu=rat(item['multiplier']);assert mu>=0;name=item['source'];text=data['cubic_operators'][name]
 assert hashlib.sha256(text.encode()).hexdigest()==APPROVED[name]==item['source_sha256'];op=json.loads(text);assert op['n']==n;sg=item['sign'];assert sg in(-1,1)
 if item['family']=='211':r=1;alpha=Q(op['a1_coefficient']);delta=Q(op['rational_error_slack_numerator'],op['rational_error_slack_denominator']);den=op['matrix_entry_denominator']
 else:
  assert item['family']=='222';r=2;alpha=Q(op['bound_a2_coefficient']);delta=Q(op['additive_bound']);den=op['scale']
 a[r]+=ball(mu*alpha);constant+=mu*delta
 assert sorted(rec['J2']for rec in op['blocks'])==sorted(blocks)
 for rec in op['blocks']:
  J=rec['J2'];b=blocks[J];assert rec['Ls']==b['ls'];T=zmat(len(b['ls']))
  if r==1:
   for p,q,x in rec['upper']:T[p,q]=T[q,p]=ball(Q(x,den))
  else:T=arb_mat([[ball(Q(x,den))for x in row]for row in rec['numerators']])
  b['dual']-=ball(mu*sg)*T
print('Independent cone coefficients ready',time.time()-st,flush=True)
# Cache exact local-Casimir matrices; independently check intended low-rank vectors.
@lru_cache(None)
def casimir(L,Lp):
 bs=[(J2,b)for J2,b in blocks.items()if L in b['ls']and Lp in b['ls']];js=[b['J']for _,b in bs]
 C=arb_mat([[ball(2*cspin)*(int(K==J)-N*sign(L+Lp)*ball((2*K+1)*(2*J+1)).sqrt()*six(j,K,L,J,j,1)*six(j,K,Lp,J,j,1))for J in js]for K in js])
 return bs,C
maxkl=0.;budgetkl=Q(0);seen=set()
for item in data['KL']:
 L,Lp,r=item['L'],item['Lp'],item['r'];assert abs(L-Lp)<=r<=min(L+Lp,n,2*t);yy=rat(item['multiplier']);bs,C=casimir(L,Lp)
 v=[sign(L+j+b['J'])*ball((2*b['J']+1)*(2*r+1)).sqrt()*six(L,j,b['J'],j,Lp,r)for _,b in bs]
 key=(L,Lp,r)
 if key not in seen:
  seen.add(key);lam=r*(r+1)
  assert abs(sum((x*x for x in v),arb(0))-1)<ball(Q(1,10**50))
  for p in range(len(bs)):
   defect=sum((C[p,q]*v[q]for q in range(len(bs))),arb(0))-lam*v[p]
   assert abs(defect)<ball(Q(1,10**50)),('KL eigenvector',key,p,str(defect));maxkl=max(maxkl,float(abs(defect).upper()))
 # Gap to rank 2t+1 at least (2t+1)(2t+2)-r(r+1).
 # Coarse sqrt dimension<=N, ||(2Swap-I)Z||<=3TrZ=24.
 budgetkl+=abs(yy)*Q(24*N,10**50*((2*t+1)*(2*t+2)-r*(r+1)))
 for (_,b),vv in zip(bs,v):
  d=len(b['ls']);p=b['ls'].index(L);q=b['ls'].index(Lp);E=zmat(d);E[q,p]=1
  b['dual']-=ball(yy)*vv/ball(2*b['J']+1).sqrt()*symmetric(E*(2*b['swap13']-b['I']))
a[2]+=1 # Collected identity C-a2+residual.
# Standard sharper residual accounting. Float proposes; Arb proves every ceiling.
def rational_upper(value,den=10**12):
 q=Q(math.ceil(float(value.upper())*den)+1,den)
 while not value<ball(q):q+=Q(1,den)
 return q
matrix_bound=Q(0);maxres=0.
for J2,b in blocks.items():
 D=symmetric(b['dual']);D=sum((g*D*g.transpose()for g in b['G']),zmat(len(b['ls'])))/6;D=b['support']*D*b['support']
 for p0 in range(D.nrows()):
  row=sum((abs(D[p0,q])for q in range(D.ncols())),arb(0))
  matrix_bound=max(matrix_bound,rational_upper(row))
  for q in range(D.ncols()):maxres=max(maxres,float(abs(D[p0,q]).upper()))
a0_bound=rational_upper(a[0]);enum_bound=max((rational_upper(abs(x))for x in a[1:]),default=Q(0))
assert budgetkl<Q(1,10**35)
budget=a0_bound+(Q(N,2)-1)*enum_bound+8*matrix_bound
upper=constant+budget+Q(1,10**35)
print('ALL_RESIDUAL_BUDGETS_PROVED',str(constant),str(a0_bound),str(enum_bound),str(matrix_bound),flush=True)
# Independent outward-rational iteration. Strict sqrt overestimate is intentional.
def upper_sqrt(x):
 assert x>=0;den=10**30
 return Q(math.isqrt(x.numerator*den*den//x.denominator)+1,den)
def upper_grid(x):
 den=10**30
 return Q(-((-x.numerator*den)//x.denominator),den)
prior=Q(9,40)if n==35 else Q(1,3);slope=Q(1,238)if n==35 else Q(1,200)
mu=sum((rat(item['multiplier'])for item in data.get('cubic_supports',[])if item['family']=='222'),Q(0));assert mu>=0
U=prior;history=[]
if upper>=0:
 for step in range(20):
  gap=max(Q(0),slope-upper_sqrt(Q(128)*U/(35*N**3)))
  V=min(U,upper_grid(upper/(1+mu*gap)))
  history.append(str(V))
  if V==U:break
  U=V
out={'passed_global_a2_upper':True,'objective':'max_a2_upper','dual_normalization':1,'n':n,'t':t,'certificate_sha256':hashlib.sha256(raw).hexdigest(),'constant_exact':str(constant),'main_residual_budget':str(budget),'a0_signed_upper_coefficient':str(a0_bound),'remaining_enum_abs_bound':str(enum_bound),'matrix_absolute_row_sum_bound':str(matrix_bound),'extra_KL_defect_bound':str(budgetkl),'extra_KL_coarse_budget':str(Q(1,10**35)),'global_a2_upper_exact':str(upper),'strict_negative_upper':upper<0,'prior_upper':str(prior),'sharp222_multiplier_sum':str(mu),'bootstrap_upper':str(U)if upper>=0 else None,'bootstrap_history':history,'KL_vectors_checked':len(seen),'diagnostic_max_KL_eigenresidual':maxkl,'diagnostic_max_moment_entry_residual':maxres,'diagnostic_max_enum_residual':max(float(abs(v).upper())for v in a),'seconds':time.time()-st,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'residual_method':'a0 exact; remaining enum mass N/2-1; Hermitian absolute row sums','arithmetic':'Independent factorial-rational6j to256bit Arb; full-space collection and KL Casimir checks; no worker imports','scope':'Necessary GLOBAL bound for unrestricted complex rank-two distance7 codes. A positive upper is NOT a length exclusion, code, or exact feasible-point theorem.'}
outpath.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
