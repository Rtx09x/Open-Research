"""Standalone exact GLOBAL a2 upper-bound collector; not an automatic no-go.
Only stdlib and python-flint. Exact rational Gram PSD factors; factorial Racah
6j coefficients enclosed by outward-rounded Arb balls. No solver/model import.
"""
import json,sys,math,time,hashlib
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
from flint import arb,arb_mat,fmpq,ctx
ctx.prec=256
ROOT=Path(__file__).parent;FILE=Path(sys.argv[1]);raw=FILE.read_bytes();c=json.loads(raw);n=c['n'];t=c['t'];N=n+1;assert(n,t,c['K'],c['distance'])in[(35,3,2,7),(36,3,2,7)];scale=c['scale'];assert scale>0 and c['objective']=='max_a2_upper' and c['dual_normalization']==1

def aq(x):
 x=Q(x);return arb(fmpq(x.numerator,x.denominator))
def rq(v):return Q(int(v),scale)
def mat(x):return arb_mat([[aq(rq(v))for v in row]for row in x])
def zero(d):return arb_mat(d,d)
def eye(d):return arb_mat([[int(a==b)for b in range(d)]for a in range(d)])
def sym(A):return(A+A.transpose())/2
def gram(x):
 A=mat(x['factor']);return A*A.transpose()
@lru_cache(None)
def f(k):return math.factorial(k)
@lru_cache(None)
def six2(a,b,c,d,e,f0):
 delta=Q(1)
 for x,y,z in[(a,b,c),(a,e,f0),(d,b,f0),(d,e,c)]:
  if(x+y+z)%2 or min(x+y-z,x-y+z,-x+y+z)<0:return arb(0)
  delta*=Q(f((x+y-z)//2)*f((x-y+z)//2)*f((-x+y+z)//2),f((x+y+z)//2+1))
 lo=[(a+b+c)//2,(a+e+f0)//2,(d+b+f0)//2,(d+e+c)//2];hi=[(a+b+d+e)//2,(a+c+d+f0)//2,(b+c+e+f0)//2]
 val=sum((Q((-1)**z*f(z+1),math.prod(f(z-u)for u in lo)*math.prod(f(u-z)for u in hi))for z in range(max(lo),min(hi)+1)),Q(0))
 return aq(val)*aq(delta).sqrt()
start=time.time();M=arb_mat([[(-1)**(n+r+k)*(2*r+1)*six2(n,n,2*r,n,n,2*k)for k in range(N)]for r in range(N)]);H=2*M-eye(N);shadow=arb_mat([[(-1)**k*M[r,k]for k in range(N)]for r in range(N)]);pair=aq(Q(4,N))*shadow;blocks={}
for J2 in range(n%2,3*n+1,2):
 ls=[L for L in range(N)if abs(2*L-n)<=J2<=2*L+n];d=len(ls);I=eye(d);F=arb_mat([[(-1)**n*arb((2*L+1)*(2*K+1)).sqrt()*six2(n,n,2*L,n,J2,2*K)for K in ls]for L in ls]);D=arb_mat([[(-1)**(n-L)if a==b else 0 for b in range(d)]for a,L in enumerate(ls)]);F13=D*F*D;group=[I,D,F,F13,D*F,F*D];Psy=sum(group,zero(d))/6;Pa=(I-D-F-F13+D*F+F*D)/6;blocks[J2]=dict(ls=ls,I=I,F=F,F13=F13,group=group,Psy=Psy,Pstd=I-Psy-Pa,support=I-Pa,R=zero(d),BR=zero(d),BD=zero(d))
 assert all(abs((F*F-I)[a,b])<arb('1e-40')for a in range(d)for b in range(d))
ra=[arb(0)for _ in range(N)];y=list(map(rq,c['equality_dual']));constant=y[0]+Q(N,2)*y[1]
for k in range(N):ra[k]-=aq(y[0])*int(k==0)+aq(y[1])+sum((aq(y[r+1])*H[r,k]for r in range(1,2*t+1)),arb(0))
at=2+2*t
for L in range(N):
 even=(n-L)%2==0
 for kind in(['Psy','Pstd']if even else['Pstd']):
  yy=aq(y[at]);at+=1;fac=Q(4,3)if kind=='Psy'else(Q(2,3)if even else Q(2))
  for k in range(N):ra[k]+=yy*aq(fac)*pair[L,k]
  for b in blocks.values():
   if L not in b['ls']:continue
   a=b['ls'].index(L);E=zero(len(b['ls']));E[a,a]=1;b['R']-=yy*sym(b[kind]*E)
assert at==len(y)
z=[aq(rq(v))for v in c['enumerator_inequality_dual']];assert all(int(v)>=0 for v in c['enumerator_inequality_dual']);at=0
for r in range(N):ra[r]+=z[at];at+=1
for r in range(2*t+1,N):
 for k in range(N):ra[k]+=z[at]*H[r,k]
 at+=1
for r in range(N):
 for k in range(N):ra[k]+=z[at]*shadow[r,k]
 at+=1
assert at==len(z)
for item in c['ordinary_PSD']:
 b=blocks[item['J2']];assert item['Ls']==b['ls'];U=mat(item['basis_U']);V=U*mat(item['factor']);b['R']+=V*V.transpose()
for item in c['logical_PSD']:
 b=blocks[item['J2']];A=gram(item);d=len(b['ls'])
 if item['kind']=='R':
  assert item['Ls']==b['ls'];b['BR']+=A
 elif item['kind']=='D':
  high=[k for k,L in enumerate(b['ls'])if L>2*t];assert item['Ls']==[b['ls'][k]for k in high]
  U=arb_mat([[b['F'][a,k]for k in high]for a in range(d)]);b['BD']+=U*A*U.transpose()
 else:raise AssertionError('unknown cone')
# Separately nonnegative R-complement tests: negative R coefficient is intentional.
for item in c.get('R_complement_supports',[]):
 mu=rq(item['multiplier']);assert mu>=0 and item['denominator']>0;bb=blocks[item['J2']];assert item['Ls']==bb['ls'];v=arb_mat([[aq(Q(int(x),item['denominator']))]for x in item['numerators']]);fv=bb['F'].transpose()*v
 for i,L in enumerate(bb['ls']):ra[L]+=aq(4*mu/Q(N*(2*L+1)))*fv[i,0]**2
 bb['BR']-=aq(mu)*(v*v.transpose())
for J2,b in blocks.items():
 d=len(b['ls']);QR=zero(d);QD=zero(d)
 for a,L in enumerate(b['ls']):
  for e,Lp in enumerate(b['ls'][:a+1]):
   vr=arb(0);vd=arb(0)
   for K2,bb in blocks.items():
    if L in bb['ls']and Lp in bb['ls']:
     coef=(-1)**n*six2(2*L,n,J2,2*Lp,n,K2);ii,jj=bb['ls'].index(L),bb['ls'].index(Lp);vr+=coef*bb['BR'][ii,jj];vd+=coef*bb['BD'][ii,jj]
   QR[a,e]=QR[e,a]=vr;QD[a,e]=QD[e,a]=vd
 b['R']+=sym(QR*b['F13'])+QD-sym(QD*b['F13'])/2
# Exact rank projection of unweighted Hermitian invariant operators.
def conjugate(A,key):return {J:b[key]*A[J]*b[key]for J,b in blocks.items()}
def project_rank(A,r):
 out={J:zero(len(b['ls']))for J,b in blocks.items()};norm=arb(0)
 for L in range(N):
  for Lp in range(L,min(N,L+r+1)):
   if L+Lp<r:continue
   js=[J for J,b in blocks.items()if L in b['ls']and Lp in b['ls']]
   co={J:(-1)**((2*L+n+J)//2)*arb((J+1)*(2*r+1)).sqrt()*six2(2*L,n,J,n,2*Lp,2*r)for J in js}
   z=sum((co[J]*arb(J+1).sqrt()*A[J][blocks[J]['ls'].index(L),blocks[J]['ls'].index(Lp)]for J in js),arb(0));norm+=(1 if L==Lp else 2)*z*z
   for J in js:
    a,d=blocks[J]['ls'].index(L),blocks[J]['ls'].index(Lp);out[J][a,d]=out[J][d,a]=co[J]*z/arb(J+1).sqrt()
 return out,norm
for item in c.get('Schur_supports',[]):
 mu=rq(item['multiplier']);assert mu>=0 and item['denominator']>0 and 0<=item['target_rank']<=n
 if mu==0:continue
 W={}
 for rec in item['test_blocks']:
  J=rec['J2'];assert rec['Ls']==blocks[J]['ls'];W[J]=arb_mat([[aq(Q(int(v),item['denominator']))for v in row]for row in rec['numerators']])
 assert set(W)==set(blocks);U,_=project_rank(conjugate(W,'F13'),item['target_rank']);U=conjugate(U,'F13')
 for r in range(N):
  _,norm=project_rank(U,r);ra[r]+=aq(Q(4*mu,N*(2*r+1)))*norm
 ra[item['target_rank']]+=aq(8*mu/N)
 for J,b in blocks.items():b['R']-=aq(2*mu)*U[J]
# Literal rational cubic inequalities: their four operator hashes are independently audited.
approved={'n35_rational_cubic_cut.json':'ddc144086b6f793e8cc00e9b4a75f6b40771a4139367d74493c93ab906fa4388','n36_rational_cubic_cut.json':'dae368180c870dfb163db19c3a8b83b894c5a21d4bbbfb960d09bd4a039c427a','quadrupole_cubic_cut_n35.json':'4c29369ca57646333eb367a47199213c6ce3664081572e428e42ba3e2ea34abc','quadrupole_cubic_cut_n36.json':'abed3a64d7e3c93150b2ec967bd1f86484fc8c020c7b0f90820aafe432618c2b'}
for item in c.get('cubic_supports',[]):
 mu=rq(item['multiplier']);assert mu>=0;name=item['source'];text=c['cubic_operators'][name];assert hashlib.sha256(text.encode()).hexdigest()==approved[name]==item['source_sha256'];op=json.loads(text);assert op['n']==n;sign=item['sign'];assert sign in(-1,1)
 if item['family']=='211':rank=1;alpha=Q(op['a1_coefficient']);delta=Q(op['rational_error_slack_numerator'],op['rational_error_slack_denominator']);den=op['matrix_entry_denominator']
 elif item['family']=='222':rank=2;alpha=Q(op['bound_a2_coefficient']);delta=Q(op['additive_bound']);den=op['scale']
 else:raise AssertionError('unknown cubic family')
 ra[rank]+=aq(mu*alpha);constant+=mu*delta
 for rec in op['blocks']:
  J=rec['J2'];b=blocks[J];assert rec['Ls']==b['ls'];T=zero(len(b['ls']))
  if rank==1:
   for i,j,v in rec['upper']:T[i,j]=T[j,i]=aq(Q(int(v),den))
  else:T=arb_mat([[aq(Q(int(v),den))for v in row]for row in rec['numerators']])
  b['R']-=aq(mu*sign)*T
print('logical cone lift seconds',time.time()-start,flush=True)
for item in c['KL']:
 L,Lp,r=item['L'],item['Lp'],item['r'];assert abs(L-Lp)<=r<=min(L+Lp,n,2*t);yy=aq(rq(item['multiplier']))
 for J2,b in blocks.items():
  if L not in b['ls']or Lp not in b['ls']:continue
  coeff=(-1)**((2*L+n+J2)//2)*arb(2*r+1).sqrt()*six2(2*L,n,J2,n,2*Lp,2*r);a,d=b['ls'].index(L),b['ls'].index(Lp);A=2*b['F13']-b['I'];R=zero(len(b['ls']))
  for k in range(len(b['ls'])):R[d,k]=A[a,k]
  b['R']-=yy*coeff*sym(R)
ra[2]+=1 # collected functional is C-a2+residual
# Sharper rigorous residual accounting on the SAME unchanged witness.
# Floats only propose rational bounds; every bound is verified against Arb.
row_balls=[];maxZ=0.
for J2,b in blocks.items():
 R=sym(b['R']);R=sum((G*R*G.transpose()for G in b['group']),zero(len(b['ls'])))/6;R=b['support']*R*b['support']
 for a in range(R.nrows()):
  row_balls.append(sum((abs(R[a,d])for d in range(R.ncols())),arb(0)))
  for d in range(R.ncols()):maxZ=max(maxZ,float(abs(R[a,d]).upper()))
def propose_upper(x,den=10**12):return Q(math.ceil(float(x.upper())*den)+1,den)
row_bound=max((propose_upper(v)for v in row_balls),default=Q(1,10**12));a_bound=max((propose_upper(abs(v))for v in ra[1:]),default=Q(1,10**12));a0_upper=propose_upper(ra[0])
assert all(v<aq(row_bound)for v in row_balls)
assert all(abs(v)<aq(a_bound)for v in ra[1:])
assert ra[0]<aq(a0_upper)
budget=8*row_bound+(Q(N,2)-1)*a_bound;upper=constant+a0_upper+budget
# A rigorously rounded scalar bootstrap from the SAME exact witness.
def ceil_rational(x,den=10**30):return Q((x.numerator*den+x.denominator-1)//x.denominator,den)
def sqrt_upper(x,den=10**30):
 assert x>=0;k=math.isqrt(x.numerator*den**2//x.denominator)
 if k*k*x.denominator<x.numerator*den**2:k+=1
 return Q(k,den)
prior=Q(9,40)if n==35 else Q(1,3);slope=Q(1,238)if n==35 else Q(1,200);mu=sum((rq(i['multiplier'])for i in c.get('cubic_supports',[])if i['family']=='222'),Q(0));U=prior;history=[]
if upper>=0:
 for iteration in range(20):
  decrement=max(Q(0),slope-sqrt_upper(Q(128)*U/(35*N**3)));new=min(U,ceil_rational(upper/(1+mu*decrement)));history.append(str(new))
  if new==U:break
  U=new
out=dict(n=n,t=t,rigorously_verified_a2_upper=True,witness_sha256=hashlib.sha256(raw).hexdigest(),constant_exact=str(constant),full_block_row_sum_bound_exact=str(row_bound),remaining_enumerator_entry_bound_exact=str(a_bound),signed_a0_residual_upper_exact=str(a0_upper),diagnostic_max_block_row_sum=max(float(v.upper())for v in row_balls),nonconstant_residual_budget_exact=str(budget),global_a2_upper_exact=str(upper),prior_a2_upper=str(prior),sharp222_multiplier_sum=str(mu),bootstrap_a2_upper_exact=(str(U)if upper>=0 else None),bootstrap_history=history,diagnostic_max_Z_residual=maxZ,diagnostic_max_a_residual=max(float(abs(v).upper())for v in ra),seconds=time.time()-start,scope='Unrestricted complex symmetric rank2 distance7 necessary bound. Independent numerical-witness replay and model audit remain separate. Positive upper is NOT a length exclusion.')
FILE.with_name(FILE.stem+'_normwise_verified.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2),flush=True)
