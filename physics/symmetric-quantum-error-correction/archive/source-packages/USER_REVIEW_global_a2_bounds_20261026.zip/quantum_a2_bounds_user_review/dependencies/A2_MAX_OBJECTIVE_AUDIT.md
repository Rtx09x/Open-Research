# Global a2 maximization: objective/sign audit

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

Historical source/analytic objective audit: PASS for the discovery solver with SHA256 `5354432a3049bb26027b18f50da68825e7f51b82e362e793805bd7f64cadb590`. That solver is not a replay dependency and is not shipped. The mathematical sign argument is reproduced below.

This is a source/analytic check, not a solve or an a2-bound certificate. The exact diff from the previously reviewed cubic solver makes only the intended mathematical changes: the extra phase-I coordinateq is fixed by the zero-cone equalityq=0, the objective becomes−a2, the extra equality is correctly unpacked as one unrestricted dual scalar, and reported candidate upper is minus the minimization dual cost. All inherited physical constraints and cubic additive margins are unchanged.

With Clarabel convention A x+s=b, the objective−a2 has dual value−b·z, a lower bound on min(−a2). Thus b·z is an upper bound on a2 only for a genuinely dual-feasible exact certificate. Discovery floats alone do not prove it. In the full-space collector, the conic/equality combination should have the form C−a2+R; add+1 to residual scalar coefficient2 when testing cancellation. Use multiplier normalization1, NOT the earlier phase-I normalization1/N². The fixedq equality has zero RHS and no contribution on the physical q=0 slice. Cubic contributions retain the positive constant+mu*delta. The exact accepted upper is C plus the full residual budget, not the printed numerical dual objective.

A toy exact sign control is min−x subject to U−x+q/N²>=0 andq=0. Nonnegative inequality dual1 and equality dual1/N² give stationarity, dual cost−U, hence upperU. This verifies that retaining the q coefficients while fixingq introduces no sign reversal or extra physical constant.

## Same-dual nonlinear sharpening

Let a verified global bound identity have222 multiplier sum b>=0 and rational global slope s. On a code with x=a2, replacing each relaxed linear cubic inequality by its sharper valid counterpart subtracts b(s−kappa sqrt(x))x from the nonnegative combination, where kappa=sqrt(128/(35N³)). Thus

`x + b(s−kappa sqrt(x))x <= C+E`

after dropping any similarly nonnegative211 improvement. For a previously certified x<=U with s−kappa sqrt(U)>=0, this implies

`x <= (C+E)/(1+b(s−kappa sqrt(U)))`.

Outward arithmetic must LOWER-bound the denominator. Induction justifies repeated certified upper refinements; no monotonicity of a cubic polynomial is needed. It may give no useful improvement and is not a contradiction merely because it contracts one loose bound. A negative C+E would already be an exclusion; otherwise a code remains possible. No extra solve or branch is licensed by this observation.
