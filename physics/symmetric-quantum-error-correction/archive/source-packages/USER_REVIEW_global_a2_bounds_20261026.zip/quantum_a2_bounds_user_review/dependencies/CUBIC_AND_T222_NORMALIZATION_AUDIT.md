# Cubic invariant cuts: independent normalization and scalar-bound audit

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

Status: analytic applicability and exact small controls PASS. This does not certify a global35/36 exclusion. The external rational approximants to all large-spin O blocks are not independently interval-replayed in this note; the separate literal-operator audit in `CUBIC_LITERAL_OPERATOR_AUDIT.md` addresses that step.

## External dipole–quadrupole inequality

Let `j=n/2`, `N=n+1`, `c=j(j+1)`, `Q_ab={J_a,J_b}/2−cδ_ab I/3`. For any Hermitian P, `d_a=Tr(PJ_a)` is real and `q_ab=Tr(PQ_ab)` is a real symmetric traceless matrix, even when the code amplitudes are complex.

The exact trace tensor is

`Tr(Q_ab Q_cd)=Nc(4c−3)/30 * [(δ_acδ_bd+δ_adδ_bc)/2−δ_abδ_cd/3]`.

It follows from irreducibility and `Tr(Q_zz²)=Nc(4c−3)/45`; the latter follows directly from `Tr(J_z²)=Nc/3` and `Tr(J_z⁴)=Nc(3c−1)/15`. In the audited enumerator convention,

`||d||²=4c a1/3`, `||q||F²=2c(4c−3)a2/15`.

For `O=Σ_ab Q_ab^(1)J_a^(2)J_b^(3)`, invariance gives `Tr(ZO)=d^Tqd`. The squared norm of `dd^T−||d||²I/3` is `2||d||⁴/3`. Therefore

`|Tr(ZO)|²≤[64c³(4c−3)/405] a1² a2`.

This argument requires Hermiticity, not real codewords, Kramers invariance or a finite-group ansatz. The operator identity

`O={K12,K13}/2−cK23/3`, with `Kij=J^(i)·J^(j)`,

is exact. `check_cubic_spin_normalization_exact.py` verifies the trace formulas for n2…10 and the complete small complex physical operator identity and trace using exact arithmetic.

## Scalar replay and globally valid linear slopes

`check_a2_bound_independent.py` rebuilds the rational Racah/MacWilliams matrices and all scalar/shadow rows independently, with no optimizer/model import. The native duals give

-35: `a2≤21829313370032021521453/98496226852400000000000 <9/40`;
-36: `a2≤773312935260586482439085939/2526717968843757780000000000 <1/3`.

Exact rational comparison then gives the valid GLOBAL linear bounds

-35: `|Tr(ZO)|≤40000 a1`;
-36: `|Tr(ZO)|≤54000 a1`.

The respective strict squared margins using9/40 and1/3 are `741023915/18` and `39829248`.

A historical alternative eight-equality/28-inequality sparse certificate was also separately replayed internally (that alternative certificate and replay are not included or needed here). Its exact bound is indeed `574057297/2590000000 = approximately0.221643744015444`, below9/40. Its coefficient residual is `48547/46620000000`. This is slightly weaker than the native bound, but fully sufficient for40000. No claim relies on an incorrectly transcribed decimal.

## Native T222 inequality

Hermitian rank2 spin tensors form the real five-dimensional representation identified with real symmetric traceless3×3 matrices. The invariant quartic space is one-dimensional: `Tr(Q⁴)=(Tr(Q²))²/2`. Consequently `||CG_2(v⊗v)||²` is a constant multiple of `||v||⁴`. On the unit axial vector `v=e0`,

`CG(2,0;2,0 |2,0)=−sqrt(2/7)`,

so the constant is exactly2/7. Coupling this rank2 output with the third rank2 vector to the normalized invariant singlet introduces1/sqrt5. Thus the unit-norm invariant T222 obeys

`|〈T222,Z〉|²≤(2/35)||Π2 P||⁶ =128 a2³/(35N³)`.

The axial vector saturates the underlying spin2 estimate. Hermiticity supplies the real-representation condition for arbitrary complex code projectors. `check_T222_constant_exact.py` verifies the Cartesian polynomial identity and both exact CG factors.

Combining any valid scalar upper bound `a2≤U2` gives the GLOBAL linear necessary inequality

`|〈T222,Z〉|≤sqrt[128U2/(35N³)] a2`.

A proposed numerical T222 must be independently checked for unit Hilbert–Schmidt norm, local operator ranks(2,2,2), and its phase. Those operator-extraction checks are separate from the present normalization proof; the sign is immaterial only when both ± linear cuts are included.
