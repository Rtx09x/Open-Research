# Independent literal211/222 operator-file audit

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

**PASS, 26 October2026.** This closes the literal coupled-spin operator identification and rational-rounding step, supplementing (not modifying) `CUBIC_AND_T222_NORMALIZATION_AUDIT.md`. It does not establish infeasibility of any length.

The separately implemented, path-portable checker `check_cubic_operator_files_independent.py` imports only stdlib and python-flint, not discovery, numerical eigensolver, SDP or discovery-model code. It reconstructs the Racah coefficients by factorial Fractions and256-bit Arb intervals. All spin blocks and ordered pair-spin lists are independently enumerated; swaps are checked orthogonal. This is the same physically audited coupled-spin convention used in the internal rank-pair/physical controls.

For211 it builds the literal `{K12,K13}/2-c K23/3` in every block and compares every rational file entry. For222 it begins with `sym(K12 K23 K13)`, applies the three local rank2 projectors in the reverse order to the discovery implementation, verifies unit full-Hilbert–Schmidt norm, verifies all three local-rank fixed-point identities, and compares the normalized operator to every rational entry. The rank-projector coefficient vectors independently pass their norm identities. The invariant222 space is one-dimensional; an overall sign has no effect on the absolute-value cut.

## Bound files and accepted cuts

| n | family | input SHA256 | accepted necessary rational cut |
|---|---|---|---|
|35|211|`ddc144086b6f793e8cc00e9b4a75f6b40771a4139367d74493c93ab906fa4388`|`abs(sum_J Tr(X_J Oq_J)) <= 40000 a1 + 1e-5`|
|36|211|`dae368180c870dfb163db19c3a8b83b894c5a21d4bbbfb960d09bd4a039c427a`|`abs(sum_J Tr(X_J Oq_J)) <= 54000 a1 + 1e-5`|
|35|222|`4c29369ca57646333eb367a47199213c6ce3664081572e428e42ba3e2ea34abc`|`abs(sum_J Tr(X_J Tq_J)) <= a2/238 + 1e-7`|
|36|222|`abed3a64d7e3c93150b2ec967bd1f86484fc8c020c7b0f90820aafe432618c2b`|`abs(sum_J Tr(X_J Tq_J)) <= a2/200 + 1e-7`|

Here `X_J=(2J+1)Z_J`, `sum_J Tr X_J=8`, and each multiplicity dimension is at mostN=n+1. Therefore a uniform entry errorepsilon gives expectation error at most8N epsilon. The checker proves entry errors below2e-8 for211 and1e-10 for222. These give211 expectation errors at most5.76e-6/5.92e-6 and222 errors2.88e-8/2.96e-8 at35/36, strictly within the declared additive margins.

The first21135 attempt used a needlessly strict entry error<1e-8 and stopped at an entry whose error is exactly1e-8 up to interval enclosure. This was NOT an operator-convention mismatch or failed supplied1e-5 expectation margin. The final independent check uses the conservative2e-8 bound and retains the original supplied cut constants unchanged. Native21136 actual max entry error is about4.9983e-9; both222 actual maxima are below5e-13.

The analytic211 inequality,222 coefficients2/7 and1/sqrt5, and scalar a2 upper bounds were already independently checked in the companion audit. The current checker also verifies all four rational slope overestimates using the conservative scalar bounds9/40 and1/3. It is therefore safe to append BOTH signs of each accepted inequality, with the additive rounding constants, to a necessary-condition model. Off-diagonal trace coefficients must be doubled when packing symmetric upper-triangle variables. The solver's dual constant must include the new positive additive margins.

Runtime2.73seconds. Exact interval receipt: `cubic_operator_files_independent.json`. No solver was run by this audit. The existence of a cut violated by a stored pseudo-point does not prove any new unrestricted lower bound;35–37 remains the bracket until a complete rigorous separation or code is established.
