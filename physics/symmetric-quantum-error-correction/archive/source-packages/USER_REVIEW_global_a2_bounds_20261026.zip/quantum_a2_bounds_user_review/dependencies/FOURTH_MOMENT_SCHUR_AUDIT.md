# Independent applicability audit: fourth-moment Schur tests at n35/36

**Review status:** internally AI-assisted derivation and checks, not external human peer review.

26 October 2026. **Analytic necessity PASS.** Numerical point diagnostics are separately labeled below; no exclusion follows until a new feasible model is separated rigorously.

Let P be an arbitrary complex rank-two projector in a spin-n/2 space, and average its simultaneous SU(2) orbit. In the operator Hilbert space put v=vec(P), w=v tensor v, and

    A=E vv^dagger, B=E vw^dagger, C=E ww^dagger.

The block covariance [[A,B],[B^dagger,C]] is PSD. Therefore Ran B is contained in Ran A and

    B^dagger A^+ B <= C.                              (1)

All matrix identifications here are fixed vectorization permutations/realignments; no separability conjecture or codeword reality is assumed. A is determined by the twirled two-copy moment, B by the twirled three-copy moment Z. C is a fourth moment, but the following exact budgets remove the need to store it.

## Total and per-rank budgets

The intrinsic normalization a_r=(n+1)||P_r||_HS^2/4 gives

    A|_(operator rank r)=lambda_r I_(2r+1),
    lambda_r=4a_r/[(n+1)(2r+1)].

Since ||v||^2=TrP^2=2, one has Tr C=4 and Tr_second C=2A. Taking the trace and partial trace in(1) yields

    sum_r ||Pi_r B||_HS^2/lambda_r <=4,              (2)
    Tr_second(B^dagger A^+ B) <=2A.                 (3)

If lambda_r=0, the corresponding component of B must vanish; pseudoinversion must not discard a nonzero range violation.

Realignment preserves the source operator-rank Hilbert--Schmidt norm. Thus ||Pi_r B||^2 equals the rank-r-on-one-factor squared norm of Z used by the numerical implementation. After filtering that source rank by lambda_r^(-1/2), projecting the remaining target factor to rank s gives q_s. The partial trace in(3) is SU(2)-invariant in the multiplicity-free operator decomposition, so (3) is equivalent to

    q_s <= 2(2s+1)lambda_s = 8a_s/(n+1)              (4)

for every s, with the zero-range conditions retained. This independently verifies the implemented normalization and the need for a separate condition at each rank, rather than only(2).

Replacing Hermitian moment matrices by their real parts remains a relaxation of arbitrary complex codes. With real A, the real part of B^dagger A^+ B is the sum of the real-B and imaginary-B Gram matrices. Dropping the latter only weakens(1)-(4); it does not impose real codewords.

## Independent3/1 physical-swap budgets

Let Pi_+=(I+Swap)/2 and Pi_-=(I-Swap)/2 on the TWO physical spin copies represented by w. Define w_±=vec((P tensor P)Pi_±). Because P tensor P commutes with Swap and is a projector,

    ||w_+||^2=K(K+1)/2=3,
    ||w_-||^2=K(K-1)/2=1,          K=2.

Apply the same covariance Schur argument to(v,w_+) and(v,w_-). This gives separate necessary bounds3 and1. Their B matrices are realignments of Z(I±Swap23)/2, or equivalently use pair12 after choosing factor3 as the source. They can be computed from the same third moment, without a new fourth-copy variable.

In the pair-spin basis, the physical pair swap has eigenvalue(-1)^(n-L). Z commutes with this swap, so its opposite-parity entries vanish. The local rank projection on the remaining factor preserves each L,L' channel; therefore splitting the rank-norm sum by pair parity is the exact sector projection, not an approximate assignment.

## Executed bounded controls and status

A historical 3/1 diagnostic (not needed for this replay) adapts the original Casimir point evaluator only by the derived parity split. Results:

    n35: symmetric0.8145926773 <=3, antisymmetric0.2569124283 <=1;
    n36: symmetric2.2749929760 <=3, antisymmetric0.4563356513 <=1;
    actual37 control:0.7285524370 <=3,0.2428508123 <=1.

Thus this refinement does not separate either saved point. All off-swap-parity entries are zero in the stored inputs, and the rank norm Parseval identities pass.

The historical partial-trace test(4) passes the strongest saved35 point and actual37 control, but strongly violates the older n36 PPT point at rank7. A separate historical channel control used explicit factorial-Racah eigenvectors rather than tridiagonal-Casimir diagonalization. That control was described as pending in this source note, and is not relied on here. These are numerical point tests, not exact primal-feasibility certificates or a global n36 contradiction. In particular the old36 point may already fail the stronger logical R/D cones. A new solve or exact dual is needed before improving the proven35<=n_min(3)<=37 bracket.
