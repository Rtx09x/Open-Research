# Two global linear cubic-moment families for the35/36 test

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

Status: native and independent exact operator/rounding checks PASS, together
with independent analytic applicability and scalar-dual replays. All four literal
operator files are bound by CUBIC_LITERAL_OPERATOR_AUDIT.md.
These cuts expose particular pseudo-moments, NOT entire forbidden lengths.

## A. External dipole–quadrupole family211

This family was developed with AI assistance and separately reconstructed
internally. Let c=j(j+1),
Q_ab={J_a,J_b}/2−cδ_ab I/3 and

  O211=Σ_ab Q_ab⊗J_a⊗J_b.

For any Hermitian rank2 projector P, set d_a=Tr(PJ_a),q_ab=Tr(PQ_ab).
Hermiticity, not real code amplitudes, makes d real and q real symmetric
traceless. Standard irreducible tensor normalization gives

  |d|²=4ca1/3,  ||q||F²=2c(4c−3)a2/15.

Since Tr(ZO211)=dᵀqd and ||ddᵀ−|d|²I/3||F²=2|d|⁴/3,

  |Tr(ZO211)|²≤(64/405)c³(4c−3)a1²a2.

The independently replayed exact scalar/shadow duals give a2<9/40 at35
and a2<1/3 at36. Rational comparison therefore gives safe slopes40000 and
54000: |Tr(ZO211)|≤s_n a1. No additional unknown moment is introduced.

Its coupled-spin blocks are explicitly

  O211_J={K12,K13}/2−(c/3)K23,
  K12=diag([L(L+1)−2c]/2), K13=F23 K12 F23,
  K23=F13 K12 F13.

The external35 operator file has denominator10^8 and additive error1e−5.
The analogous36 rational operator uses the same conservative error margin.
The exact scalar upper bound quoted externally is574057297/2590000000
≈.2216437440, valid but slightly weaker than the native rational dual.

## B. Native pure-quadrupole family222

Let T222 be ANY Hermitian SU2-invariant unit-HS tensor with operator rank2
on each of the three factors. This invariant space is one-dimensional, so
its sign is immaterial to an absolute-value bound. Let v=Π2P, as a vector
in the real Hermitian spin2 representation. Then

  ||CG_2(v⊗v)||²=(2/7)||v||⁴.                          (1)

Proof: identify v with a real symmetric traceless3×3 matrix. Its invariant
quartics are multiples of(Tr q²)², since Tr q⁴=(Tr q²)²/2. Thus the left side
is a constant times||v||⁴. On the unit axial vector e0 the exact coefficient
CG(2,0;2,0|2,0)=−sqrt(2/7) fixes the constant. No statement about real Dicke
amplitudes is used.

The normalized singlet V2⊗V2→V0 contributes1/sqrt5. Cauchy–Schwarz and(1)
therefore imply

  |Tr(ZT222)|²≤(2/35)||v||⁶=128a2³/(35N³).            (2)

With the same certified scalar upper U2, (2) yields a GLOBAL linear bound

  |Tr(ZT222)|≤sqrt[128U2/(35N³)] a2.

The convenient rational overestimates are1/238 at35 and1/200 at36. Unlike
a tangent approximation to a2², these are valid for the entire certified
range0≤a2≤U2. No interval branch or disjunction is required.

For reproducible exact matrices, start with
W_J=sym(K12 K23 K13), project to rank2 separately on factors1,2,3, and divide
by its positive full-HS norm. This produces the unit T222 above. The standalone
checker rebuilds all permutations and projections by exact factorial Racah
coefficients with256-bit Arb, without importing the numerical model. It
verifies the recorded rational operator differs entrywise by<10^−10.

Every multiplicity block has dimension≤N, so the full operator-norm error is
≤N·10^−10. Since Tr Z=8, the expectation error is≤8N·10^−10<10^−7. Consequently
the literal rational files give the necessary cuts

  |Tr(Z Tq222)|≤a2/238+10^−7  (n35),
  |Tr(Z Tq222)|≤a2/200+10^−7  (n36).

The rounding slack is mandatory. No solver should silently omit it.

## Evidence and exact acceptance boundary

`a2_interval_duals.json` contains the native nonnegative rational duals and
their residual budgets. The accompanying `check_a2_bound_independent.py`
rebuilds the scalar proof with exact fractions. The original exact scalar
receipt is `a2_bound_independent.json`. Both full dual witnesses embed their
literal rational cubic matrices and constants; see `../REPRODUCIBILITY.md`
for the separate operator-identification replay. No discovery solver or
stored pseudo-moment is needed for that replay.

The saved35/new36 violations of the rounded222 cuts are1.63e−5 and1.00e−5.
The external211 cut also rejects saved35, while its conservative36 version
does not reject the new36 point. A joint solve can still find another valid
pseudo-moment: none of these point separations proves an unrestricted no-go.

Any positive joint phase-I result must be converted into a rigorously checked
full-space dual. New inequality constants contribute positively to the dual
constant term. Each matrix is already rational, so its solver contribution
can be reconstructed exactly before the usual Racah/S3 residual accounting.
Known37 and arbitrary complex small-spin controls must be retained. The
unrestricted three-error bracket remains35–37 until a complete new exclusion
or exact code is independently established.
