# General necessity identities: historical derivation excerpt

This internally AI-assisted derivation excerpt reproduces Sections 2–5 of
an earlier necessity proof. It is specialized there to n=18, j=9, N=19 and
two-error detection cutoff 4. The unrelated minimum-length theorem and its
numerical certificate are deliberately not reproduced. This excerpt does
not assert a new two-error result or re-prove the inherited 35–37 bracket.

For the present arbitrary-n, three-error application, the same derivations
use j=n/2, N=n+1, and tensor cutoff 2t=6. Replace scalar numerical factors
19 by N and the spin labels 9 by j; the ranges extend to n and 3j. The
odd-n conventions are important: the MacWilliams sign is (-1)^(n+r+k),
the swap23 Racah matrix gains (-1)^n, and the crossing map gains (-1)^n.
The pair-symmetric parity is (-1)^(n-L)=+1, not always even L.
The pair-sector ratios remain 4/3, 2/3 and 2. These general conventions
are stated in the current theorem and reconstructed by both dual checkers.

Only the reasoning and normalization identities are used here. The mixed
projector-complement cones described below are valid necessary conditions
but are not all needed by the current witnesses. General logical R/D
positivity, detected faces and lifted-KL equivalence are derived separately
in general_lift_and_faces.md. The exact Schur-support rows are derived in
SCHUR_SUPPORT_ROW_DERIVATION.md.

The original excerpt’s numbered citations refer to its prior source context,
not additional local replay files. It derives the physical-rank necessity
by spin raising operators and derives the pair-sector factors from the two
projector marginal identities. Its standard Wigner-6j recoupling identities
fix the scalar/shadow normalization used in the arithmetic checkers.

---

## 2. Spin reduction and intrinsic normalization

For n=18 the symmetric Hilbert space is the spin-j=9 irreducible representation V, of dimension N=19. Under conjugation,

    End(V) = ⊕_(r=0)^18 W_r,       dim W_r=2r+1.

Choose any Hilbert–Schmidt orthonormal tensor basis T_(r,q) of W_r, with T_(0,0)=I/√19. Compression of weight-at-most-four physical operators spans W_0⊕…⊕W_4. One can see necessity directly: J_+^r is a sum of physical weight-r raising products and generates W_r under collective rotations; conversely products of at most four one-site spin operators have tensor rank at most four. Therefore every code in §1 satisfies

    P T P = (Tr(P T)/2) P,       T ∈ W_0⊕…⊕W_4.                 (1)

Define

    a_r = (19/4) Σ_q |Tr(P T_(r,q))|².

Then a_r≥0, a_0=1, and Parseval with Tr(P²)=2 gives Σ_r a_r=19/2. This last normalization follows directly from the definition; the sentence after Eq. B18 of the cited intrinsic-code paper contains a conflicting normalization typo and is not used.

In the real standard Wigner-6j convention, put

    M_(r,k) = (-1)^(18+r+k) (2r+1) {9 9 r; 9 9 k},
    H = 2M-I.

The other quadratic enumerator is

    b_r = (19/2) Σ_q Tr(P T_(r,q)† P T_(r,q)) = (2Ma)_r.

The Hilbert–Schmidt Cauchy–Schwarz inequality on the two-dimensional code gives b_r≥a_r; equality holds exactly when each compressed rank-r tensor is scalar. Thus

    a≥0, Ha≥0, (Ha)_r=0 for r=1,2,3,4.                       (2)

These statements concern arbitrary complex P. All definitions are invariant under changes of tensor basis inside W_r.

## 3. Actual two-copy and three-copy moments

Let U_g be the spin-nine representation and normalized Haar measure be dg. Set

    Y = ∫ (U_g P U_g†)⊗2 dg,
    Z = ∫ (U_g P U_g†)⊗3 dg.

These are positive semidefinite, not normalized density operators: Tr Y=4 and Tr Z=8. They commute with collective SU(2); Z also commutes with every copy permutation. These permutations act on the three **spin-nine copies**, not the original eighteen physical qubits.

Couple copies 1 and 2 to pair spin L=0,…,18. Since V⊗V is multiplicity-free,

    Y = ⊕_L [t_L/(2L+1)] I_(2L+1),
    t_L = (4/19) Σ_r (-1)^r M_(L,r) a_r ≥0.                  (3)

Equation (3) is the standard tensor-operator/CG recoupling identity, obtained by expanding P in the orthonormal T_(r,q) and tracing against the pair-spin projector. It fixes the normalization of every two-copy term below; Σ_L t_L=4.

Couple this pair to the third spin-nine copy. Let

    Λ_J = {L: 0≤L≤18, |L-9|≤J≤L+9},    J=0,…,27.

Then

    Z = ⊕_J I_(2J+1)⊗Z_J,    X_J=(2J+1)Z_J≥0,
    Σ_J Tr X_J=8,           |Λ_J|≤19.                        (4)

The certificate uses X_J as its weighted full multiplicity variables. It does not depend on floating-point reduced S3 bases.

### Exact permutation matrices and projector identities

Use the CG phase gauge in which

    D_J[L,L'] = (-1)^(18-L) δ_(L,L'),
    F_J[L,L'] = √((2L+1)(2L'+1)) {9 9 L; 9 J L'},
    F13_J = D_J F_J D_J.

They represent Swap12, Swap23 and Swap13. They are real orthogonal matrices and obey the S3 relations. This gauge is related to another common CG choice by diag((-1)^L); every formula here uses the displayed gauge consistently.

Let Psym and Palt be the exact group-average projections onto the symmetric and alternating S3 sectors, and Pstd=I-Psym-Palt. Rank(P)=2 gives

    Z_J Palt_J=0,

because the alternating third tensor power of a two-dimensional space vanishes. Directly from P²=P and Tr P=2,

    Tr_3 Z=2Y,     Tr_3(Z Swap23)=Y.                          (5)

The L-diagonal consequences are

    Σ_J (X_J)[L,L]=2t_L,
    Σ_J (X_J F_J)[L,L]=t_L.                                  (6)

Together with the S3 commutant and the absent alternating sector, these can be expressed as the equality rows used in the certificate:

- if L is even, Σ_J(Psym_J X_J)[L,L]=4t_L/3 and Σ_J(Pstd_J X_J)[L,L]=2t_L/3;
- if L is odd, Σ_J(Pstd_J X_J)[L,L]=2t_L.

For example, on the pair12-symmetric line of the standard S3 representation, Swap23 has diagonal entry -1/2; solving the two marginal equations gives the stated 4/3 and 2/3 factors. On its pair12-antisymmetric line the entry is +1/2. These are necessary equalities, not fitted constraints.

## 4. Mixed projector/complement positivity and partial transpose

Write Q=I-P, and let Y12,Y13,Y23 denote Y embedded into the indicated pair with identity on the unused copy. Twirling positive products involving P and Q gives

    Z ≥0,
    Y12-Z ≥0,
    (2/19)I-Y12-Y13+Z ≥0,
    (1-6/19)I+Y12+Y13+Y23-Z ≥0.                              (7)

Their permutations are also valid. These follow by expanding, respectively, P⊗P⊗P, P⊗P⊗Q, P⊗Q⊗Q, and Q⊗Q⊗Q. The single-copy average is (2/19)I by irreducibility.

Define spin time reversal on one operator by

    θ(A)=C A^T C†,    C|j,m>=(-1)^(j-m)|j,-m>,

and τ3=id⊗id⊗θ. Although partial transpose is not positive on arbitrary entangled operators, every tensor product just used has positive individual factors. Its partial transpose, and hence its τ3 image, is positive. Convex integration preserves this. Thus τ3 applied to every product-derived operator in (7), including its permutations, gives further necessary PSD inequalities.

In full multiplicity blocks the crossing identity is

    (τ3 Z)^K[L,L'] = Σ_J (2J+1) {L 9 J; L' 9 K} Z_J[L,L']
                   = Σ_J {L 9 J; L' 9 K} X_J[L,L'].           (8)

For general n this has an overall (-1)^n; n=18 is even. Partial time reversal preserves collective invariance and Swap12 parity, but generally **not** full S3 invariance. The certificate retains the full parity multiplicity blocks on this output; it does not impose an invalid S3 or alternating-sector restriction there.

For explicit reproduction, in each J block put

    D=diag(t_L/(2L+1)),
    Dθ=diag(Σ_r {9 9 r;9 9 L} t_r),
    P13=F_J Dθ F_J,       P23=F13_J Dθ F13_J,
    Zθ=(τ3 Z)_J.

The five inequivalent mixed τ3 cones used by the witness, in addition to Zθ≥0, are

    D-Zθ ≥0,
    P13-Zθ ≥0,
    (2/19)I-D-P13+Zθ ≥0,
    (2/19)I-P13-P23+Zθ ≥0,
    (1-6/19)I+D+P13+P23-Zθ ≥0.                               (9)

The omitted permutations are Swap12 conjugates. Ordinary mixed blocks in (7) use Y13=F_J D F_J and Y23=F13_J D F13_J.

## 5. Lifted Knill–Laflamme equalities

This is the decisive strengthening over the feasible lower-order relaxations. For arbitrary operators A,B and any T∈W_0⊕…⊕W_4, (1) implies

    2 Tr(P A P T) Tr(P B) - Tr(P A) Tr(P B) Tr(P T)=0.          (10)

The swap trace identity identifies (10) with

    Tr([(2Swap13-I) P⊗3] [A⊗B⊗T])=0.

The detected tensor-rank space is invariant under rotations. Therefore twirling preserves the identity, and

    Π_(rank≤4 on factor3) [(2Swap13-I)Z] = 0.                 (11)

Here Π is Hilbert–Schmidt orthogonal projection onto the indicated operator subspace; the first two factors are unrestricted. Rank zero recovers the existing projector marginal, but the other ranks need not follow from quadratic enumerators.

Equation (11) can be written entirely in the full-spin blocks. For fixed pair spins L,L', define

    W_J=(2F13_J-I)Z_J,
    w_J=√(2J+1) W_J[L,L'].

On this channel the local commutator Casimir

    Δ3(A)=Σ_(i=x,y,z) [J_i^(3),[J_i^(3),A]]

has eigenvalues r(r+1), for |L-L'|≤r≤min(L+L',18). Its orthonormal recoupling eigenvectors in the w_J coordinates are

    U_(J,r)=(-1)^(L+9+J) √((2J+1)(2r+1)) {L 9 J;9 L' r}.     (12)

Consequently (11) is exactly U_r^T w=0 for each allowed r≤4. The finite witness stores arbitrary rational vectors h and uses the exact projected vectors Σ_(r≤4) U_r U_r^T h. Such multipliers give exact equality combinations regardless of how h was numerically suggested. A separate independent verifier instead bounds their low-rank projection defect using the exact Casimir spectral gap; thus the two arithmetic routes do not share an unverified numerical eigenspace assumption.

