# All tested fourth-Schur marginal gates follow from a linear logical-complement cone

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

Status: analytic identity and implication, independently checked on a full complex physical Haar control. This corrects the interpretation of the new Schur diagnostics: **they are not a genuinely new fourth-copy strengthening once the logical complement cone below is present.** Their use in the current36 relaxation remains valid, because that complement had not been imposed there.

## 1. Physical definitions and the existing cone

For a rank-two orthogonal projector P, use row-major `v=vec(P)` and average over physical SU(2) rotations. Define

`A=E vv†`,

`R=E[(vv†)⊗P]`,

`R_Q=A⊗I−R=E[(vv†)⊗(I−P)]`.

Thus `R≥0`, `R_Q≥0`, and `Tr_last R=2A`. A fixed time-reversal unitary identifies this R with the already-used `tau_3(Z Swap_13)`, where `Z=E P⊗P⊗P`. No reality or Kramers assumption is made.

The historical point diagnostic represented this cone by

`R_Q = F diag(4a_L/[N(2L+1)]) F^T − R`.

It was tested on the strong saved35 point, but not imposed in the old36 point-producing relaxation. The comparison here uses complete physical spin blocks and does not reuse a historical S3 eigensolver gauge.

## 2. The unsplit Schur marginal

Write `w=v⊗v` and `B=E v w†`. At the index level,

`B_(ab),(cd,ef)=E[P_ab P_dc P_fe]`

and

`R_(ab,e),(cd,f)=E[P_ab P_dc P_ef]`.

Consequently, after the indicated realignment,

`Tr_second_operator[B† A^+ B] = Tr_last[R(A^+⊗I)R]`.

This is an exact index identity, independent of positivity or a code assumption.

The positive R has support contained in `Ran(A)⊗V`: if u is in `ker A`, the zero partial-trace quadratic form implies that R annihilates every `u⊗e`. On this support set

`S=(A^(-1/2)⊗I)R(A^(-1/2)⊗I)`.

The two linear cones give `0≤S≤I`. Therefore `S²≤S`, so

`R(A^+⊗I)R≤R`.

Partial tracing proves

`Tr_second_operator[B† A^+ B]≤2A`.

This is precisely the tested per-operator-rank budget `q_s≤8a_s/N`. Its total trace budget≤4 follows as well. The singular-A range condition is automatically supplied by R positivity and its marginal.

## 3. The complete joint swap-sector refinement

Let `w±=vec[(P⊗P)Π±]`, where Π± are the physical two-factor symmetric/antisymmetric projectors. Under the same realignment, `B±=E v w±†` corresponds to `R Pi±` on the right, with `Pi±=(I±S_13)/2` on the three tensor legs of R.

Thus the joint two-by-two Schur marginal has blocks

`Tr_last[Pi_sigma R(A^+⊗I)R Pi_tau]`.

The map taking an operator X to the block matrix with entries `Tr_last[Pi_sigma X Pi_tau]` is positive (compression followed by partial trace). Applying it to `R−R(A^+⊗I)R≥0` dominates the whole joint Schur marginal by the same block construction from R.

Let `T=E(P⊗P^T)`. Direct contraction gives those latter blocks as

`[[A+T/4, A/2−T/4], [A/2−T/4, T/4]]`.

These are the joint-sector budgets of the historical marginal refinement, reproduced explicitly above. Therefore the separate3/1 trace constraints, their per-rank versions, and the full joint2×2 per-rank condition are all consequences of `R≥0`, `R_Q≥0` and the existing marginals.

This does **not** establish that R_Q follows from bare R/D positivity. It identifies the precise additional linear cone sufficient for every Schur gate tested here.

## 4. Independent controls and saved-point outcomes

A separate internal numerical control (not included as a replay dependency) directly constructed a generic complex spin-one rank-two projector and its full Haar averages. It imports no Racah/model code and verifies:

- unsplit realignment/product identity: error below2.0·10^-15;
- joint-sector realignment: error below1.1·10^-15;
- `Tr_last R=2A`: error below1.5·10^-15;
- R, R_Q and `R−R(A^+⊗I)R` positive to floating precision.

The complete-spin point diagnostics give:

| point | minimum R_Q eigenvalue |
|---|---:|
| strong saved35 |−8.61·10^-15|
| old saved36 |−7.57523116065065·10^-5|
| actual37 control |−1.48·10^-17|

For old36 the corresponding high-support D_Q minimum is `+2.26·10^-18`, a numerical boundary value, not an exact feasibility certificate. These historical point diagnostics are explanatory numerical controls, not exact proof objects; their raw files are not needed or included.

## Consequence for the finite-gap effort

The current36 R/D plus Schur supporting-cut solve is mathematically valid. However, a survival of its finite Schur cuts should next be checked against the full R_Q cone rather than interpreted as satisfaction of a new independent fourth-copy theory. Strong35 already passes the relevant logical-complement checks, which explains its survival of all these Schur diagnostics. No35/36 exclusion, code, or exact feasible point is established here.
