#!/usr/bin/env python3
import sympy as s,json
from sympy.physics.wigner import clebsch_gordan
from pathlib import Path
x,y,z,u,v=s.symbols('x y z u v',real=True);Q=s.Matrix([[x,y,z],[y,u,v],[z,v,-x-u]])
assert s.expand(s.trace(Q**4)-s.trace(Q**2)**2/2)==0
cg=clebsch_gordan(2,2,2,0,0,0);assert s.simplify(cg**2-s.Rational(2,7))==0
singlets=[clebsch_gordan(2,2,0,m,-m,0)for m in range(-2,3)]
assert all(s.simplify(c-(-1)**(2-m)/s.sqrt(5))==0 for m,c in zip(range(-2,3),singlets))
assert sum(c*c for c in singlets)==1
out={'status':'PASS exact Cartesian invariant and CG normalization controls','CG220':str(cg),'squared_CG2_norm_constant':'2/7','singlet_factor_squared':'1/5','T222_squared_constant':'2/35','enumerator_constant':'128/(35*N^3)','scope':'All real spin2 vectors, including rank2 multipoles of arbitrary Hermitian projectors.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
