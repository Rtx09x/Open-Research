#!/usr/bin/env python3
"""Independent Fraction reconstruction of the native scalar/shadow a2 duals."""
from fractions import Fraction as F
from math import factorial as fac
from functools import lru_cache
from pathlib import Path
import json,hashlib,time
ROOT=Path(__file__).resolve().parent;path=ROOT/'a2_interval_duals.json';t0=time.monotonic()
@lru_cache(None)
def racah(n,r,k):
 p=F(fac(n-r)*fac(r)**2,fac(n+r+1))*F(fac(n-k)*fac(k)**2,fac(n+k+1))
 return p*sum((F((-1)**z*fac(z+1),fac(z-n-r)**2*fac(z-n-k)**2*fac(2*n-z)*fac(n+r+k-z)**2)for z in range(max(n+r,n+k),min(2*n,n+r+k)+1)),F(0))
rows=[]
for q in json.loads(path.read_text()):
 n=q['n'];N=n+1;assert q['t']==3 and q['rank']==2;scale=q['scale'];y=[F(v,scale)for v in q['y']];z=[F(v,scale)for v in q['z']];assert all(v>=0 for v in z)
 I=[[F(r==k)for k in range(N)]for r in range(N)];M=[[(-1)**(n+r+k)*(2*r+1)*racah(n,r,k)for k in range(N)]for r in range(N)];H=[[2*M[r][k]-I[r][k]for k in range(N)]for r in range(N)];S=[[(-1)**k*M[r][k]for k in range(N)]for r in range(N)]
 E=[I[0],[F(1)]*N]+H[1:7];b=[F(1),F(N,2)]+[F(0)]*6;G=I+H[7:]+S;assert len(z)==len(G)
 residual=[-I[2][k]-sum(y[j]*E[j][k]for j in range(len(E)))-sum(z[j]*G[j][k]for j in range(len(G)))for k in range(N)]
 delta=max(abs(v)for v in residual);center=-sum(v*w for v,w in zip(y,b));upper=center+F(N,2)*delta
 assert delta==F(q['delta_exact']) and center==F(q['center_exact']) and upper==F(q['upper_exact'])
 simple=F(9,40)if n==35 else F(1,3);assert upper<simple
 c=F(n*(n+2),4);factor=F(64,405)*c**3*(4*c-3);linear=40000 if n==35 else 54000;assert factor*simple<linear**2
 rows.append({'n':n,'residual_max':str(delta),'center':str(center),'upper':str(upper),'simple_bound':str(simple),'linear_cubic_cut_constant':linear,'strict_squared_margin':str(F(linear**2)-factor*simple)})
out={'status':'PASS exact independent scalar/shadow replay','source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'results':rows,'seconds':time.monotonic()-t0,'external_fraction_note':'The separate external574057297/2590000000 bound is not verified here without its own multipliers.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
