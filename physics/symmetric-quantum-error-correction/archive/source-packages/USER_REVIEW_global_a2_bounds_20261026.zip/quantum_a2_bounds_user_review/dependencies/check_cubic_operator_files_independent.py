#!/usr/bin/env python3
"""Independent interval replay of literal 211/222 matrices, no worker imports."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from flint import arb,arb_mat,fmpq,ctx
import math,json,hashlib,time
ctx.prec=256
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
@lru_cache(None)
def fac(k):return math.factorial(k)
def ball(x):
 x=F(x);return arb(fmpq(x.numerator,x.denominator))
@lru_cache(None)
def racah(a,b,c,d,e,f):
 p=F(1)
 for x,y,z in ((a,b,c),(a,e,f),(d,b,f),(d,e,c)):
  if (x+y+z)%2 or min(x+y-z,x-y+z,-x+y+z)<0:return arb(0)
  p*=F(fac((x+y-z)//2)*fac((x-y+z)//2)*fac((-x+y+z)//2),fac((x+y+z)//2+1))
 A=((a+b+c)//2,(a+e+f)//2,(d+b+f)//2,(d+e+c)//2)
 B=((a+b+d+e)//2,(a+c+d+f)//2,(b+c+e+f)//2)
 s=sum((F((-1)**z*fac(z+1),math.prod(fac(z-u)for u in A)*math.prod(fac(v-z)for v in B))for z in range(max(A),min(B)+1)),F(0))
 return ball(s)*ball(p).sqrt()
def trace(A):return sum((A[i,i]for i in range(A.nrows())),arb(0))
def maxnorm(A):return max((abs(A[i,j]).upper()for i in range(A.nrows())for j in range(A.ncols())),default=arb(0))
def eye(d):return arb_mat([[int(i==j)for j in range(d)]for i in range(d)])
def diagonal(v):return arb_mat([[v[i]if i==j else 0 for j in range(len(v))]for i in range(len(v))])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=time.monotonic();results=[]
for n in [35,36]:
 N=n+1;c=F(n*(n+2),4);blocks={}
 for J in range(n%2,3*n+1,2):
  ls=[L for L in range(N)if abs(2*L-n)<=J<=2*L+n]
  if not ls:continue
  U=arb_mat([[(-1)**n*arb((2*L+1)*(2*K+1)).sqrt()*racah(n,n,2*L,n,J,2*K)for K in ls]for L in ls])
  assert maxnorm(U*U-eye(len(ls)))<ball(F(1,10**60))
  D=diagonal([arb((-1)**(n-L))for L in ls]);V=D*U*D
  A=diagonal([ball(F(L*(L+1),2)-c)for L in ls]);B=U*A*U;C=V*A*V
  O=(A*B+B*A)/2-ball(c/3)*C
  W=A*C*B;W=(W+W.transpose())/2
  blocks[J]={'ls':ls,'ix':{L:i for i,L in enumerate(ls)},'U':U,'V':V,'O211':O,'W':W}
 channels=[]
 for L in range(N):
  for K in range(L,min(N,L+3)):
   if L+K<2:continue
   js=[J for J,b in blocks.items()if L in b['ix']and K in b['ix']]
   u={J:(-1)**((2*L+n+J)//2)*arb(5*(J+1)).sqrt()*racah(2*L,n,J,n,2*K,4)for J in js}
   assert abs(sum((x*x for x in u.values()),arb(0))-1)<ball(F(1,10**60))
   channels.append((L,K,js,u))
 def third(X):
  Y={J:arb_mat(len(b['ls']),len(b['ls']))for J,b in blocks.items()}
  for L,K,js,u in channels:
   alpha=sum((u[J]*arb(J+1).sqrt()*X[J][blocks[J]['ix'][L],blocks[J]['ix'][K]]for J in js),arb(0))
   for J in js:
    i,j=blocks[J]['ix'][L],blocks[J]['ix'][K];Y[J][i,j]=Y[J][j,i]=alpha*u[J]/arb(J+1).sqrt()
  return Y
 def conjugate(X,key):return {J:b[key]*X[J]*b[key]for J,b in blocks.items()}
 def local(X,which):
  if which==3:return third(X)
  key='V'if which==1 else'U'
  return conjugate(third(conjugate(X,key)),key)
 W={J:b['W']for J,b in blocks.items()}
 # Reverse the worker's local projection order; commuting local ranks must agree.
 for r in (3,2,1):W=local(W,r)
 norm2=sum(((J+1)*trace(A*A)for J,A in W.items()),arb(0));assert norm2>0
 T={J:A/norm2.sqrt()for J,A in W.items()}
 assert abs(sum(((J+1)*trace(A*A)for J,A in T.items()),arb(0))-1)<ball(F(1,10**50))
 for r in(1,2,3):
  Y=local(T,r)
  assert max(maxnorm(Y[J]-T[J])for J in T)<ball(F(1,10**50))
 p=ROOT/f'operators/quadrupole_cubic_cut_n{n}.json';d=json.loads(p.read_text());assert d['n']==n
 assert sorted(row['J2']for row in d['blocks'])==sorted(blocks)
 worst=arb(0)
 for row in d['blocks']:
  J=row['J2'];assert row['Ls']==blocks[J]['ls']
  Q=arb_mat([[ball(F(x,d['scale']))for x in line]for line in row['numerators']]);e=maxnorm(T[J]-Q)
  assert e<ball(F(1,10**10));worst=max(worst,e)
 assert 8*N*F(1,10**10)<F(d['additive_bound'])
 assert F(128)*F(d['scalar_a2_upper'])/(35*N**3)<F(d['bound_a2_coefficient'])**2
 results.append({'family':'222','n':n,'sha256':sha(p),'all_three_local_ranks_verified':2,'full_HS_norm_verified':1,'max_entry_error_interval':str(worst),'certified_entry_error':'1/10000000000','expectation_error_bound':str(8*N*F(1,10**10)),'declared_additive':d['additive_bound'],'slope':d['bound_a2_coefficient']})
 if n in (35,36):
  p=ROOT/f'operators/n{n}_rational_cubic_cut.json';d=json.loads(p.read_text());assert sorted(row['J2']for row in d['blocks'])==sorted(blocks)
  worst=arb(0)
  for row in d['blocks']:
   J=row['J2'];assert row['Ls']==blocks[J]['ls'];dim=len(row['Ls']);Q=arb_mat(dim,dim)
   seen=set()
   for i,j,x in row['upper']:
    assert i<=j and (i,j)not in seen;seen.add((i,j));Q[i,j]=Q[j,i]=ball(F(x,d['matrix_entry_denominator']))
   assert len(seen)==dim*(dim+1)//2
   e=maxnorm(blocks[J]['O211']-Q)
   if not e<ball(F(2,10**8)):
    print('211 bad J',J,'error',e,'own',blocks[J]['O211'][0,0],blocks[J]['O211'][0,1] if dim>1 else '', 'given',Q[0,0],Q[0,1] if dim>1 else '',flush=True)
    raise AssertionError('211')
   worst=max(worst,e)
  slack=F(d['rational_error_slack_numerator'],d['rational_error_slack_denominator']);assert 8*N*F(2,10**8)<slack
  assert F(64,405)*c**3*(4*c-3)*(F(9,40) if n==35 else F(1,3))<d['a1_coefficient']**2
  results.append({'family':'211','n':n,'sha256':sha(p),'literal_operator_formula':'{K12,K13}/2-c K23/3','max_entry_error_interval':str(worst),'certified_entry_error':'1/50000000','expectation_error_bound':str(8*N*F(2,10**8)),'declared_additive':str(slack),'slope':d['a1_coefficient']})
 print('n',n,'PASS',time.monotonic()-start,flush=True)
out={'status':'PASS literal operator files independently reconstructed; no model/solver imports','seconds':time.monotonic()-start,'results':results}
(HERE/'cubic_operator_files_independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
