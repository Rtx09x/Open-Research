#!/usr/bin/env python3
"""Exact trace-normalization and small complex physical O control."""
import sympy as s,json,time
from pathlib import Path
st=time.monotonic();tracechecks=[]
for n in range(2,11):
 N=n+1;j=s.Rational(n,2);c=j*(j+1);ms=[w-j for w in range(N)]
 assert sum(m*m for m in ms)==N*c/3
 assert s.simplify(sum((m*m-c/3)**2 for m in ms)-N*c*(4*c-3)/45)==0
 tracechecks.append(n)
n=2;N=3;j=1;c=s.Integer(2);Jz=s.diag(-1,0,1);Jp=s.zeros(N)
for w in range(n):Jp[w+1,w]=s.sqrt((n-w)*(w+1))
Js=[(Jp+Jp.T)/2,(Jp-Jp.T)/(2*s.I),Jz];Id=s.eye(N);Q=[[s.simplify((A*B+B*A)/2-c*int(a==b)*Id/3)for b,B in enumerate(Js)]for a,A in enumerate(Js)]
K12=sum((s.kronecker_product(A,A,Id)for A in Js),s.zeros(N**3));K13=sum((s.kronecker_product(A,Id,A)for A in Js),s.zeros(N**3));K23=sum((s.kronecker_product(Id,A,A)for A in Js),s.zeros(N**3));O=sum((s.kronecker_product(Q[a][b],Js[a],Js[b])for a in range(3)for b in range(3)),s.zeros(N**3));assert (O-(K12*K13+K13*K12)/2+c*K23/3).applyfunc(s.simplify)==s.zeros(N**3)
u=s.Matrix([1,s.I,1+s.I])/2;assert s.simplify((u.conjugate().T*u)[0]-1)==0;P=Id-u*u.conjugate().T;d=s.Matrix([s.trace(P*A)for A in Js]);qq=s.Matrix([[s.trace(P*Q[a][b])for b in range(3)]for a in range(3)]);val=s.simplify((d.T*qq*d)[0]);literal=s.simplify(s.trace(s.kronecker_product(P,P,P)*O));assert literal==val
normd=s.simplify((d.T*d)[0]);normq=s.simplify(s.trace(qq.T*qq));a1=s.simplify(3*normd/(4*c));a2=s.simplify(15*normq/(2*c*(4*c-3)));rhs=s.Rational(64,405)*c**3*(4*c-3)*a1*a1*a2;assert s.simplify(rhs-val**2)>=0
assert s.simplify(s.Rational(2,3)*normq*normd**2-rhs)==0
out={'status':'PASS exact trace and physical operator controls','trace_formula_n_values':tracechecks,'small_complex_projector_rank':2,'O_trace':str(val),'a1':str(a1),'a2':str(a2),'cubic_squared_bound':str(rhs),'strict_slack':str(s.simplify(rhs-val**2)),'seconds':time.monotonic()-st}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
