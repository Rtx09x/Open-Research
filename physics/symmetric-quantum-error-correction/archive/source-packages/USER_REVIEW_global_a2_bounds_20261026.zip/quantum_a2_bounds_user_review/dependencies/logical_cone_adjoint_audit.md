# R/D cone adjoint derivation

**Review status:** internally AI-assisted mathematical and arithmetic checks. “Independent” means a separate implementation or internal derivation, not independent human peer review. External peer review and priority are unestablished.

**Verdict:** the historical full-space logical cone collector has the correct signs, order and weighting. The mathematical derivation is retained below; the shipped dual checkers implement this same adjoint. This is a mathematical/model line audit, not another independent arithmetic replay of its n18 control.

Let `Zhat_J=(2J+1) Z_J` and let `F_J` denote the physical swap13 in the pair12 multiplicity basis. Define the crossing map from weighted input blocks to *unweighted* output blocks by

`C(X)_K[L,L'] = sum_J (-1)^n {L j J; L' j K} X_J[L,L']`.

There is no additional `(2J+1)` in this expression: it has already been absorbed into `Zhat`. The forward cones are

`R=C(Zhat F)`, `D=C(Zhat) - C(Zhat F)/2`.

Physical `Zhat` commutes with the swaps, so the forward products are Hermitian. For real symmetric dual blocks `B_R,B_D`, let `Q_R=C*(B_R)` and `Q_D=C*(B_D)`, where the adjoint is taken in the ordinary sum-of-block-traces pairing. Then their contribution to the coefficient of `Zhat_J` is exactly

`Q_D + sym(Q_R F_J) - sym(Q_D F_J)/2`.

This matches the collector's `sym(QR*F13)+QD-sym(QD*F13)/2`. Swapping the product order inside `sym` gives the same matrix. The entrywise transpose crossing uses the same six-j coefficient with the loop indices in their forward positions; no unweighted physical Hilbert trace should be inserted a second time.

The D dual is lifted as `U B_D U^T`, where `U=F23[:, pair-spin>2t]` maps the pair13 detected-spin complement into the pair12 coordinates. This is the correct pair change; it is distinct from the physical swap13 multiplying Z. All full R multiplicities, including opposite pair-spin parity, are retained. Restricting R to the usual PPT parity blocks would be invalid.

Any rational lifted factor `V` gives a valid full-D dual `V V^T` even if V is only approximately in the high-rank face, because the physical full D is PSD. Thus a future certificate can use a rational full factor without exactifying the facial basis. The current exact Racah lift is also valid. Numerical coefficient truncation and QR used in discovery have no logical role after the full-space residual is checked.

Applicability: before twirling, `D=(P⊗theta(P)−|P>><<P|/2)⊗P` is PSD for any complex rank-two projector P; its first factor is an orthogonal projector of rank three. R is the positive rank-one vectorized-P factor tensored with P. Distance `2t+1` puts D on the pair-spin >2t face via KL, without imposing zero scalar moments or real codewords. Taking real parts of the invariant blocks preserves all necessary real-coefficient constraints and PSD. Final S3 averaging and antisymmetric-support compression of the residual remain justified as in the previously audited general certificate.

This audit does not claim n35 exclusion. The first n35 CVXPY run timed out; only the new direct-solver n18 control is presently reported complete.
