#!/usr/bin/env python3
"""Lightweight release integrity and exact receipt consistency, NOT a full proof replay."""
from pathlib import Path
from fractions import Fraction as Q
import ast, hashlib, json, math
R=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((R/'MANIFEST.json').read_text())
files=manifest['files']
for name,record in files.items():
 p=R/name
 assert p.is_file(), ('missing',name)
 assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'], ('hash',name)
assert {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}==set(files)|{'MANIFEST.json'}, 'extra or missing files'
for p in R.rglob('*.py'):ast.parse(p.read_text(),filename=str(p.relative_to(R)))
for n,simple in [(35,Q(2613,50000)),(36,Q(2213,20000))]:
 w=json.loads((R/f'witness_n{n}.json').read_text())
 a=json.loads((R/f'independent_n{n}.json').read_text())
 b=json.loads((R/f'primary_n{n}.json').read_text())
 assert sha(R/f'witness_n{n}.json')==a['certificate_sha256']==b['witness_sha256']
 assert (w['n'],w['t'],w['K'],w['distance'],w['dual_normalization'])==(n,3,2,7,1)
 assert a['passed_global_a2_upper'] is True and a['strict_negative_upper'] is False
 N=n+1
 C=Q(a['constant_exact']);budget=Q(a['a0_signed_upper_coefficient'])+(Q(N,2)-1)*Q(a['remaining_enum_abs_bound'])+8*Q(a['matrix_absolute_row_sum_bound'])
 assert budget==Q(a['main_residual_budget'])
 raw=C+budget+Q(a['extra_KL_coarse_budget'])
 assert Q(a['extra_KL_defect_bound'])<Q(a['extra_KL_coarse_budget'])==Q(1,10**35)
 assert raw==Q(a['global_a2_upper_exact'])
 assert Q(b['global_a2_upper_exact'])==C+budget
 for receipt,raw_key,prior_key,final_key in [(a,'global_a2_upper_exact','prior_upper','bootstrap_upper'),(b,'global_a2_upper_exact','prior_a2_upper','bootstrap_a2_upper_exact')]:
  U=Q(receipt[prior_key]);mu=Q(receipt['sharp222_multiplier_sum']);slope=Q(1,238) if n==35 else Q(1,200);den=10**30
  assert 1<=len(receipt['bootstrap_history'])<=20
  for value in receipt['bootstrap_history']:
   rad=Q(128)*U/(35*N**3);root=Q(math.isqrt(rad.numerator*den*den//rad.denominator)+1,den)
   assert root*root>rad
   target=Q(receipt[raw_key])/(1+mu*max(Q(0),slope-root))
   ceiling=Q(-((-target.numerator*den)//target.denominator),den)
   U=min(U,ceiling);assert U==Q(value)
  assert U==Q(receipt[final_key])<simple
 assert Q(a['bootstrap_upper'])==Q(b['bootstrap_a2_upper_exact'])
 for name,content in w['cubic_operators'].items():assert (R/'operators'/name).read_bytes()==content.encode('utf-8')
 operator_receipt=json.loads((R/'dependencies/cubic_operator_files_independent.json').read_text())
 for rec in operator_receipt['results']:
  if rec['n']!=n:continue
  name=f'n{n}_rational_cubic_cut.json' if rec['family']=='211' else f'quadrupole_cubic_cut_n{n}.json'
  assert sha(R/'operators'/name)==rec['sha256']
  assert Q(rec['expectation_error_bound'])==8*N*Q(rec['certified_entry_error'])<Q(rec['declared_additive'])
scalar=json.loads((R/'dependencies/a2_bound_independent.json').read_text())
assert sha(R/'dependencies/a2_interval_duals.json')==scalar['source_sha256']
print('PASS: manifest, Python syntax, exact receipt identities/bootstrap, witness and operator bindings.')
print('This is packaging/receipt QA, not full-space arithmetic or external peer review.')
